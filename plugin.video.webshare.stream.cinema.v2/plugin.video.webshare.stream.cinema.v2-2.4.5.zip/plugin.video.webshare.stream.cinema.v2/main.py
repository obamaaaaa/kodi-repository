import sys
import json
import time
import urllib.parse
import urllib.request
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor, as_completed

import resources.lib.db as db
import resources.lib.webshare as webshare
import resources.lib.player as player
import resources.lib.tmdb as tmdb
import resources.lib.whitelist as whitelist
from resources.lib.helper import ICONS
from resources.lib import tv_navigation
from resources.lib.title_cleaner import clean_title_for_kodi, calculate_match_score
import resources.lib.buffer_manager as buffer_manager
import xml.etree.ElementTree as ET

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

def get_search_files_limit():
    """Vrátí nastavený limit počtu načítaných souborů z vyhledávání Webshare/HellSpy/Přehraj.to."""
    try:
        val = ADDON.getSetting('search_files_limit')
        if val:
            return max(5, min(100, int(float(val))))
    except Exception:
        pass
    return 20

def format_season_count(count):
    """Vrátí správně skloňovaný počet sérií v češtině (1 série, 2-4 série, 5+ sérií)."""
    try:
        n = int(count)
    except (ValueError, TypeError):
        return f"{count} sérií" if count else "? sérií"

    if n == 1:
        return "1 série"
    elif 2 <= n <= 4:
        return f"{n} série"
    else:
        return f"{n} sérií"

limit_to_search = 20
limit_to_search_quick = 5

def get_ws_token():
    """Vrátí uložený token z paměti Kodi, nebo provede nový login"""
    window = xbmcgui.Window(10000)  # Hlavní okno Kodi (drží paměť po dobu běhu Kodi)
    token = window.getProperty('ws_token')
    
    if not token:
        ws_user = ADDON.getSetting('username')
        ws_pass = ADDON.getSetting('password')
        token = webshare.login(ws_user, ws_pass)
        if token:
            window.setProperty('ws_token', token)
            
    return token

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def check_first_run_and_status():
    first_run = ADDON.getSetting('first_run_done')

    if first_run != 'true':
        ADDON.setSetting('first_run_done', 'true')
        whitelist.get_hw_code()
        dialog_ok("Vítejte v doplňku Webshare", "Doplněk byl úspěšně nainstalován. Prosím, nastavte své přihlašovací údaje a TMDB API klíč v nastavení doplňku.")
        ADDON.openSettings()
        return

    # Kontrola Webshare
    ws_user = ADDON.getSetting('username')
    ws_pass = ADDON.getSetting('password')
    ws_token = webshare.login(ws_user, ws_pass)
    ws_status = "OK" if ws_token else "CHYBA (Neplatné údaje nebo síť)"

    # Kontrola TMDB
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    tmdb_status = "CHYBA (Chybí klíč)"
    if tmdb_key:
        try:
            url = f"https://api.themoviedb.org/3/authentication?api_key={tmdb_key}"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                if data.get('success', False):
                    tmdb_status = "OK"
                else:
                    tmdb_status = "CHYBA (Neplatný API klíč)"
        except Exception:
            tmdb_status = "CHYBA (Připojení k TMDB)"

    if ws_status != "OK" or tmdb_status != "OK":
        dialog_ok("Stav připojení doplňku", f"Webshare: {ws_status}\nTMDB API: {tmdb_status}")
    else:
        dialog_notif("Stav připojení", f"Webshare: {ws_status} | TMDB: {tmdb_status}", xbmcgui.NOTIFICATION_INFO)

def log_debug(msg):
    s = str(msg).strip()
    if not s.startswith('['):
        s = f"[Webshare] {s}"
    xbmc.log(s, xbmc.LOGINFO)

def log_error(msg):
    s = str(msg).strip()
    if not s.startswith('['):
        s = f"[Webshare CHYBA] {s}"
    xbmc.log(s, xbmc.LOGERROR)

def log_timing(msg):
    s = str(msg).strip()
    if not s.startswith('['):
        s = f"[Webshare ČASOVÁNÍ] {s}"
    xbmc.log(s, xbmc.LOGINFO)

def dialog_ok(title, message):
    xbmcgui.Dialog().ok(title, message);

def dialog_notif(title, message, notif_type=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(title, message, notif_type, 5000);


def show_loading_dialog(title, message="Načítám..."):
    """Zobrazí loading dialog s textem o probíhající operaci."""
    dialog = xbmcgui.DialogProgress()
    dialog.create(title, message)
    return dialog


def close_loading_dialog(dialog):
    """Zavře loading dialog, pokud existuje."""
    if dialog:
        try:
            dialog.close()
        except Exception:
            pass


def update_loading_dialog(dialog, percent, message):
    """Aktualizuje progress dialog a jeho text. Vrátí True, pokud byl dialog zrušen."""
    if dialog:
        try:
            if dialog.iscanceled():
                return True
            dialog.update(percent, message)
            return dialog.iscanceled()
        except Exception:
            pass
    return False


def is_loading_cancelled(dialog):
    """Ověří, zda uživatel stiskl Zrušit na dialogu."""
    if dialog:
        try:
            return bool(dialog.iscanceled())
        except Exception:
            pass
    return False





def get_progress_label_suffix(tmdb_id, media_type, total_episodes=0):
    """Vrátí řetězec s procenty rozkoukání pro film nebo seriál."""
    if not tmdb_id:
        return ""
    
    if media_type == "tv":
        pct = db.get_tv_show_progress(tmdb_id, total_episodes)
        if pct >= 100:
            return " [COLOR lime](Zhlédnuto)[/COLOR]"
        elif pct > 0:
            return f" [COLOR orange]({pct}%)[/COLOR]"
    else:
        st = db.get_item_watch_status(tmdb_id, 0, 0)
        if st:
            if st.get('watched'):
                return " [COLOR lime](Zhlédnuto)[/COLOR]"
            elif st.get('total_time', 0) > 0 and st.get('resume_time', 0) > 15:
                pct = int((st['resume_time'] / st['total_time']) * 100)
                return f" [COLOR orange]({pct}%)[/COLOR]"
    return ""


def build_media_item_label(item, media_type, ws_token, prefix=""):
    """
    Sestaví popisek a jazykový řetězec pro film nebo seriál s ověřením dostupnosti na Webshare.
    Zajistí jednotné formátování jak v kategoriích (populární atd.), tak ve vyhledávání.
    """
    total_episodes = item.get('number_of_episodes', 0)
    progress_suffix = get_progress_label_suffix(item.get('id'), media_type, total_episodes)

    if media_type == 'tv':
        show_p = db.get_tv_show_progress(item.get('id'), total_episodes)
        is_watched = (show_p >= 100)
    else:
        st = db.get_item_watch_status(item.get('id'), 0, 0)
        is_watched = bool(st and st.get('watched'))

    pref_str = f"{prefix} " if prefix else ""
    raw_title = item.get('title', '')
    title_text = clean_title_for_kodi(
        raw_title,
        english_title=item.get('english_title', ''),
        original_title=item.get('original_title', ''),
        year=item.get('year', ''),
        media_type=media_type
    )
    disp_title = f"[COLOR gray]{title_text}[/COLOR]" if is_watched else title_text
    item_year = item.get('year', '')

    if media_type == "tv":
        series_check = webshare.check_tv_series(item, token=ws_token, limit=get_search_files_limit())
        season_count = item.get('number_of_seasons') or 0
        season_text = format_season_count(season_count) if season_count else "? sérií"
        series_lang = series_check.get('lang', '??')
        if series_check.get('available'):
            label = f"{pref_str}{disp_title}{progress_suffix} [COLOR grey]({item_year})[/COLOR] • [COLOR lime]{season_text}[/COLOR] • [COLOR lime]{series_lang}[/COLOR]"
            lang_str = f"[COLOR lime]{series_lang}[/COLOR]"
        else:
            label = f"[COLOR gray]{pref_str}{title_text}{progress_suffix} ({item_year}) • {season_text} • S01E01 nenalezen[/COLOR]"
            lang_str = "[COLOR gray]S01E01 nenalezen[/COLOR]"
    else:
        available_files = webshare.search_and_verify_movie_quick(item, token=ws_token, media_type=media_type, limit=limit_to_search_quick).get("files", [])
        valid_files = [f for f in available_files if f.get('valid', True)]

        # Rychlá kontrola dostupnosti filmu pro menu
        if not valid_files and ADDON.getSetting('source_hellspy') == 'true':
            try:
                from resources.lib import hellspy
                hs_files = hellspy.search_hellspy(item, media_type='movie', limit=3)
                valid_hs = [f for f in hs_files if f.get('valid', True)]
                if valid_hs:
                    valid_files = valid_hs
            except Exception as e:
                pass

        if not valid_files:
            label = f"[COLOR grey]NEDOSTUPNÉ: {pref_str}{title_text}{progress_suffix} ({item_year})[/COLOR]"
            lang_str = "[COLOR gray]NENALEZENO[/COLOR]"
        else:
            langs_set = set()
            for f in valid_files:
                raw_lang = str(f.get('lang', '')).upper().strip()
                if raw_lang and raw_lang != '??':
                    parts = [p.strip() for p in raw_lang.split('/') if p.strip()]
                    for p in parts:
                        if p != '??':
                            langs_set.add(p)

            def lang_sort_key(l):
                if l == 'CZ': return 0
                elif 'TIT' in l or 'SUB' in l: return 1
                elif 'SK' in l: return 2
                elif 'EN' in l: return 3
                return 4

            sorted_langs = sorted(list(langs_set), key=lang_sort_key)
            colored_langs = []
            for l in sorted_langs:
                if 'CZ' == l: colored_langs.append(f"[COLOR lime][{l}][/COLOR]")
                elif 'CZ TIT' == l or 'SK' in l: colored_langs.append(f"[COLOR yellow][{l}][/COLOR]")
                elif 'EN' in l: colored_langs.append(f"[COLOR blue][{l}][/COLOR]")
                else: colored_langs.append(f"[COLOR gray][{l}][/COLOR]")

            joined_langs = " ".join(colored_langs)
            lang_str = f" {joined_langs}" if colored_langs else ""
            label = f"{pref_str}{disp_title}{progress_suffix} [COLOR grey]({item_year})[/COLOR]  •  {lang_str}"

    return label, lang_str, is_watched


def verify_media_items_batch(items, default_media_type, ws_token, prefix="", loading=None, title_msg=""):
    """
    Ověří položky buď paralelně (podle nastavení 'exp_parallel_search'),
    nebo sekvenčně (spolehlivý fallback).
    Vrací: (verified_items, ws_wall_time, slowest_item)
    kde verified_items je seznam [(item, label, lang_str, is_w), ...] v původním pořadí.
    """
    total = len(items)
    if total == 0:
        return [], 0.0, ("", 0.0)

    exp_parallel = ADDON.getSetting('exp_parallel_search')
    is_parallel = (exp_parallel != "false")

    thread_count = 16

    def _verify_single(idx, item):
        t0 = time.time()
        mtype = item.get('media_type') or default_media_type
        pfx = ('[F]' if mtype == 'movie' else '[S]') if prefix == 'auto' else prefix
        lbl, l_str, is_w = build_media_item_label(item, mtype, ws_token, prefix=pfx)
        dur = time.time() - t0
        return idx, item, lbl, l_str, is_w, dur

    results = [None] * total
    slowest_item = ["", 0.0]
    t_start = time.time()

    if is_parallel and total > 1:
        try:
            with ThreadPoolExecutor(max_workers=min(thread_count, total)) as executor:
                future_map = {executor.submit(_verify_single, i, itm): i for i, itm in enumerate(items)}
                completed = 0
                for future in as_completed(future_map):
                    if loading and is_loading_cancelled(loading):
                        break
                    try:
                        idx, itm, lbl, l_str, is_w, dur = future.result()
                        results[idx] = (itm, lbl, l_str, is_w)
                        if dur > slowest_item[1]:
                            slowest_item[0] = itm.get('title', '')
                            slowest_item[1] = dur
                    except Exception as e:
                        log_error(f"Chyba při paralelním ověřování položky: {e}")

                    completed += 1
                    if loading:
                        pct = 10 + int((completed / total) * 85)
                        orig_idx = future_map[future]
                        cur_title = items[orig_idx].get('title', '')
                        update_loading_dialog(loading, pct, f"{title_msg}\n({completed}/{total}) Hotovo: {cur_title}")
        except Exception as e:
            log_error(f"Selhání paralelního zpracování, přepínám na sekvenční: {e}")
            results = [None] * total

    # Sekvenční zpracování (pokud je paralelní vypnuté, nebo pro položky, které nebyly dokončeny)
    for idx, item in enumerate(items):
        if results[idx] is not None:
            continue
        if loading and is_loading_cancelled(loading):
            break
        if loading:
            pct = 10 + int(((idx + 1) / total) * 85)
            item_title = item.get('title', '')
            update_loading_dialog(loading, pct, f"{title_msg}\n({idx + 1}/{total}) Zpracovávám: {item_title}")
        idx, item, lbl, l_str, is_w, dur = _verify_single(idx, item)
        results[idx] = (item, lbl, l_str, is_w)
        if dur > slowest_item[1]:
            slowest_item[0] = item.get('title', '')
            slowest_item[1] = dur

    verified = [r for r in results if r is not None]
    ws_wall_time = time.time() - t_start
    return verified, ws_wall_time, (slowest_item[0], slowest_item[1])


def tmdb_list_menu(media_type, category, genre_id=None, page=1, similar_id=None, item_title="", year=None, genre_name=None):
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        log_error("Není zadán TMDB API klíč v nastavení doplňku.")
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, "movies" if media_type == "movie" else "tvshows")

    try:
        page = int(page)
    except (TypeError, ValueError):
        page = 1
    if page < 1:
        page = 1

    try:
        items_per_page = int(float(ADDON.getSetting('items_per_page') or 30))
    except Exception:
        items_per_page = 30

    cat_cz = {
        'popular': 'populární',
        'trending': 'trendy',
        'top_rated': 'nejlépe hodnocené',
        'new': 'novinky',
        'genre': 'kategorii',
        'year': 'rok',
        'similar': 'podobné tituly'
    }.get(category, category)

    type_cz = "filmy" if media_type == "movie" else "seriály"
    if category == "similar" and item_title:
        loading_text = f"Hledám tituly podobné: {item_title}..."
    elif category == "year" and year:
        loading_text = f"Načítám {type_cz} z roku {year}..."
    elif category == "genre" and genre_name:
        loading_text = f"Načítám {type_cz} v kategorii {genre_name}..."
    elif category in ("trending", "top_rated"):
        loading_text = f"Načítám {cat_cz} {type_cz} z TMDB..."
    else:
        loading_text = f"Načítám seznam {type_cz} z TMDB..."

    loading = show_loading_dialog("Načítám", loading_text)
    t_tmdb_start = time.time()
    try:
        items = tmdb.fetch_tmdb_items(
            media_type,
            category,
            tmdb_key,
            genre_id=genre_id,
            page=page,
            similar_id=similar_id,
            year=year,
            count=items_per_page
        )
    finally:
        update_loading_dialog(loading, 10, f"Hledám na Webshare.cz...")
    t_tmdb = time.time() - t_tmdb_start

    if is_loading_cancelled(loading):
        close_loading_dialog(loading)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not items:
        close_loading_dialog(loading)
        if category == "similar":
            dialog_notif("Podobné tituly", "Nebyly nalezeny žádné podobné tituly", xbmcgui.NOTIFICATION_INFO)
        li = xbmcgui.ListItem(label="Nic nenalezeno")
        li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ws_token = get_ws_token()

    if page > 1:
        prev_li = xbmcgui.ListItem(label=f"Zpět ({page - 1})")
        prev_li.setArt({'icon': ICONS.get('BOOK', ''), 'thumb': ICONS.get('BOOK', '')})
        prev_params = {
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": category,
            "page": page - 1
        }
        if genre_id:
            prev_params["genre_id"] = genre_id
        if similar_id:
            prev_params["similar_id"] = similar_id
        if item_title:
            prev_params["title"] = item_title
        if year:
            prev_params["year"] = year
        prev_url = build_url(prev_params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=prev_url, listitem=prev_li, isFolder=True)
        
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    total = len(items)
    try:
        title_msg = f"Ověřuji dostupnost na Webshare... (str. {page})"
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            items, media_type, ws_token, prefix="", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        skipped_items = []
        for item, label, lang_str, is_w in verified_items:
            # V seznamech filmů a seriálů vynecháme nedostupné tituly
            if "NENALEZENO" in lang_str or "nenalezen" in lang_str.lower() or "NEDOSTUPNÉ:" in label:
                skipped_items.append(item)
                continue

            li = xbmcgui.ListItem(label=label, label2=lang_str)
            li.setProperty('item_languages', lang_str)
            
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            info_tag.setPlot(item['overview'])
            info_tag.setPlotOutline(item['tagline'])
            info_tag.setRating(float(item['rating']))
            info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')
            info_tag.setIMDBNumber(item.get('imdb_id', ''))

            if item['year'].isdigit():
                info_tag.setYear(int(item['year']))
            if item['release_date']:
                info_tag.setPremiered(item['release_date'])
            if item['runtime'] > 0:
                info_tag.setDuration(item['runtime'] * 60)
            if item['genres']:
                info_tag.setGenres(item['genres'])
            if item['directors']:
                info_tag.setDirectors(item['directors'])
            if item['cast']:
                actors = [xbmc.Actor(name=a['name'], role=a['role'], thumbnail=a['thumbnail']) for a in item['cast']]
                info_tag.setCast(actors)
            
            art = {}
            if item['poster']:
                art['poster'] = item['poster']
                art['thumb'] = item['poster']
                art['icon'] = item['poster']
            if item['fanart']:
                art['fanart'] = item['fanart']
            li.setArt(art)

            if media_type == 'tv':
                show_p = db.get_tv_show_progress(item['id'], item.get('number_of_episodes', 0))
                is_w = (show_p >= 100)
                is_r = (0 < show_p < 100)
                li.addContextMenuItems(make_tv_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
            else:
                st = db.get_item_watch_status(item['id'], 0, 0)
                is_w = bool(st and st.get('watched'))
                is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
                li.addContextMenuItems(make_movie_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
                elif is_r:
                    info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "original_title": item.get('original_title') or item['title'],
                "year": item['year'],
                "media_type": media_type,
                "tmdb_id": item['id'],
                "poster": item.get('poster', ''),
                "fanart": item.get('fanart', ''),
                "overview": item.get('overview', '')
            })
            
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1

        if skipped_items:
            for s_itm in skipped_items:
                s_title = s_itm.get('title') or s_itm.get('name', 'Neznámý')
                s_year = str(s_itm.get('year', '')).strip()
                s_year_tag = f" ({s_year})" if s_year else ""
                m_type_str = "Seriál" if media_type == 'tv' else "Film"
                log_debug(f"[Vynecháno] {m_type_str} '{s_title}'{s_year_tag}: Žádný stream nenalezen na aktivních zdrojích, vynecháno ze seznamu.")
            log_debug(f"[Seznam] Zobrazeno {added_count} z {len(verified_items)} titulů ({len(skipped_items)} vynecháno kvůli nedostupnosti streamů)")
    finally:
        close_loading_dialog(loading)

    if cancelled and added_count == 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not cancelled and total >= 10:
        next_li = xbmcgui.ListItem(label=f"Další ({page + 1})")
        next_li.setArt({'icon': ICONS.get('NEXT', ICONS.get('BOOK', '')), 'thumb': ICONS.get('NEXT', ICONS.get('BOOK', ''))})
        next_params = {
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": category,
            "page": page + 1
        }
        if genre_id:
            next_params["genre_id"] = genre_id
        if genre_name:
            next_params["genre_name"] = genre_name
        if similar_id:
            next_params["similar_id"] = similar_id
        if item_title:
            next_params["title"] = item_title
        if year:
            next_params["year"] = year
        next_url = build_url(next_params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    t_total = time.time() - t_start
    t_kodi = max(0.0, t_total - t_tmdb - t_ws_total)
    avg_ws = (t_ws_total / total) if total > 0 else 0
    slow_str = f" | Nejpomalejší ověření: '{slowest_item[0]}' ({slowest_item[1]:.2f}s)" if (total > 0 and slowest_item[1] >= 0.5) else ""
    log_timing(
        f"Načtení {media_type} ('{category}', str. {page}, {total} ks): "
        f"TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s (průměr {avg_ws:.2f}s/ks){slow_str} | "
        f"Kodi GUI={t_kodi:.2f}s | CELKEM={t_total:.2f}s"
    )
    
def main_menu():
    check_first_run_and_status()
    buffer_manager.update_addon_buffer_setting(ADDON)
    
    exp_adv = (ADDON.getSetting('exp_advanced_search') == 'true')
    items = [
        ("[B]Hledat[/B]", ICONS['SEARCH'], {"mode": "search"}),
    ]
    if exp_adv:
        items.append(("[B]Pokročilé hledání[/B]", ICONS['SEARCH_PLUS'], {"mode": "advanced_search_menu"}))
    items.extend([
        ("Filmy", ICONS['FILM'], {"mode": "movies_menu"}),
        ("Seriály", ICONS['THEATRE'], {"mode": "tv_menu"}),
        ("Historie", ICONS['HISTORY'], {"mode": "history"}),
        ("Nastavení", ICONS['SETTINGS'], {"mode": "open_settings"}),
    ])


    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        is_folder = params["mode"] not in ["open_settings"]
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)
    check_buffer_recommendation()

def sub_menu(media_type):
    """Podnabídka pro Filmy nebo Seriály"""
    type_label = "filmy" if media_type == "movie" else "seriály"
    
    items = [
        ("Nově nadabované", ICONS['MICROPHONE'], {"mode": "fresh_releases", "media_type": media_type, "release_type": "dubbed"}),
        ("Nově s titulkama", ICONS['SUBTITLES'], {"mode": "fresh_releases", "media_type": media_type, "release_type": "subtitled"}),
        ("Trendy tento týden", ICONS['TRENDING'], {"mode": "tmdb_list", "media_type": media_type, "category": "trending"}),
        (f"Populární {type_label}", ICONS['POPULAR'], {"mode": "tmdb_list", "media_type": media_type, "category": "popular"}),
        ("Novinky na TMDB", ICONS['NEWS'], {"mode": "tmdb_list", "media_type": media_type, "category": "new"}),
        ("Nejlépe hodnocené", ICONS['STAR'], {"mode": "tmdb_list", "media_type": media_type, "category": "top_rated"}),
        ("Podle roku", ICONS['CALENDAR'], {"mode": "years_menu", "media_type": media_type}),
        ("Podle žánru", ICONS['GENRES'], {"mode": "genres_menu", "media_type": media_type})
    ]

    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    check_buffer_recommendation()

def format_episode_range(episodes):
    """
    Sestaví kompaktní řetězec epizod pro seriál (např. S01E01 - S01E12, S01E05, S01E01 - S02E10 (15 dílů)).
    """
    if not episodes:
        return ""
    valid_eps = [(s, e) for s, e in episodes if s > 0 or e > 0]
    if not valid_eps:
        return ""
    unique_eps = sorted(list(set(valid_eps)))
    if len(unique_eps) == 1:
        s, e = unique_eps[0]
        return f"S{s:02d}E{e:02d}"

    seasons = sorted(list(set(s for s, _ in unique_eps)))
    if len(seasons) == 1:
        s = seasons[0]
        ep_nums = [e for _, e in unique_eps]
        min_e = min(ep_nums)
        max_e = max(ep_nums)
        count = len(ep_nums)
        if count == (max_e - min_e + 1):
            return f"S{s:02d}E{min_e:02d} - S{s:02d}E{max_e:02d}"
        else:
            return f"S{s:02d}E{min_e:02d} - S{s:02d}E{max_e:02d} ({count} dílů)"
    else:
        min_s = min(seasons)
        max_s = max(seasons)
        first_ep = unique_eps[0]
        last_ep = unique_eps[-1]
        count = len(unique_eps)
        return f"S{min_s:02d}E{first_ep[1]:02d} - S{max_s:02d}E{last_ep[1]:02d} ({count} dílů)"

def show_fresh_releases_menu(media_type="movie", release_type="dubbed", page=1):
    """
    Zobrazí seznam nově nahraných dabovaných nebo otitulkovaných filmů / seriálů ze Supabase.
    Běží bleskově (do 0.2s), protože data jsou předem spárovaná s TMDB v Supabase tabulce fresh_releases.
    U seriálů automaticky sloučí více epizod téhož seriálu do jednoho tlačítka s rozsahem dílů.
    """
    xbmcplugin.setContent(HANDLE, "movies" if media_type == "movie" else "tvshows")
    
    try:
        page = int(page)
    except (TypeError, ValueError):
        page = 1
    if page < 1:
        page = 1

    limit = 30 if media_type == "movie" else 100
    offset = (page - 1) * limit

    from resources.lib.stream_cache import SUPABASE_URL, ANON_KEY

    cat_title = "Nově nadabované" if release_type == "dubbed" else "Nově s titulkama"
    type_label = "filmy" if media_type == "movie" else "seriály"

    query_params = {
        "media_type": f"eq.{media_type}",
        "release_type": f"eq.{release_type}",
        "order": "released_at.desc",
        "limit": str(limit),
        "offset": str(offset)
    }
    url = f"{SUPABASE_URL}/fresh_releases?" + urllib.parse.urlencode(query_params)
    headers = {
        "apikey": ANON_KEY,
        "Authorization": f"Bearer {ANON_KEY}"
    }

    items = []
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=5) as resp:
            items = json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        log_error(f"Chyba při načítání fresh_releases ze Supabase: {e}")

    raw_items_count = len(items)

    # U seriálů sloučíme více epizod téhož seriálu do jednoho tlačítka (např. S01E01 - S01E12)
    if media_type == "tv" and items:
        grouped_items = []
        show_map = {}

        for it in items:
            key = it.get('tmdb_id') or (it.get('title') or '').strip().lower()
            s = int(it.get('season') or 0)
            e = int(it.get('episode') or 0)

            if key not in show_map:
                show_map[key] = len(grouped_items)
                show_obj = dict(it)
                show_obj['episodes_list'] = [(s, e)] if (s > 0 or e > 0) else []
                grouped_items.append(show_obj)
            else:
                idx = show_map[key]
                if s > 0 or e > 0:
                    grouped_items[idx]['episodes_list'].append((s, e))
                if (it.get('released_at') or '') > (grouped_items[idx].get('released_at') or ''):
                    grouped_items[idx]['released_at'] = it.get('released_at')

        items = grouped_items

    if page > 1:
        prev_li = xbmcgui.ListItem(label=f"Zpět ({page - 1})")
        prev_li.setArt({'icon': ICONS.get('BOOK', ''), 'thumb': ICONS.get('BOOK', '')})
        prev_url = build_url({
            "mode": "fresh_releases",
            "media_type": media_type,
            "release_type": release_type,
            "page": page - 1
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=prev_url, listitem=prev_li, isFolder=True)

    if not items and page == 1:
        empty_li = xbmcgui.ListItem(label=f"[COLOR gray]Zatím žádné {cat_title.lower()} {type_label}[/COLOR]")
        empty_li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=empty_li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    tmdb_key = ADDON.getSetting('tmdb_api_key')

    for it in items:
        tmdb_id = it.get('tmdb_id')
        title = it.get('title') or "Neznámý název"
        orig_title = it.get('original_title') or title
        year_val = str(it.get('year') or '')
        season = int(it.get('season') or 0)
        episode = int(it.get('episode') or 0)
        quality = it.get('quality') or ''
        poster_p = it.get('poster_path') or ''
        backdrop_p = it.get('backdrop_path') or ''

        # Načteme kompletní detaily z TMDB (z lokální SQLite cache, případně API)
        details = {}
        if tmdb_id and tmdb_key:
            details = tmdb.get_item_details(media_type, tmdb_id, tmdb_key) or {}

        overview = details.get('overview') or ''
        tagline = details.get('tagline') or ''
        rating = float(details.get('vote_average') or details.get('rating') or 0.0)
        
        # Ošetření žánrů - Kodi striktně vyžaduje List[str], z TMDB často přichází List[dict]
        genres = []
        for g in (details.get('genres') or []):
            if isinstance(g, dict) and g.get('name'):
                genres.append(str(g['name']))
            elif isinstance(g, str) and g.strip():
                genres.append(g.strip())

        credits = details.get('credits', {}) if isinstance(details.get('credits'), dict) else {}
        directors = [str(c['name']) for c in credits.get('crew', []) if isinstance(c, dict) and c.get('job') == 'Director' and c.get('name')]
        
        cast_actors = []
        for a in credits.get('cast', [])[:10]:
            if isinstance(a, dict) and a.get('name'):
                p_path = a.get('profile_path')
                thumb = ("https://image.tmdb.org/t/p/w185" + p_path) if p_path else ""
                cast_actors.append(xbmc.Actor(name=str(a['name']), role=str(a.get('character', '')), thumbnail=thumb))

        runtime = int(details.get('runtime') or (details.get('episode_run_time', [0])[0] if details.get('episode_run_time') else 0) or 0)
        premiered = details.get('release_date') or details.get('first_air_date') or ''
        if not year_val and details.get('year'):
            year_val = str(details.get('year'))

        # Datum přidání na začátek
        date_badge = ""
        raw_date = it.get('released_at') or it.get('created_at') or ''
        if raw_date:
            try:
                d_part = raw_date.split('T')[0]
                parts = d_part.split('-')
                if len(parts) == 3:
                    d_num = int(parts[2])
                    m_num = int(parts[1])
                    date_badge = f"[COLOR gray][{d_num}.{m_num}.][/COLOR] "
            except Exception:
                pass

        # Jazykový tag ve stylu ostatních menu ([CZ], [CZ TIT], [SK]...)
        det_l = str(it.get('detected_language') or '').upper()
        if release_type == "dubbed":
            if "SK" in det_l:
                lang_badge = "[COLOR yellow][SK][/COLOR]"
                lang_str = "SK"
            else:
                lang_badge = "[COLOR lime][CZ][/COLOR]"
                lang_str = "CZ"
        else:
            if "SK" in det_l:
                lang_badge = "[COLOR yellow][SK TIT][/COLOR]"
                lang_str = "SK TIT"
            else:
                lang_badge = "[COLOR yellow][CZ TIT][/COLOR]"
                lang_str = "CZ TIT"

        # Stav zhlédnutí pro zešednutí zhlédnutých položek
        if media_type == 'tv':
            show_p = db.get_tv_show_progress(tmdb_id, details.get('number_of_episodes', 0))
            is_w = (show_p >= 100)
            is_r = (0 < show_p < 100)
        else:
            st = db.get_item_watch_status(tmdb_id, 0, 0)
            is_w = bool(st and st.get('watched'))
            is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)

        disp_title = f"[COLOR gray]{title}[/COLOR]" if is_w else title
        year_str = f" [COLOR grey]({year_val})[/COLOR]" if year_val else ""

        if media_type == "tv":
            ep_range_str = format_episode_range(it.get('episodes_list', []))
            if ep_range_str:
                label = f"{date_badge}{disp_title} - {ep_range_str}{year_str}  •  {lang_badge}"
            elif season > 0 and episode > 0:
                label = f"{date_badge}{disp_title} - S{season:02d}E{episode:02d}{year_str}  •  {lang_badge}"
            else:
                label = f"{date_badge}{disp_title}{year_str}  •  {lang_badge}"
        else:
            label = f"{date_badge}{disp_title}{year_str}  •  {lang_badge}"

        li = xbmcgui.ListItem(label=label, label2=lang_str)
        li.setProperty('item_languages', lang_str)

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setOriginalTitle(orig_title)
        info_tag.setPlot(overview)
        info_tag.setPlotOutline(tagline)
        info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')
        if rating > 0:
            info_tag.setRating(rating)
        if genres:
            info_tag.setGenres(genres)
        if directors:
            info_tag.setDirectors(directors)
        if cast_actors:
            info_tag.setCast(cast_actors)
        if runtime > 0:
            info_tag.setDuration(runtime * 60)
        if premiered:
            info_tag.setPremiered(premiered)
        if year_val.isdigit():
            info_tag.setYear(int(year_val))

        poster_url = f"https://image.tmdb.org/t/p/w500{poster_p}" if poster_p else (details.get('poster') or '')
        fanart_url = f"https://image.tmdb.org/t/p/original{backdrop_p}" if backdrop_p else (details.get('fanart') or '')
        art = {}
        if poster_url:
            art['poster'] = poster_url
            art['thumb'] = poster_url
            art['icon'] = poster_url
        if fanart_url:
            art['fanart'] = fanart_url
        li.setArt(art)

        if media_type == 'tv':
            li.addContextMenuItems(make_tv_context_menu(tmdb_id, title, is_watched=is_w, is_resume=is_r))
            if is_w:
                info_tag.setPlaycount(1)
            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": orig_title,
                "year": year_val,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
                "poster": poster_url,
                "fanart": fanart_url,
                "overview": overview
            })
        else:
            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=is_w, is_resume=is_r))
            if is_w:
                info_tag.setPlaycount(1)
            elif is_r:
                info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))
            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": orig_title,
                "year": year_val,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
                "poster": poster_url,
                "fanart": fanart_url,
                "overview": overview
            })

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    if raw_items_count >= limit:
        next_li = xbmcgui.ListItem(label=f"Další ({page + 1})")
        next_li.setArt({'icon': ICONS.get('NEXT', ICONS.get('BOOK', '')), 'thumb': ICONS.get('NEXT', ICONS.get('BOOK', ''))})
        next_url = build_url({
            "mode": "fresh_releases",
            "media_type": media_type,
            "release_type": release_type,
            "page": page + 1
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def years_menu(media_type):
    """Seznam roků pro vyhledávání filmů/seriálů od roku 2026 dolů."""
    type_label = "Filmy" if media_type == "movie" else "Seriály"
    
    current_year = 2026
    min_year = 1940
    
    for y in range(current_year, min_year - 1, -1):
        li = xbmcgui.ListItem(label=f"{type_label} z roku {y}", label2=str(y))
        li.setArt({
            'icon': ICONS.get('CALENDAR', ''),
            'thumb': ICONS.get('CALENDAR', '')
        })
        url = build_url({
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": "year",
            "year": str(y)
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu(media_type):
    """Seznam žánrů/kategorií z TMDB"""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    url = f"https://api.themoviedb.org/3/genre/{media_type}/list?api_key={tmdb_key}&language=cs-CZ"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as response:
            data = json.loads(response.read().decode('utf-8'))
            genres = data.get("genres", [])

            import unicodedata
            processed = []
            for genre in genres:
                gid = genre.get("id")
                raw_name = genre.get("name", "")
                clean_name = tmdb.translate_genre(genre_id=gid, name=raw_name)
                processed.append({"id": gid, "name": clean_name})

            # Řazení žánrů podle české abecedy
            processed.sort(key=lambda g: unicodedata.normalize('NFKD', g['name']).encode('ascii', 'ignore').decode().lower())

            for genre in processed:
                li = xbmcgui.ListItem(label=genre["name"])
                li.setArt({
                    'icon': ICONS['GENRES'],
                    'thumb': ICONS['GENRES']
                })
                item_url = build_url({
                    "mode": "tmdb_list",
                    "media_type": media_type,
                    "category": "genre",
                    "genre_id": genre["id"],
                    "genre_name": genre["name"]
                })
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_url, listitem=li, isFolder=True)

    except Exception as e:
        dialog_notif("Chyba", f"Nelze načíst žánry: {e}", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(HANDLE)

def search_tmdb_menu(query):
    """Vyhledá položky v TMDB a zobrazí je s prefixem [F]/[S]."""
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        log_error("Není zadán TMDB API klíč v nastavení doplňku.")
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, "movies")

    loading = show_loading_dialog("Vyhledávám", f"Vyhledávám (TMDB): {query}")
    t_tmdb_start = time.time()
    try:
        items = tmdb.search_tmdb_items(
            query,
            tmdb_key
        )
    finally:
        close_loading_dialog(loading)
    t_tmdb = time.time() - t_tmdb_start

    if is_loading_cancelled(loading):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
        
    if not items:
        li = xbmcgui.ListItem(label="Nic nenalezeno")
        li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        log_timing(f"Hledání '{query}': 0 položek | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
        return

    ws_token = get_ws_token()
    total = len(items)
    loading = show_loading_dialog("Vytvářím", "Ověřuji dostupnost a jazyky na Webshare.cz...")
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    try:
        title_msg = f"Ověřuji dostupnost '{query}' na Webshare..."
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            items, 'movie', ws_token, prefix="auto", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        # Řazení vyhledaných výsledků:
        # 1. Nalezené / dostupné na Webshare mají absolutní přednost před nedostupnými
        # 2. Skóre shody s vyhledávaným dotazem (přesný název > začíná na dotaz > obsažená slova > preference typu média s/f)
        # 3. Hodnocení / rating TMDB
        def search_rank_key(res_tuple):
            itm, lbl, l_str, is_w = res_tuple
            is_avail = not ("NENALEZENO" in l_str or "nenalezen" in l_str.lower() or "NEDOSTUPNÉ:" in lbl)
            avail_score = 1 if is_avail else 0
            match_score = calculate_match_score(query, itm)
            rating = float(itm.get('rating') or 0.0)
            year_val = int(itm.get('year')) if str(itm.get('year', '')).isdigit() else 0
            return (-avail_score, -match_score, -rating, -year_val)

        sorted_verified_items = sorted(verified_items, key=search_rank_key)

        for item, label, lang_str, is_w in sorted_verified_items:
            media_type = item.get('media_type', 'movie')

            li = xbmcgui.ListItem(label=label, label2=lang_str)
            li.setProperty('item_languages', lang_str)

            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            info_tag.setPlot(item['overview'])
            info_tag.setPlotOutline(item['tagline'])
            info_tag.setRating(float(item['rating']))
            info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')

            if item['year'].isdigit():
                info_tag.setYear(int(item['year']))
            if item['release_date']:
                info_tag.setPremiered(item['release_date'])
            if item['runtime'] > 0:
                info_tag.setDuration(item['runtime'] * 60)
            if item['genres']:
                info_tag.setGenres(item['genres'])
            if item['directors']:
                info_tag.setDirectors(item['directors'])
            if item['cast']:
                actors = [
                    xbmc.Actor(
                        name=actor['name'],
                        role=actor['role'],
                        thumbnail=actor['thumbnail']
                    )
                    for actor in item['cast']
                ]
                info_tag.setCast(actors)

            art = {}
            if item['poster']:
                art['poster'] = item['poster']
                art['thumb'] = item['poster']
                art['icon'] = item['poster']
            if item['fanart']:
                art['fanart'] = item['fanart']
            li.setArt(art)

            if media_type == 'tv':
                show_p = db.get_tv_show_progress(item['id'], item.get('number_of_episodes', 0))
                is_w = (show_p >= 100)
                is_r = (0 < show_p < 100)
                li.addContextMenuItems(make_tv_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
            else:
                st = db.get_item_watch_status(item['id'], 0, 0)
                is_w = bool(st and st.get('watched'))
                is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
                li.addContextMenuItems(make_movie_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
                elif is_r:
                    info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "original_title": item.get('original_title') or item['title'],
                "year": item['year'],
                "media_type": media_type,
                "tmdb_id": item['id'],
                "poster": item.get('poster', ''),
                "fanart": item.get('fanart', ''),
                "overview": item.get('overview', '')
            })

            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1
    finally:
        close_loading_dialog(loading)

    if cancelled and added_count == 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    t_total = time.time() - t_start
    t_kodi = max(0.0, t_total - t_tmdb - t_ws_total)
    avg_ws = (t_ws_total / total) if total > 0 else 0
    slow_str = f" | Nejpomalejší ověření: '{slowest_item[0]}' ({slowest_item[1]:.2f}s)" if (total > 0 and slowest_item[1] >= 0.5) else ""
    log_timing(
        f"Hledání '{query}' ({total} položek): "
        f"TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s (průměr {avg_ws:.2f}s/ks){slow_str} | "
        f"Kodi GUI={t_kodi:.2f}s | CELKEM={t_total:.2f}s"
    )

def show_advanced_search_menu():
    """Zobrazí nabídku pokročilého hledání (podle herce nebo režiséra)."""
    items = [
        ("Hledat podle herce", ICONS['ACTOR'], {"mode": "advanced_search_input", "person_type": "actor"}),
        ("Hledat podle režiséra", ICONS['DIRECTOR'], {"mode": "advanced_search_input", "person_type": "director"}),
    ]
    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon, 'thumb': icon})
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def search_person_menu(query, person_type="actor"):
    """Vyhledá osobu a přímo zobrazí její filmografii (s prvním tlačítkem s informacemi)."""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    loading = show_loading_dialog("Vyhledávám", f"Vyhledávám osobu: {query}")
    try:
        persons = tmdb.search_tmdb_person(query, tmdb_key)
    finally:
        close_loading_dialog(loading)

    if not persons:
        dialog_ok("Hledání", f"Pro dotaz '{query}' nebyla nalezena žádná osoba.")
        return

    # Vybereme nejlepší shodu (první položka má nejvyšší popularitu v TMDB)
    best_person = persons[0]
    q_lower = query.strip().lower()
    for p in persons:
        if p.get('name', '').strip().lower() == q_lower:
            best_person = p
            break

    show_person_credits_menu(
        person_id=best_person['id'],
        person_name=best_person['name'],
        person_type=person_type,
        page=1,
        person_profile=best_person.get('profile', ''),
        known_for=best_person.get('known_for_str', '')
    )


def show_person_credits_menu(person_id, person_name, person_type, page=1, person_profile="", known_for=""):
    """Zobrazí filmy a seriály dané osoby (herec/režisér) od nejnovějších po nejstarší s ověřením na Webshare."""
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, "movies")

    type_title = "Herec" if person_type == "actor" else "Režisér"
    loading = show_loading_dialog("Načítám", f"Načítám filmografii: {person_name} ({type_title})...")
    t_tmdb_start = time.time()
    try:
        all_items = tmdb.get_person_movie_credits(person_id, person_type, tmdb_key)
    finally:
        close_loading_dialog(loading)
    t_tmdb = time.time() - t_tmdb_start

    if not all_items:
        dialog_ok("Filmografie", f"Pro '{person_name}' nebyly nalezeny žádné tituly.")
        return

    try:
        items_per_page = int(float(ADDON.getSetting('items_per_page') or 20))
    except Exception:
        items_per_page = 20

    total_items = len(all_items)
    start_idx = (page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    page_items = all_items[start_idx:end_idx]

    if not page_items:
        dialog_ok("Filmografie", "Žádné další tituly na této stránce.")
        return

    # 1. PRVNÍ TLAČÍTKO: Informační záhlaví s fotkou osoby, jménem a celkovým počtem titulů
    if page == 1:
        header_label = f"[B]{person_name}[/B] [COLOR gray]({type_title} • Celkem {total_items} filmů a seriálů)[/COLOR]"
        header_label2 = f"Známé z: {known_for}" if known_for else "Filmy a seriály od nejnovějších po nejstarší"
        header_li = xbmcgui.ListItem(label=header_label, label2=header_label2)
        fallback_person_icon = ICONS.get('ACTOR', '') if person_type == 'actor' else ICONS.get('DIRECTOR', '')
        head_img = person_profile or fallback_person_icon
        first_fanart = page_items[0].get('fanart', '') if page_items else ''
        header_li.setArt({
            'icon': head_img,
            'thumb': head_img,
            'poster': head_img,
            'fanart': first_fanart,
        })
        info_url = build_url({
            "mode": "person_info_dialog",
            "person_name": person_name,
            "person_type": person_type,
            "total_items": str(total_items),
            "known_for": known_for
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=info_url, listitem=header_li, isFolder=False)

    ws_token = get_ws_token()
    first_year = page_items[0].get('year', '') if page_items else ''
    first_year_suffix = f" ({first_year}...)" if first_year else ""
    loading = show_loading_dialog("Ověřuji", f"Ověřuji dostupnost na Webshare{first_year_suffix}")
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    try:
        title_msg = f"Ověřuji tituly: {person_name} (str. {page})..."
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            page_items, 'movie', ws_token, prefix="auto", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        for item, base_label, lang_str, is_w in verified_items:
            mtype = item.get('media_type', 'movie')
            char = item.get('character', '')

            # V závorce jakou roli hrál
            if person_type == 'actor' and char:
                role_bracket = f"({char})"
            elif person_type == 'director':
                role_bracket = "(Režie)"
            else:
                role_bracket = ""

            role_tag = f" [COLOR lightgray]{role_bracket}[/COLOR]" if role_bracket else ""
            label = f"{base_label}{role_tag}"
            label2 = f"{role_bracket}  •  {lang_str}" if (role_bracket and lang_str) else (role_bracket or lang_str)

            li = xbmcgui.ListItem(label=label, label2=label2)
            default_icon = ICONS.get('FILM', '') if mtype == 'movie' else ICONS.get('THEATRE', '')
            poster_art = item.get('poster') or default_icon
            fanart_art = item.get('fanart') or ''

            li.setArt({
                'icon': poster_art,
                'thumb': poster_art,
                'poster': poster_art,
                'fanart': fanart_art,
            })
            li.setProperty('item_languages', lang_str)
            if role_bracket:
                li.setProperty('person_role', role_bracket)

            if mtype == 'tv':
                show_p = db.get_tv_show_progress(item['id'], item.get('number_of_episodes', 0))
                li.addContextMenuItems(make_tv_context_menu(item['id'], item['title'], is_watched=(show_p >= 100), is_resume=(0 < show_p < 100)))
            else:
                st = db.get_item_watch_status(item['id'], 0, 0)
                is_w = bool(st and st.get('watched'))
                is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
                li.addContextMenuItems(make_movie_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))

            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            if item.get('overview'):
                info_tag.setPlot(item['overview'])
            if item.get('rating'):
                info_tag.setRating(float(item['rating']))
            info_tag.setMediaType('tvshow' if mtype == 'tv' else 'movie')
            if item.get('year') and str(item['year']).isdigit():
                info_tag.setYear(int(item['year']))
            if item.get('release_date'):
                info_tag.setPremiered(item['release_date'])

            if person_type == 'actor' and char:
                info_tag.setCast([xbmc.Actor(name=person_name, role=char, thumbnail=person_profile or '')])
            elif person_type == 'director':
                info_tag.setDirectors([person_name])

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "original_title": item['original_title'],
                "year": item['year'],
                "tmdb_id": item['id'],
                "media_type": mtype,
                "poster": poster_art,
                "fanart": fanart_art,
                "overview": item.get('overview', '')
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        if not cancelled and end_idx < total_items:
            next_li = xbmcgui.ListItem(label=f"Další ({page + 1})")
            next_li.setArt({'icon': ICONS.get('NEXT', ICONS.get('BOOK', '')), 'thumb': ICONS.get('NEXT', ICONS.get('BOOK', ''))})
            next_url = build_url({
                "mode": "person_credits",
                "person_id": person_id,
                "person_name": person_name,
                "person_type": person_type,
                "page": page + 1,
                "person_profile": person_profile,
                "known_for": known_for
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        t_total = time.time() - t_start
        log_timing(f"Tituly pro '{person_name}' ({person_type}, str. {page}, {len(page_items)} ks z {total_items}): TMDB={t_tmdb:.2f}s | WS={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)

def show_tv_series_menu(item):
    """Zobrazí seznam sezón seriálu s procenty zhlédnutí pro každou sérii."""
    t_start = time.time()
    title = item.get('title', '')
    loading = show_loading_dialog("Načítám", f"Načítám sezóny seriálu {title}...")
    try:
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        if not tmdb_key:
            log_error("Není zadán TMDB API klíč")
            dialog_notif("TMDB chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmcplugin.setContent(HANDLE, "seasons")

        ws_token = get_ws_token()
        if not ws_token:
            log_error("Není dostupný Webshare token")
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        t_tmdb_start = time.time()
        seasons = tmdb.get_tv_seasons(item.get('id'), tmdb_key)
        t_tmdb = time.time() - t_tmdb_start

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        if not seasons:
            li = xbmcgui.ListItem(label="Žádné sezóny nenalezeny")
            li.setArt({'icon': ICONS.get('THEATRE', ''), 'thumb': ICONS.get('THEATRE', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            log_timing(f"Sezóny pro '{title}': 0 sezón | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
            return

        num_seasons = len(seasons)
        t_ws_start = time.time()
        cancelled = False

        update_loading_dialog(loading, 30, f"Ověřuji dostupnost {num_seasons} sezón...")

        def _check_season(s):
            s_num = s.get('season_number', 0)
            res = webshare.check_tv_episode_availability(
                item, s_num, 1, item.get('year', ''), ws_token, limit=get_search_files_limit()
            )
            return s_num, res

        season_results = {}
        if num_seasons > 0:
            with ThreadPoolExecutor(max_workers=min(10, num_seasons)) as pool:
                for s_num, res in pool.map(_check_season, seasons):
                    season_results[s_num] = res

        t_ws_total = time.time() - t_ws_start
        added_count = 0

        for i, season in enumerate(seasons):
            if is_loading_cancelled(loading):
                cancelled = True
                break

            season_number = season.get('season_number', 0)
            ep_count = season.get('episode_count', 0)
            first_ep_result = season_results.get(season_number, {})
            is_season_available = bool(first_ep_result.get('available'))
            season_lang = first_ep_result.get('lang', '') if is_season_available else None
            
            if not is_season_available:
                log_debug(f"[Dostupnost] Seriál '{title}' Sezóna {season_number}: Nedostupná (žádný stream pro 1. díl).")

            # Výpočet procenta rozkoukání celé série
            season_pct = db.get_tv_season_progress(item.get('id'), season_number, ep_count)
            is_season_watched = (season_pct >= 100)
            if is_season_watched:
                season_pct_str = " [COLOR lime](Zhlédnuto)[/COLOR]"
            elif season_pct > 0:
                season_pct_str = f" [COLOR orange]({season_pct}%)[/COLOR]"
            else:
                season_pct_str = ""
            
            # Sestavení popisku: pokud není 1. díl dostupný, celá série je šedá, ale stále rozkliknutelná
            base_label = tv_navigation.build_season_label(item.get('title', ''), season, lang=season_lang, is_available=is_season_available)
            if is_season_watched and is_season_available:
                label = f"[COLOR gray]{base_label}[/COLOR]{season_pct_str}"
            else:
                label = f"{base_label}{season_pct_str}"
            label2 = season.get('overview', '') or ('Dostupná' if is_season_available else 'Nedostupná')


            li = xbmcgui.ListItem(label=label, label2=label2)
            season_poster = season.get('poster') or item.get('poster', '')
            season_fanart = item.get('fanart', '')
            li.setArt({
                'icon': season_poster or ICONS.get('THEATRE', ''),
                'thumb': season_poster or ICONS.get('THEATRE', ''),
                'poster': season_poster,
                'fanart': season_fanart,
            })
            li.setProperty('season_number', str(season_number))
            if season_lang:
                li.setProperty('season_lang', season_lang)

            season_plot = season.get('overview', '') or item.get('overview', '')
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('season')
            info_tag.setTvShowTitle(item.get('title', ''))
            info_tag.setTitle(base_label)
            if season_plot:
                info_tag.setPlot(season_plot)
            if season_number > 0:
                info_tag.setSeason(season_number)
            if season.get('air_date'):
                info_tag.setPremiered(season.get('air_date'))
            if season_pct >= 100:
                info_tag.setPlaycount(1)

            li.addContextMenuItems(make_season_context_menu(item.get('id'), season_number, item.get('title', ''), is_watched=(season_pct >= 100)))

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "tv_season_selected",
                    "title": item.get('title', ''),
                    "original_title": item.get('original_title', item.get('title', '')),
                    "year": item.get('year', ''),
                    "tmdb_id": item.get('id'),
                    "season_number": season_number,
                    "poster": season_poster,
                    "fanart": season_fanart,
                    "overview": season_plot,
                }),
                listitem=li,
                isFolder=True,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        t_total = time.time() - t_start
        log_timing(f"Sezóny pro '{title}' ({num_seasons} sezón): TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)

def show_tv_episode_menu(show_item, season_number):
    """Zobrazí epizody sezóny, ověří dostupnost na Webshare a označí nedostupné šedě."""
    t_start = time.time()
    title = show_item.get('title', '')
    loading = show_loading_dialog("Načítám", f"Načítám epizody sezóny {season_number}...")
    try:
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        if not tmdb_key:
            log_error("Není zadán TMDB API klíč")
            dialog_notif("TMDB chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmcplugin.setContent(HANDLE, "episodes")

        ws_token = get_ws_token()
        if not ws_token:
            log_error("Není dostupný Webshare token")
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        t_tmdb_start = time.time()
        season_data = tmdb.get_season_details(show_item.get('id'), season_number, tmdb_key)
        t_tmdb = time.time() - t_tmdb_start

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        episodes = season_data.get('episodes', [])
        if not episodes:
            li = xbmcgui.ListItem(label="Žádné epizody nenalezeny")
            li.setArt({'icon': ICONS.get('THEATRE', ''), 'thumb': ICONS.get('THEATRE', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            log_timing(f"Epizody pro '{title}' S{season_number}: 0 epizod | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
            return

        num_episodes = len(episodes)
        t_ws_start = time.time()
        cancelled = False

        update_loading_dialog(loading, 30, f"Ověřuji dostupnost {num_episodes} epizod...")

        def _check_ep(ep):
            ep_num = ep.get('episode_number', 0)
            res = webshare.check_tv_episode_availability(
                show_item,
                season_number,
                ep_num,
                show_item.get('year', ''),
                ws_token,
                limit=get_search_files_limit(),
            )
            return ep_num, res

        episode_results = {}
        if num_episodes > 0:
            with ThreadPoolExecutor(max_workers=min(15, num_episodes)) as pool:
                for ep_num, res in pool.map(_check_ep, episodes):
                    episode_results[ep_num] = res

        # Obohacení jazyků epizod ze StreamCache DB (pokud existují skutečné audio/titulky)
        try:
            from resources.lib import stream_cache
            candidate_idents = [res.get('ident') for res in episode_results.values() if res and res.get('ident')]
            if candidate_idents:
                cached_data = stream_cache.get_cached_streams_batch(candidate_idents)
                for ep_num, res in episode_results.items():
                    c_ident = res.get('ident')
                    if c_ident and c_ident in cached_data:
                        c_info = cached_data[c_ident]
                        a_langs = [str(l).upper() for l in c_info.get('audio_languages') or []]
                        s_langs = [str(l).upper() for l in c_info.get('subtitles') or []]
                        
                        if 'CZ' in a_langs:
                            res['lang'] = 'CZ'
                        elif 'SK' in a_langs:
                            res['lang'] = 'SK'
                        elif 'CZ' in s_langs:
                            res['lang'] = 'CZ TIT'
                        elif 'SK' in s_langs:
                            res['lang'] = 'SK TIT'
                        elif a_langs:
                            res['lang'] = " / ".join(a_langs[:2])
                        elif s_langs:
                            res['lang'] = f"T: {s_langs[0]}"
        except Exception as e:
            log_debug(f"Chyba při zjišťování jazyků epizod z DB: {e}")

        t_ws_total = time.time() - t_ws_start
        added_count = 0

        for i, episode in enumerate(episodes):
            if is_loading_cancelled(loading):
                cancelled = True
                break

            episode_number = episode.get('episode_number', 0)
            ep_status = db.get_item_watch_status(show_item.get('id'), season_number, episode_number)

            ep_result = episode_results.get(episode_number, {})
            is_ep_available = bool(ep_result.get('available'))
            ep_lang = ep_result.get('lang', '') if is_ep_available else None

            if not is_ep_available:
                ep_name_val = episode.get('name') or f"Díl {episode_number}"
                log_debug(f"[Dostupnost] Epizoda '{title}' S{season_number:02d}E{episode_number:02d} ({ep_name_val}): Nedostupná (žádný stream).")

            is_ep_watched = bool(ep_status and ep_status.get('watched'))
            is_ep_resume = bool(ep_status and ep_status.get('resume_time', 0) > 15 and not is_ep_watched)

            # Sestavení popisku: pokud je zhlédnuto, název dílu je šedý a má (Zhlédnuto)
            base_label = tv_navigation.build_episode_label(episode, is_available=is_ep_available, lang=ep_lang, is_watched=is_ep_watched)

            if is_ep_watched:
                label = base_label
            elif is_ep_resume and ep_status.get('total_time', 0) > 0:
                pct = int((ep_status['resume_time'] / ep_status['total_time']) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label


            label2 = f"Jazyk: {ep_lang}" if is_ep_available else (episode.get('overview', '') or "Nedostupné")

            li = xbmcgui.ListItem(label=label, label2=label2)
            li.addContextMenuItems(make_episode_context_menu(show_item.get('id'), season_number, episode_number, show_item.get('title', ''), is_watched=is_ep_watched, is_resume=is_ep_resume))



            still_path = episode.get('still_path') or ''
            show_poster = show_item.get('poster') or ''
            show_fanart = show_item.get('fanart') or ''
            ep_image = f"https://image.tmdb.org/t/p/w500{still_path}" if still_path else show_poster
            art = {
                'icon': ep_image or ICONS.get('THEATRE', ''),
                'thumb': ep_image or ICONS.get('THEATRE', ''),
                'poster': ep_image or show_poster or ICONS.get('THEATRE', ''),
                'fanart': f"https://image.tmdb.org/t/p/w1280{still_path}" if still_path else show_fanart
            }
            li.setArt(art)
            li.setProperty('episode_number', str(episode_number))
            li.setProperty('season_number', str(season_number))

            ep_name = episode.get('name', '') or f"Epizoda {episode_number}"
            ep_plot = episode.get('overview', '') or show_item.get('overview', '')

            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('episode')
            info_tag.setTvShowTitle(show_item.get('title', ''))
            info_tag.setTitle(ep_name)
            if ep_plot:
                info_tag.setPlot(ep_plot)
            info_tag.setSeason(season_number)
            info_tag.setEpisode(episode_number)
            if is_ep_watched:
                info_tag.setPlaycount(1)
            elif is_ep_resume:
                info_tag.setResumePoint(ep_status['resume_time'], ep_status.get('total_time', 0))
            if episode.get('air_date'):
                info_tag.setPremiered(episode.get('air_date'))
            if episode.get('vote_average'):
                try:
                    info_tag.setRating(float(episode.get('vote_average', 0)))
                except (TypeError, ValueError):
                    pass
            if episode.get('runtime'):
                info_tag.setDuration(int(episode.get('runtime')) * 60)

            guest_stars = []
            for actor in episode.get('guest_stars', [])[:5]:
                if actor.get('name'):
                    p_path = actor.get('profile_path')
                    actor_thumb = f"https://image.tmdb.org/t/p/w185{p_path}" if p_path else ""
                    guest_stars.append(xbmc.Actor(name=actor.get('name', ''), role=actor.get('character', ''), thumbnail=actor_thumb))
            if guest_stars:
                info_tag.setCast(guest_stars)

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "tv_episode_selected",
                    "title": show_item.get('title', ''),
                    "original_title": show_item.get('original_title', show_item.get('title', '')),
                    "year": show_item.get('year', ''),
                    "tmdb_id": show_item.get('id'),
                    "season_number": season_number,
                    "episode_number": episode_number,
                    "episode_name": ep_name,
                    "episode_plot": ep_plot,
                    "episode_still": f"https://image.tmdb.org/t/p/w500{still_path}" if still_path else '',
                    "poster": show_poster,
                    "fanart": show_fanart,
                }),
                listitem=li,
                isFolder=True,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        t_total = time.time() - t_start
        log_timing(f"Epizody pro '{title}' S{season_number} ({num_episodes} dílů): TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)
        
IMPORTANT_DISPLAY_LANGS = {'CZ', 'SK', 'EN', 'PL', 'DE'}

def filter_display_languages(langs, original_language=""):
    """
    Filtruje jazyky pro zobrazení: zachovává pouze nejdůležitější jazyky (CZ, SK, EN, PL, DE)
    a případně originální jazyk titulu (např. JA pro japonské anime).
    Odstraňuje useless jazyky (FR, IT, RU, KO, atd.), které zbytečně zaplňují popis.
    """
    if not langs:
        return []

    allowed = set(IMPORTANT_DISPLAY_LANGS)
    if original_language:
        ol = str(original_language).upper().strip()
        if len(ol) == 2:
            allowed.add(ol)
        elif ol in ('JAPANESE', 'JPN'):
            allowed.add('JA')
        elif ol in ('KOREAN', 'KOR'):
            allowed.add('KO')
        elif ol in ('FRENCH', 'FRA', 'FRE'):
            allowed.add('FR')
        elif ol in ('SPANISH', 'SPA'):
            allowed.add('ES')
        elif ol in ('ITALIAN', 'ITA'):
            allowed.add('IT')
        elif ol in ('RUSSIAN', 'RUS'):
            allowed.add('RU')

    filtered = []
    for l in langs:
        l_up = str(l).upper().strip()
        if l_up in allowed and l_up not in filtered:
            filtered.append(l_up)

    priority = {'CZ': 0, 'SK': 1, 'EN': 2, 'PL': 3, 'DE': 4}
    filtered.sort(key=lambda x: priority.get(x, 5))
    return filtered


def sort_all_languages(langs):
    """
    Seřadí všechny jazyky pro výpis v popisu tak, aby prioritní jazyky (CZ, SK, EN, PL, DE)
    byly na začátku a všechny ostatní jazyky (RU, FR, ES, JA, atd.) následovaly abecedně.
    Žádný jazyk se nezahazuje.
    """
    if not langs:
        return []
    unique = []
    for l in langs:
        l_up = str(l).upper().strip()
        if l_up and l_up not in unique:
            unique.append(l_up)
    priority = {'CZ': 0, 'SK': 1, 'EN': 2, 'PL': 3, 'DE': 4}
    unique.sort(key=lambda x: (priority.get(x, 10), x))
    return unique


def build_stream_details_plot(file_item, base_plot="", original_language=""):
    """Vytvoří přehledný text s podrobnostmi o streamu (kodek, kvalita, HDR, audio, titulky, velikost) pro zobrazení v levém panelu."""
    q = file_item.get('quality') or ''
    codec = file_item.get('video_codec') or file_item.get('codec') or ''
    hdr = file_item.get('hdr_format') or file_item.get('hdr') or ''
    size_mb = file_item.get('size_mb')
    audio_langs = file_item.get('audio_languages') or []
    subtitles = file_item.get('subtitles') or []
    lang_raw = file_item.get('lang', '')
    orig_lang = file_item.get('original_language') or original_language or ''

    # Pokud známe opravdová ověřená metadata (z DB nebo po synchronním probe), hlavička bude tmavě zelená, jinak žlutá
    has_real_metadata = bool(file_item.get('real_metadata') or file_item.get('from_db'))
    header_color = "darkgreen" if has_real_metadata else "yellow"

    lines = []
    lines.append(f"[COLOR {header_color}][B]PODROBNOSTI SOUBORU:[/B][/COLOR]")
    
    src = str(file_item.get('source', 'webshare')).lower()
    if src == 'hellspy':
        source_color = "deepskyblue"
        source_name = "HellSpy"
    elif src == 'prehrajto':
        source_color = "coral"
        source_name = "Přehraj.to"
    elif src in ('streamtape', 'mixdrop', 'filemoon'):
        source_color = "gold"
        source_name = src.capitalize()
    else:
        source_color = "dodgerblue"
        source_name = "Webshare"
    lines.append(f"  • Zdroj: [COLOR {source_color}][B]{source_name}[/B][/COLOR]")

    qual_parts = []
    if q and q != '??':
        qual_parts.append(f"[COLOR lime][B]{q}[/B][/COLOR]")
    if codec:
        qual_parts.append(f"[[B]{codec.upper()}[/B]]")
    if hdr:
        qual_parts.append(f"[[COLOR magenta][B]{hdr.upper()}[/B][/COLOR]]")
    if qual_parts:
        lines.append("  • Kvalita: " + " ".join(qual_parts))

    if size_mb is not None:
        if size_mb >= 1024:
            size_formatted = f"{size_mb / 1024:.2f} GB"
        else:
            size_formatted = f"{size_mb:.0f} MB"
        lines.append(f"  • Velikost: [B]{size_formatted}[/B]")

    # 1. Výpis všech detekovaných jazyků audia (žádný jazyk se neignoruje v popisu)
    # Řazení: CZ, SK, EN, PL, DE mají přednost, zbytek následuje abecedně
    all_audio = sort_all_languages(audio_langs)
    if not all_audio and lang_raw:
        raw_clean = str(lang_raw).upper().strip()
        if 'TIT' in raw_clean:
            # Jedná se o titulky, audio je původní nebo EN
            if orig_lang and str(orig_lang).upper() not in ('CZ', 'SK'):
                all_audio = [str(orig_lang).upper()]
            else:
                all_audio = ['EN']
        elif 'CZ' in raw_clean:
            all_audio = ['CZ']
        elif 'SK' in raw_clean:
            all_audio = ['SK']
        elif 'EN' in raw_clean:
            all_audio = ['EN']
        elif raw_clean != 'NEZNÁMÝ':
            all_audio = [raw_clean]

    if all_audio:
        audio_str = ", ".join(all_audio)
        lines.append(f"  • Audio: [COLOR lime]{audio_str}[/COLOR]")

    # 2. Výpis všech detekovaných titulků s fallbackem na název souboru
    all_subs = sort_all_languages(subtitles)
    if not all_subs:
        fn_lower = file_item.get('name', '').lower()
        if lang_raw and 'TIT' in str(lang_raw).upper():
            all_subs = ['SK' if ('sktit' in fn_lower or 'sk tit' in fn_lower or 'SK' in str(lang_raw).upper()) else 'CZ']
        elif any(k in fn_lower for k in ('cz tit', 'cztit', 'titulky', 'sktit', 'sk tit', '.tit.')):
            all_subs = ['SK' if ('sktit' in fn_lower or 'sk tit' in fn_lower) else 'CZ']

    if all_subs:
        sub_txt = ", ".join(all_subs)
        lines.append(f"  • Titulky: [COLOR cyan]{sub_txt}[/COLOR]")

    # 3. Skutečná délka videa
    f_dur = file_item.get('duration') or 0
    if f_dur and f_dur > 0:
        d_min = int(round(f_dur / 60.0))
        d_h = d_min // 60
        d_m = d_min % 60
        dur_full = f"{d_h}h {d_m:02d}m ({int(f_dur // 60)} min)" if d_h > 0 else f"{d_m} min"
        lines.append(f"  • Skutečná délka: [B]{dur_full}[/B]")

    fname = file_item.get('name', '')
    if fname:
        lines.append(f"[COLOR gray]Soubor: {fname}[/COLOR]")

    if base_plot:
        lines.append("-------------")
        lines.append(base_plot)

    return "\n".join(lines)


def show_tv_episode_files(show_item, season_number, episode_number):
    """Zobrazí dostupné soubory pro epizodu a předá sezónu i díl do přehrávače."""
    loading = show_loading_dialog("Načítám", f"Kontroluji epizodu {season_number}x{episode_number}...")
    try:
        ws_token = get_ws_token()
        if not ws_token:
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmcplugin.setContent(HANDLE, "files")

        search_limit = get_search_files_limit()

        update_loading_dialog(loading, 20, "Stahuji výsledky epizody z Webshare...")
        episode_result = webshare.search_and_verify_episode(
            show_item,
            season_number,
            episode_number,
            token=ws_token,
            limit=search_limit
        )
        files = episode_result.get('files', [])

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        valid_files = []
        for index, file_item in enumerate(files):
            if is_loading_cancelled(loading):
                break
            percent = 20 + int(40 * (index + 1) / max(1, len(files)))
            if update_loading_dialog(loading, percent, f"Kontroluji soubor {index + 1}/{len(files)}"):
                break
            if not file_item.get('valid', False):
                continue
            if file_item.get('size_mb', 0) < 30:
                continue
            file_item['source'] = 'webshare'
            valid_files.append(file_item)

        # Doplnění výsledků ze zdroje Přehraj.to pro epizodu
        if ADDON.getSetting('source_prehrajto') != 'false' and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 60, "Vyhledávám na Přehraj.to...")
                from resources.lib import prehrajto
                p_files = prehrajto.search_prehrajto(
                    show_item,
                    media_type='tv',
                    season=season_number,
                    episode=episode_number,
                    year=show_item.get('year', ''),
                    limit=search_limit
                )
                for pf in p_files:
                    if pf.get('valid') and pf.get('size_mb', 0) >= 30:
                        valid_files.append(pf)
            except Exception as e:
                log_debug(f"Chyba při vyhledávání epizody na Přehraj.to: {e}")

        # 1c. Doplnění výsledků ze zdroje HellSpy pro epizodu
        if ADDON.getSetting('source_hellspy') == 'true' and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 60, "Vyhledávám na HellSpy...")
                from resources.lib import hellspy
                hs_files = hellspy.search_hellspy(
                    show_item,
                    media_type='tv',
                    season=season_number,
                    episode=episode_number,
                    year=show_item.get('year', ''),
                    limit=search_limit
                )
                for hf in hs_files:
                    if hf.get('valid') and hf.get('size_mb', 0) >= 30:
                        valid_files.append(hf)
            except Exception as e:
                log_debug(f"Chyba při vyhledávání epizody na HellSpy: {e}")

        # 1d. Doplnění výsledků z anglických zdrojů (Streamtape, Mixdrop, Filemoon)
        if ADDON.getSetting('source_english') == 'true' and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 65, "Vyhledávám na anglických zdrojích...")
                from resources.lib import english_sources
                en_files = english_sources.search_english(
                    show_item,
                    media_type='tv',
                    season=season_number,
                    episode=episode_number,
                    year=show_item.get('year', ''),
                    limit=search_limit
                )
                for ef in en_files:
                    if ef.get('valid'):
                        valid_files.append(ef)
            except Exception as e:
                log_debug(f"Chyba při vyhledávání epizody na anglických zdrojích: {e}")

        # Kompaktní výpis nalezených souborů do konzole
        show_str = show_item.get('title') or show_item.get('name', 'Seriál')
        ep_tag = f"S{season_number:02d}E{episode_number:02d}"
        if valid_files:
            sample_parts = []
            for f in valid_files[:3]:
                f_l = f.get('lang', '??')
                f_q = f.get('quality', '??')
                f_s = int(f.get('size_mb', 0))
                f_n = str(f.get('name', ''))[:45]
                sample_parts.append("[%s|%s|%dMB] %s" % (f_l, f_q, f_s, f_n))
            more_str = (" (+%d dalších)" % (len(valid_files) - 3)) if len(valid_files) > 3 else ""
            samples_str = "; ".join(sample_parts)

            ws_cnt = sum(1 for f in valid_files if f.get('source') == 'webshare')
            pt_cnt = sum(1 for f in valid_files if f.get('source') == 'prehrajto')
            hs_cnt = sum(1 for f in valid_files if f.get('source') == 'hellspy')
            en_cnt = sum(1 for f in valid_files if f.get('source') in ('streamtape', 'mixdrop', 'filemoon', 'english'))
            src_parts = []
            if ws_cnt: src_parts.append(f"Webshare: {ws_cnt}")
            if pt_cnt: src_parts.append(f"Přehraj.to: {pt_cnt}")
            if hs_cnt: src_parts.append(f"HellSpy: {hs_cnt}")
            src_summary = (" (" + ", ".join(src_parts) + ")") if src_parts else ""

            log_debug("[Soubory] '%s' %s: %d platných streamů%s | Ukázka: %s%s" % (
                show_str, ep_tag, len(valid_files), src_summary, samples_str, more_str
            ))
        else:
            log_debug("[Nenalezeno] '%s' %s: Žádný platný soubor nenalezen na žádném z aktivních zdrojů." % (
                show_str, ep_tag
            ))

        if not valid_files:
            if is_loading_cancelled(loading):
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            li = xbmcgui.ListItem(label="Žádné vhodné soubory nenalezeny")
            li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            return

        tmdb_key = ADDON.getSetting('tmdb_api_key')
        tmdb_id = show_item.get('id', '')
        tmdb_details = tmdb.get_item_details(media_type='tv', tmdb_id=tmdb_id, api_key=tmdb_key) if (tmdb_key and tmdb_id) else {}

        # Obohacení z mezipaměti Supabase (pokud data existují v DB)
        try:
            from resources.lib import stream_cache
            file_idents = [f.get('ident') for f in valid_files if f.get('ident')]
            cached_streams = stream_cache.get_cached_streams_batch(file_idents)
            for f in valid_files:
                ident = f.get('ident')
                if ident in cached_streams:
                    cs = cached_streams[ident]
                    f['from_db'] = True
                    f['real_metadata'] = True
                    if cs.get('quality') and cs['quality'] != '??':
                        f['quality'] = str(cs['quality']).lstrip('~')
                        f['quality_estimated'] = False
                    if cs.get('video_codec'):
                        f['video_codec'] = cs['video_codec']
                        f['codec'] = cs['video_codec']
                    if cs.get('hdr_format'):
                        f['hdr_format'] = cs['hdr_format']
                        f['hdr'] = cs['hdr_format']
                    if cs.get('audio_languages'):
                        f['audio_languages'] = cs['audio_languages']
                        if 'CZ' in cs['audio_languages']:
                            f['lang'] = 'CZ'
                        elif 'SK' in cs['audio_languages']:
                            f['lang'] = 'SK'
                        elif cs['audio_languages']:
                            f['lang'] = cs['audio_languages'][0]
                    if cs.get('subtitles'):
                        f['subtitles'] = cs['subtitles']
                    if cs.get('duration'):
                        f['duration'] = cs['duration']
        except Exception as e:
            log_debug(f"Chyba při obohacení epizod z DB cache: {e}")

        # Kontrola parametrů streamů pro všechny nalezené soubory (kvalita, kodeky, délka)
        if valid_files and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 70, "Ověřuji parametry streamů (kvalita, kodeky, délka)...")
                from resources.lib import stream_cache
                probe_info = {
                    'id': show_item.get('id', ''),
                    'season': season_number,
                    'episode': episode_number
                }
                def _probe_progress(cur, tot):
                    pct = 70 + int(15 * cur / max(1, tot))
                    update_loading_dialog(loading, pct, f"Ověřuji stream {cur}/{tot}...")

                stream_cache.probe_and_update_files_sync(
                    valid_files,
                    probe_info,
                    ws_token,
                    progress_callback=_probe_progress,
                    cancel_callback=lambda: is_loading_cancelled(loading),
                    max_probe=None
                )
            except Exception as e:
                log_debug(f"Chyba při synchronním ověření epizod: {e}")

        try:
            ep_runtime = int(float(show_item.get('runtime') or tmdb_details.get('runtime') or 0))
        except (ValueError, TypeError):
            ep_runtime = 0
        if ep_runtime and ep_runtime > 0:
            exp_sec = float(ep_runtime) * 60.0
            filtered_by_dur = []
            rejected_by_dur = []
            for f in valid_files:
                f_dur = f.get('duration', 0)
                ok, diff_pct = webshare.is_duration_within_tolerance(f_dur, exp_sec, tolerance=0.08, file_name=f.get('name', ''), media_type='tv')
                if ok:
                    filtered_by_dur.append(f)
                else:
                    rejected_by_dur.append((f.get('name', ''), f_dur, diff_pct))

            if rejected_by_dur:
                rej_cnt = len(rejected_by_dur)
                log_debug(f"[Filtrace délky] Vyřazeno {rej_cnt} souborů kvůli neshodě délky epizody s TMDB ({ep_runtime} min):")
                for r_name, r_dur, r_diff in rejected_by_dur[:5]:
                    d_min = int(r_dur // 60)
                    d_pct = int(r_diff * 100)
                    log_debug(f"  - {r_name} (délka: {d_min} min, rozdíl: {d_pct}%)")

            if filtered_by_dur:
                valid_files = filtered_by_dur
            else:
                log_debug("[Filtrace délky] Žádná epizoda neprošla tolerancí, ponechávám původní soubory.")

        webshare.estimate_missing_qualities(valid_files, runtime_minutes=ep_runtime, media_type='tv')

        added_count = 0
        cancelled = False
        orig_lang = show_item.get('original_language') or ''
        sorted_files = webshare.sort_webshare_files(valid_files)
        for file_item in sorted_files:
            if is_loading_cancelled(loading):
                cancelled = True
                break
            file_item['original_language'] = orig_lang
            label = webshare.build_webshare_file_label(file_item)
            li = xbmcgui.ListItem(label=label)
            q_val = str(file_item.get('quality', '')).replace('~', '').upper()
            stream_icon = ICONS.get('FILM', '')
            if '4K' in q_val:
                stream_icon = ICONS.get('4K', stream_icon)
            elif '1080' in q_val:
                stream_icon = ICONS.get('1080', stream_icon)
            elif '720' in q_val:
                stream_icon = ICONS.get('720', stream_icon)
            elif 'SD' in q_val:
                stream_icon = ICONS.get('SD', stream_icon)

            li.setArt({
                'icon': stream_icon,
                'thumb': show_item.get('episode_still') or show_item.get('poster') or stream_icon,
                'fanart': show_item.get('fanart') or ''
            })
            li.setProperty("webshare_name", file_item.get('name', ''))
            li.setProperty('IsPlayable', 'true')

            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('episode')
            show_title = show_item.get('title', '')
            info_tag.setTvShowTitle(show_title)
            ep_name = show_item.get('episode_name', '')
            ep_plot = show_item.get('episode_plot', '')
            orig_lang = show_item.get('original_language') or ''
            ep_full_title = f"{show_title} - S{season_number:02d}E{episode_number:02d} - {ep_name}" if ep_name else f"{show_title} - S{season_number:02d}E{episode_number:02d}"
            info_tag.setTitle(ep_full_title)
            info_tag.setPlot(build_stream_details_plot(file_item, ep_plot, original_language=orig_lang))
            info_tag.setSeason(season_number)
            info_tag.setEpisode(episode_number)

            v_codec = file_item.get('video_codec') or file_item.get('codec') or ''
            if v_codec:
                li.setProperty('video_codec', v_codec)
            hdr = file_item.get('hdr_format') or file_item.get('hdr') or ''
            if hdr:
                li.setProperty('hdr_type', hdr)
            q_val = str(file_item.get('quality', '')).replace('~', '')
            w, h = 0, 0
            if q_val == '4K':
                w, h = 3840, 2160
            elif q_val == '1080p':
                w, h = 1920, 1080
            elif q_val == '720p':
                w, h = 1280, 720
            elif q_val in ('SD', '480p', '576p'):
                w, h = 720, 576

            if w > 0 or v_codec:
                try:
                    vs = xbmc.VideoStreamDetail()
                    if w > 0:
                        vs.setWidth(w)
                        vs.setHeight(h)
                    if v_codec:
                        vs.setCodec(v_codec)
                    info_tag.addVideoStream(vs)
                except Exception:
                    pass

            f_dur = file_item.get('duration') or 0
            if f_dur and f_dur > 0:
                info_tag.setDuration(int(f_dur))
            elif ep_runtime:
                info_tag.setDuration(int(ep_runtime) * 60)

            for a_lang in (file_item.get('audio_languages') or []):
                try:
                    info_tag.addAudioStream(xbmc.AudioStreamDetail(language=str(a_lang).lower()))
                except Exception:
                    pass
            for s_lang in (file_item.get('subtitles') or []):
                try:
                    info_tag.addSubtitleStream(xbmc.SubtitleStreamDetail(language=str(s_lang).lower()))
                except Exception:
                    pass
    
            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "webshare_file_selected",
                    "webshare_id": file_item.get('ident', ''),
                    "name": file_item.get('name', ''),
                    "lang": file_item.get('lang', ''),
                    "quality": file_item.get('quality', ''),
                    "tmdb_info": {
                        **show_item,
                        "media_type": "tv",
                        "season": season_number,
                        "episode": episode_number,
                        "episode_name": ep_name,
                        "episode_plot": ep_plot,
                        "episode_still": show_item.get('episode_still', ''),
                        "source": file_item.get('source', 'webshare')
                    },
                    "season_number": season_number,
                    "episode_number": episode_number,
                    "tmdb_details": tmdb_details,
                    "episode_name": ep_name,
                    "episode_plot": ep_plot,
                    "episode_still": show_item.get('episode_still', ''),
                }),
                listitem=li,
                isFolder=False,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    except Exception as e:
        log_error(f"Chyba při zobrazení epizod: {e}")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    finally:
        close_loading_dialog(loading)


def show_webshare_results_menu(item):
    """Zobrazí seznam Webshare souborů po výběru filmu seřazený podle jazyka."""
    media_type = item.get("media_type", "movie")

    if media_type == "tv":
        show_tv_series_menu(item)
        return

    loading = show_loading_dialog("Načítám", "Kontroluji dostupné Webshare soubory...")
    try:
        ws_token = get_ws_token()
        if not ws_token:
            close_loading_dialog(loading)
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmcplugin.setContent(HANDLE, "files")

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        search_limit = get_search_files_limit()

        update_loading_dialog(loading, 20, "Stahuji výsledky z Webshare...")
        search_result = webshare.search_and_verify_movie(item, token=ws_token, media_type=media_type, limit=search_limit)
        files = search_result.get("files", [])

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        # 1. Filtrace neplatných a malých souborů
        valid_files = []
        for index, file_item in enumerate(files):
            if is_loading_cancelled(loading):
                break
            percent = 20 + int(40 * (index + 1) / max(1, len(files)))
            if update_loading_dialog(loading, percent, f"Kontroluji soubor {index + 1}/{len(files)}"):
                break
            if not file_item.get('valid', False):
                continue
            
            size_mb = file_item.get('size_mb', 0)
            if size_mb < 50:
                continue

            file_item['source'] = 'webshare'
            valid_files.append(file_item)

        # 1b. Doplnění výsledků ze zdroje Přehraj.to
        if ADDON.getSetting('source_prehrajto') != 'false' and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 60, "Vyhledávám na Přehraj.to...")
                from resources.lib import prehrajto
                p_files = prehrajto.search_prehrajto(item, media_type='movie', limit=search_limit)
                for pf in p_files:
                    if pf.get('valid') and pf.get('size_mb', 0) >= 50:
                        valid_files.append(pf)
            except Exception as e:
                log_debug(f"Chyba při vyhledávání na Přehraj.to: {e}")

        # 1c. Doplnění výsledků ze zdroje HellSpy (vyhledá se vždy, pokud je povolen)
        if ADDON.getSetting('source_hellspy') == 'true' and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 60, "Vyhledávám na HellSpy...")
                from resources.lib import hellspy
                hs_files = hellspy.search_hellspy(item, media_type='movie', limit=search_limit)
                for hf in hs_files:
                    if hf.get('valid') and hf.get('size_mb', 0) >= 50:
                        valid_files.append(hf)
            except Exception as e:
                log_debug(f"Chyba při vyhledávání na HellSpy: {e}")

        # 1d. Doplnění výsledků z anglických zdrojů (Streamtape, Mixdrop, Filemoon)
        if ADDON.getSetting('source_english') == 'true' and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 65, "Vyhledávám na anglických zdrojích...")
                from resources.lib import english_sources
                en_files = english_sources.search_english(item, media_type='movie', limit=search_limit)
                for ef in en_files:
                    if ef.get('valid'):
                        valid_files.append(ef)
            except Exception as e:
                log_debug(f"Chyba při vyhledávání na anglických zdrojích: {e}")

        # Kompaktní výpis nalezených souborů do konzole
        title_str = item.get('title') or item.get('name', 'Film')
        year_str = str(item.get('year', '')).strip()
        year_tag = f" ({year_str})" if year_str else ""
        if valid_files:
            sample_parts = []
            for f in valid_files[:3]:
                f_l = f.get('lang', '??')
                f_q = f.get('quality', '??')
                f_s = int(f.get('size_mb', 0))
                f_n = str(f.get('name', ''))[:45]
                sample_parts.append("[%s|%s|%dMB] %s" % (f_l, f_q, f_s, f_n))
            more_str = (" (+%d dalších)" % (len(valid_files) - 3)) if len(valid_files) > 3 else ""
            samples_str = "; ".join(sample_parts)

            ws_cnt = sum(1 for f in valid_files if f.get('source') == 'webshare')
            pt_cnt = sum(1 for f in valid_files if f.get('source') == 'prehrajto')
            hs_cnt = sum(1 for f in valid_files if f.get('source') == 'hellspy')
            en_cnt = sum(1 for f in valid_files if f.get('source') in ('streamtape', 'mixdrop', 'filemoon', 'english'))
            src_parts = []
            if ws_cnt: src_parts.append(f"Webshare: {ws_cnt}")
            if pt_cnt: src_parts.append(f"Přehraj.to: {pt_cnt}")
            if hs_cnt: src_parts.append(f"HellSpy: {hs_cnt}")
            src_summary = (" (" + ", ".join(src_parts) + ")") if src_parts else ""

            log_debug("[Soubory] '%s'%s: %d platných streamů%s | Ukázka: %s%s" % (
                title_str, year_tag, len(valid_files), src_summary, samples_str, more_str
            ))
        else:
            log_debug("[Nenalezeno] '%s'%s: Žádný platný soubor nenalezen na žádném z aktivních zdrojů." % (
                title_str, year_tag
            ))

        if not valid_files:
            if is_loading_cancelled(loading):
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            close_loading_dialog(loading)
            li = xbmcgui.ListItem(label="Žádné vhodné soubory nenalezeny")
            li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            return

        # Načtení detailů z TMDB pro zjištění očekávané délky a metadat
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        tmdb_id = item.get('id', '')
        tmdb_details = tmdb.get_item_details(media_type='movie', tmdb_id=tmdb_id, api_key=tmdb_key) if (tmdb_key and tmdb_id) else {}
        try:
            movie_runtime = int(float(tmdb_details.get('runtime') or item.get('runtime') or 0))
        except (ValueError, TypeError):
            movie_runtime = 0

        # Obohacení z mezipaměti Supabase (pokud data existují v DB)
        try:
            from resources.lib import stream_cache
            file_idents = [f.get('ident') for f in valid_files if f.get('ident')]
            cached_streams = stream_cache.get_cached_streams_batch(file_idents)
            for f in valid_files:
                ident = f.get('ident')
                if ident in cached_streams:
                    cs = cached_streams[ident]
                    f['from_db'] = True
                    f['real_metadata'] = True
                    if cs.get('quality') and cs['quality'] != '??':
                        f['quality'] = str(cs['quality']).lstrip('~')
                        f['quality_estimated'] = False
                    if cs.get('video_codec'):
                        f['video_codec'] = cs['video_codec']
                        f['codec'] = cs['video_codec']
                    if cs.get('hdr_format'):
                        f['hdr_format'] = cs['hdr_format']
                        f['hdr'] = cs['hdr_format']
                    if cs.get('audio_languages'):
                        f['audio_languages'] = cs['audio_languages']
                        if 'CZ' in cs['audio_languages']:
                            f['lang'] = 'CZ'
                        elif 'SK' in cs['audio_languages']:
                            f['lang'] = 'SK'
                        elif cs['audio_languages']:
                            f['lang'] = cs['audio_languages'][0]
                    if cs.get('subtitles'):
                        f['subtitles'] = cs['subtitles']
                    if cs.get('duration'):
                        f['duration'] = cs['duration']
        except Exception as e:
            log_debug(f"Chyba při obohacení filmů z DB cache: {e}")

        # Kontrola parametrů streamů pro všechny nalezené soubory (kvalita, kodeky, délka)
        if valid_files and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 70, "Ověřuji parametry streamů (kvalita, kodeky, délka)...")
                from resources.lib import stream_cache
                probe_info = {
                    'id': tmdb_id,
                    'season': None,
                    'episode': None
                }
                def _probe_progress(cur, tot):
                    pct = 70 + int(15 * cur / max(1, tot))
                    update_loading_dialog(loading, pct, f"Ověřuji stream {cur}/{tot}...")

                stream_cache.probe_and_update_files_sync(
                    valid_files,
                    probe_info,
                    ws_token,
                    progress_callback=_probe_progress,
                    cancel_callback=lambda: is_loading_cancelled(loading),
                    max_probe=None
                )
            except Exception as e:
                log_debug(f"Chyba při synchronním ověření filmů: {e}")

        # Filtrace souborů podle délky oproti TMDB (tolerance 8%, u režisérských/prodloužených verzí až 18%)
        if movie_runtime and movie_runtime > 0:
            exp_sec = float(movie_runtime) * 60.0
            filtered_by_dur = []
            rejected_by_dur = []
            for f in valid_files:
                f_dur = f.get('duration', 0)
                ok, diff_pct = webshare.is_duration_within_tolerance(f_dur, exp_sec, tolerance=0.08, file_name=f.get('name', ''), media_type='movie')
                if ok:
                    filtered_by_dur.append(f)
                else:
                    rejected_by_dur.append((f.get('name', ''), f_dur, diff_pct))

            if rejected_by_dur:
                rej_cnt = len(rejected_by_dur)
                log_debug(f"[Filtrace délky] Vyřazeno {rej_cnt} souborů kvůli neshodě délky s TMDB ({movie_runtime} min):")
                for r_name, r_dur, r_diff in rejected_by_dur[:5]:
                    d_min = int(r_dur // 60)
                    d_pct = int(r_diff * 100)
                    log_debug(f"  - {r_name} (délka: {d_min} min, rozdíl: {d_pct}%)")

            if filtered_by_dur:
                valid_files = filtered_by_dur
            else:
                log_debug("[Filtrace délky] Žádný soubor neprošel tolerancí 8%, ponechávám původní soubory.")

        # 2. Odhad chybějících kvalit a seřazení podle nastavení uživatele
        webshare.estimate_missing_qualities(valid_files, runtime_minutes=movie_runtime, media_type='movie')
        sorted_files = webshare.sort_webshare_files(valid_files)

        update_loading_dialog(loading, 80, "Vytvářím seznam položek...")

        # 4. Vykreslení položek v Kodi
        p_path = tmdb_details.get('poster_path')
        b_path = tmdb_details.get('backdrop_path')
        movie_poster = item.get('poster') or (("https://image.tmdb.org/t/p/w500" + p_path) if p_path else '')
        movie_fanart = item.get('fanart') or (("https://image.tmdb.org/t/p/w1280" + b_path) if b_path else '')
        movie_plot = tmdb_details.get('overview', '') or item.get('overview', '') or item.get('plot', '')
        movie_genres = [tmdb.translate_genre(g.get('id'), g.get('name')) for g in tmdb_details.get('genres', [])] if tmdb_details.get('genres') else []
        movie_rating = float(tmdb_details.get('vote_average') or item.get('rating', 0.0) or 0.0)
        orig_lang = item.get('original_language') or tmdb_details.get('original_language') or ''

        added_count = 0
        cancelled = False
        for index, file_item in enumerate(sorted_files):
            if is_loading_cancelled(loading):
                cancelled = True
                break
            percent = 80 + int(20 * (index + 1) / max(1, len(sorted_files)))
            if update_loading_dialog(loading, percent, f"Přidávám položku {index + 1}/{len(sorted_files)}"):
                cancelled = True
                break
            file_item['original_language'] = orig_lang
            label = webshare.build_webshare_file_label(file_item)
            li = xbmcgui.ListItem(label=label)
            q_val = str(file_item.get('quality', '')).replace('~', '').upper()
            stream_icon = ICONS.get('FILM', '')
            if '4K' in q_val:
                stream_icon = ICONS.get('4K', stream_icon)
            elif '1080' in q_val:
                stream_icon = ICONS.get('1080', stream_icon)
            elif '720' in q_val:
                stream_icon = ICONS.get('720', stream_icon)
            elif 'SD' in q_val:
                stream_icon = ICONS.get('SD', stream_icon)

            li.setArt({
                'icon': stream_icon,
                'thumb': movie_poster or stream_icon,
                'fanart': movie_fanart or ''
            })
            li.setProperty("webshare_name", file_item.get('name', ''))
            li.setProperty("webshare_valid", "true" if file_item.get('valid', False) else "false")
            li.setProperty("webshare_lang", file_item.get('lang', ''))
            li.setProperty("webshare_quality", file_item.get('quality', ''))
            li.setProperty("webshare_size_mb", str(file_item.get('size_mb', '')))
            li.setProperty('IsPlayable', 'true')

            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('movie')
            movie_title = item.get('title', '')
            info_tag.setTitle(movie_title)
            info_tag.setPlot(build_stream_details_plot(file_item, movie_plot, original_language=orig_lang))
            if movie_genres:
                info_tag.setGenres(movie_genres)
            f_dur = file_item.get('duration') or 0
            if f_dur and f_dur > 0:
                info_tag.setDuration(int(f_dur))
            elif movie_runtime:
                info_tag.setDuration(int(movie_runtime) * 60)
            if movie_rating > 0:
                info_tag.setRating(movie_rating)
            if str(item.get('year', '')).isdigit():
                info_tag.setYear(int(item.get('year')))

            v_codec = file_item.get('video_codec') or file_item.get('codec') or ''
            if v_codec:
                li.setProperty('video_codec', v_codec)
            hdr = file_item.get('hdr_format') or file_item.get('hdr') or ''
            if hdr:
                li.setProperty('hdr_type', hdr)
            q_val = str(file_item.get('quality', '')).replace('~', '')
            w, h = 0, 0
            if q_val == '4K':
                w, h = 3840, 2160
            elif q_val == '1080p':
                w, h = 1920, 1080
            elif q_val == '720p':
                w, h = 1280, 720
            elif q_val in ('SD', '480p', '576p'):
                w, h = 720, 576

            if w > 0 or v_codec:
                try:
                    vs = xbmc.VideoStreamDetail()
                    if w > 0:
                        vs.setWidth(w)
                        vs.setHeight(h)
                    if v_codec:
                        vs.setCodec(v_codec)
                    info_tag.addVideoStream(vs)
                except Exception:
                    pass

            for a_lang in (file_item.get('audio_languages') or []):
                try:
                    info_tag.addAudioStream(xbmc.AudioStreamDetail(language=str(a_lang).lower()))
                except Exception:
                    pass
            for s_lang in (file_item.get('subtitles') or []):
                try:
                    info_tag.addSubtitleStream(xbmc.SubtitleStreamDetail(language=str(s_lang).lower()))
                except Exception:
                    pass

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "webshare_file_selected",
                    "webshare_id": file_item.get('ident', ''),
                    "name": file_item.get('name', ''),
                    "lang": file_item.get('lang', ''),
                    "quality": file_item.get('quality', ''),
                    "tmdb_info": {**item, "source": file_item.get('source', 'webshare')},
                    "tmdb_details": tmdb_details
                }),
                listitem=li,
                isFolder=False
            )
            added_count += 1

        if (cancelled or is_loading_cancelled(loading)) and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    except Exception as e:
        log_error(f"Chyba při zobrazení filmů: {e}")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    finally:
        close_loading_dialog(loading)


def show_webshare_account_info():
    """Zobrazí informace o účtu Webshare."""
    ws_token = get_ws_token()

    if not ws_token:
        dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        response = requests.post(
            "https://webshare.cz/api/user_data/",
            headers={
                "Accept": "text/xml; charset=UTF-8",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            },
            data={"wst": ws_token},
            timeout=10,
        )

        root = ET.fromstring(response.text)

        status = root.findtext("status")
        if status != "OK":
            message = root.findtext("message") or "Neznámá chyba"
            dialog_notif("Webshare chyba", message, xbmcgui.NOTIFICATION_ERROR)
            return

        username = root.findtext("username") or "-"
        vip = root.findtext("vip") == "1"
        vip_until = root.findtext("vip_until") or "-"
        vip_days = root.findtext("vip_days") or "0"
        points = root.findtext("points") or "0"

        if vip:
            vip_text = f"[COLOR green]ANO[/COLOR]\nPlatnost do: {vip_until}\nZbývá: {vip_days} dní"
        else:
            vip_text = "[COLOR red]NE[/COLOR]"

        info_message = (
            f"Uživatel: {username}\n"
            f"VIP: {vip_text}\n"
            f"Body: {points}"
        )

        dialog_ok("Informace o účtu Webshare", info_message)

    except Exception as e:
        dialog_notif("Webshare chyba", str(e), xbmcgui.NOTIFICATION_ERROR)


def run_speed_test():
    """Spustí test rychlosti stahování z Webshare s možností kdykoliv jej zrušit."""
    dp = xbmcgui.DialogProgress()
    dp.create("Test rychlosti Webshare", "Připojování a získávání testovacího odkazu...")

    ws_token = get_ws_token()
    is_vip = False
    username = ""

    # 1. Zjištění stavu účtu (VIP / Free)
    if ws_token:
        try:
            r = requests.post(
                "https://webshare.cz/api/user_data/",
                data={"wst": ws_token},
                timeout=4,
            )
            if r.status_code == 200:
                root = ET.fromstring(r.text)
                is_vip = root.findtext("vip") == "1"
                username = root.findtext("username") or ""
        except Exception:
            pass

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    dp.update(5, "Získávám přímý odkaz ze serverů Webshare...")

    # 2. Získání testovacího odkazu (vyhledáním velkého souboru nebo fallback)
    test_ident = None
    try:
        search_data = {'what': 'mkv', 'limit': 10, 'sort': 'size', 'category': 'video'}
        if ws_token:
            search_data['wst'] = ws_token
        r = requests.post("https://webshare.cz/api/search/", data=search_data, timeout=6)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            if root.findtext('status') == 'OK':
                for f in root.findall('file'):
                    size = int(f.findtext('size', '0'))
                    if size >= 200 * 1024 * 1024:
                        test_ident = f.findtext('ident')
                        break
    except Exception:
        pass

    if not test_ident:
        test_ident = "a663e0f1lw"

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    link_data = {'ident': test_ident}
    if ws_token:
        link_data['wst'] = ws_token

    download_url = None
    try:
        r = requests.post("https://webshare.cz/api/file_link/", data=link_data, timeout=6)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            if root.findtext('status') == 'OK':
                download_url = root.findtext('link')
    except Exception as e:
        log_error(f"Chyba při získávání testovacího odkazu: {e}")

    if not download_url:
        dp.close()
        dialog_ok("Chyba testu rychlosti", "Nepodařilo se získat odkaz pro stahování z Webshare.")
        return

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    dp.update(10, "Spouštím stahování a měření rychlosti...")

    test_duration = 10.0  # Max délka testu v sekundách
    max_bytes = 150 * 1024 * 1024  # Max limit dat (150 MB)
    chunk_size = 128 * 1024  # 128 KB chunk

    total_bytes = 0
    bytes_since_update = 0
    speeds = []
    start_time = None
    was_cancelled = False

    try:
        with requests.get(download_url, stream=True, timeout=8) as resp:
            resp.raise_for_status()
            start_time = time.time()
            last_update_time = start_time

            for chunk in resp.iter_content(chunk_size=chunk_size):
                if dp.iscanceled():
                    was_cancelled = True
                    break

                if not chunk:
                    continue

                total_bytes += len(chunk)
                bytes_since_update += len(chunk)
                now = time.time()
                dt = now - last_update_time

                # Průběžná aktualizace dialogu každých ~0.3 s
                if dt >= 0.3:
                    current_spd = bytes_since_update / dt
                    speeds.append(current_spd)
                    bytes_since_update = 0
                    last_update_time = now

                    elapsed = now - start_time
                    percent = min(99, int((elapsed / test_duration) * 100))

                    curr_mbps = (current_spd * 8) / (1024 * 1024)
                    curr_mbs = current_spd / (1024 * 1024)
                    avg_spd = total_bytes / elapsed if elapsed > 0 else 0
                    avg_mbps = (avg_spd * 8) / (1024 * 1024)
                    down_mb = total_bytes / (1024 * 1024)
                    rem_sec = max(0.0, test_duration - elapsed)

                    dp.update(
                        percent,
                        f"Rychlost: [COLOR lime]{curr_mbps:.1f} Mb/s[/COLOR] ({curr_mbs:.1f} MB/s)\n"
                        f"Průměr: {avg_mbps:.1f} Mb/s  •  Staženo: {down_mb:.1f} MB\n"
                        f"Zbývá: {rem_sec:.1f} s  (Stiskněte Zrušit pro ukončení)"
                    )

                if (now - start_time) >= test_duration or total_bytes >= max_bytes:
                    break

    except Exception as e:
        log_error(f"Chyba při běhu testu rychlosti: {e}")
        if not was_cancelled and total_bytes == 0:
            dp.close()
            dialog_ok("Chyba testu", f"Během stahování došlo k chybě:\n{e}")
            return
    finally:
        dp.close()

    if not start_time:
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    elapsed = max(0.1, time.time() - start_time)
    avg_speed = total_bytes / elapsed
    max_speed = max(speeds) if speeds else avg_speed

    avg_mbps = (avg_speed * 8) / (1024 * 1024)
    avg_mbs = avg_speed / (1024 * 1024)
    max_mbps = (max_speed * 8) / (1024 * 1024)
    max_mbs = max_speed / (1024 * 1024)
    down_mb = total_bytes / (1024 * 1024)

    if total_bytes == 0 and was_cancelled:
        dialog_notif("Test rychlosti", "Test byl zrušen před zahájením stahování.")
        return

    # Text doporučení a hodnocení
    if avg_mbps >= 60:
        eval_text = "[COLOR lime]Vynikající rychlost[/COLOR]\nPlynulé přehrávání i nejnáročnějších 4K HDR a REMUX filmů."
    elif avg_mbps >= 25:
        eval_text = "[COLOR lime]Velmi dobrá rychlost[/COLOR]\nBezproblémové pro 1080p a většinu 4K filmů."
    elif avg_mbps >= 10:
        eval_text = "[COLOR yellow]Průměrná rychlost[/COLOR]\nVhodné pro 720p / 1080p s nižším datovým tokem, 4K se může sekat."
    else:
        eval_text = "[COLOR red]Nízká rychlost[/COLOR]\nMůže docházet k načítání (zkontrolujte VIP účet či Wi-Fi/kabel)."

    title_dialog = "Test rychlosti (Ukončen)" if was_cancelled else "Výsledek testu rychlosti"
    header_line = "Test byl předčasně ukončen uživatelem.\nNaměřené hodnoty do ukončení:" if was_cancelled else "Měření stahování z Webshare dokončeno:"

    msg = (
        f"{header_line}\n\n"
        f"• Průměrná rychlost: [COLOR lime]{avg_mbps:.2f} Mb/s[/COLOR]  ({avg_mbs:.2f} MB/s)\n"
        f"• Maximální rychlost: [COLOR lime]{max_mbps:.2f} Mb/s[/COLOR]  ({max_mbs:.2f} MB/s)\n"
        f"• Staženo: {down_mb:.1f} MB za {elapsed:.1f} s\n"
        f"Doporučení:\n{eval_text}"
    )

    dialog_ok(title_dialog, msg)


def test_hellspy_connection():
    """Otestuje funkčnost připojení k HellSpy (vyhledávání, API i dostupnost CDN streamu)."""
    dp = xbmcgui.DialogProgress()
    dp.create("HellSpy Test připojení", "Testuji připojení k HellSpy.to...")
    try:
        from resources.lib import hellspy
        import time

        dp.update(25, "1/3: Testuji dostupnost webu a vyhledávání...")
        t0 = time.time()
        res = hellspy.search_hellspy_raw("matrix", limit=1, timeout=7)
        t_search = time.time() - t0

        if not res:
            dp.close()
            dialog_ok(
                "HellSpy Test připojení",
                "[COLOR orange]Částečná odezva:[/COLOR]\n\n"
                "Server HellSpy odpověděl, ale vyhledávání nevrátilo žádný výsledek.\n"
                "Web může být dočasně přetížený nebo provádí údržbu."
            )
            return

        dp.update(65, "2/3: Testuji oficiální download & stream API...")
        v = res[0]
        t1 = time.time()
        dl_url = hellspy.get_hellspy_download_url(v.get('id'), v.get('fileHash'), timeout=7)
        t_api = time.time() - t1

        if not dl_url:
            dp.close()
            dialog_ok(
                "HellSpy Test připojení",
                f"[COLOR orange]Pozor:[/COLOR]\n\n"
                f"• Vyhledávání: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
                f"• Stream API: [COLOR red]Chyba[/COLOR] (nepodařilo se získat odkaz z CDN)\n\n"
                f"Zkuste test opakovat za malou chvíli."
            )
            return

        dp.update(90, "3/3: Ověřuji přímý stream na CDN...")
        t2 = time.time()
        cdn_ok = False
        try:
            req = urllib.request.Request(dl_url, headers={
                "User-Agent": hellspy.USER_AGENT,
                "Range": "bytes=0-100"
            })
            with urllib.request.urlopen(req, timeout=5) as c_resp:
                if c_resp.status in (200, 206):
                    cdn_ok = True
        except Exception as ce:
            log_debug(f"HellSpy CDN test: {ce}")
            cdn_ok = False
        t_cdn = time.time() - t2

        dp.close()

        total_time = t_search + t_api + t_cdn
        status_cdn = f"[COLOR lime]Funkční[/COLOR] (HTTP 206, {t_cdn:.2f} s)" if cdn_ok else "[COLOR yellow]Částečně dostupné[/COLOR]"

        dialog_ok(
            "HellSpy Test připojení - OK",
            f"• Vyhledávání videí: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
            f"• Oficiální stream API: [COLOR lime]OK[/COLOR] ({t_api:.2f} s)\n"
            f"• CDN přehrávání: {status_cdn}\n"
            f"• Celková odezva: [B]{total_time:.2f} s[/B]\n"
        )

    except Exception as e:
        dp.close()
        log_error(f"Chyba při testu HellSpy připojení: {e}")
        dialog_ok(
            "HellSpy Test připojení",
            f"[COLOR red][B]Test připojení k HellSpy selhal![/B][/COLOR]\n\n"
            f"Chyba: {e}\n\n"
            f"Zkontrolujte připojení k internetu nebo dostupnost serveru hellspy.to."
        )


def test_prehrajto_connection():
    """Otestuje funkčnost připojení k Přehraj.to (vyhledávání i přímý CDN stream)."""
    dp = xbmcgui.DialogProgress()
    dp.create("Přehraj.to Test připojení", "Testuji připojení k Prehrajto.cz...")
    try:
        from resources.lib import prehrajto
        import time

        dp.update(25, "1/3: Testuji dostupnost webu a vyhledávání...")
        t0 = time.time()
        res = prehrajto.search_prehrajto_raw("matrix", limit=1, timeout=7)
        t_search = time.time() - t0

        if not res:
            dp.close()
            dialog_ok(
                "Přehraj.to Test připojení",
                "[COLOR orange]Částečná odezva:[/COLOR]\n\n"
                "Server Prehrajto.cz neodpověděl nebo je dočasně přetížený (HTTP 429).\n"
                "Zkuste test opakovat za malou chvíli."
            )
            return

        dp.update(65, "2/3: Testuji extrakci přímého streamu...")
        card = res[0]
        t1 = time.time()
        stream_url = prehrajto.get_prehrajto_direct_url(card.get('href'), timeout=7)
        t_stream = time.time() - t1

        if not stream_url:
            dp.close()
            dialog_ok(
                "Přehraj.to Test připojení",
                f"[COLOR orange]Pozor:[/COLOR]\n\n"
                f"• Vyhledávání: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
                f"• Extrakce streamu: [COLOR red]Chyba[/COLOR] (nepodařilo se získat odkaz z videa)\n\n"
                f"Zkuste test opakovat za malou chvíli."
            )
            return

        dp.update(90, "3/3: Ověřuji přímý CDN stream...")
        t2 = time.time()
        cdn_ok = False
        try:
            req = urllib.request.Request(stream_url, headers={
                "User-Agent": prehrajto.USER_AGENT,
                "Referer": "https://prehrajto.cz/",
                "Range": "bytes=0-100"
            })
            with urllib.request.urlopen(req, timeout=5) as c_resp:
                if c_resp.status in (200, 206):
                    cdn_ok = True
        except Exception as ce:
            log_debug(f"Prehraj.to CDN test: {ce}")
            cdn_ok = False
        t_cdn = time.time() - t2

        dp.close()

        total_time = t_search + t_stream + t_cdn
        if cdn_ok:
            status_cdn = "[COLOR lime]Funkční[/COLOR] (HTTP 206, " + f"{t_cdn:.2f}" + " s)"
        else:
            status_cdn = "[COLOR yellow]Částečně dostupné[/COLOR]"

        dialog_ok(
            "Přehraj.to Test připojení - OK",
            f"• Vyhledávání videí: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
            f"• Extrakce CDN streamu: [COLOR lime]OK[/COLOR] ({t_stream:.2f} s)\n"
            f"• CDN přehrávání: {status_cdn}\n"
            f"• Celková odezva: [B]{total_time:.2f} s[/B]\n"
        )

    except Exception as e:
        dp.close()
        log_error(f"Chyba při testu Přehraj.to připojení: {e}")
        dialog_ok(
            "Přehraj.to Test připojení",
            f"[COLOR red][B]Test připojení k Přehraj.to selhal![/B][/COLOR]\n\n"
            f"Chyba: {e}\n\n"
            f"Zkontrolujte připojení k internetu nebo dostupnost serveru prehrajto.cz."
        )


def test_english_connection():
    """Otestuje funkčnost resolverů pro anglické zdroje (Streamtape, Mixdrop, Filemoon)."""
    dp = xbmcgui.DialogProgress()
    dp.create("Anglické zdroje - Test", "Testuji dostupnost resolverů...")
    try:
        dp.update(30, "1/2: Kontroluji modul ResolveURL...")
        has_resolveurl = False
        resolveurl_ver = ""
        try:
            import importlib
            res_mod = importlib.import_module("resolveurl")
            if res_mod:
                has_resolveurl = True
                resolveurl_ver = getattr(res_mod, '__version__', 'instalován')
        except Exception:
            pass

        dp.update(70, "2/2: Kontroluji vestavěné resolvery (Streamtape, Mixdrop)...")
        from resources.lib import english_sources

        dp.close()

        if has_resolveurl:
            res_url_txt = "[COLOR lime]Ano (" + str(resolveurl_ver) + ")[/COLOR]"
        else:
            res_url_txt = "[COLOR yellow]Ne (použijí se vestavěné resolvery)[/COLOR]"

        dialog_ok(
            "Anglické zdroje - OK",
            f"• Podporované servery: [B]Streamtape, Mixdrop, Filemoon[/B]\n"
            f"• ResolveURL modul: {res_url_txt}\n"
            f"• Vestavěný Dean Edwards JS unpacker: [COLOR lime]Aktivní[/COLOR]\n"
            f"• Vestavěný Streamtape extractor: [COLOR lime]Aktivní[/COLOR]\n"
        )
    except Exception as e:
        dp.close()
        log_error(f"Chyba při testu anglických zdrojů: {e}")
        dialog_ok(
            "Anglické zdroje - Test",
            f"[COLOR red][B]Chyba při inicializaci anglických zdrojů![/B][/COLOR]\n\n"
            f"Chyba: {e}"
        )


def check_buffer_recommendation():
    """Zkontroluje velikost vyrovnávací paměti Kodi a pokud je tovární/malá (< 40MB), nabídne uživateli optimalizaci."""
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty('buffer_prompt_shown_this_session') == 'true':
            return

        dismissed = ADDON.getSetting('buffer_warning_dismissed')
        if str(dismissed).lower() == 'true':
            return

        buf_info = buffer_manager.get_current_buffer_info()
        if buf_info.get('is_small', False):
            window.setProperty('buffer_prompt_shown_this_session', 'true')
            curr_mb = buf_info.get('memory_size_mb', 20)
            heading = "Optimalizace bufferu"
            msg = (
                f"Buffer Kodi je pouze {curr_mb} MB (může se sekat 4K/FHD).\n\n"
                "Nastavit doporučených 150 MB RAM?"
            )
            dialog = xbmcgui.Dialog()
            try:
                # Kodi C++ API vyžaduje poziční argumenty: (heading, message, customlabel, nolabel, yeslabel)
                choice = dialog.yesnocustom(
                    heading,
                    msg,
                    "Nezobrazovat",
                    "Později",
                    "Nastavit 150 MB"
                )
            except Exception:
                res = dialog.yesno(heading, msg, "Zrušit", "Nastavit 150 MB")
                choice = 1 if res else 0

            if choice == 1:
                success, err = buffer_manager.set_buffer_size(150, buffermode=1, readfactor=20)
                if success:
                    buffer_manager.update_addon_buffer_setting(ADDON)
                    dialog_ok("Buffer nastaven", "Nastaveno [B]150 MB[/B]. Změna platí po restartu Kodi.")
                else:
                    dialog_ok("Chyba", f"Zápis selhal: {err}")
            elif choice == 2:
                ADDON.setSetting('buffer_warning_dismissed', 'true')
                dialog_notif("Buffer", "Upozornění vypnuto.")
    except Exception as e:
        log_error(f"Chyba při kontrole bufferu: {e}")


def configure_buffer_dialog():
    """Interaktivní dialog pro správu a nastavení vyrovnávací paměti Kodi."""
    try:
        buf_info = buffer_manager.get_current_buffer_info()
        curr_mb = buf_info.get('memory_size_mb', 20)
        has_custom = buf_info.get('configured', False)
        b_mode = buf_info.get('buffermode', 1)
        r_factor = buf_info.get('readfactor', 4)

        status_tag = f"{curr_mb} MB"
        if not has_custom:
            status_tag += " (výchozí)"
        else:
            status_tag += f" (vlastní, mód {b_mode})"

        options = [
            f"Info o bufferu ({status_tag})",
            "150 MB [Doporučeno pro 4K/FullHD]",
            "250 MB [Velký - pro výkonná PC/TV]",
            "80 MB [Úsporný - pro slabší TV]",
            "20 MB [Výchozí]",
            "Znovu zapnout upozornění při startu"
        ]

        dialog = xbmcgui.Dialog()
        idx = dialog.select(f"Buffer (Aktuálně: {curr_mb} MB)", options)
        if idx < 0:
            return

        if idx == 0:
            ram_est = curr_mb * 3
            is_sm = buf_info.get('is_small', False)
            status_desc = "Malý (může se sekat)" if is_sm else "Optimální"
            as_path = buffer_manager.get_advancedsettings_path() or "neexistuje"

            info_msg = (
                f"• Velikost: [B]{curr_mb} MB[/B] (RAM: ~{ram_est} MB)\n"
                f"• Stahování: [B]{r_factor}x[/B] | Mód: [B]{b_mode}[/B]\n"
                f"• Stav: [B]{status_desc}[/B]\n"
                f"• Soubor: {as_path}"
            )
            dialog_ok("Info o bufferu", info_msg)
            return

        if idx == 1:
            target_mb = 150
        elif idx == 2:
            target_mb = 250
        elif idx == 3:
            target_mb = 80
        elif idx == 4:
            target_mb = 20
        elif idx == 5:
            ADDON.setSetting('buffer_warning_dismissed', 'false')
            xbmcgui.Window(10000).clearProperty('buffer_prompt_shown_this_session')
            dialog_notif("Buffer", "Upozornění zapnuto.")
            return

        success, err = buffer_manager.set_buffer_size(target_mb, buffermode=1, readfactor=20)
        if success:
            buffer_manager.update_addon_buffer_setting(ADDON)
            dialog_ok("Buffer nastaven", f"Nastaveno [B]{target_mb} MB[/B]. Změna platí po restartu Kodi.")
        else:
            dialog_ok("Chyba", f"Zápis selhal: {err}")
    except Exception as e:
        log_error(f"Chyba při nastavování bufferu: {e}")
        dialog_ok("Chyba", str(e))
        
def make_movie_context_menu(tmdb_id, title, is_watched=False, is_resume=False):
    """Vytvoří položky kontextového menu pro film."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")

    menu.append(("Informace", "Action(Info)"))

    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit jako nezhlédnuté", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit jako zhlédnuté", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))

    similar_url = f"{base_url}?mode=tmdb_list&media_type=movie&category=similar&similar_id={tmdb_id}&title={quoted_title}"
    menu.append(("Podobné tituly", f"ActivateWindow(Videos,{similar_url},return)"))

    return menu

def make_tv_context_menu(tmdb_id, title, is_watched=False, is_resume=False):
    """Vytvoří položky kontextového menu pro seriál."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")

    menu.append(("Informace", "Action(Info)"))

    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit seriál jako nezhlédnutý", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit seriál jako zhlédnutý", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))

    similar_url = f"{base_url}?mode=tmdb_list&media_type=tv&category=similar&similar_id={tmdb_id}&title={quoted_title}"
    menu.append(("Podobné tituly", f"ActivateWindow(Videos,{similar_url},return)"))

    return menu

def handle_context_search_person(tmdb_id, media_type, role_type):
    """Obsluha výběru herce nebo režiséra z kontextové nabídky titulu."""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key or not tmdb_id:
        return
    details = tmdb.get_item_details(media_type, tmdb_id, tmdb_key)
    if not details:
        dialog_notif("Chyba", "Nepodařilo se načíst detaily z TMDB", xbmcgui.NOTIFICATION_ERROR)
        return

    if role_type == "actor":
        cast = details.get('cast', [])
        if not cast:
            dialog_notif("Obsazení", "Nebyly nalezeny informace o hercích", xbmcgui.NOTIFICATION_INFO)
            return
        options = []
        for a in cast:
            a_name = a.get('name', '')
            a_role = a.get('role', '')
            options.append(f"{a_name} ({a_role})" if a_role else a_name)
        idx = xbmcgui.Dialog().select("Vyberte herce / herečku", options)
        if idx >= 0:
            selected_actor = cast[idx]['name']
            quoted = urllib.parse.quote_plus(selected_actor)
            target_url = f"plugin://plugin.video.webshare.stream.cinema.v2/?mode=search_person&query={quoted}&person_type=actor"
            xbmc.executebuiltin(f"ActivateWindow(Videos,{target_url},return)")
    else:
        directors = details.get('directors', [])
        if not directors:
            dialog_notif("Režie", "Nebyl nalezen režisér", xbmcgui.NOTIFICATION_INFO)
            return
        if len(directors) == 1:
            target_director = directors[0]
        else:
            idx = xbmcgui.Dialog().select("Vyberte režiséra", directors)
            if idx < 0:
                return
            target_director = directors[idx]
        quoted = urllib.parse.quote_plus(target_director)
        target_url = f"plugin://plugin.video.webshare.stream.cinema.v2/?mode=search_person&query={quoted}&person_type=director"
        xbmc.executebuiltin(f"ActivateWindow(Videos,{target_url},return)")

def make_season_context_menu(tmdb_id, season_number, title, is_watched=False):
    """Vytvoří položky kontextového menu pro sérii seriálu."""
    menu = [("Informace", "Action(Info)")]
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&title={quoted_title}"
        menu.append(("Označit sérii jako nezhlédnutou", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&title={quoted_title}"
        menu.append(("Označit sérii jako zhlédnutou", f"RunPlugin({watch_url})"))
    return menu

def make_episode_context_menu(tmdb_id, season_number, episode_number, title, is_watched=False, is_resume=False):
    """Vytvoří položky kontextového menu pro epizodu seriálu."""
    menu = [("Informace", "Action(Info)")]
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Označit díl jako nezhlédnutý", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Označit díl jako zhlédnutý", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))
    return menu

def show_history_menu():
    items = [
        ("Rozkoukané filmy a seriály", ICONS['RESUME'], {"mode": "history_resume_menu"}),
        ("Zhlédnuté filmy a seriály", ICONS['WATCHED'], {"mode": "history_watched_menu"}),
        ("Historie přehrávání (poslední díly a filmy)", ICONS['HISTORY'], {"mode": "history_playback_log"}),
        ("Historie vyhledávání", ICONS['SEARCH'], {"mode": "history_search"}),
    ]


    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
def show_search_history():
    """Zobrazí seznam naposledy hledaných výrazů z DB a možnosti správy."""
    handle = int(sys.argv[1])
    base_url = sys.argv[0]

    # Nastavení typu obsahu pro Kodi
    xbmcplugin.setContent(handle, "files")

    # 1. Nové vyhledávání (použije mode == "search", který vyvolá Dialog.input)
    new_search_url = f"{base_url}?mode=search"
    item_new = xbmcgui.ListItem(label="[B]Nové Hledání[/B]")
    item_new.setArt({"icon": ICONS.get('SEARCH', 'DefaultAddonsSearch.png'), "thumb": ICONS.get('SEARCH', 'DefaultAddonsSearch.png')})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=new_search_url, listitem=item_new, isFolder=True
    )

    # 2. Načtení historie z DB
    history_items = db.get_search_history(limit=20)

    for query in history_items:
        encoded_query = urllib.parse.quote_plus(query)
        item_url = f"{base_url}?mode=search_predefined&search_arg={encoded_query}"

        if query.startswith("[H] "):
            item_icon = ICONS.get('ACTOR', ICONS.get('HISTORY', 'DefaultFolder.png'))
        elif query.startswith("[R] "):
            item_icon = ICONS.get('DIRECTOR', ICONS.get('HISTORY', 'DefaultFolder.png'))
        else:
            item_icon = ICONS.get('HISTORY', 'DefaultFolder.png')

        list_item = xbmcgui.ListItem(label=query)
        list_item.setArt({"icon": item_icon, "thumb": item_icon})

        delete_url = f"{base_url}?mode=delete_search&query={encoded_query}"
        list_item.addContextMenuItems(
            [("Smazat z historie", f"RunPlugin({delete_url})")]
        )

        xbmcplugin.addDirectoryItem(
            handle=handle, url=item_url, listitem=list_item, isFolder=True
        )

    xbmcplugin.endOfDirectory(handle)

    
def format_seconds(seconds):
    """Pomocná funkce pro převod sekund na HH:MM:SS."""
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"

def history_resume_menu():
    """
    Zobrazí seznam rozkoukaných filmů a seriálů s procenty, časy a plakáty.
    - Film: Otevře dostupné soubory filmu (search_webshare) a při přehrání nabídne pokračovat
    - Seriál: Otevře seznam sérií daného seriálu s indikátory rozkoukání
    """
    items = db.get_in_progress_items(limit=50)


    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádné rozkoukané položky[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api_key = ADDON.getSetting('tmdb_api_key')

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        details = item.get('details', {}) or {}

        # Pokud chybí metadata v DB, dotáhneme z TMDB a uložíme do DB
        if not details.get('poster') and tmdb_id and api_key:
            tmdb_details = tmdb.get_item_details(media_type, tmdb_id, api_key)
            if tmdb_details:
                details = {**tmdb_details, **details}
                db.save_item_metadata(tmdb_id, media_type, title, details=details)

        year_val = details.get('year') or details.get('release_date', '')[:4] or details.get('first_air_date', '')[:4] or ''
        year_str = year_val if year_val else "N/A"
        poster = details.get('poster') or details.get('thumb') or ''
        poster_p = details.get('poster_path')
        if not poster and poster_p:
            poster = f"https://image.tmdb.org/t/p/w500{poster_p}"
        fanart = details.get('fanart') or ''
        backdrop_p = details.get('backdrop_path')
        if not fanart and backdrop_p:
            fanart = f"https://image.tmdb.org/t/p/original{backdrop_p}"

        if media_type == "tv":
            num_eps = details.get('number_of_episodes') or 0
            show_pct = db.get_tv_show_progress(tmdb_id, num_eps)
            season_cnt = details.get('number_of_seasons') or 0
            season_cnt_str = format_season_count(season_cnt)
            season_text = f" • [COLOR lime]{season_cnt_str}[/COLOR]" if season_cnt else ""

            last_s = item.get('season', 0)
            last_e = item.get('episode', 0)
            ep_info = f" • [COLOR yellow]Naposledy: S{last_s:02d}E{last_e:02d}[/COLOR]" if (last_s > 0 and last_e > 0) else ""
            
            label = f"{title} [COLOR orange]({show_pct}%)[/COLOR] [COLOR grey]({year_str})[/COLOR]{season_text}{ep_info}"

            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_tv_context_menu(tmdb_id, title, is_watched=False, is_resume=True))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or details.get('original_name') or title,
                "year": year_val,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
            })
        else:
            resume_time = item.get('resume_time', 0)
            total_time = item.get('total_time', 0)
            pct = int((resume_time / total_time) * 100) if total_time > 0 else 0
            time_str = f" • {format_seconds(resume_time)} / {format_seconds(total_time)}" if total_time > 0 else ""
            label = f"{title} [COLOR orange]({pct}%)[/COLOR] [COLOR grey]({year_str})[/COLOR]{time_str}"

            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=False, is_resume=True))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or title,
                "year": year_val,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
            })

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setOriginalTitle(details.get('original_title') or details.get('original_name') or title)
        info_tag.setPlot(details.get('overview', ''))
        info_tag.setPlotOutline(details.get('tagline', ''))
        info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')
        if year_val.isdigit():
            info_tag.setYear(int(year_val))
        if details.get('rating') or details.get('vote_average'):
            try:
                info_tag.setRating(float(details.get('rating') or details.get('vote_average') or 0))
            except (ValueError, TypeError):
                pass
        if details.get('runtime'):
            try:
                info_tag.setDuration(int(details['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        if item.get('resume_time', 0) > 0:
            info_tag.setResumePoint(item['resume_time'], item.get('total_time', 0))

        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)



def history_watched_menu():
    """Zobrazí seznam zhlédnutých filmů a dokončených seriálů s plnými metadaty a plakáty."""
    items = db.get_watched_items(limit=50)


    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádné zhlédnuté položky[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api_key = ADDON.getSetting('tmdb_api_key')

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        details = item.get('details', {}) or {}

        if not details.get('poster') and tmdb_id and api_key:
            tmdb_details = tmdb.get_item_details(media_type, tmdb_id, api_key)
            if tmdb_details:
                details = {**tmdb_details, **details}
                db.save_item_metadata(tmdb_id, media_type, title, details=details)

        year_val = details.get('year') or details.get('release_date', '')[:4] or details.get('first_air_date', '')[:4] or ''
        year_str = year_val if year_val else "N/A"
        poster = details.get('poster') or details.get('thumb') or ''
        poster_p = details.get('poster_path')
        if not poster and poster_p:
            poster = f"https://image.tmdb.org/t/p/w500{poster_p}"
        fanart = details.get('fanart') or ''
        backdrop_p = details.get('backdrop_path')
        if not fanart and backdrop_p:
            fanart = f"https://image.tmdb.org/t/p/original{backdrop_p}"

        if media_type == "tv":
            season_cnt = details.get('number_of_seasons') or 0
            season_cnt_str = format_season_count(season_cnt)
            season_text = f" • [COLOR lime]{season_cnt_str}[/COLOR]" if season_cnt else ""
            label = f"[COLOR gray]{title}[/COLOR] [COLOR lime](Zhlédnuto - Celý seriál)[/COLOR] [COLOR grey]({year_str})[/COLOR]{season_text}"
            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_tv_context_menu(tmdb_id, title, is_watched=True, is_resume=False))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or details.get('original_name') or title,
                "year": year_val,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
            })
        else:
            label = f"[COLOR gray]{title}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR] [COLOR grey]({year_str})[/COLOR]"
            li = xbmcgui.ListItem(label=label)

            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=True, is_resume=False))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or title,
                "year": year_val,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
            })

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setOriginalTitle(details.get('original_title') or details.get('original_name') or title)
        info_tag.setPlot(details.get('overview', ''))
        info_tag.setPlotOutline(details.get('tagline', ''))
        info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')
        info_tag.setPlaycount(1)

        if year_val.isdigit():
            info_tag.setYear(int(year_val))
        if details.get('rating') or details.get('vote_average'):
            try:
                info_tag.setRating(float(details.get('rating') or details.get('vote_average') or 0))
            except (ValueError, TypeError):
                pass
        if details.get('runtime'):
            try:
                info_tag.setDuration(int(details['runtime']) * 60)
            except (ValueError, TypeError):
                pass

        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)



def history_playback_log():
    """Zobrazí chronologický přehled nedávno přehrávaných videí (filmů i konkrétních epizod)."""
    items = db.get_playback_history(limit=50)

    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádná historie přehrávání[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        season = item.get('season', 0)
        episode = item.get('episode', 0)
        is_watched = item.get('watched', False)
        resume_time = item.get('resume_time', 0)
        total_time = item.get('total_time', 0)
        details = item.get('details', {}) or {}

        if media_type == "tv" and season > 0 and episode > 0:
            ep_tag = f"S{season:02d}E{episode:02d}"
            base_label = f"{title} - {ep_tag}"
            if is_watched:
                label = f"[COLOR gray]{base_label}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR]"
            elif resume_time > 15 and total_time > 0:
                pct = int((resume_time / total_time) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label

            url = build_url({
                "mode": "tv_episode_selected",
                "title": title,
                "tmdb_id": tmdb_id,
                "season_number": season,
                "episode_number": episode,
                "year": details.get('year', '')
            })
            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_episode_context_menu(tmdb_id, season, episode, title, is_watched=is_watched, is_resume=(resume_time > 15 and not is_watched)))
        else:
            base_label = title
            if is_watched:
                label = f"[COLOR gray]{base_label}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR]"
            elif resume_time > 15 and total_time > 0:
                pct = int((resume_time / total_time) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
                "year": details.get('year', '')
            })
            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=is_watched, is_resume=(resume_time > 15 and not is_watched)))

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        if is_watched:
            info_tag.setPlaycount(1)
        if resume_time > 0:
            info_tag.setResumePoint(resume_time, total_time)

        poster = details.get('poster') or details.get('thumb') or ''
        fanart = details.get('fanart') or ''
        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
def router(paramstring):
    """Směrování parametrů"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get("mode")

    if mode == "open_settings":
        whitelist.get_hw_code()
        buffer_manager.update_addon_buffer_setting(ADDON)
        ADDON.openSettings()
        return
    elif mode == "check_whitelist":
        whitelist.show_whitelist_status_dialog()
        return

    # Ověření přístupových práv přes Supabase whitelist
    if not whitelist.ensure_access():
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not mode:
        db.cleanup_cache(ttl_days=7)
        main_menu()
    elif mode == "movies_menu":
        sub_menu("movie")
    elif mode == "tv_menu":
        sub_menu("tv")
    elif mode == "fresh_releases":
        show_fresh_releases_menu(
            media_type=params.get("media_type", "movie"),
            release_type=params.get("release_type", "dubbed"),
            page=int(params.get("page", 1))
        )
    elif mode == "genres_menu":
        genres_menu(params.get("media_type", "movie"))
    elif mode == "years_menu":
        years_menu(params.get("media_type", "movie"))
    elif mode == "open_settings":
        whitelist.get_hw_code()
        buffer_manager.update_addon_buffer_setting(ADDON)
        ADDON.openSettings()
    elif mode == "tmdb_list":
        tmdb_list_menu(
            media_type=params.get("media_type", "movie"),
            category=params.get("category", "popular"),
            genre_id=params.get("genre_id"),
            page=params.get("page", 1),
            similar_id=params.get("similar_id"),
            item_title=params.get("title", ""),
            year=params.get("year"),
            genre_name=params.get("genre_name")
        )
    elif mode == "search":
        query = xbmcgui.Dialog().input("Hledat film nebo seriál")
        if query:
            db.add_search_query(query)
            search_tmdb_menu(query)
    elif mode == "search_predefined":
        query = params.get("search_arg", "")
        if query.startswith("[H] "):
            search_person_menu(query[4:].strip(), "actor")
        elif query.startswith("[R] "):
            search_person_menu(query[4:].strip(), "director")
        else:
            db.add_search_query(query)
            search_tmdb_menu(query)
    elif mode == "advanced_search_menu":
        show_advanced_search_menu()
    elif mode == "advanced_search_input":
        person_type = params.get("person_type", "actor")
        prompt = "Zadejte jméno herce / herečky" if person_type == "actor" else "Zadejte jméno režiséra / režisérky"
        query = xbmcgui.Dialog().input(prompt)
        if query:
            prefix = "[H]" if person_type == "actor" else "[R]"
            db.add_search_query(f"{prefix} {query}")
            search_person_menu(query, person_type)
    elif mode == "person_credits":
        show_person_credits_menu(
            person_id=params.get("person_id"),
            person_name=params.get("person_name", ""),
            person_type=params.get("person_type", "actor"),
            page=int(params.get("page", 1)),
            person_profile=params.get("person_profile", ""),
            known_for=params.get("known_for", "")
        )
    elif mode == "person_info_dialog":
        p_name = params.get("person_name", "")
        p_type = "Herec" if params.get("person_type") == "actor" else "Režisér"
        tot = params.get("total_items", "")
        kf = params.get("known_for", "")
        msg = f"Osoba: {p_name}\nObor: {p_type}\nCelkem filmů a seriálů: {tot}"
        if kf:
            msg += f"\nZnámé z: {kf}"
        dialog_ok(p_name, msg)
    elif mode == "search_person":
        query = params.get("query", "")
        person_type = params.get("person_type", "actor")
        if query:
            search_person_menu(query, person_type)
    elif mode == "context_search_person":
        tmdb_id = params.get("tmdb_id")
        media_type = params.get("media_type", "movie")
        role_type = params.get("role_type", "actor")
        handle_context_search_person(tmdb_id, media_type, role_type)
    elif mode == "search_webshare":
        show_webshare_results_menu({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "media_type": params.get("media_type", "movie"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", "")
        })
    elif mode == "tv_season_selected":
        show_tv_episode_menu({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", ""),
        }, int(params.get("season_number", 0)))
    elif mode == "tv_episode_selected":
        show_tv_episode_files({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", ""),
            "episode_name": params.get("episode_name", ""),
            "episode_plot": params.get("episode_plot", ""),
            "episode_still": params.get("episode_still", ""),
        }, int(params.get("season_number", 0)), int(params.get("episode_number", 0)))
    elif mode == "webshare_file_selected":
        player.play_webshare_video(
            file_id=params.get("webshare_id", ""),
            file_name=params.get("name", ""),
            tmdb_info=params.get("tmdb_info"),
            season=int(params.get("season_number", 0)),
            episode=int(params.get("episode_number", 0)),
            wst_token=get_ws_token(),
            tmdb_details=params.get("tmdb_details"),
            episode_name=params.get("episode_name", ""),
            episode_plot=params.get("episode_plot", ""),
            episode_still=params.get("episode_still", ""),
            media_type=params.get("media_type")
        )
    elif mode == "series_selected":
        sel_title = params.get('title', '')
        dialog_ok("Seriál", f"Vybraná série: {sel_title}")
    elif mode == "show_account_info":
        show_webshare_account_info()
    elif mode == "run_speed_test":
        run_speed_test()
    elif mode == "test_hellspy_connection":
        test_hellspy_connection()
    elif mode == "test_prehrajto_connection":
        test_prehrajto_connection()
    elif mode == "test_english_connection":
        test_english_connection()
    elif mode == "configure_buffer":
        configure_buffer_dialog()
    elif mode == "history":
        show_history_menu()
    elif mode == "history_search":
        show_search_history()
    elif mode == "history_resume_menu":
        history_resume_menu()
    elif mode == "history_watched_menu":
        history_watched_menu()
    elif mode == "history_playback_log":
        history_playback_log()
    elif mode == "mark_watched":
        item_title = params.get("title", "")
        db.mark_item_watched(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0)),
            title=item_title
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Označeno jako zhlédnuté: {item_title}" if item_title else "Označeno jako zhlédnuté"
        dialog_notif("Webshare", msg)
    elif mode == "mark_unwatched":
        item_title = params.get("title", "")
        db.mark_item_unwatched(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0))
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Označeno jako nezhlédnuté: {item_title}" if item_title else "Označeno jako nezhlédnuté"
        dialog_notif("Webshare", msg)
    elif mode == "remove_resume":
        item_title = params.get("title", "")
        db.remove_from_in_progress(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0))
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Odebráno z rozkoukaných: {item_title}" if item_title else "Odebráno z rozkoukaných"
        dialog_notif("Webshare", msg)
    elif mode == "clear_resume_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat celou historii rozkoukaných?"):
            db.clear_in_progress_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie rozkoukaných byla vymazána.")
    elif mode == "clear_watched_only_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat historii zhlédnutých filmů a seriálů?"):
            db.clear_watched_only_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie zhlédnutých byla vymazána.")
    elif mode == "clear_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat historii vyhledávání?"):
            db.clear_search_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie vyhledávání byla vymazána.")
    elif mode == "clear_watched_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat veškerou historii sledování (rozkoukané i zhlédnuté)?"):
            db.clear_watch_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Veškerá historie sledování byla vymazána.")


if __name__ == "__main__":
    raw_params = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(raw_params)