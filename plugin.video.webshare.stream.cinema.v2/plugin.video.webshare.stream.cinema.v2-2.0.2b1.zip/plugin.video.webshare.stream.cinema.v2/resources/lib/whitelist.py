import os
import uuid
import platform
import hashlib
import time
import requests

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcaddon = None
    xbmcvfs = None

SUPABASE_URL = "https://ewthovlfiuipyvfedrut.supabase.co/rest/v1/whitelist"
ANON_KEY = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
    "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV3dGhvdmxmaXVpcHl2ZmVkcnV0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE5ODI0MjgsImV4cCI6MjEwNzU1ODQyOH0."
    "6wbNeQ3l6iHlAk7cnO6FVlFLUtF5Lv3A2_VsLl-o88Y"
)

CACHE_TTL_SECONDS = 300  # 5 minut paměťová cache pro plynulé procházení menu


def log_debug(msg):
    if xbmc:
        xbmc.log(f"[Webshare Whitelist] {msg}", xbmc.LOGINFO)
    else:
        print(f"[Webshare Whitelist] {msg}")


def log_error(msg):
    if xbmc:
        xbmc.log(f"[Webshare Whitelist ERROR] {msg}", xbmc.LOGERROR)
    else:
        print(f"[Webshare Whitelist ERROR] {msg}")


def get_profile_path():
    """Vrátí absolutní cestu ke složce profilu doplňku."""
    if not xbmcaddon or not xbmcvfs:
        return os.path.dirname(os.path.abspath(__file__))
    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        raw_path = addon.getAddonInfo("profile")
        profile_path = xbmcvfs.translatePath(raw_path)
        if not os.path.exists(profile_path):
            os.makedirs(profile_path, exist_ok=True)
        return profile_path
    except Exception as e:
        log_error(f"Nelze získat profile path: {e}")
        return os.path.dirname(os.path.abspath(__file__))


def get_hw_code():
    """
    Vygeneruje nebo načte unikátní persistentní identifikátor zařízení (SHA-256 hash).
    Ukládá se do souboru device_hw.id v profilu doplňku, aby se neměnil při přepínání sítě.
    """
    profile_dir = get_profile_path()
    id_file = os.path.join(profile_dir, "device_hw.id")

    # 1. Zkusíme načíst uložený kód ze souboru
    if os.path.exists(id_file):
        try:
            with open(id_file, "r", encoding="utf-8") as f:
                saved_code = f.read().strip()
            if saved_code and len(saved_code) == 64:
                _sync_setting_hw_code(saved_code)
                return saved_code
        except Exception as e:
            log_error(f"Chyba při čtení device_hw.id: {e}")

    # 2. Vygenerujeme nový deterministický SHA-256 hash z hardwarových specifikací
    try:
        mac_node = str(uuid.getnode())
        sys_name = platform.system()
        node_name = platform.node()
        machine = platform.machine()
        processor = platform.processor()
        kodi_name = xbmc.getInfoLabel("System.FriendlyName") if xbmc else ""
        kodi_os = xbmc.getInfoLabel("System.OSVersionInfo") if xbmc else ""

        raw_components = [
            sys_name,
            node_name,
            machine,
            processor,
            mac_node,
            kodi_name,
            kodi_os
        ]
        raw_string = "|".join(raw_components)
        hw_hash = hashlib.sha256(raw_string.encode("utf-8")).hexdigest()
    except Exception as e:
        log_error(f"Chyba při generování hw_code: {e}")
        hw_hash = hashlib.sha256(str(uuid.uuid4()).encode("utf-8")).hexdigest()

    # 3. Uložíme kód do souboru
    try:
        with open(id_file, "w", encoding="utf-8") as f:
            f.write(hw_hash)
    except Exception as e:
        log_error(f"Nelze zapsat device_hw.id: {e}")

    _sync_setting_hw_code(hw_hash)
    return hw_hash


def _sync_setting_hw_code(hw_code):
    """Zobrazí HW kód v nastavení doplňku pro snadné opsání."""
    if not xbmcaddon:
        return
    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        current_val = addon.getSetting("whitelist_hw_code")
        if current_val != hw_code:
            addon.setSetting("whitelist_hw_code", hw_code)
    except Exception:
        pass


def get_username():
    """
    Získá uživatelské jméno / přezdívku z nastavení doplňku.
    Priorita: whitelist_username -> username (Webshare) -> Kodi FriendlyName -> 'Kodi User'
    """
    if not xbmcaddon:
        return "Kodi User"
    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        user = addon.getSetting("whitelist_username")
        if not user or not user.strip():
            user = addon.getSetting("username")
        if not user or not user.strip():
            user = xbmc.getInfoLabel("System.FriendlyName") if xbmc else ""
        if not user or not user.strip():
            user = "Kodi User"
        return user.strip()
    except Exception:
        return "Kodi User"


def get_headers(extra=None):
    headers = {
        "apikey": ANON_KEY,
        "Authorization": f"Bearer {ANON_KEY}",
    }
    if extra:
        headers.update(extra)
    return headers


def check_whitelist(force_refresh=False):
    """
    Ověří stav schválení zařízení v Supabase databázi.
    Vrací trojici: (is_approved: bool, status: str, is_new: bool)
    status může být:
      - 'approved' (schváleno)
      - 'pending' (čeká na schválení adminem)
      - 'registered' (nově odeslána žádost)
      - 'error' (chyba sítě / serveru)
    """
    hw_code = get_hw_code()
    username = get_username()

    # 1. Rychlá kontrola paměťové cache (pokud není vynucen refresh)
    if not force_refresh and xbmcgui:
        try:
            window = xbmcgui.Window(10000)
            cached_approved = window.getProperty("wsc_whitelist_approved")
            cached_time = window.getProperty("wsc_whitelist_time")
            if cached_approved == "1" and cached_time:
                elapsed = time.time() - float(cached_time)
                if elapsed < CACHE_TTL_SECONDS:
                    return True, "approved", False
        except Exception:
            pass

    # 2. SELECT dotaz na stav v Supabase
    select_url = f"{SUPABASE_URL}?hw_code=eq.{hw_code}&select=is_approved,username"
    try:
        resp = requests.get(select_url, headers=get_headers(), timeout=7)
        if resp.status_code != 200:
            log_error(f"Supabase GET selhal (status {resp.status_code}): {resp.text}")
            return False, "error", False

        records = resp.json()
    except Exception as e:
        log_error(f"Chyba při komunikaci se Supabase: {e}")
        return False, "error", False

    # 3. Zpracování existujícího záznamu
    if records and len(records) > 0:
        row = records[0]
        is_approved = bool(row.get("is_approved", False))
        db_username = row.get("username", "")

        if is_approved:
            # Uložení do paměťové cache
            if xbmcgui:
                try:
                    window = xbmcgui.Window(10000)
                    window.setProperty("wsc_whitelist_approved", "1")
                    window.setProperty("wsc_whitelist_time", str(time.time()))
                except Exception:
                    pass
            return True, "approved", False
        else:
            # Není schváleno -> vymažeme cache
            if xbmcgui:
                try:
                    xbmcgui.Window(10000).clearProperty("wsc_whitelist_approved")
                except Exception:
                    pass

            # Pokud uživatel změnil jméno v nastavení, aktualizujeme záznam v DB (upsert)
            if username and username != db_username:
                try:
                    upsert_headers = get_headers({
                        "Content-Type": "application/json",
                        "Prefer": "resolution=merge-duplicates"
                    })
                    requests.post(
                        SUPABASE_URL,
                        headers=upsert_headers,
                        json={"username": username, "hw_code": hw_code, "is_approved": False},
                        timeout=5
                    )
                except Exception as ex:
                    log_debug(f"Aktualizace username selhala: {ex}")

            return False, "pending", False

    # 4. DB nevrátila žádný záznam -> Odeslání nové žádosti (UPSERT / POST)
    try:
        upsert_headers = get_headers({
            "Content-Type": "application/json",
            "Prefer": "resolution=merge-duplicates,return=representation"
        })
        payload = {
            "username": username,
            "hw_code": hw_code,
            "is_approved": False
        }
        post_resp = requests.post(SUPABASE_URL, headers=upsert_headers, json=payload, timeout=7)
        if post_resp.status_code in (200, 201):
            log_debug(f"Úspěšně vytvořena nová žádost o přístup pro {username} ({hw_code})")
            if xbmcgui:
                try:
                    xbmcgui.Window(10000).clearProperty("wsc_whitelist_approved")
                except Exception:
                    pass
            return False, "registered", True
        else:
            log_error(f"POST do Supabase selhal (status {post_resp.status_code}): {post_resp.text}")
            return False, "error", False
    except Exception as e:
        log_error(f"Chyba při odesílání žádosti do Supabase: {e}")
        return False, "error", False


def ensure_access(force_refresh=False, silent=False):
    """
    Zkontroluje přístup. Pokud uživatel nemá přístup, zobrazí dialog a vrátí False.
    Pokud má přístup, vrátí True.
    """
    is_approved, status, is_new = check_whitelist(force_refresh=force_refresh)

    if is_approved:
        return True

    if silent or not xbmcgui:
        return False

    hw_code = get_hw_code()
    username = get_username()

    if status == "registered":
        xbmcgui.Dialog().ok(
            "Žádost odeslána",
            f"Zařízení bylo úspěšně zaregistrováno.\n\n"
            f"Přístup v tuto chvíli [COLOR orange]čeká na schválení[/COLOR].\n"
            f"Po schválení se doplněk automaticky zpřístupní."
            f"• Přezdívka: [B]{username}[/B]\n"
            f"• HW Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
        )
    elif status == "pending":
        xbmcgui.Dialog().ok(
            "Přístup nepovolen",
            f"Vaše zařízení [COLOR orange]čeká na schválení[/COLOR].\n\n"
            f"• Přezdívka: [B]{username}[/B]\n"
            f"• HW Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"Před aktivací doplňku musí admin přístup schválit."
        )
    else:  # status == "error"
        xbmcgui.Dialog().ok(
            "Chyba ověření přístupu",
            f"Nepodařilo se ověřit stav přístupu vůči serveru.\n\n"
            f"• HW Kód: {hw_code}\n"
            f"• Zkontrolujte prosím připojení k internetu a zkuste to znovu, nebo aktualizujte doplňek."
        )

    return False


def show_whitelist_status_dialog():
    """
    Manuální kontrola stavu spuštěná z nastavení doplňku.
    """
    if not xbmcgui:
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Ověřování přístupu", "Probíhá kontaktování serveru Supabase...")
    dp.update(40, "Zjišťuji stav schválení vašeho zařízení...")

    is_approved, status, is_new = check_whitelist(force_refresh=True)
    dp.close()

    hw_code = get_hw_code()
    username = get_username()

    if is_approved:
        xbmcgui.Dialog().ok(
            "Stav přístupu k doplňku",
            f"Přístup je [COLOR lime]PLNĚ SCHVÁLEN[/COLOR]!\n\n"
            f"• Přezdívka: [B]{username}[/B]\n"
            f"• HW Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"Doplněk je aktivní a můžete jej bez omezení používat."
        )
    elif status == "registered":
        xbmcgui.Dialog().ok(
            "Žádost o přístup odeslána",
            f"Nová žádost byla odeslána do databáze.\n\n"
            f"• Přezdívka: [B]{username}[/B]\n"
            f"• HW Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"Stav: [COLOR orange]Čeká na schválení administrátorem[/COLOR]."
        )
    elif status == "pending":
        xbmcgui.Dialog().ok(
            "Stav přístupu k doplňku",
            f"Stav přístupu: [COLOR orange]ČEKÁ NA SCHVÁLENÍ[/COLOR]\n\n"
            f"• Přezdívka: [B]{username}[/B]\n"
            f"• HW Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"Požádejte administrátora o schválení tohoto HW kódu v Supabase."
        )
    else:
        xbmcgui.Dialog().ok(
            "Chyba spojení se serverem",
            f"Nepodařilo se ověřit přístup vůči Supabase.\n\n"
            f"• HW Kód: {hw_code}\n"
            f"Zkontrolujte prosím připojení k internetu."
        )
