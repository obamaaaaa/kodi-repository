import sys
import json
import time
import urllib.parse
import urllib.request
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor, as_completed

import resources.lib.db as db
import resources.lib.webshare as webshare
import resources.lib.player as player
import resources.lib.tmdb as tmdb
import resources.lib.whitelist as whitelist
from resources.lib.helper import ICONS
from resources.lib import tv_navigation
from resources.lib.title_cleaner import clean_title_for_kodi, calculate_match_score
import xml.etree.ElementTree as ET

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

limit_to_search = 10
limit_to_search_quick = 5

def get_ws_token():
    """Vrátí uložený token z paměti Kodi, nebo provede nový login"""
    window = xbmcgui.Window(10000)  # Hlavní okno Kodi (drží paměť po dobu běhu Kodi)
    token = window.getProperty('ws_token')
    
    if not token:
        ws_user = ADDON.getSetting('username')
        ws_pass = ADDON.getSetting('password')
        token = webshare.login(ws_user, ws_pass)
        if token:
            window.setProperty('ws_token', token)
            
    return token

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def check_first_run_and_status():
    first_run = ADDON.getSetting('first_run_done')

    if first_run != 'true':
        ADDON.setSetting('first_run_done', 'true')
        whitelist.get_hw_code()
        dialog_ok("Vítejte v doplňku Webshare", "Doplněk byl úspěšně nainstalován. Prosím, nastavte své přihlašovací údaje a TMDB API klíč v nastavení doplňku.")
        ADDON.openSettings()
        return

    # Kontrola Webshare
    ws_user = ADDON.getSetting('username')
    ws_pass = ADDON.getSetting('password')
    ws_token = webshare.login(ws_user, ws_pass)
    ws_status = "OK" if ws_token else "CHYBA (Neplatné údaje nebo síť)"

    # Kontrola TMDB
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    tmdb_status = "CHYBA (Chybí klíč)"
    if tmdb_key:
        try:
            url = f"https://api.themoviedb.org/3/authentication?api_key={tmdb_key}"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                if data.get('success', False):
                    tmdb_status = "OK"
                else:
                    tmdb_status = "CHYBA (Neplatný API klíč)"
        except Exception:
            tmdb_status = "CHYBA (Připojení k TMDB)"

    if ws_status != "OK" or tmdb_status != "OK":
        dialog_notif("Chyba připojení", f"Webshare: {ws_status}\nTMDB API: {tmdb_status}", xbmcgui.NOTIFICATION_ERROR)
    else:
        dialog_ok("Stav připojení doplňku", f"Webshare: {ws_status}\nTMDB API: {tmdb_status}")

def log_debug(msg):
    xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)

def log_error(msg):
    xbmc.log(f"[Webshare CHYBA] {msg}", xbmc.LOGERROR)

def log_timing(msg):
    xbmc.log(f"[Webshare ČASOVÁNÍ] {msg}", xbmc.LOGINFO)

def dialog_ok(title, message):
    xbmcgui.Dialog().ok(title, message);

def dialog_notif(title, message, notif_type=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(title, message, notif_type, 5000);


def show_loading_dialog(title, message="Načítám..."):
    """Zobrazí loading dialog s textem o probíhající operaci."""
    dialog = xbmcgui.DialogProgress()
    dialog.create(title, message)
    return dialog


def close_loading_dialog(dialog):
    """Zavře loading dialog, pokud existuje."""
    if dialog:
        try:
            dialog.close()
        except Exception:
            pass


def update_loading_dialog(dialog, percent, message):
    """Aktualizuje progress dialog a jeho text. Vrátí True, pokud byl dialog zrušen."""
    if dialog:
        try:
            if dialog.iscanceled():
                return True
            dialog.update(percent, message)
            return dialog.iscanceled()
        except Exception:
            pass
    return False


def is_loading_cancelled(dialog):
    """Ověří, zda uživatel stiskl Zrušit na dialogu."""
    if dialog:
        try:
            return bool(dialog.iscanceled())
        except Exception:
            pass
    return False


def get_progress_label_suffix(tmdb_id, media_type, total_episodes=0):
    """Vrátí řetězec s procenty rozkoukání pro film nebo seriál."""
    if not tmdb_id:
        return ""
    
    if media_type == "tv":
        pct = db.get_tv_show_progress(tmdb_id, total_episodes)
        if pct >= 100:
            return " [COLOR lime](Zhlédnuto)[/COLOR]"
        elif pct > 0:
            return f" [COLOR orange]({pct}%)[/COLOR]"
    else:
        st = db.get_item_watch_status(tmdb_id, 0, 0)
        if st:
            if st.get('watched'):
                return " [COLOR lime](Zhlédnuto)[/COLOR]"
            elif st.get('total_time', 0) > 0 and st.get('resume_time', 0) > 15:
                pct = int((st['resume_time'] / st['total_time']) * 100)
                return f" [COLOR orange]({pct}%)[/COLOR]"
    return ""


def build_media_item_label(item, media_type, ws_token, prefix=""):
    """
    Sestaví popisek a jazykový řetězec pro film nebo seriál s ověřením dostupnosti na Webshare.
    Zajistí jednotné formátování jak v kategoriích (populární atd.), tak ve vyhledávání.
    """
    total_episodes = item.get('number_of_episodes', 0)
    progress_suffix = get_progress_label_suffix(item.get('id'), media_type, total_episodes)

    if media_type == 'tv':
        show_p = db.get_tv_show_progress(item.get('id'), total_episodes)
        is_watched = (show_p >= 100)
    else:
        st = db.get_item_watch_status(item.get('id'), 0, 0)
        is_watched = bool(st and st.get('watched'))

    pref_str = f"{prefix} " if prefix else ""
    raw_title = item.get('title', '')
    title_text = clean_title_for_kodi(
        raw_title,
        english_title=item.get('english_title', ''),
        original_title=item.get('original_title', ''),
        year=item.get('year', ''),
        media_type=media_type
    )
    disp_title = f"[COLOR gray]{title_text}[/COLOR]" if is_watched else title_text
    item_year = item.get('year', '')

    if media_type == "tv":
        series_check = webshare.check_tv_series(item, token=ws_token, limit=limit_to_search)
        season_count = item.get('number_of_seasons') or 0
        season_text = f"{season_count} sérií" if season_count else "? sérií"
        series_lang = series_check.get('lang', '??')
        if series_check.get('available'):
            label = f"{pref_str}{disp_title}{progress_suffix} [COLOR grey]({item_year})[/COLOR] • [COLOR lime]{season_text}[/COLOR] • [COLOR lime]{series_lang}[/COLOR]"
            lang_str = f"[COLOR lime]{series_lang}[/COLOR]"
        else:
            label = f"[COLOR gray]{pref_str}{title_text}{progress_suffix} ({item_year}) • {season_text} • S01E01 nenalezen[/COLOR]"
            lang_str = "[COLOR gray]S01E01 nenalezen[/COLOR]"
    else:
        available_files = webshare.search_and_verify_movie_quick(item, token=ws_token, media_type=media_type, limit=limit_to_search_quick).get("files", [])
        valid_files = [f for f in available_files if f.get('valid', True)]

        if not valid_files:
            label = f"[COLOR grey]NEDOSTUPNÉ: {pref_str}{title_text}{progress_suffix} ({item_year})[/COLOR]"
            lang_str = "[COLOR gray]NENALEZENO[/COLOR]"
        else:
            langs_set = set()
            for f in valid_files:
                raw_lang = str(f.get('lang', '')).upper().strip()
                if raw_lang and raw_lang != '??':
                    parts = [p.strip() for p in raw_lang.split('/') if p.strip()]
                    for p in parts:
                        if p != '??':
                            langs_set.add(p)

            def lang_sort_key(l):
                if l == 'CZ': return 0
                elif 'TIT' in l or 'SUB' in l: return 1
                elif 'SK' in l: return 2
                elif 'EN' in l: return 3
                return 4

            sorted_langs = sorted(list(langs_set), key=lang_sort_key)
            colored_langs = []
            for l in sorted_langs:
                if 'CZ' == l: colored_langs.append(f"[COLOR lime][{l}][/COLOR]")
                elif 'CZ TIT' == l or 'SK' in l: colored_langs.append(f"[COLOR yellow][{l}][/COLOR]")
                elif 'EN' in l: colored_langs.append(f"[COLOR blue][{l}][/COLOR]")
                else: colored_langs.append(f"[COLOR gray][{l}][/COLOR]")

            joined_langs = " ".join(colored_langs)
            lang_str = f" {joined_langs}" if colored_langs else ""
            label = f"{pref_str}{disp_title}{progress_suffix} [COLOR grey]({item_year})[/COLOR]  •  {lang_str}"

    return label, lang_str, is_watched


def verify_media_items_batch(items, default_media_type, ws_token, prefix="", loading=None, title_msg=""):
    """
    Ověří položky buď paralelně (podle nastavení 'exp_parallel_search'),
    nebo sekvenčně (spolehlivý fallback).
    Vrací: (verified_items, ws_wall_time, slowest_item)
    kde verified_items je seznam [(item, label, lang_str, is_w), ...] v původním pořadí.
    """
    total = len(items)
    if total == 0:
        return [], 0.0, ("", 0.0)

    exp_parallel = ADDON.getSetting('exp_parallel_search')
    is_parallel = (exp_parallel != "false")

    thread_count = 10

    def _verify_single(idx, item):
        t0 = time.time()
        mtype = item.get('media_type') or default_media_type
        pfx = ('[F]' if mtype == 'movie' else '[S]') if prefix == 'auto' else prefix
        lbl, l_str, is_w = build_media_item_label(item, mtype, ws_token, prefix=pfx)
        dur = time.time() - t0
        return idx, item, lbl, l_str, is_w, dur

    results = [None] * total
    slowest_item = ["", 0.0]
    t_start = time.time()

    if is_parallel and total > 1:
        try:
            with ThreadPoolExecutor(max_workers=min(thread_count, total)) as executor:
                future_map = {executor.submit(_verify_single, i, itm): i for i, itm in enumerate(items)}
                completed = 0
                for future in as_completed(future_map):
                    if loading and is_loading_cancelled(loading):
                        break
                    try:
                        idx, itm, lbl, l_str, is_w, dur = future.result()
                        results[idx] = (itm, lbl, l_str, is_w)
                        if dur > slowest_item[1]:
                            slowest_item[0] = itm.get('title', '')
                            slowest_item[1] = dur
                    except Exception as e:
                        log_error(f"Chyba při paralelním ověřování položky: {e}")

                    completed += 1
                    if loading:
                        pct = 10 + int((completed / total) * 85)
                        orig_idx = future_map[future]
                        cur_title = items[orig_idx].get('title', '')
                        update_loading_dialog(loading, pct, f"{title_msg}\n({completed}/{total}) Hotovo: {cur_title}")
        except Exception as e:
            log_error(f"Selhání paralelního zpracování, přepínám na sekvenční: {e}")
            results = [None] * total

    # Sekvenční zpracování (pokud je paralelní vypnuté, nebo pro položky, které nebyly dokončeny)
    for idx, item in enumerate(items):
        if results[idx] is not None:
            continue
        if loading and is_loading_cancelled(loading):
            break
        if loading:
            pct = 10 + int(((idx + 1) / total) * 85)
            item_title = item.get('title', '')
            update_loading_dialog(loading, pct, f"{title_msg}\n({idx + 1}/{total}) Zpracovávám: {item_title}")
        idx, item, lbl, l_str, is_w, dur = _verify_single(idx, item)
        results[idx] = (item, lbl, l_str, is_w)
        if dur > slowest_item[1]:
            slowest_item[0] = item.get('title', '')
            slowest_item[1] = dur

    verified = [r for r in results if r is not None]
    ws_wall_time = time.time() - t_start
    return verified, ws_wall_time, (slowest_item[0], slowest_item[1])


def tmdb_list_menu(media_type, category, genre_id=None, page=1):
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        log_error("Není zadán TMDB API klíč v nastavení doplňku.")
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        page = int(page)
    except (TypeError, ValueError):
        page = 1
    if page < 1:
        page = 1

    loading = show_loading_dialog("Načítám", f"Načítám seznam {media_type} z TMDB...")
    t_tmdb_start = time.time()
    try:
        items = tmdb.fetch_tmdb_items(
            media_type,
            category,
            tmdb_key,
            genre_id=genre_id,
            page=page,
        )
    finally:
        update_loading_dialog(loading, 10, f"Hledám na Webshare.cz...")
    t_tmdb = time.time() - t_tmdb_start

    if is_loading_cancelled(loading):
        close_loading_dialog(loading)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    ws_token = get_ws_token()

    if page > 1:
        prev_li = xbmcgui.ListItem(label=f"Zpět ({page - 1})")
        prev_li.setArt({'icon': ICONS.get('BOOK', ''), 'thumb': ICONS.get('BOOK', '')})
        prev_url = build_url({
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": category,
            "genre_id": genre_id,
            "page": page - 1
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=prev_url, listitem=prev_li, isFolder=True)
        
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    total = len(items)
    try:
        title_msg = f"Ověřuji dostupnost na Webshare... (str. {page})"
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            items, media_type, ws_token, prefix="", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        for item, label, lang_str, is_w in verified_items:
            li = xbmcgui.ListItem(label=label, label2=lang_str)
            li.setProperty('item_languages', lang_str)
            
            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            info_tag.setPlot(item['overview'])
            info_tag.setPlotOutline(item['tagline'])
            info_tag.setRating(float(item['rating']))
            info_tag.setMediaType(media_type)
            info_tag.setIMDBNumber(item.get('imdb_id', ''))

            if item['year'].isdigit():
                info_tag.setYear(int(item['year']))
            if item['release_date']:
                info_tag.setPremiered(item['release_date'])
            if item['runtime'] > 0:
                info_tag.setDuration(item['runtime'] * 60)
            if item['genres']:
                info_tag.setGenres(item['genres'])
            if item['directors']:
                info_tag.setDirectors(item['directors'])
            if item['cast']:
                actors = [xbmc.Actor(name=a['name'], role=a['role'], thumbnail=a['thumbnail']) for a in item['cast']]
                info_tag.setCast(actors)
            
            art = {}
            if item['poster']:
                art['poster'] = item['poster']
                art['thumb'] = item['poster']
            if item['fanart']:
                art['fanart'] = item['fanart']
            li.setArt(art)

            if media_type == 'tv':
                show_p = db.get_tv_show_progress(item['id'], item.get('number_of_episodes', 0))
                is_w = (show_p >= 100)
                is_r = (0 < show_p < 100)
                li.addContextMenuItems(make_tv_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
            else:
                st = db.get_item_watch_status(item['id'], 0, 0)
                is_w = bool(st and st.get('watched'))
                is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
                li.addContextMenuItems(make_movie_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
                elif is_r:
                    info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "year": item['year'],
                "media_type": media_type,
                "tmdb_id": item['id']
            })
            
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1
    finally:
        close_loading_dialog(loading)

    if cancelled and added_count == 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not cancelled:
        next_li = xbmcgui.ListItem(label=f"Další ({page + 1})")
        next_li.setArt({'icon': ICONS.get('BOOK', ''), 'thumb': ICONS.get('BOOK', '')})
        next_url = build_url({
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": category,
            "genre_id": genre_id,
            "page": page + 1
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    t_total = time.time() - t_start
    t_kodi = max(0.0, t_total - t_tmdb - t_ws_total)
    avg_ws = (t_ws_total / total) if total > 0 else 0
    slow_str = f" | Nejpomalejší ověření: '{slowest_item[0]}' ({slowest_item[1]:.2f}s)" if (total > 0 and slowest_item[1] >= 0.5) else ""
    log_timing(
        f"Načtení {media_type} ('{category}', str. {page}, {total} ks): "
        f"TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s (průměr {avg_ws:.2f}s/ks){slow_str} | "
        f"Kodi GUI={t_kodi:.2f}s | CELKEM={t_total:.2f}s"
    )
    
def main_menu():
    check_first_run_and_status()
    
    exp_adv = (ADDON.getSetting('exp_advanced_search') == 'true')
    items = [
        ("[B]Hledat[/B]", ICONS['SEARCH'], {"mode": "search"}),
    ]
    if exp_adv:
        items.append(("[B]Pokročilé hledání[/B]", ICONS['SEARCH'], {"mode": "advanced_search_menu"}))
    items.extend([
        ("Filmy", ICONS['FILM'], {"mode": "movies_menu"}),
        ("Seriály", ICONS['THEATRE'], {"mode": "tv_menu"}),
        ("Historie", ICONS['HISTORY'], {"mode": "history"}),
        ("Nastavení", ICONS['SETTINGS'], {"mode": "open_settings"}),
    ])


    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        is_folder = params["mode"] not in ["open_settings"]
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)

def sub_menu(media_type):
    """Podnabídka pro Filmy nebo Seriály"""
    type_label = "Filmy" if media_type == "movie" else "Seriály"
    
    items = [
        
        (f"Populární {type_label}", ICONS['POPULAR'], {"mode": "tmdb_list", "media_type": media_type, "category": "popular"}),
        ("Novinky na TMDB", ICONS['CALENDAR'], {"mode": "tmdb_list", "media_type": media_type, "category": "new"}),
        ("Podle kategorie", ICONS['BOOK'], {"mode": "genres_menu", "media_type": media_type})
    ]

    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu(media_type):
    """Seznam žánrů/kategorií z TMDB"""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    url = f"https://api.themoviedb.org/3/genre/{media_type}/list?api_key={tmdb_key}&language=cs-CZ"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as response:
            data = json.loads(response.read().decode('utf-8'))
            genres = data.get("genres", [])

            for genre in genres:
                li = xbmcgui.ListItem(label=genre["name"])
                item_url = build_url({
                    "mode": "tmdb_list",
                    "media_type": media_type,
                    "category": "genre",
                    "genre_id": genre["id"]
                })
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_url, listitem=li, isFolder=True)

    except Exception as e:
        dialog_notif("Chyba", f"Nelze načíst žánry: {e}", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(HANDLE)

def search_tmdb_menu(query):
    """Vyhledá položky v TMDB a zobrazí je s prefixem [F]/[S]."""
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        log_error("Není zadán TMDB API klíč v nastavení doplňku.")
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    loading = show_loading_dialog("Vyhledávám", f"Vyhledávám (TMDB): {query}")
    t_tmdb_start = time.time()
    try:
        items = tmdb.search_tmdb_items(
            query,
            tmdb_key
        )
    finally:
        close_loading_dialog(loading)
    t_tmdb = time.time() - t_tmdb_start

    if is_loading_cancelled(loading):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
        
    if not items:
        li = xbmcgui.ListItem(label="Nic nenalezeno")
        li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        log_timing(f"Hledání '{query}': 0 položek | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
        return

    ws_token = get_ws_token()
    total = len(items)
    loading = show_loading_dialog("Vytvářím", "Ověřuji dostupnost a jazyky na Webshare.cz...")
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    try:
        title_msg = f"Ověřuji dostupnost '{query}' na Webshare..."
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            items, 'movie', ws_token, prefix="auto", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        # Řazení vyhledaných výsledků:
        # 1. Nalezené / dostupné na Webshare mají absolutní přednost před nedostupnými
        # 2. Skóre shody s vyhledávaným dotazem (přesný název > začíná na dotaz > obsažená slova > preference typu média s/f)
        # 3. Hodnocení / rating TMDB
        def search_rank_key(res_tuple):
            itm, lbl, l_str, is_w = res_tuple
            is_avail = not ("NENALEZENO" in l_str or "nenalezen" in l_str.lower() or "NEDOSTUPNÉ:" in lbl)
            avail_score = 1 if is_avail else 0
            match_score = calculate_match_score(query, itm)
            rating = float(itm.get('rating') or 0.0)
            year_val = int(itm.get('year')) if str(itm.get('year', '')).isdigit() else 0
            return (-avail_score, -match_score, -rating, -year_val)

        sorted_verified_items = sorted(verified_items, key=search_rank_key)

        for item, label, lang_str, is_w in sorted_verified_items:
            media_type = item.get('media_type', 'movie')

            li = xbmcgui.ListItem(label=label, label2=lang_str)
            li.setProperty('item_languages', lang_str)

            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            info_tag.setPlot(item['overview'])
            info_tag.setPlotOutline(item['tagline'])
            info_tag.setRating(float(item['rating']))
            info_tag.setMediaType(media_type)

            if item['year'].isdigit():
                info_tag.setYear(int(item['year']))
            if item['release_date']:
                info_tag.setPremiered(item['release_date'])
            if item['runtime'] > 0:
                info_tag.setDuration(item['runtime'] * 60)
            if item['genres']:
                info_tag.setGenres(item['genres'])
            if item['directors']:
                info_tag.setDirectors(item['directors'])
            if item['cast']:
                actors = [
                    xbmc.Actor(
                        name=actor['name'],
                        role=actor['role'],
                        thumbnail=actor['thumbnail']
                    )
                    for actor in item['cast']
                ]
                info_tag.setCast(actors)

            art = {}
            if item['poster']:
                art['poster'] = item['poster']
                art['thumb'] = item['poster']
            if item['fanart']:
                art['fanart'] = item['fanart']
            li.setArt(art)

            if media_type == 'tv':
                show_p = db.get_tv_show_progress(item['id'], item.get('number_of_episodes', 0))
                is_w = (show_p >= 100)
                is_r = (0 < show_p < 100)
                li.addContextMenuItems(make_tv_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
            else:
                st = db.get_item_watch_status(item['id'], 0, 0)
                is_w = bool(st and st.get('watched'))
                is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
                li.addContextMenuItems(make_movie_context_menu(item['id'], item['title'], is_watched=is_w, is_resume=is_r))
                if is_w:
                    info_tag.setPlaycount(1)
                elif is_r:
                    info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "original_title": item.get('original_title') or item['title'],
                "year": item['year'],
                "media_type": media_type,
                "tmdb_id": item['id']
            })

            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1
    finally:
        close_loading_dialog(loading)

    if cancelled and added_count == 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    t_total = time.time() - t_start
    t_kodi = max(0.0, t_total - t_tmdb - t_ws_total)
    avg_ws = (t_ws_total / total) if total > 0 else 0
    slow_str = f" | Nejpomalejší ověření: '{slowest_item[0]}' ({slowest_item[1]:.2f}s)" if (total > 0 and slowest_item[1] >= 0.5) else ""
    log_timing(
        f"Hledání '{query}' ({total} položek): "
        f"TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s (průměr {avg_ws:.2f}s/ks){slow_str} | "
        f"Kodi GUI={t_kodi:.2f}s | CELKEM={t_total:.2f}s"
    )

def show_advanced_search_menu():
    """Zobrazí nabídku pokročilého hledání (podle herce nebo režiséra)."""
    items = [
        ("Hledat podle herce / herečky", ICONS['SEARCH'], {"mode": "advanced_search_input", "person_type": "actor"}),
        ("Hledat podle režiséra / režisérky", ICONS['SEARCH'], {"mode": "advanced_search_input", "person_type": "director"}),
    ]
    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon, 'thumb': icon})
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def search_person_menu(query, person_type):
    """Vyhledá osoby na TMDB a zobrazí výběr nebo rovnou jejich filmografii."""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    loading = show_loading_dialog("Vyhledávám", f"Vyhledávám osobu: {query}")
    try:
        persons = tmdb.search_tmdb_person(query, tmdb_key)
    finally:
        close_loading_dialog(loading)

    if not persons:
        dialog_ok("Hledání", f"Pro dotaz '{query}' nebyla nalezena žádná osoba.")
        return

    if len(persons) == 1:
        show_person_credits_menu(persons[0]['id'], persons[0]['name'], person_type, page=1)
        return

    for p in persons:
        name = p.get('name', '')
        known_for = p.get('known_for_str', '')
        label = f"{name} [COLOR gray]({known_for})[/COLOR]" if known_for else name
        dept = p.get('known_for_department', '')
        label2 = f"Obor: {dept}" if dept else ""
        li = xbmcgui.ListItem(label=label, label2=label2)
        prof = p.get('profile') or ICONS.get('SEARCH', '')
        li.setArt({'icon': prof, 'thumb': prof})
        url = build_url({
            "mode": "person_credits",
            "person_id": p['id'],
            "person_name": name,
            "person_type": person_type,
            "page": 1
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_person_credits_menu(person_id, person_name, person_type, page=1):
    """Zobrazí filmy dané osoby (herec/režisér) od nejnovějších po nejstarší s ověřením na Webshare."""
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    type_title = "Herec" if person_type == "actor" else "Režisér"
    loading = show_loading_dialog("Načítám", f"Načítám filmografii: {person_name} ({type_title})...")
    t_tmdb_start = time.time()
    try:
        all_movies = tmdb.get_person_movie_credits(person_id, person_type, tmdb_key)
    finally:
        close_loading_dialog(loading)
    t_tmdb = time.time() - t_tmdb_start

    if not all_movies:
        dialog_ok("Filmografie", f"Pro '{person_name}' nebyly nalezeny žádné filmy.")
        return

    try:
        items_per_page = int(float(ADDON.getSetting('items_per_page') or 20))
    except Exception:
        items_per_page = 20

    total_movies = len(all_movies)
    start_idx = (page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    page_items = all_movies[start_idx:end_idx]

    if not page_items:
        dialog_ok("Filmografie", "Žádné další filmy na této stránce.")
        return

    ws_token = get_ws_token()
    first_year = page_items[0].get('year', '') if page_items else ''
    first_year_suffix = f" ({first_year}...)" if first_year else ""
    loading = show_loading_dialog("Ověřuji", f"Ověřuji filmy na Webshare{first_year_suffix}")
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    try:
        title_msg = f"Ověřuji filmy: {person_name} (str. {page})..."
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            page_items, 'movie', ws_token, prefix="[F]", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        for item, base_label, lang_str, is_w in verified_items:
            role_disp = item.get('role_display', '')
            role_tag = f" [COLOR cyan][{role_disp}][/COLOR]" if role_disp else ""
            
            label = f"{base_label}{role_tag}"
            label2 = f"{role_disp}  •  {lang_str}" if (role_disp and lang_str) else (role_disp or lang_str)

            li = xbmcgui.ListItem(label=label, label2=label2)
            li.setArt({
                'icon': item.get('poster') or ICONS.get('FILM', ''),
                'thumb': item.get('poster') or ICONS.get('FILM', ''),
                'poster': item.get('poster') or ICONS.get('FILM', ''),
                'fanart': item.get('fanart') or '',
            })
            li.setProperty('item_languages', lang_str)
            if role_disp:
                li.setProperty('person_role', role_disp)

            info_tag = li.getVideoInfoTag()
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            if item.get('overview'):
                info_tag.setPlot(item['overview'])
            if item.get('rating'):
                info_tag.setRating(float(item['rating']))
            info_tag.setMediaType('movie')
            if item.get('year') and str(item['year']).isdigit():
                info_tag.setYear(int(item['year']))
            if item.get('release_date'):
                info_tag.setPremiered(item['release_date'])

            if person_type == 'actor' and item.get('character'):
                info_tag.setCast([xbmc.Actor(name=person_name, role=item['character'], thumbnail=item.get('poster', ''))])
            elif person_type == 'director':
                info_tag.setDirectors([person_name])

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "original_title": item['original_title'],
                "year": item['year'],
                "tmdb_id": item['id'],
                "media_type": "movie"
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        if not cancelled and end_idx < total_movies:
            next_li = xbmcgui.ListItem(label=f"Další ({page + 1})")
            next_li.setArt({'icon': ICONS.get('BOOK', ''), 'thumb': ICONS.get('BOOK', '')})
            next_url = build_url({
                "mode": "person_credits",
                "person_id": person_id,
                "person_name": person_name,
                "person_type": person_type,
                "page": page + 1
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        t_total = time.time() - t_start
        log_timing(f"Filmy pro '{person_name}' ({person_type}, str. {page}, {len(page_items)} ks z {total_movies}): TMDB={t_tmdb:.2f}s | WS={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)

def show_tv_series_menu(item):
    """Zobrazí seznam sezón seriálu s procenty zhlédnutí pro každou sérii."""
    t_start = time.time()
    title = item.get('title', '')
    loading = show_loading_dialog("Načítám", f"Načítám sezóny seriálu {title}...")
    try:
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        if not tmdb_key:
            log_error("Není zadán TMDB API klíč")
            dialog_notif("TMDB chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
            return

        ws_token = get_ws_token()
        if not ws_token:
            log_error("Není dostupný Webshare token")
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        t_tmdb_start = time.time()
        seasons = tmdb.get_tv_seasons(item.get('id'), tmdb_key)
        t_tmdb = time.time() - t_tmdb_start

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        if not seasons:
            li = xbmcgui.ListItem(label="Žádné sezóny nenalezeny")
            li.setArt({'icon': ICONS.get('THEATRE', ''), 'thumb': ICONS.get('THEATRE', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            log_timing(f"Sezóny pro '{title}': 0 sezón | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
            return

        num_seasons = len(seasons)
        one_season = 100 / num_seasons if num_seasons > 0 else 100
        t_ws_total = 0.0
        added_count = 0
        cancelled = False
        
        for i, season in enumerate(seasons):
            if is_loading_cancelled(loading):
                cancelled = True
                break

            if update_loading_dialog(loading, int(i * one_season), f"Kontroluji dostupnost sezón... ({i + 1}/{num_seasons})"):
                cancelled = True
                break
            
            season_number = season.get('season_number', 0)
            ep_count = season.get('episode_count', 0)
            
            # Kontrola první epizody dané sezóny (u speciálů S00E01, u série 1 S01E01 atd.)
            t_ws_item_start = time.time()
            first_ep_result = webshare.check_tv_episode_availability(
                title,
                season_number,
                1,
                item.get('year', ''),
                ws_token,
                limit=limit_to_search,
            )
            t_ws_total += time.time() - t_ws_item_start
            is_season_available = bool(first_ep_result.get('available'))
            season_lang = first_ep_result.get('lang', '') if is_season_available else None
            
            # Výpočet procenta rozkoukání celé série
            season_pct = db.get_tv_season_progress(item.get('id'), season_number, ep_count)
            is_season_watched = (season_pct >= 100)
            if is_season_watched:
                season_pct_str = " [COLOR lime](Zhlédnuto)[/COLOR]"
            elif season_pct > 0:
                season_pct_str = f" [COLOR orange]({season_pct}%)[/COLOR]"
            else:
                season_pct_str = ""
            
            # Sestavení popisku: pokud není 1. díl dostupný, celá série je šedá, ale stále rozkliknutelná
            base_label = tv_navigation.build_season_label(item.get('title', ''), season, lang=season_lang, is_available=is_season_available)
            if is_season_watched and is_season_available:
                label = f"[COLOR gray]{base_label}[/COLOR]{season_pct_str}"
            else:
                label = f"{base_label}{season_pct_str}"
            label2 = season.get('overview', '') or ('Dostupná na Webshare' if is_season_available else 'Nedostupná na Webshare')


            li = xbmcgui.ListItem(label=label, label2=label2)
            season_poster = season.get('poster') or item.get('poster', '')
            season_fanart = item.get('fanart', '')
            li.setArt({
                'icon': season_poster or ICONS.get('THEATRE', ''),
                'thumb': season_poster or ICONS.get('THEATRE', ''),
                'poster': season_poster,
                'fanart': season_fanart,
            })
            li.setProperty('season_number', str(season_number))
            if season_lang:
                li.setProperty('season_lang', season_lang)

            season_plot = season.get('overview', '') or item.get('overview', '')
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('season')
            info_tag.setTvShowTitle(item.get('title', ''))
            info_tag.setTitle(base_label)
            if season_plot:
                info_tag.setPlot(season_plot)
            if season_number > 0:
                info_tag.setSeason(season_number)
            if season.get('air_date'):
                info_tag.setPremiered(season.get('air_date'))
            if season_pct >= 100:
                info_tag.setPlaycount(1)

            li.addContextMenuItems(make_season_context_menu(item.get('id'), season_number, item.get('title', ''), is_watched=(season_pct >= 100)))

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "tv_season_selected",
                    "title": item.get('title', ''),
                    "original_title": item.get('original_title', item.get('title', '')),
                    "year": item.get('year', ''),
                    "tmdb_id": item.get('id'),
                    "season_number": season_number,
                    "poster": season_poster,
                    "fanart": season_fanart,
                    "overview": season_plot,
                }),
                listitem=li,
                isFolder=True,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        t_total = time.time() - t_start
        log_timing(f"Sezóny pro '{title}' ({num_seasons} sezón): TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)

def show_tv_episode_menu(show_item, season_number):
    """Zobrazí epizody sezóny, ověří dostupnost na Webshare a označí nedostupné šedě."""
    t_start = time.time()
    title = show_item.get('title', '')
    loading = show_loading_dialog("Načítám", f"Načítám epizody sezóny {season_number}...")
    try:
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        if not tmdb_key:
            log_error("Není zadán TMDB API klíč")
            dialog_notif("TMDB chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
            return

        ws_token = get_ws_token()
        if not ws_token:
            log_error("Není dostupný Webshare token")
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        t_tmdb_start = time.time()
        season_data = tmdb.get_season_details(show_item.get('id'), season_number, tmdb_key)
        t_tmdb = time.time() - t_tmdb_start

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        episodes = season_data.get('episodes', [])
        if not episodes:
            li = xbmcgui.ListItem(label="Žádné epizody nenalezeny")
            li.setArt({'icon': ICONS.get('THEATRE', ''), 'thumb': ICONS.get('THEATRE', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            log_timing(f"Epizody pro '{title}' S{season_number}: 0 epizod | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
            return

        num_episodes = len(episodes)
        one_ep = 100 / num_episodes if num_episodes > 0 else 100
        t_ws_total = 0.0
        added_count = 0
        cancelled = False

        for i, episode in enumerate(episodes):
            if is_loading_cancelled(loading):
                cancelled = True
                break

            if update_loading_dialog(loading, int(i * one_ep), f"Kontroluji dostupnost epizod... ({i + 1}/{num_episodes})"):
                cancelled = True
                break

            episode_number = episode.get('episode_number', 0)
            ep_status = db.get_item_watch_status(show_item.get('id'), season_number, episode_number)

            # Kontrola dostupnosti konkrétní epizody na Webshare
            t_ep_ws_start = time.time()
            ep_result = webshare.check_tv_episode_availability(
                title,
                season_number,
                episode_number,
                show_item.get('year', ''),
                ws_token,
                limit=limit_to_search,
            )
            t_ws_total += time.time() - t_ep_ws_start
            is_ep_available = bool(ep_result.get('available'))
            ep_lang = ep_result.get('lang', '') if is_ep_available else None

            is_ep_watched = bool(ep_status and ep_status.get('watched'))
            is_ep_resume = bool(ep_status and ep_status.get('resume_time', 0) > 15 and not is_ep_watched)

            # Sestavení popisku: pokud je zhlédnuto, název dílu je šedý a má (Zhlédnuto)
            base_label = tv_navigation.build_episode_label(episode, is_available=is_ep_available, lang=ep_lang, is_watched=is_ep_watched)

            if is_ep_watched:
                label = base_label
            elif is_ep_resume and ep_status.get('total_time', 0) > 0:
                pct = int((ep_status['resume_time'] / ep_status['total_time']) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label


            label2 = f"Jazyk: {ep_lang}" if is_ep_available else (episode.get('overview', '') or "Nedostupné na Webshare")

            li = xbmcgui.ListItem(label=label, label2=label2)
            li.addContextMenuItems(make_episode_context_menu(show_item.get('id'), season_number, episode_number, show_item.get('title', ''), is_watched=is_ep_watched, is_resume=is_ep_resume))



            still_path = episode.get('still_path') or ''
            show_poster = show_item.get('poster') or ''
            show_fanart = show_item.get('fanart') or ''
            ep_image = f"https://image.tmdb.org/t/p/w500{still_path}" if still_path else show_poster
            art = {
                'icon': ep_image or ICONS.get('THEATRE', ''),
                'thumb': ep_image or ICONS.get('THEATRE', ''),
                'poster': show_poster or ep_image or ICONS.get('THEATRE', ''),
                'fanart': f"https://image.tmdb.org/t/p/w1280{still_path}" if still_path else show_fanart
            }
            li.setArt(art)
            li.setProperty('episode_number', str(episode_number))
            li.setProperty('season_number', str(season_number))

            ep_name = episode.get('name', '') or f"Epizoda {episode_number}"
            ep_plot = episode.get('overview', '') or show_item.get('overview', '')

            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('episode')
            info_tag.setTvShowTitle(show_item.get('title', ''))
            info_tag.setTitle(ep_name)
            if ep_plot:
                info_tag.setPlot(ep_plot)
            info_tag.setSeason(season_number)
            info_tag.setEpisode(episode_number)
            if is_ep_watched:
                info_tag.setPlaycount(1)
            elif is_ep_resume:
                info_tag.setResumePoint(ep_status['resume_time'], ep_status.get('total_time', 0))
            if episode.get('air_date'):
                info_tag.setPremiered(episode.get('air_date'))
            if episode.get('vote_average'):
                try:
                    info_tag.setRating(float(episode.get('vote_average', 0)))
                except (TypeError, ValueError):
                    pass
            if episode.get('runtime'):
                info_tag.setDuration(int(episode.get('runtime')) * 60)

            guest_stars = []
            for actor in episode.get('guest_stars', [])[:5]:
                if actor.get('name'):
                    p_path = actor.get('profile_path')
                    actor_thumb = f"https://image.tmdb.org/t/p/w185{p_path}" if p_path else ""
                    guest_stars.append(xbmc.Actor(name=actor.get('name', ''), role=actor.get('character', ''), thumbnail=actor_thumb))
            if guest_stars:
                info_tag.setCast(guest_stars)

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "tv_episode_selected",
                    "title": show_item.get('title', ''),
                    "original_title": show_item.get('original_title', show_item.get('title', '')),
                    "year": show_item.get('year', ''),
                    "tmdb_id": show_item.get('id'),
                    "season_number": season_number,
                    "episode_number": episode_number,
                    "episode_name": ep_name,
                    "episode_plot": ep_plot,
                    "episode_still": f"https://image.tmdb.org/t/p/w500{still_path}" if still_path else '',
                    "poster": show_poster,
                    "fanart": show_fanart,
                }),
                listitem=li,
                isFolder=True,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        t_total = time.time() - t_start
        log_timing(f"Epizody pro '{title}' S{season_number} ({num_episodes} dílů): TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)
        
def show_tv_episode_files(show_item, season_number, episode_number):
    """Zobrazí dostupné soubory pro epizodu a předá sezónu i díl do přehrávače."""
    loading = show_loading_dialog("Načítám", f"Kontroluji epizodu {season_number}x{episode_number}...")
    try:
        ws_token = get_ws_token()
        if not ws_token:
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        episode_result = webshare.check_tv_episode_availability(
            show_item.get('title', ''),
            season_number,
            episode_number,
            show_item.get('year', ''),
            ws_token,
            limit=limit_to_search,
        )

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        if not episode_result.get('available'):
            li = xbmcgui.ListItem(label="Žádné dostupné soubory nenalezeny")
            li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            return

        raw_files = webshare.search_webshare_raw(episode_result.get('query', ''), token=ws_token, limit=limit_to_search)

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        valid_files = []
        for file_item in raw_files:
            if is_loading_cancelled(loading):
                break
            valid, reason = webshare.validate_file(
                file_item['name'],
                file_item.get('password', False),
                show_item.get('title', ''),
                show_item.get('year', ''),
                media_type='tv',
                target_season=season_number,
                target_episode=episode_number
            )
            if not valid:
                continue
            valid_files.append({
                'name': file_item['name'],
                'ident': file_item.get('ident', ''),
                'size_mb': round(file_item.get('size', 0) / (1024 * 1024), 2),
                'lang': webshare.detect_language(file_item['name']),
                'quality': webshare.detect_quality(file_item['name']),
                'valid': True,
            })

        if not valid_files:
            if is_loading_cancelled(loading):
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            li = xbmcgui.ListItem(label="Žádné vhodné soubory nenalezeny")
            li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            return

        tmdb_key = ADDON.getSetting('tmdb_api_key')
        tmdb_id = show_item.get('id', '')
        tmdb_details = tmdb.get_item_details(media_type='tv', tmdb_id=tmdb_id, api_key=tmdb_key) if (tmdb_key and tmdb_id) else {}

        ep_runtime = show_item.get('runtime') or tmdb_details.get('runtime', 0)
        webshare.estimate_missing_qualities(valid_files, runtime_minutes=ep_runtime, media_type='tv')

        added_count = 0
        cancelled = False
        sorted_files = webshare.sort_webshare_files(valid_files)
        for file_item in sorted_files:
            if is_loading_cancelled(loading):
                cancelled = True
                break
            label = webshare.build_webshare_file_label(file_item)
            li = xbmcgui.ListItem(label=label)
            li.setArt({
                'icon': ICONS.get('FILM', ''),
                'thumb': show_item.get('episode_still') or show_item.get('poster') or ICONS.get('FILM', ''),
                'poster': show_item.get('poster') or ICONS.get('FILM', ''),
                'fanart': show_item.get('fanart') or ''
            })
            li.setProperty("webshare_name", file_item.get('name', ''))
            li.setProperty('IsPlayable', 'true')

            ep_name = show_item.get('episode_name', '')
            ep_plot = show_item.get('episode_plot', '')
            if ep_name or ep_plot:
                info_tag = li.getVideoInfoTag()
                info_tag.setMediaType('episode')
                show_title = show_item.get('title', '')
                info_tag.setTvShowTitle(show_title)
                ep_full_title = f"{show_title} - S{season_number:02d}E{episode_number:02d} - {ep_name}" if ep_name else f"{show_title} - S{season_number:02d}E{episode_number:02d}"
                info_tag.setTitle(ep_full_title)
                if ep_plot:
                    info_tag.setPlot(ep_plot)
                info_tag.setSeason(season_number)
                info_tag.setEpisode(episode_number)
    
            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "webshare_file_selected",
                    "webshare_id": file_item.get('ident', ''),
                    "name": file_item.get('name', ''),
                    "lang": file_item.get('lang', ''),
                    "quality": file_item.get('quality', ''),
                    "tmdb_info": {
                        **show_item,
                        "media_type": "tv",
                        "season": season_number,
                        "episode": episode_number,
                        "episode_name": ep_name,
                        "episode_plot": ep_plot,
                        "episode_still": show_item.get('episode_still', ''),
                    },
                    "season_number": season_number,
                    "episode_number": episode_number,
                    "tmdb_details": tmdb_details,
                    "episode_name": ep_name,
                    "episode_plot": ep_plot,
                    "episode_still": show_item.get('episode_still', ''),
                }),
                listitem=li,
                isFolder=False,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    finally:
        close_loading_dialog(loading)


def show_webshare_results_menu(item):
    """Zobrazí seznam Webshare souborů po výběru filmu seřazený podle jazyka."""
    media_type = item.get("media_type", "movie")

    if media_type == "tv":
        show_tv_series_menu(item)
        return

    loading = show_loading_dialog("Načítám", "Kontroluji dostupné Webshare soubory...")
    try:
        ws_token = get_ws_token()
        if not ws_token:
            close_loading_dialog(loading)
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        update_loading_dialog(loading, 20, "Stahuji výsledky z Webshare...")
        search_result = webshare.search_and_verify_movie(item, token=ws_token, media_type=media_type, limit=limit_to_search)
        files = search_result.get("files", [])

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        # 1. Filtrace neplatných a malých souborů
        valid_files = []
        for index, file_item in enumerate(files):
            if is_loading_cancelled(loading):
                break
            percent = 20 + int(50 * (index + 1) / max(1, len(files)))
            if update_loading_dialog(loading, percent, f"Kontroluji soubor {index + 1}/{len(files)}"):
                break
            if not file_item.get('valid', False):
                continue
            
            size_mb = file_item.get('size_mb', 0)
            if size_mb < 50:
                continue

            valid_files.append(file_item)

        if not valid_files:
            if is_loading_cancelled(loading):
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            close_loading_dialog(loading)
            li = xbmcgui.ListItem(label="Žádné vhodné soubory nenalezeny")
            li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            return

        # 2. Odhad chybějících kvalit a seřazení podle nastavení uživatele
        movie_runtime = item.get('runtime', 0)
        webshare.estimate_missing_qualities(valid_files, runtime_minutes=movie_runtime, media_type='movie')
        sorted_files = webshare.sort_webshare_files(valid_files)

        update_loading_dialog(loading, 80, "Vytvářím seznam položek...")

        # 4. Vykreslení položek v Kodi
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        tmdb_id = item.get('id', '')
        tmdb_details = tmdb.get_item_details(media_type='movie', tmdb_id=tmdb_id, api_key=tmdb_key) if (tmdb_key and tmdb_id) else {}

        added_count = 0
        cancelled = False
        for index, file_item in enumerate(sorted_files):
            if is_loading_cancelled(loading):
                cancelled = True
                break
            percent = 80 + int(20 * (index + 1) / max(1, len(sorted_files)))
            if update_loading_dialog(loading, percent, f"Přidávám položku {index + 1}/{len(sorted_files)}"):
                cancelled = True
                break
            label = webshare.build_webshare_file_label(file_item)
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': ICONS.get('FILM', ''), 'thumb': ICONS.get('FILM', '')})
            li.setProperty("webshare_name", file_item.get('name', ''))
            li.setProperty("webshare_valid", "true" if file_item.get('valid', False) else "false")
            li.setProperty("webshare_lang", file_item.get('lang', ''))
            li.setProperty("webshare_quality", file_item.get('quality', ''))
            li.setProperty("webshare_size_mb", str(file_item.get('size_mb', '')))
            li.setProperty('IsPlayable', 'true')

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "webshare_file_selected",
                    "webshare_id": file_item.get('ident', ''),
                    "name": file_item.get('name', ''),
                    "lang": file_item.get('lang', ''),
                    "quality": file_item.get('quality', ''),
                    "tmdb_info": item,
                    "tmdb_details": tmdb_details
                }),
                listitem=li,
                isFolder=False
            )
            added_count += 1

        if (cancelled or is_loading_cancelled(loading)) and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    finally:
        close_loading_dialog(loading)


def show_webshare_account_info():
    """Zobrazí informace o účtu Webshare."""
    ws_token = get_ws_token()

    if not ws_token:
        dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        response = requests.post(
            "https://webshare.cz/api/user_data/",
            headers={
                "Accept": "text/xml; charset=UTF-8",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            },
            data={"wst": ws_token},
            timeout=10,
        )

        root = ET.fromstring(response.text)

        status = root.findtext("status")
        if status != "OK":
            message = root.findtext("message") or "Neznámá chyba"
            dialog_notif("Webshare chyba", message, xbmcgui.NOTIFICATION_ERROR)
            return

        username = root.findtext("username") or "-"
        vip = root.findtext("vip") == "1"
        vip_until = root.findtext("vip_until") or "-"
        vip_days = root.findtext("vip_days") or "0"
        points = root.findtext("points") or "0"

        if vip:
            vip_text = f"[COLOR green]ANO[/COLOR]\nPlatnost do: {vip_until}\nZbývá: {vip_days} dní"
        else:
            vip_text = "[COLOR red]NE[/COLOR]"

        info_message = (
            f"Uživatel: {username}\n"
            f"VIP: {vip_text}\n"
            f"Body: {points}"
        )

        dialog_ok("Informace o účtu Webshare", info_message)

    except Exception as e:
        dialog_notif("Webshare chyba", str(e), xbmcgui.NOTIFICATION_ERROR)


def run_speed_test():
    """Spustí test rychlosti stahování z Webshare s možností kdykoliv jej zrušit."""
    dp = xbmcgui.DialogProgress()
    dp.create("Test rychlosti Webshare", "Připojování a získávání testovacího odkazu...")

    ws_token = get_ws_token()
    is_vip = False
    username = ""

    # 1. Zjištění stavu účtu (VIP / Free)
    if ws_token:
        try:
            r = requests.post(
                "https://webshare.cz/api/user_data/",
                data={"wst": ws_token},
                timeout=4,
            )
            if r.status_code == 200:
                root = ET.fromstring(r.text)
                is_vip = root.findtext("vip") == "1"
                username = root.findtext("username") or ""
        except Exception:
            pass

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    dp.update(5, "Získávám přímý odkaz ze serverů Webshare...")

    # 2. Získání testovacího odkazu (vyhledáním velkého souboru nebo fallback)
    test_ident = None
    try:
        search_data = {'what': 'mkv', 'limit': 10, 'sort': 'size', 'category': 'video'}
        if ws_token:
            search_data['wst'] = ws_token
        r = requests.post("https://webshare.cz/api/search/", data=search_data, timeout=6)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            if root.findtext('status') == 'OK':
                for f in root.findall('file'):
                    size = int(f.findtext('size', '0'))
                    if size >= 200 * 1024 * 1024:
                        test_ident = f.findtext('ident')
                        break
    except Exception:
        pass

    if not test_ident:
        test_ident = "a663e0f1lw"

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    link_data = {'ident': test_ident}
    if ws_token:
        link_data['wst'] = ws_token

    download_url = None
    try:
        r = requests.post("https://webshare.cz/api/file_link/", data=link_data, timeout=6)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            if root.findtext('status') == 'OK':
                download_url = root.findtext('link')
    except Exception as e:
        log_error(f"Chyba při získávání testovacího odkazu: {e}")

    if not download_url:
        dp.close()
        dialog_ok("Chyba testu rychlosti", "Nepodařilo se získat odkaz pro stahování z Webshare.")
        return

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    dp.update(10, "Spouštím stahování a měření rychlosti...")

    test_duration = 10.0  # Max délka testu v sekundách
    max_bytes = 150 * 1024 * 1024  # Max limit dat (150 MB)
    chunk_size = 128 * 1024  # 128 KB chunk

    total_bytes = 0
    bytes_since_update = 0
    speeds = []
    start_time = None
    was_cancelled = False

    try:
        with requests.get(download_url, stream=True, timeout=8) as resp:
            resp.raise_for_status()
            start_time = time.time()
            last_update_time = start_time

            for chunk in resp.iter_content(chunk_size=chunk_size):
                if dp.iscanceled():
                    was_cancelled = True
                    break

                if not chunk:
                    continue

                total_bytes += len(chunk)
                bytes_since_update += len(chunk)
                now = time.time()
                dt = now - last_update_time

                # Průběžná aktualizace dialogu každých ~0.3 s
                if dt >= 0.3:
                    current_spd = bytes_since_update / dt
                    speeds.append(current_spd)
                    bytes_since_update = 0
                    last_update_time = now

                    elapsed = now - start_time
                    percent = min(99, int((elapsed / test_duration) * 100))

                    curr_mbps = (current_spd * 8) / (1024 * 1024)
                    curr_mbs = current_spd / (1024 * 1024)
                    avg_spd = total_bytes / elapsed if elapsed > 0 else 0
                    avg_mbps = (avg_spd * 8) / (1024 * 1024)
                    down_mb = total_bytes / (1024 * 1024)
                    rem_sec = max(0.0, test_duration - elapsed)

                    dp.update(
                        percent,
                        f"Rychlost: [COLOR lime]{curr_mbps:.1f} Mb/s[/COLOR] ({curr_mbs:.1f} MB/s)\n"
                        f"Průměr: {avg_mbps:.1f} Mb/s  •  Staženo: {down_mb:.1f} MB\n"
                        f"Zbývá: {rem_sec:.1f} s  (Stiskněte Zrušit pro ukončení)"
                    )

                if (now - start_time) >= test_duration or total_bytes >= max_bytes:
                    break

    except Exception as e:
        log_error(f"Chyba při běhu testu rychlosti: {e}")
        if not was_cancelled and total_bytes == 0:
            dp.close()
            dialog_ok("Chyba testu", f"Během stahování došlo k chybě:\n{e}")
            return
    finally:
        dp.close()

    if not start_time:
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    elapsed = max(0.1, time.time() - start_time)
    avg_speed = total_bytes / elapsed
    max_speed = max(speeds) if speeds else avg_speed

    avg_mbps = (avg_speed * 8) / (1024 * 1024)
    avg_mbs = avg_speed / (1024 * 1024)
    max_mbps = (max_speed * 8) / (1024 * 1024)
    max_mbs = max_speed / (1024 * 1024)
    down_mb = total_bytes / (1024 * 1024)

    if total_bytes == 0 and was_cancelled:
        dialog_notif("Test rychlosti", "Test byl zrušen před zahájením stahování.")
        return

    # Text doporučení a hodnocení
    if avg_mbps >= 60:
        eval_text = "[COLOR lime]Vynikající rychlost[/COLOR]\nPlynulé přehrávání i nejnáročnějších 4K HDR a REMUX filmů."
    elif avg_mbps >= 25:
        eval_text = "[COLOR lime]Velmi dobrá rychlost[/COLOR]\nBezproblémové pro 1080p a většinu 4K filmů."
    elif avg_mbps >= 10:
        eval_text = "[COLOR yellow]Průměrná rychlost[/COLOR]\nVhodné pro 720p / 1080p s nižším datovým tokem, 4K se může sekat."
    else:
        eval_text = "[COLOR red]Nízká rychlost[/COLOR]\nMůže docházet k načítání (zkontrolujte VIP účet či Wi-Fi/kabel)."

    if is_vip:
        account_type = f"[COLOR lime]VIP účet ({username})[/COLOR]"
    elif ws_token:
        account_type = f"[COLOR yellow]Free účet ({username}) – Webshare omezuje rychlost[/COLOR]"
    else:
        account_type = "[COLOR red]Nepřihlášen – Omezená rychlost Webshare[/COLOR]"

    title_dialog = "Test rychlosti (Ukončen)" if was_cancelled else "Výsledek testu rychlosti"
    header_line = "Test byl předčasně ukončen uživatelem.\nNaměřené hodnoty do ukončení:" if was_cancelled else "Měření stahování z Webshare dokončeno:"

    msg = (
        f"{header_line}\n\n"
        f"• Průměrná rychlost: [COLOR lime]{avg_mbps:.2f} Mb/s[/COLOR]  ({avg_mbs:.2f} MB/s)\n"
        f"• Maximální rychlost: [COLOR lime]{max_mbps:.2f} Mb/s[/COLOR]  ({max_mbs:.2f} MB/s)\n"
        f"• Staženo: {down_mb:.1f} MB za {elapsed:.1f} s\n"
        f"• Režim: {account_type}\n\n"
        f"Doporučení:\n{eval_text}"
    )

    dialog_ok(title_dialog, msg)
        
def make_movie_context_menu(tmdb_id, title, is_watched=False, is_resume=False):
    """Vytvoří položky kontextového menu pro film."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit jako nezhlédnuté", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit jako zhlédnuté", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))
    return menu

def make_tv_context_menu(tmdb_id, title, is_watched=False, is_resume=False):
    """Vytvoří položky kontextového menu pro seriál."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit seriál jako nezhlédnutý", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit seriál jako zhlédnutý", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))
    return menu

def make_season_context_menu(tmdb_id, season_number, title, is_watched=False):
    """Vytvoří položky kontextového menu pro sérii seriálu."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&title={quoted_title}"
        menu.append(("Označit sérii jako nezhlédnutou", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&title={quoted_title}"
        menu.append(("Označit sérii jako zhlédnutou", f"RunPlugin({watch_url})"))
    return menu

def make_episode_context_menu(tmdb_id, season_number, episode_number, title, is_watched=False, is_resume=False):
    """Vytvoří položky kontextového menu pro epizodu seriálu."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Označit díl jako nezhlédnutý", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Označit díl jako zhlédnutý", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))
    return menu

def show_history_menu():
    items = [
        ("Rozkoukané filmy a seriály", ICONS['RESUME'], {"mode": "history_resume_menu"}),
        ("Zhlédnuté filmy a seriály", ICONS['WATCHED'], {"mode": "history_watched_menu"}),
        ("Historie přehrávání (poslední díly a filmy)", ICONS['FILM'], {"mode": "history_playback_log"}),
        ("Historie vyhledávání", ICONS['SEARCH'], {"mode": "history_search"}),
    ]


    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
def show_search_history():
    """Zobrazí seznam naposledy hledaných výrazů z DB a možnosti správy."""
    handle = int(sys.argv[1])
    base_url = sys.argv[0]

    # Nastavení typu obsahu pro Kodi
    xbmcplugin.setContent(handle, "files")

    # 1. Nové vyhledávání (použije mode == "search", který vyvolá Dialog.input)
    new_search_url = f"{base_url}?mode=search"
    item_new = xbmcgui.ListItem(label="[B]Nové Hledání[/B]")
    item_new.setArt({"icon": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=new_search_url, listitem=item_new, isFolder=True
    )

    # 2. Načtení historie z DB
    history_items = db.get_search_history(limit=20)

    for query in history_items:
        encoded_query = urllib.parse.quote_plus(query)
        item_url = f"{base_url}?mode=search_predefined&search_arg={encoded_query}"

        list_item = xbmcgui.ListItem(label=query)
        list_item.setArt({"icon": "DefaultFolder.png"})

        delete_url = f"{base_url}?mode=delete_search&query={encoded_query}"
        list_item.addContextMenuItems(
            [("Smazat z historie", f"RunPlugin({delete_url})")]
        )

        xbmcplugin.addDirectoryItem(
            handle=handle, url=item_url, listitem=list_item, isFolder=True
        )

    xbmcplugin.endOfDirectory(handle)

    
def format_seconds(seconds):
    """Pomocná funkce pro převod sekund na HH:MM:SS."""
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"

def history_resume_menu():
    """
    Zobrazí seznam rozkoukaných filmů a seriálů s procenty, časy a plakáty.
    - Film: Otevře dostupné soubory filmu (search_webshare) a při přehrání nabídne pokračovat
    - Seriál: Otevře seznam sérií daného seriálu s indikátory rozkoukání
    """
    items = db.get_in_progress_items(limit=50)


    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádné rozkoukané položky[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api_key = ADDON.getSetting('tmdb_api_key')

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        details = item.get('details', {}) or {}

        # Pokud chybí metadata v DB, dotáhneme z TMDB a uložíme do DB
        if not details.get('poster') and tmdb_id and api_key:
            tmdb_details = tmdb.get_item_details(media_type, tmdb_id, api_key)
            if tmdb_details:
                details = {**tmdb_details, **details}
                db.save_item_metadata(tmdb_id, media_type, title, details=details)

        year_val = details.get('year') or details.get('release_date', '')[:4] or details.get('first_air_date', '')[:4] or ''
        year_str = year_val if year_val else "N/A"
        poster = details.get('poster') or details.get('thumb') or ''
        poster_p = details.get('poster_path')
        if not poster and poster_p:
            poster = f"https://image.tmdb.org/t/p/w500{poster_p}"
        fanart = details.get('fanart') or ''
        backdrop_p = details.get('backdrop_path')
        if not fanart and backdrop_p:
            fanart = f"https://image.tmdb.org/t/p/original{backdrop_p}"

        if media_type == "tv":
            num_eps = details.get('number_of_episodes') or 0
            show_pct = db.get_tv_show_progress(tmdb_id, num_eps)
            season_cnt = details.get('number_of_seasons') or 0
            season_text = f" • [COLOR lime]{season_cnt} sérií[/COLOR]" if season_cnt else ""

            last_s = item.get('season', 0)
            last_e = item.get('episode', 0)
            ep_info = f" • [COLOR yellow]Naposledy: S{last_s:02d}E{last_e:02d}[/COLOR]" if (last_s > 0 and last_e > 0) else ""
            
            label = f"{title} [COLOR orange]({show_pct}%)[/COLOR] [COLOR grey]({year_str})[/COLOR]{season_text}{ep_info}"

            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_tv_context_menu(tmdb_id, title, is_watched=False, is_resume=True))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or details.get('original_name') or title,
                "year": year_val,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
            })
        else:
            resume_time = item.get('resume_time', 0)
            total_time = item.get('total_time', 0)
            pct = int((resume_time / total_time) * 100) if total_time > 0 else 0
            time_str = f" • {format_seconds(resume_time)} / {format_seconds(total_time)}" if total_time > 0 else ""
            label = f"{title} [COLOR orange]({pct}%)[/COLOR] [COLOR grey]({year_str})[/COLOR]{time_str}"

            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=False, is_resume=True))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or title,
                "year": year_val,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
            })

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setOriginalTitle(details.get('original_title') or details.get('original_name') or title)
        info_tag.setPlot(details.get('overview', ''))
        info_tag.setPlotOutline(details.get('tagline', ''))
        info_tag.setMediaType(media_type)
        if year_val.isdigit():
            info_tag.setYear(int(year_val))
        if details.get('rating') or details.get('vote_average'):
            try:
                info_tag.setRating(float(details.get('rating') or details.get('vote_average') or 0))
            except (ValueError, TypeError):
                pass
        if details.get('runtime'):
            try:
                info_tag.setDuration(int(details['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        if item.get('resume_time', 0) > 0:
            info_tag.setResumePoint(item['resume_time'], item.get('total_time', 0))

        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)



def history_watched_menu():
    """Zobrazí seznam zhlédnutých filmů a dokončených seriálů s plnými metadaty a plakáty."""
    items = db.get_watched_items(limit=50)


    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádné zhlédnuté položky[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api_key = ADDON.getSetting('tmdb_api_key')

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        details = item.get('details', {}) or {}

        if not details.get('poster') and tmdb_id and api_key:
            tmdb_details = tmdb.get_item_details(media_type, tmdb_id, api_key)
            if tmdb_details:
                details = {**tmdb_details, **details}
                db.save_item_metadata(tmdb_id, media_type, title, details=details)

        year_val = details.get('year') or details.get('release_date', '')[:4] or details.get('first_air_date', '')[:4] or ''
        year_str = year_val if year_val else "N/A"
        poster = details.get('poster') or details.get('thumb') or ''
        poster_p = details.get('poster_path')
        if not poster and poster_p:
            poster = f"https://image.tmdb.org/t/p/w500{poster_p}"
        fanart = details.get('fanart') or ''
        backdrop_p = details.get('backdrop_path')
        if not fanart and backdrop_p:
            fanart = f"https://image.tmdb.org/t/p/original{backdrop_p}"

        if media_type == "tv":
            season_cnt = details.get('number_of_seasons') or 0
            season_text = f" • [COLOR lime]{season_cnt} sérií[/COLOR]" if season_cnt else ""
            label = f"[COLOR gray]{title}[/COLOR] [COLOR lime](Zhlédnuto - Celý seriál)[/COLOR] [COLOR grey]({year_str})[/COLOR]{season_text}"
            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_tv_context_menu(tmdb_id, title, is_watched=True, is_resume=False))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or details.get('original_name') or title,
                "year": year_val,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
            })
        else:
            label = f"[COLOR gray]{title}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR] [COLOR grey]({year_str})[/COLOR]"
            li = xbmcgui.ListItem(label=label)

            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=True, is_resume=False))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or title,
                "year": year_val,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
            })

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setOriginalTitle(details.get('original_title') or details.get('original_name') or title)
        info_tag.setPlot(details.get('overview', ''))
        info_tag.setPlotOutline(details.get('tagline', ''))
        info_tag.setMediaType(media_type)
        info_tag.setPlaycount(1)

        if year_val.isdigit():
            info_tag.setYear(int(year_val))
        if details.get('rating') or details.get('vote_average'):
            try:
                info_tag.setRating(float(details.get('rating') or details.get('vote_average') or 0))
            except (ValueError, TypeError):
                pass
        if details.get('runtime'):
            try:
                info_tag.setDuration(int(details['runtime']) * 60)
            except (ValueError, TypeError):
                pass

        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)



def history_playback_log():
    """Zobrazí chronologický přehled nedávno přehrávaných videí (filmů i konkrétních epizod)."""
    items = db.get_playback_history(limit=50)

    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádná historie přehrávání[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        season = item.get('season', 0)
        episode = item.get('episode', 0)
        is_watched = item.get('watched', False)
        resume_time = item.get('resume_time', 0)
        total_time = item.get('total_time', 0)
        details = item.get('details', {}) or {}

        if media_type == "tv" and season > 0 and episode > 0:
            ep_tag = f"S{season:02d}E{episode:02d}"
            base_label = f"{title} - {ep_tag}"
            if is_watched:
                label = f"[COLOR gray]{base_label}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR]"
            elif resume_time > 15 and total_time > 0:
                pct = int((resume_time / total_time) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label

            url = build_url({
                "mode": "tv_episode_selected",
                "title": title,
                "tmdb_id": tmdb_id,
                "season_number": season,
                "episode_number": episode,
                "year": details.get('year', '')
            })
            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_episode_context_menu(tmdb_id, season, episode, title, is_watched=is_watched, is_resume=(resume_time > 15 and not is_watched)))
        else:
            base_label = title
            if is_watched:
                label = f"[COLOR gray]{base_label}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR]"
            elif resume_time > 15 and total_time > 0:
                pct = int((resume_time / total_time) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
                "year": details.get('year', '')
            })
            li = xbmcgui.ListItem(label=label)
            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=is_watched, is_resume=(resume_time > 15 and not is_watched)))

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        if is_watched:
            info_tag.setPlaycount(1)
        if resume_time > 0:
            info_tag.setResumePoint(resume_time, total_time)

        poster = details.get('poster') or details.get('thumb') or ''
        fanart = details.get('fanart') or ''
        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
def router(paramstring):
    """Směrování parametrů"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get("mode")

    if mode == "open_settings":
        whitelist.get_hw_code()
        ADDON.openSettings()
        return
    elif mode == "check_whitelist":
        whitelist.show_whitelist_status_dialog()
        return

    # Ověření přístupových práv přes Supabase whitelist
    if not whitelist.ensure_access():
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not mode:
        db.cleanup_cache(ttl_days=7)
        main_menu()
    elif mode == "movies_menu":
        sub_menu("movie")
    elif mode == "tv_menu":
        sub_menu("tv")
    elif mode == "genres_menu":
        genres_menu(params.get("media_type", "movie"))
    elif mode == "open_settings":
        ADDON.openSettings()
    elif mode == "tmdb_list":
        tmdb_list_menu(
            media_type=params.get("media_type", "movie"),
            category=params.get("category", "popular"),
            genre_id=params.get("genre_id"),
            page=params.get("page", 1)
        )
    elif mode == "search":
        query = xbmcgui.Dialog().input("Hledat film nebo seriál")
        if query:
            db.add_search_query(query)
            search_tmdb_menu(query)
    elif mode == "search_predefined":
        query = params.get("search_arg", "")
        db.add_search_query(query)
        search_tmdb_menu(query)
    elif mode == "advanced_search_menu":
        show_advanced_search_menu()
    elif mode == "advanced_search_input":
        person_type = params.get("person_type", "actor")
        prompt = "Zadejte jméno herce / herečky" if person_type == "actor" else "Zadejte jméno režiséra / režisérky"
        query = xbmcgui.Dialog().input(prompt)
        if query:
            prefix = "[H]" if person_type == "actor" else "[R]"
            db.add_search_query(f"{prefix} {query}")
            search_person_menu(query, person_type)
    elif mode == "person_credits":
        show_person_credits_menu(
            person_id=params.get("person_id"),
            person_name=params.get("person_name", ""),
            person_type=params.get("person_type", "actor"),
            page=int(params.get("page", 1))
        )
    elif mode == "search_webshare":
        show_webshare_results_menu({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "media_type": params.get("media_type", "movie")
        })
    elif mode == "tv_season_selected":
        show_tv_episode_menu({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", ""),
        }, int(params.get("season_number", 0)))
    elif mode == "tv_episode_selected":
        show_tv_episode_files({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", ""),
            "episode_name": params.get("episode_name", ""),
            "episode_plot": params.get("episode_plot", ""),
            "episode_still": params.get("episode_still", ""),
        }, int(params.get("season_number", 0)), int(params.get("episode_number", 0)))
    elif mode == "webshare_file_selected":
        player.play_webshare_video(
            file_id=params.get("webshare_id", ""),
            file_name=params.get("name", ""),
            tmdb_info=params.get("tmdb_info"),
            season=int(params.get("season_number", 0)),
            episode=int(params.get("episode_number", 0)),
            wst_token=get_ws_token(),
            tmdb_details=params.get("tmdb_details"),
            episode_name=params.get("episode_name", ""),
            episode_plot=params.get("episode_plot", ""),
            episode_still=params.get("episode_still", "")
        )
    elif mode == "series_selected":
        sel_title = params.get('title', '')
        dialog_ok("Seriál", f"Vybraná série: {sel_title}")
    elif mode == "show_account_info":
        show_webshare_account_info()
    elif mode == "run_speed_test":
        run_speed_test()
    elif mode == "history":
        show_history_menu()
    elif mode == "history_search":
        show_search_history()
    elif mode == "history_resume_menu":
        history_resume_menu()
    elif mode == "history_watched_menu":
        history_watched_menu()
    elif mode == "history_playback_log":
        history_playback_log()
    elif mode == "mark_watched":
        item_title = params.get("title", "")
        db.mark_item_watched(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0)),
            title=item_title
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Označeno jako zhlédnuté: {item_title}" if item_title else "Označeno jako zhlédnuté"
        dialog_notif("Webshare", msg)
    elif mode == "mark_unwatched":
        item_title = params.get("title", "")
        db.mark_item_unwatched(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0))
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Označeno jako nezhlédnuté: {item_title}" if item_title else "Označeno jako nezhlédnuté"
        dialog_notif("Webshare", msg)
    elif mode == "remove_resume":
        item_title = params.get("title", "")
        db.remove_from_in_progress(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0))
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Odebráno z rozkoukaných: {item_title}" if item_title else "Odebráno z rozkoukaných"
        dialog_notif("Webshare", msg)
    elif mode == "clear_resume_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat celou historii rozkoukaných?"):
            db.clear_in_progress_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie rozkoukaných byla vymazána.")
    elif mode == "clear_watched_only_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat historii zhlédnutých filmů a seriálů?"):
            db.clear_watched_only_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie zhlédnutých byla vymazána.")
    elif mode == "clear_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat historii vyhledávání?"):
            db.clear_search_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie vyhledávání byla vymazána.")
    elif mode == "clear_watched_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat veškerou historii sledování (rozkoukané i zhlédnuté)?"):
            db.clear_watch_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Veškerá historie sledování byla vymazána.")


if __name__ == "__main__":
    raw_params = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(raw_params)