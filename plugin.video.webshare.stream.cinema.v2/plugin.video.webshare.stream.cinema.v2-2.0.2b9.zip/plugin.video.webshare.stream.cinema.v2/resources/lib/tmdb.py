from concurrent.futures import ThreadPoolExecutor

import re
import requests
import xbmc
from . import db
from .title_cleaner import clean_title_for_kodi, has_unrenderable_chars, transliterate_all
try:
    from main import log_debug
except ImportError:
    def log_debug(msg):
        xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)
        
TMDB_BASE_URL = "https://api.themoviedb.org/3"
IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

def get_item_details(media_type, tmdb_id, api_key):
    """Načte podrobné informace s využitím modulu db.py"""
    url = f"{TMDB_BASE_URL}/{media_type}/{tmdb_id}"
    params = {
        'api_key': api_key,
        'language': 'cs-CZ',
        'append_to_response': 'credits,translations'
    }
    
    # 1. Čistý klíč nezávislý na API klíči (např. "tmdb_movie_634649_cs-CZ")
    cache_key = f"tmdb_{media_type}_{tmdb_id}_cs-CZ"

    cached_data = db.get_cache(cache_key, ttl_days=7)
    if cached_data is not None:
        log_debug("Mám data!")
        return cached_data

    try:
        r = requests.get(url, params=params, timeout=5)
        if r.status_code == 200:
            data = r.json()
            if not data.get('overview'):
                translations = data.get('translations', {}).get('translations', [])
                for t in translations:
                    if t.get('iso_639_1') == 'en':
                        t_data = t.get('data', {})
                        t_overview = t_data.get('overview', '')
                        if t_overview:
                            data['overview'] = t_overview
                            break
            if not data.get('tagline'):
                translations = data.get('translations', {}).get('translations', [])
                for t in translations:
                    if t.get('iso_639_1') == 'en':
                        t_data = t.get('data', {})
                        t_tagline = t_data.get('tagline', '')
                        if t_tagline:
                            data['tagline'] = t_tagline
                            break
            db.set_cache(cache_key, data)
            return data
    except Exception as e:
        log_debug(f"Chyba při načítání detailu ID {tmdb_id}: {e}")

    return {}

def _process_tmdb_item(item, media_type, api_key):
    # OK
    """Pomocná funkce pro paralelní zpracování jedné položky."""
    tmdb_id = item.get('id')
    details = get_item_details(media_type, tmdb_id, api_key)
    
    raw_title = item.get('title') or item.get('name', 'Neznámý název')
    raw_original_title = item.get('original_title') or item.get('original_name', '')
    release_date = item.get('release_date') or item.get('first_air_date', '')
    year = release_date[:4] if release_date else 'N/A'

    # Získání anglického názvu z translations pro spolehlivý překlad asijských/cizojazyčných děl
    english_title = ""
    translations = details.get('translations', {}).get('translations', [])
    for t in translations:
        if t.get('iso_639_1') == 'en':
            t_data = t.get('data', {})
            english_title = t_data.get('title') or t_data.get('name') or ''
            if english_title:
                break

    if not english_title and item.get('original_language') == 'en':
        english_title = raw_original_title

    # Ošetření názvů: pokud obsahují znaky (Hangul/CJK), které Kodi zobrazuje jako obdélníky,
    # použijeme anglický název nebo provedeme romanizaci (např. '아씨마님' -> 'Assimanim').
    clean_title = clean_title_for_kodi(
        raw_title,
        english_title=english_title,
        original_title=raw_original_title,
        year=year,
        media_type=media_type
    )

    clean_orig_title = clean_title_for_kodi(
        raw_original_title,
        english_title=english_title,
        original_title=raw_original_title,
        year=year,
        media_type=media_type
    )

    runtime = details.get('runtime') if media_type == 'movie' else (
        details.get('episode_run_time', [0])[0] if details.get('episode_run_time') else 0
    )
    
    genres = [g['name'] for g in details.get('genres', [])]
    
    credits = details.get('credits', {})
    cast = []
    for actor in credits.get('cast', [])[:5]:
        p_path = actor.get('profile_path')
        cast.append({
            'name': actor.get('name'),
            'role': actor.get('character', ''),
            'thumbnail': (IMAGE_BASE_URL + "w185" + str(p_path)) if p_path else ''
        })
    
    directors = [crew['name'] for crew in credits.get('crew', []) if crew.get('job') == 'Director']

    poster_path = item.get('poster_path')
    backdrop_path = item.get('backdrop_path')
    
    parsed_item = {
        'id': tmdb_id,
        'title': clean_title,
        'original_title': clean_orig_title,
        'raw_title': raw_title,
        'raw_original_title': raw_original_title,
        'english_title': english_title,
        'year': year,
        'release_date': release_date,
        'rating': round(item.get('vote_average', 0), 1),
        'overview': item.get('overview') or details.get('overview', ''),
        'tagline': details.get('tagline', ''),
        'runtime': runtime or 0,
        'genres': genres,
        'cast': cast,
        'directors': directors,
        'poster': f"{IMAGE_BASE_URL}w500{poster_path}" if poster_path else '',
        'fanart': f"{IMAGE_BASE_URL}w1280{backdrop_path}" if backdrop_path else '',
        'number_of_seasons': details.get('number_of_seasons') or 0,
        'number_of_episodes': details.get('number_of_episodes') or 0
    }
    
    # Pro search potřebujeme vědět, zda jde o movie nebo tv
    if 'media_type' in item:
        parsed_item['media_type'] = item['media_type']
    else:
        parsed_item['media_type'] = media_type

    return parsed_item

def get_season_details(series_id, season_number, api_key):
    """Načte detail jedné sezóny seriálu z TMDB s mezipamětí a fallbackem na EN pro chybějící popisky/názvy."""
    cache_key = f"tmdb_tv_{series_id}_season_{season_number}_v2"
    cached = db.get_cache(cache_key, ttl_days=7)
    if cached is not None:
        return cached

    url = f"{TMDB_BASE_URL}/tv/{series_id}/season/{season_number}"
    params = {
        'api_key': api_key,
        'language': 'cs-CZ',
    }
    data_cs = {}
    try:
        r = requests.get(url, params=params, timeout=5)
        if r.status_code == 200:
            data_cs = r.json()
    except Exception as e:
        xbmc.log(f"[TMDB] Chyba při načítání sezóny {season_number} pro seriál {series_id}: {e}", xbmc.LOGINFO)

    if not data_cs:
        return {}

    episodes = data_cs.get('episodes') or []
    need_en = False
    if not data_cs.get('overview'):
        need_en = True
    else:
        for ep in episodes:
            ep_name = ep.get('name', '').strip().lower()
            ep_num = ep.get('episode_number', 0)
            if not ep.get('overview') or not ep_name or ep_name in (f"epizoda {ep_num}", f"díl {ep_num}", f"episode {ep_num}"):
                need_en = True
                break

    if need_en:
        try:
            params_en = {'api_key': api_key, 'language': 'en-US'}
            r_en = requests.get(url, params=params_en, timeout=5)
            if r_en.status_code == 200:
                data_en = r_en.json()
                if not data_cs.get('overview') and data_en.get('overview'):
                    data_cs['overview'] = data_en.get('overview')
                en_eps = {ep.get('episode_number'): ep for ep in data_en.get('episodes', [])}
                for ep in episodes:
                    ep_num = ep.get('episode_number', 0)
                    en_ep = en_eps.get(ep_num)
                    if en_ep:
                        if not ep.get('overview') and en_ep.get('overview'):
                            ep['overview'] = en_ep.get('overview')
                        ep_name = ep.get('name', '').strip()
                        if (not ep_name or ep_name.lower() in (f"epizoda {ep_num}", f"díl {ep_num}", f"episode {ep_num}")) and en_ep.get('name'):
                            ep['name'] = en_ep.get('name')
        except Exception as e:
            xbmc.log(f"[TMDB] Chyba při načítání EN fallbacku pro sezónu {season_number}: {e}", xbmc.LOGINFO)

    db.set_cache(cache_key, data_cs)
    return data_cs


def get_tv_seasons(series_id, api_key):
    """Vrátí seznam sezón pro seriál včetně osnovních metadat bleskově přímo z detailů seriálu."""
    details = get_item_details('tv', series_id, api_key)
    raw_seasons = details.get('seasons') or []
    seasons = []
    series_overview = details.get('overview', '')

    if raw_seasons:
        for s in raw_seasons:
            season_number = s.get('season_number', 0)
            poster_path = s.get('poster_path')
            poster = f"{IMAGE_BASE_URL}w500{poster_path}" if poster_path else ''
            default_name = "Speciály" if season_number == 0 else f"Sezóna {season_number}"
            overview = s.get('overview', '') or series_overview
            seasons.append({
                'season_number': season_number,
                'name': s.get('name') or default_name,
                'overview': overview,
                'air_date': s.get('air_date', ''),
                'episode_count': s.get('episode_count') or 0,
                'poster': poster,
                'episodes': [],
            })
    else:
        season_count = details.get('number_of_seasons') or 0
        for season_number in range(1, season_count + 1):
            seasons.append({
                'season_number': season_number,
                'name': f"Sezóna {season_number}",
                'overview': series_overview,
                'air_date': '',
                'episode_count': 0,
                'poster': '',
                'episodes': [],
            })

    # Seřadit tak, aby sezóna 0 byla na začátku (nebo podle season_number)
    seasons.sort(key=lambda x: x.get('season_number', 0))
    return seasons


def fetch_tmdb_items(media_type, category, api_key, genre_id=None, page=1):
    # OK
    if category == "popular":
        url = f"{TMDB_BASE_URL}/{media_type}/popular"
        params = {'api_key': api_key, 'language': 'cs-CZ', 'page': page}
    elif category == "new":
        endpoint = "now_playing" if media_type == "movie" else "on_the_air"
        url = f"{TMDB_BASE_URL}/{media_type}/{endpoint}"
        params = {'api_key': api_key, 'language': 'cs-CZ', 'page': page}
    elif category == "genre":
        url = f"{TMDB_BASE_URL}/discover/{media_type}"
        params = {'api_key': api_key, 'language': 'cs-CZ', 'with_genres': genre_id, 'page': page}
    else:
        return []
        
    try:
        r = requests.get(url, params=params, timeout=10)
        r.raise_for_status()
        results = r.json().get('results', [])
        
        # Paralelní načtení detailů pro všechny položky najednou
        items = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(_process_tmdb_item, item, media_type, api_key)
                for item in results
            ]
            for future in futures:
                items.append(future.result())

        return items
    except Exception as e:
        log_debug(f"Chyba při komunikaci s TMDB: {e}")
        return []
    
def search_tmdb_items(query, api_key, page=1):
    if not query:
        return []

    # Očištění dotazu od přípon typu (s), [s], (f), [f], (seriál), (film) pro API dotaz
    clean_query = re.sub(r'[\(\[\{]\s*(?:s|f|seri[aá]l|film)\s*[\)\]\}]', '', query, flags=re.I).strip()
    if not clean_query:
        clean_query = query.strip()

    wants_tv = bool(re.search(r'[\(\[\{]\s*(?:s|seri[aá]l)\s*[\)\]\}]', query, re.I))
    wants_movie = bool(re.search(r'[\(\[\{]\s*(?:f|film)\s*[\)\]\}]', query, re.I))

    # Pořadí dotazování: pokud uživatel zadal (s), prohledáváme nejprve seriály
    if wants_tv:
        media_types = ("tv", "movie")
    elif wants_movie:
        media_types = ("movie", "tv")
    else:
        media_types = ("tv", "movie")

    all_items = []
    for media_type in media_types:
        url = f"{TMDB_BASE_URL}/search/{media_type}"
        params = {
            'api_key': api_key,
            'language': 'cs-CZ',
            'query': clean_query,
            'page': page
        }
        try:
            r = requests.get(url, params=params, timeout=10)
            r.raise_for_status()
            results = r.json().get('results', [])

            # Paralelní načtení detailů pro vyhledané položky
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = [
                    executor.submit(_process_tmdb_item, item, media_type, api_key)
                    for item in results
                ]
                for future in futures:
                    all_items.append(future.result())

        except Exception as e:
            log_debug(f"Chyba při vyhledávání v TMDB pro typ {media_type}: {e}")

    return all_items


def search_tmdb_person(query, api_key):
    """Vyhledá osoby (herce, režiséry) na TMDB."""
    if not query:
        return []
    url = f"{TMDB_BASE_URL}/search/person"
    params = {
        'api_key': api_key,
        'query': query,
        'language': 'cs-CZ',
    }
    try:
        r = requests.get(url, params=params, timeout=8)
        if r.status_code == 200:
            data = r.json()
            results = []
            for p in data.get('results', []):
                profile_path = p.get('profile_path')
                known_for = [k.get('title') or k.get('name') for k in p.get('known_for', []) if (k.get('title') or k.get('name'))]
                results.append({
                    'id': p.get('id'),
                    'name': p.get('name', ''),
                    'known_for_department': p.get('known_for_department', ''),
                    'profile': f"{IMAGE_BASE_URL}w300{profile_path}" if profile_path else '',
                    'known_for_str': ", ".join(known_for[:3]) if known_for else ''
                })
            return results
    except Exception as e:
        log_debug(f"Chyba při hledání osoby '{query}': {e}")
    return []


def get_person_movie_credits(person_id, person_type, api_key):
    """
    Načte filmografii dané osoby z TMDB, seřazenou od nejnovějších po nejstarší.
    Pro herce (actor) vrátí filmy s rolí (character).
    Pro režiséra (director) vrátí režírované filmy.
    """
    cache_key = f"tmdb_person_{person_id}_movie_credits"
    cached = db.get_cache(cache_key, ttl_days=3)
    if cached is not None:
        data = cached
    else:
        url = f"{TMDB_BASE_URL}/person/{person_id}/movie_credits"
        params = {
            'api_key': api_key,
            'language': 'cs-CZ',
        }
        try:
            r = requests.get(url, params=params, timeout=10)
            if r.status_code == 200:
                data = r.json()
                db.set_cache(cache_key, data)
            else:
                data = {}
        except Exception as e:
            log_debug(f"Chyba při načítání kreditů osoby ID {person_id}: {e}")
            data = {}

    if not data:
        return []

    if person_type == 'director':
        raw_items = [c for c in data.get('crew', []) if c.get('job') == 'Director']
    else:
        raw_items = data.get('cast', [])

    movies_map = {}
    for m in raw_items:
        m_id = m.get('id')
        if not m_id:
            continue

        char = (m.get('character') or '').strip()
        job = (m.get('job') or '').strip()

        if m_id in movies_map:
            if char and char not in movies_map[m_id].get('character', ''):
                existing_char = movies_map[m_id].get('character', '')
                new_char = f"{existing_char}, {char}" if existing_char else char
                movies_map[m_id]['character'] = new_char
                if person_type == 'actor':
                    movies_map[m_id]['role_display'] = f"Role: {new_char}"
            continue

        raw_title = m.get('title') or m.get('original_title') or 'Neznámý film'
        raw_orig_title = m.get('original_title') or raw_title
        rel_date = m.get('release_date') or ''
        year = rel_date[:4] if rel_date else ''
        poster_path = m.get('poster_path')
        backdrop_path = m.get('backdrop_path')

        clean_title = clean_title_for_kodi(raw_title, original_title=raw_orig_title, year=year, media_type='movie')
        clean_orig = clean_title_for_kodi(raw_orig_title, original_title=raw_orig_title, year=year, media_type='movie')

        role_display = f"Role: {char}" if (person_type == 'actor' and char) else ("Režie" if person_type == 'director' else "")

        movies_map[m_id] = {
            'id': m_id,
            'title': clean_title,
            'original_title': clean_orig,
            'raw_title': raw_title,
            'raw_original_title': raw_orig_title,
            'english_title': '',
            'year': year,
            'release_date': rel_date,
            'rating': round(m.get('vote_average', 0), 1),
            'overview': m.get('overview', ''),
            'tagline': '',
            'runtime': 0,
            'genres': [],
            'cast': [{'name': m.get('name', ''), 'role': char, 'thumbnail': ''}] if char else [],
            'directors': [m.get('name', '')] if person_type == 'director' else [],
            'poster': f"{IMAGE_BASE_URL}w500{poster_path}" if poster_path else '',
            'fanart': f"{IMAGE_BASE_URL}w1280{backdrop_path}" if backdrop_path else '',
            'media_type': 'movie',
            'character': char,
            'job': job,
            'role_display': role_display,
        }

    movie_list = list(movies_map.values())
    movie_list.sort(key=lambda x: x.get('release_date') or '0000-00-00', reverse=True)
    return movie_list