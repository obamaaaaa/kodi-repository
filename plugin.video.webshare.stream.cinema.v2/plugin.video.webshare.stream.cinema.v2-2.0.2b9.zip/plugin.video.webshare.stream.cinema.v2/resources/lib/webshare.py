import hashlib
import os
import re
import unicodedata
import difflib
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
import time
import requests
import xbmc
try:
    import xbmcaddon
except ImportError:
    xbmcaddon = None

try:
    from .title_cleaner import clean_title_for_kodi, has_unrenderable_chars
except ImportError:
    try:
        from resources.lib.title_cleaner import clean_title_for_kodi, has_unrenderable_chars
    except ImportError:
        def clean_title_for_kodi(t, **kwargs): return t
        def has_unrenderable_chars(t): return False

try:
    from main import log_debug
except ImportError:
    def log_debug(msg):
        xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)

TIMEOUT = 10

# Session s HTTP poolováním pro podporu paralelních vláken
session = requests.Session()
adapter = requests.adapters.HTTPAdapter(pool_connections=20, pool_maxsize=20, max_retries=1)
session.mount('https://', adapter)
session.mount('http://', adapter)

_search_cache = {}
_CACHE_TTL = 900  # 15 minut v sekundách

def _is_setting_enabled(setting_id, default=True):
    if not xbmcaddon:
        return default
    try:
        addon = xbmcaddon.Addon()
        val = addon.getSetting(setting_id)
        if val == "" or val is None:
            return default
        return val.lower() == "true"
    except Exception:
        return default

VIDEO_EXTENSIONS = {'.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.flv', '.webm', '.ts'}

def build_webshare_file_label(file_item):
    """Vytvoří popisek souboru pro Kodi v požadovaném formátu:
    [JAZYK] [KVALITA] [VELIKOST MB] Název souboru
    """
    lang_raw = str(file_item.get('lang', 'Neznámý')).upper()
    name = file_item.get('name', '')
    
    # 1. Jazyk (CZ = zelená, SK/CZ TIT = žlutá, EN = modrá, ostatní = šedá)
    if lang_raw == 'CZ':
        lang_str = "[COLOR lime]CZ[/COLOR]"
    elif lang_raw == 'CZ TIT':
        lang_str = "[COLOR yellow]CZ TIT[/COLOR]"
    elif lang_raw == 'SK':
        lang_str = "[COLOR yellow]SK[/COLOR]"
    elif lang_raw == 'EN':
        lang_str = "[COLOR blue]EN[/COLOR]"
    else:
        lang_str = f"[COLOR gray]{lang_raw}[/COLOR]"
        
    # 2. Kvalita
    quality = file_item.get('quality') or detect_quality(name)
    is_estimated = file_item.get('quality_estimated', False) or str(quality).startswith('~')

    if is_estimated:
        # Světle šedá pro tipnutou kvalitu
        quality_str = f"[COLOR lightgray]{quality}[/COLOR]"
    elif quality == "4K":
        quality_str = f"[COLOR lime]{quality}[/COLOR]"
    elif quality == "1080p":
        quality_str = f"[COLOR yellow]{quality}[/COLOR]"
    elif quality == "720p":
        quality_str = f"[COLOR orange]{quality}[/COLOR]"
    elif quality in ("SD", "KN", "CAM"):
        quality_str = f"[COLOR gray]{quality}[/COLOR]"
    else:
        quality_str = f"[COLOR gray]{quality}[/COLOR]"
    
    # 3. Velikost souboru (šedá)
    size = file_item.get('size_mb')
    if size is not None:
        size_fmt = f"{size:.0f}" if size >= 10 else f"{size:.1f}"
        size_str = f"[COLOR gray][{size_fmt} MB][/COLOR]"
    else:
        size_str = "[COLOR gray][? MB][/COLOR]"
        
    return f"{lang_str}    {quality_str}      {size_str}  {name}"

def detect_quality(filename):
    """Detekuje kvalitu/rozlišení videa podle názvu souboru"""
    fn = filename.lower()
    
    if re.search(r'\b(2160p|4k|uhd)\b', fn):
        return "4K"
    elif re.search(r'\b(1080p|1080i|fhd)\b', fn):
        return "1080p"
    elif re.search(r'\b(720p|hd)\b', fn):
        return "720p"
    elif re.search(r'\b(cam|camrip|hdcam|ts|hdts|telesync)\b', fn):
        return "CAM"
    elif re.search(r'\b(480p|576p|dvd|dvdrip|sd)\b', fn):
        return "SD"
    elif re.search(r'\b(kinorip|kino)\b', fn):
        return "KN"
        
    return "??"

def estimate_missing_qualities(files, runtime_minutes=None, media_type='movie'):
    """
    Pokud existují v seznamu položky s platnými kvalitami,
    odhadne chybějící kvalitu u ostatních souborů podle velikosti a délky.
    Tipnutá kvalita se označí prefixem '~' (např. '~1080p') a zobrazí se světle šedě.
    """
    if not files:
        return files

    runtime = runtime_minutes if (runtime_minutes and runtime_minutes > 0) else (45 if media_type == 'tv' else 100)

    # Shromáždíme referenční velikosti pro známé kvality
    quality_sizes = {}
    for f in files:
        q = f.get('quality', '')
        if q in ('4K', '1080p', '720p', 'SD') and f.get('size_mb', 0) > 0:
            quality_sizes.setdefault(q, []).append(f['size_mb'])

    medians = {q: sorted(sizes)[len(sizes) // 2] for q, sizes in quality_sizes.items()}
    has_enough_references = (len(medians) >= 2 or sum(len(s) for s in quality_sizes.values()) >= 3)

    for f in files:
        q = f.get('quality', '')
        if q in ('??', '', 'Neznámá', None):
            size_mb = f.get('size_mb', 0)
            if size_mb <= 0:
                continue

            best_q = None
            if has_enough_references and medians:
                import math
                best_q = min(medians.keys(), key=lambda k: abs(math.log(max(size_mb, 1) / max(medians[k], 1))))

            mb_per_min = size_mb / max(runtime, 1)
            if not best_q:
                if media_type == 'tv':
                    if size_mb >= 3500 or mb_per_min >= 50:
                        best_q = '4K'
                    elif size_mb >= 900 or mb_per_min >= 18:
                        best_q = '1080p'
                    elif size_mb >= 350 or mb_per_min >= 7:
                        best_q = '720p'
                    else:
                        best_q = 'SD'
                else:
                    if size_mb >= 10000 or mb_per_min >= 80:
                        best_q = '4K'
                    elif size_mb >= 1800 or mb_per_min >= 16:
                        best_q = '1080p'
                    elif size_mb >= 750 or mb_per_min >= 7:
                        best_q = '720p'
                    else:
                        best_q = 'SD'

            if best_q:
                f['quality'] = f"~{best_q}"
                f['quality_estimated'] = True
                f['base_quality'] = best_q

    return files
def detect_language(filename, search_language=None):
    """Detekuje jazykovou stopu podle názvu souboru."""
    fn = filename.lower()
    langs = []

    boundary = r'(?<![a-z0-9]){0}(?![a-z0-9])'

    # CZ TITULKY
    if re.search(
        boundary.format(
            r'(?:cz[\s._-]?(?:tit|titulky)|'
            r'czech[\s._-]?(?:tit|titulky)|'
            r'cztit|czech_tit)'
        ),
        fn,
        re.IGNORECASE
    ):
        langs.append("CZ TIT")

    # CZ DABING
    elif re.search(
        boundary.format(
            r'(?:cz[\s._-]?dab|'
            r'czdab|'
            r'czech[\s._-]?dab|'
            r'dabing|'
            r'cz)'
        ),
        fn,
        re.IGNORECASE
    ):
        langs.append("CZ")

    # SK
    if re.search(
        boundary.format(
            r'(?:sk[\s._-]?dab|'
            r'skdab|'
            r'slovak|'
            r'sk)'
        ),
        fn,
        re.IGNORECASE
    ):
        langs.append("SK")

    # EN
    if re.search(
        boundary.format(r'(?:eng|english|en)'),
        fn,
        re.IGNORECASE
    ):
        langs.append("EN")

    # MULTI AUDIO
    if re.search(
        boundary.format(r'(?:dual|multi)'),
        fn,
        re.IGNORECASE
    ):
        langs.append("MULTI")

    if not langs and search_language:
        return search_language.upper()

    return "/".join(langs) if langs else "??"

def get_language_score(lang: str) -> int:
    """Vrátí skóre priority jazyka (vyšší číslo = vyšší priorita)."""
    if not lang:
        return 0
    u = str(lang).upper().strip()
    if 'CZ TIT' in u or 'CZ_TIT' in u or 'SUB' in u or ('TIT' in u and 'CZ' in u):
        return 3
    if 'CZ' in u or 'CZE' in u or 'CS' in u or 'MULTI' in u or 'DUAL' in u:
        return 4
    if 'SK' in u or 'SVK' in u:
        return 2
    if 'EN' in u or 'ENG' in u:
        return 1
    return 0

def get_quality_score(quality: str) -> int:
    """Vrátí skóre priority kvality (vyšší číslo = vyšší priorita)."""
    if not quality:
        return 0
    q = str(quality).upper().replace('~', '').strip()
    if '4K' in q or '2160' in q or 'UHD' in q:
        return 5
    if '2K' in q or '1440' in q:
        return 4
    if '1080' in q or 'FHD' in q:
        return 3
    if '720' in q or 'HD' in q:
        return 2
    if 'SD' in q or '576' in q or '480' in q or 'DVD' in q:
        return 1
    return 0

def sort_webshare_files(files, sort_mode=None):
    """
    Seřadí nalezené soubory z Webshare podle zvolené priority:
      - 'language': 1. Jazyk (CZ > CZ TIT > SK > EN), 2. Kvalita, 3. Velikost
      - 'quality':  1. Kvalita (4K > 1080p > 720p > SD), 2. Jazyk, 3. Velikost
      - 'size':     1. Velikost (největší soubor první), 2. Jazyk, 3. Kvalita
    """
    if not files:
        return []

    if sort_mode is None:
        try:
            if xbmcaddon:
                raw_setting = (xbmcaddon.Addon().getSetting('sort_mode') or '').strip()
                if 'KVALIT' in raw_setting.upper() or raw_setting == '1':
                    sort_mode = 'quality'
                elif 'VELIKOST' in raw_setting.upper() or raw_setting == '2':
                    sort_mode = 'size'
                elif 'JAZYK' in raw_setting.upper() or raw_setting == '0':
                    sort_mode = 'language'
                else:
                    sort_mode = 'language'
        except Exception:
            sort_mode = 'language'

    sm = str(sort_mode or 'language').lower()
    if 'kvalit' in sm or sm == 'quality':
        return sorted(
            files,
            key=lambda f: (
                -get_quality_score(f.get('quality', '')),
                -get_language_score(f.get('lang', '')),
                -f.get('size_mb', 0)
            )
        )
    elif 'velikost' in sm or sm == 'size':
        return sorted(
            files,
            key=lambda f: (
                -f.get('size_mb', 0),
                -get_language_score(f.get('lang', '')),
                -get_quality_score(f.get('quality', ''))
            )
        )
    else:
        return sorted(
            files,
            key=lambda f: (
                -get_language_score(f.get('lang', '')),
                -get_quality_score(f.get('quality', '')),
                -f.get('size_mb', 0)
            )
        )

def normalize_title(text):
    """
    Normalizuje text pro porovnání (lowercase, bez diakritiky, jen alfanumerické znaky)
    """
    if not text:
        return ""
    text = re.sub(r'^\[.*?\]\s*', '', text)
    text = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

def words_match(w1, w2):
    """Porovná dva výrazy s tolerancí drobných jazykových odchylek (např. Odyssea vs Odyssey)."""
    if w1 == w2:
        return True
    if len(w1) >= 4 and len(w2) >= 4:
        if difflib.SequenceMatcher(None, w1, w2).ratio() >= 0.8:
            return True
    return False

def validate_file(
    filename,
    is_passworded,
    target_title,
    target_year,
    media_type='movie',
    target_season=None,
    target_episode=None
):
    """Ověří platnost souboru podle flexibilního porovnání slov a segmentů."""

    # 1. Kontrola přípony
    ext = ('.' + filename.split('.')[-1].lower() if '.' in filename else '')
    if ext not in VIDEO_EXTENSIONS:
        return False, f"Neplatná přípona ({ext})"

    # 2. Kontrola hesla
    if is_passworded:
        return False, "Zaheslováno na Webshare"
    if re.search(r'\b(?:zaheslov[aá]n[ooyí]|heslo\s*[:=]|heslo\s+v\s+popis[ue]?)\b', filename, re.IGNORECASE):
        return False, "Zaheslováno v popisu/názvu"

    # 3. Kontrola názvu pomocí složených segmentů a vyhledávání sekvence slov
    filename_without_ext = os.path.splitext(filename)[0].strip()
    titles_list = target_title if isinstance(target_title, list) else [target_title]
    
    # Rozšířený regex pro zachycení S01E01, 1x01 i 1 - 01 / 1-1
    se_pattern = r'(?<![a-z0-9])(?:s(\d{1,2})[\s._-]*e(\d{1,2})|(\d{1,2})x(\d{1,2})|(\d{1,2})[\s._-]*[-][\s._-]*(\d{1,2}))(?![a-z0-9])'
    se_match = re.search(se_pattern, filename_without_ext, re.IGNORECASE)
    if se_match:
        fn_title_part = filename_without_ext[:se_match.start()]
    else:
        year_m = re.search(r'(?<!\d)(19\d{2}|20\d{2})(?!\d)', filename_without_ext)
        if year_m:
            fn_title_part = filename_without_ext[:year_m.start()]
        else:
            fn_title_part = filename_without_ext
            
    # Ošetření spin-offů: Pokud je target "Zelenáč", ale název souboru obsahuje "Zelenáčka FBI", odmítnout
    fn_title_clean = normalize_title(fn_title_part).lower()
    for t in titles_list:
        if not t:
            continue
        t_clean = normalize_title(t).lower()
        
        # Pokud název v souboru začíná hledaným názvem, ale má za ním další slova (např. "zelenacka fbi" vs "zelenac")
        # Porovnáme délku slovní zásoby v titulku
        fn_words = fn_title_clean.split()
        t_words = t_clean.split()
        
        # Pokud je v názvu souboru více slov než v hledaném titulu před S01E01, 
        # zkontrolujeme, zda to není známý přívlastek/spin-off
        if len(fn_words) > len(t_words):
            extra_words = fn_words[len(t_words):]
            # Pokud extra slova obsahují podstatné názvy jako fbi, la, miami apod.
            if any(w in extra_words for w in ['fbi', 'la', 'miami', 'ny', 'chicago']):
                extra_str = ' '.join(extra_words)
                return False, f"Jedná se o spin-off ({extra_str})"
    
    # Rozdělení složených názvů (např. "The Rookie - Zelenáč", "The Rookie / Zelenáč", "The Rookie-Zelenáč")
    raw_segments = re.split(r'\s*[-/:|]\s*|\s+-\s*', fn_title_part)
    raw_segments.append(fn_title_part)
    raw_segments.append(filename_without_ext)

    fn_segments_words = []
    for seg in raw_segments:
        norm_seg = normalize_title(seg)
        words = norm_seg.split()
        if words:
            fn_segments_words.append(words)

    if not fn_segments_words:
        return False, "Prázdný název souboru"

    match_found = False

    for t in titles_list:
        if not t:
            continue

        t_clean = t.strip()
        t_variants = [t_clean]

        t_lower = t_clean.lower()
        for prefix in ("the ", "a ", "an "):
            if t_lower.startswith(prefix):
                t_variants.append(t_clean[len(prefix):].strip())
                break

        for variant in t_variants:
            v_norm = normalize_title(variant)
            v_words = v_norm.split()
            if not v_words:
                continue

            v_len = len(v_words)

            for fn_words in fn_segments_words:
                fn_len = len(fn_words)
                if fn_len < v_len:
                    continue

                # Zkontrolujeme, zda v_words odpovídá souvislé sekvenci slov v fn_words
                for start_idx in range(fn_len - v_len + 1):
                    if all(words_match(fn_words[start_idx + i], v_words[i]) for i in range(v_len)):
                        match_found = True
                        break
                if match_found:
                    break

            if match_found:
                break

        if match_found:
            break

    if not match_found:
        return False, "Nezačíná správným textem"

    # 4. Kontrola traileru
    all_titles_str = " ".join([str(t) for t in titles_list]).lower()
    if 'trailer' not in all_titles_str:
        if re.search(r'(?<![a-z0-9])trailer(?![a-z0-9])', filename, re.IGNORECASE):
            return False, "Jedná se o Trailer"

    # 5. Kontrola seriálového označení (S01E01, 1x01 atd.)
    #has_series_pattern = bool(
    #    re.search(
    #        r'(?<![A-Za-z0-9])(?:s\d{1,2}[\s._-]*e\d{1,2}|\d{1,2}x\d{1,2})(?![A-Za-z0-9])',
    #        filename,
    #        re.IGNORECASE
    #    )
    #)
    
    # 5. Kontrola seriálového označení a PŘESNÉHO čísla epizody
    se_matches = re.findall(
        r'(?<![A-Za-z0-9])(?:s(\d{1,2})[\s._-]*e(\d{1,2})|(\d{1,2})x(\d{1,2}))(?![A-Za-z0-9])',
        filename,
        re.IGNORECASE
    )

    if media_type == 'movie':
        if se_matches:
            return False, "Jedná se o seriál"
    else:
        if not se_matches:
            return False, "Nejedná se o díl seriálu"
        
        # Pokud známe požadovanou sezónu a díl, ověříme je
        if target_season is not None and target_episode is not None:
            found_correct_episode = False
            for s1, e1, s2, e2 in se_matches:
                s_num = int(s1 if s1 else s2)
                e_num = int(e1 if e1 else e2)
                
                if s_num == int(target_season) and e_num == int(target_episode):
                    found_correct_episode = True
                    break

            if not found_correct_episode:
                # Vypíšeme první nalezenou epizodu ze souboru pro jasný debug log
                first_s = int(se_matches[0][0] if se_matches[0][0] else se_matches[0][2])
                first_e = int(se_matches[0][1] if se_matches[0][1] else se_matches[0][3])
                return False, f"Nesprávný díl (soubor má S{first_s:02d}E{first_e:02d}, hledáno S{int(target_season):02d}E{int(target_episode):02d})"

    # 6. Kontrola roku (pouze pro filmy; u seriálů ročník v názvu označuje vysílání konkrétní sezóny)
    if target_year and media_type == 'movie':
        target_year_str = str(target_year)
        fn_years = re.findall(r'(?<!\d)(19\d{2}|20\d{2})(?!\d)', filename)

        if fn_years and target_year_str not in fn_years:
            return False, f"Špatný rok ({fn_years[0]})"

    # 7. Kontrola čísel v názvu (pouze pro filmy)
    if media_type == 'movie':
        primary_title = titles_list[0] if titles_list else ""
        target_numbers = set(re.findall(r'\b\d+\b', primary_title))
        fn_lower = filename.lower()

        if target_year and str(target_year) in fn_lower:
            title_part = fn_lower.split(str(target_year))[0]
        else:
            year_match = re.search(r'(?<!\d)(19|20)\d{2}(?!\d)', fn_lower)
            title_part = fn_lower.split(year_match.group(0))[0] if year_match else fn_lower

        file_numbers = set(re.findall(r'\b\d+\b', title_part))

        if target_numbers:
            for num in target_numbers:
                if num not in file_numbers:
                    return False, f"Chybí číslo dílu / neshoda čísla ({num})"
        else:
            unexpected = [n for n in file_numbers if len(n) == 1 and n != '0']
            if unexpected:
                return False, f"Obsahuje číslo dílu ({unexpected[0]}), které v názvu filmu neexistuje"

    return True, "OK"

def search_webshare_raw(query, token=None, limit=20):
    norm_query = normalize_title(query)
    use_cache = _is_setting_enabled('exp_cache_results', True)
    cache_key = (norm_query, limit, bool(token))

    now = time.time()
    if use_cache and cache_key in _search_cache:
        cached_ts, cached_files = _search_cache[cache_key]
        if now - cached_ts < _CACHE_TTL:
            return [dict(f) for f in cached_files]

    url = "https://webshare.cz/api/search/"
    data = {
        'what': norm_query,
        'limit': limit,
        'sort': 'size',
        'category': 'video'
    }
    if token:
        data['wst'] = token
        
    try:
        use_keepalive = _is_setting_enabled('exp_session_keepalive', True)
        client = session if use_keepalive else requests
        r = client.post(url, data=data, timeout=8)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            
            status = root.findtext('status')
            if status and status != 'OK':
                return []

            files = []
            for f in root.findall('file'):
                files.append({
                    'ident': f.findtext('ident', ''),
                    'name': f.findtext('name', ''),
                    'size': int(f.findtext('size', 0)),
                    'password': str(f.findtext('password', '0')).strip().lower() in ('1', 'true', 'yes')
                })

            if use_cache:
                if len(_search_cache) > 500:
                    _search_cache.clear()
                _search_cache[cache_key] = (now, files)

            return files
    except Exception as e:
        log_debug(f"[Webshare API Chyba] {e}")
    return []

def search_and_verify_movie(tmdb_item, token=None, media_type='movie', limit=10):
    """Najde a vyhodnotí soubory pro jeden TMDB film (česky i anglicky)"""
    year = str(tmdb_item.get('year', '')).strip()
    title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
    title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type=media_type)
    title_en = clean_title_for_kodi(title_en, year=year, media_type=media_type)

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        tmdb_item.get('english_title', '').strip(),
        tmdb_item.get('title', '').strip(),
        tmdb_item.get('original_title', '').strip()
    ]))))

    queries = []
    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} {year}".strip(), "CZ"))
        queries.append((title_cz, "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} {year}".strip(), "EN"))
        queries.append((title_en, "EN"))

    found_files = {}
    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)
        for f in raw_files:
            f['_search_language'] = search_language
            found_files[f['ident']] = f

    results = []
    for ident, f in found_files.items():
        search_language = f.get('_search_language')

        valid, reason = validate_file(
            f['name'],
            f['password'],
            all_titles,
            year,
            media_type=media_type
        )

        lang = detect_language(f['name'], search_language=search_language)
        quality = detect_quality(f['name'])

        results.append({
            'name': f['name'],
            'ident': f['ident'],
            'size_mb': round(f['size'] / (1024 * 1024), 2),
            'valid': valid,
            'reason': reason,
            'lang': lang,
            'quality': quality
        })

    return {
        'tmdb_title': title_cz or title_en,
        'tmdb_id': tmdb_item.get('id'),
        'files': results
    }

def search_and_verify_movie_quick(tmdb_item, token=None, media_type='movie', limit=5): 
    """Rychlá verze vyhledání filmu - minimalizuje počet API dotazů"""
    year = str(tmdb_item.get('year', '')).strip()
    title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip() 
    title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip() 

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type=media_type)
    title_en = clean_title_for_kodi(title_en, year=year, media_type=media_type)

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        tmdb_item.get('english_title', '').strip(),
        tmdb_item.get('title', '').strip(),
        tmdb_item.get('original_title', '').strip()
    ]))))

    queries = [] 
    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} {year}".strip(), "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} {year}".strip(), "EN"))

    found_files = {}
    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)

        for f in raw_files:
            f['_search_language'] = search_language
            found_files[f['ident']] = f

        if found_files:
            break

    results = []
    for f in found_files.values():
        search_language = f.get('_search_language')

        valid, reason = validate_file(
            f['name'],
            f.get('password', False),
            all_titles,
            year,
            media_type=media_type
        )

        if not valid:
            #log_debug(
            #    f"search_and_verify_movie_quick() - "
            #    f"Rejected: {f['name']} - {reason}"
            #)
            continue

        lang = detect_language(f['name'], search_language=search_language)
        quality = detect_quality(f['name'])

        results.append({
            'name': f['name'],
            'ident': f['ident'],
            'size_mb': round(f['size'] / (1024 * 1024), 2),
            'valid': True,
            'reason': reason,
            'lang': lang,
            'quality': quality
        })

    return {
        'tmdb_title': title_cz or title_en,
        'tmdb_id': tmdb_item.get('id'),
        'files': results
    }
    

def check_tv_episode_availability(show_title, season_number, episode_number, year, token, limit=10):
    """Zkontroluje dostupnost jednoho dílu seriálu na Webshare a vrátí nejlepší shodu."""
    query = f"{show_title} S{season_number:02d}E{episode_number:02d}".strip()
    raw_files = search_webshare_raw(query, token=token, limit=limit)

    valid_candidates = []

    for file_item in raw_files:
        file_name = file_item['name']
        valid, reason = validate_file(
            file_name,
            file_item.get('password', False),
            show_title,
            year,
            media_type='tv',
            target_season=season_number,
            target_episode=episode_number
        )
        
        #log_debug(f"Kontrola episode: {query} - Soubor: {file_name} - Validní: {valid} - Důvod: {reason}")
        
        if not valid:
            continue

        lang = detect_language(file_name)
        quality = detect_quality(file_name)

        valid_candidates.append({
            'available': True,
            'lang': lang,
            'quality': quality,
            'name': file_name,
            'reason': reason,
            'ident': file_item.get('ident', ''),
            'query': query,
            'lang_score': get_language_score(lang),
            'quality_score': get_quality_score(quality)
        })

    if valid_candidates:
        # Vybere kandidáta s nejvyšším skóre podle jazyka a kvality
        best_candidate = max(
            valid_candidates,
            key=lambda x: (x['lang_score'], x['quality_score'])
        )
        
        # Odstraníme pomocné klíče skóre před vrácením výsledku
        best_candidate.pop('lang_score', None)
        best_candidate.pop('quality_score', None)
        
        return best_candidate

    return {
        'available': False,
        'lang': '??',
        'quality': '??',
        'name': '',
        'reason': 'Nenalezeno',
        'ident': '',
        'query': query,
    }

def check_tv_series(tmdb_item, token=None, limit=10):
    """Prohledá všechny výsledky pro daný seriál a vrátí nejlepší shodu dle jazyka a kvality."""
    year = str(tmdb_item.get('year', '')).strip()
    title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
    title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type='tv')
    title_en = clean_title_for_kodi(title_en, year=year, media_type='tv')

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        tmdb_item.get('english_title', '').strip(),
        tmdb_item.get('title', '').strip(),
        tmdb_item.get('original_title', '').strip()
    ]))))

    queries = []
    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} S01E01", "CZ"))
        if year:
            queries.append((f"{title_cz} {year} S01E01", "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} S01E01", "EN"))
        if year:
            queries.append((f"{title_en} {year} S01E01", "EN"))

    valid_candidates = []

    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)
        
        for file_item in raw_files:
            file_name = file_item['name']
            
            valid, reason = validate_file(
                file_name,
                file_item.get('password', False),
                all_titles,
                year,
                media_type='tv'
            )

            lang = detect_language(file_name, search_language=search_language)
            quality = detect_quality(file_name)

            if not valid:
                continue

            # Uložíme kandidáta spolu s vypočítaným skóre
            valid_candidates.append({
                'lang': lang,
                'quality': quality,
                'lang_score': get_language_score(lang),
                'quality_score': get_quality_score(quality)
            })

        # Zrychlení: pokud jsme nalezli CZ dabing, není třeba posílat další dotazy
        if any(c.get('lang') == 'CZ' for c in valid_candidates):
            break

    if valid_candidates:
        # Seřazení kandidátů: primárně podle jazyka (lang_score), sekundárně podle kvality (quality_score)
        best_match = max(
            valid_candidates,
            key=lambda x: (x['lang_score'], x['quality_score'])
        )

        return {
            'available': True,
            'lang': best_match['lang'],
            'quality': best_match['quality']
        }

    return {
        'available': False,
        'lang': '??',
        'quality': '??',
        'reason': 'Nenalezeno'
    }

def md5_crypt(password, salt, magic='$1$'):
    """MD5 crypt pro Webshare API"""
    if isinstance(password, str): password = password.encode('utf-8')
    if isinstance(salt, str): salt = salt.encode('utf-8')
    if isinstance(magic, str): magic = magic.encode('utf-8')
    m = hashlib.md5(); m.update(password + magic + salt)
    a = hashlib.md5(password + salt + password).digest()
    for i in range(len(password), 0, -16): m.update(a[:min(16, i)])
    i = len(password)
    while i:
        if i & 1: m.update(b'\x00')
        else: m.update(password[0:1])
        i >>= 1
    final = m.digest()
    for i in range(1000):
        m2 = hashlib.md5()
        if i & 1: m2.update(password)
        else: m2.update(final)
        if i % 3: m2.update(salt)
        if i % 7: m2.update(password)
        if i & 1: m2.update(final)
        else: m2.update(password)
        final = m2.digest()
    itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    def to64(v, n):
        ret = ""
        while n - 1 >= 0: n -= 1; ret += itoa64[v & 0x3f]; v >>= 6
        return ret
    hashed = to64((final[0]<<16)|(final[6]<<8)|final[12], 4) + to64((final[1]<<16)|(final[7]<<8)|final[13], 4) + \
             to64((final[2]<<16)|(final[8]<<8)|final[14], 4) + to64((final[3]<<16)|(final[9]<<8)|final[15], 4) + \
             to64((final[4]<<16)|(final[10]<<8)|final[5], 4) + to64(final[11], 2)
    return magic.decode('utf-8') + salt.decode('utf-8') + '$' + hashed

def login(user, password):
    """Přihlášení k Webshare API"""
    if not user or not password:
        return None
    try:
        r = session.post("https://webshare.cz/api/salt/", data={'username_or_email': user}, timeout=TIMEOUT)
        salt = ET.fromstring(r.content).findtext("salt")
        if not salt:
            log_debug("[Webshare CHYBA] login(): Nezískán salt ze serveru")
            return None
        enc = hashlib.sha1(md5_crypt(password, salt).encode('utf-8')).hexdigest()
        r = session.post("https://webshare.cz/api/login/", data={'username_or_email': user, 'password': enc, 'keep_logged_in': 1}, timeout=TIMEOUT)
        token = ET.fromstring(r.content).findtext("token")
        if not token:
            log_debug("[Webshare CHYBA] login(): Neplatné přihlašovací údaje")
        return token
    except Exception as e:
        log_debug(f"[Webshare CHYBA] login() výjimka: {e}")
        return None