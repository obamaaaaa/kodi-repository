import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import os

#sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

def _icon(name, fallbacks=None):
    """Vrátí cestu k ikoně s ověřením existence a podporou fallbacků."""
    primary = os.path.join(MEDIA_PATH, name)
    if os.path.exists(primary):
        return primary
    if fallbacks:
        for fb in fallbacks:
            if not fb:
                continue
            if fb.startswith('Default'):
                return fb
            fb_path = os.path.join(MEDIA_PATH, fb) if not os.path.isabs(fb) else fb
            if os.path.exists(fb_path):
                return fb_path
    return primary

ICONS = {
    'SEARCH': _icon('search.png'),
    'SEARCH_PLUS': _icon('searchplus.png', ['search.png']),
    'FILM': _icon('film.png'),
    'HISTORY': _icon('history.png'),
    'RESUME': _icon('history_resume.png', ['resume.png']),
    'WATCHED': _icon('history_watched.png', ['watched.png']),
    'POPULAR': _icon('popular.png', ['fire.png', 'trending.png', 'star.png']),
    'FIRE': _icon('fire.png', ['popular.png']),
    'TREND': _icon('trending.png', ['trend.png', 'fire.png']),
    'TRENDING': _icon('trending.png', ['trend.png', 'fire.png']),
    'NEW': _icon('new.png', ['news.png']),
    'NEWS': _icon('news.png', ['new.png']),
    'THEATRE': _icon('theatre.png'),
    'STAR': _icon('star.png'),
    'GENRES': _icon('genres.png'),
    'CZ': _icon('czech.png', ['cz.png']),
    'CZECH': _icon('czech.png', ['cz.png']),
    'MICROPHONE': _icon('microphone.png', ['czech.png']),
    'TRANSCRIPT': _icon('subtitles.png', ['transcript.png']),
    'SUBTITLES': _icon('subtitles.png', ['transcript.png']),
    'CALENDAR': _icon('calendar.png'),
    'BOOK': _icon('book.png'),
    'OVERLAY_WATCHED': _icon('watched.png', ['history_watched.png']),
    'OVERLAY_RESUME': _icon('resume.png', ['history_resume.png']),
    '4K': _icon('4k.png'),
    '1080': _icon('1080p.png'),
    '1080P': _icon('1080p.png'),
    '720': _icon('720p.png'),
    '720P': _icon('720p.png'),
    'SD': _icon('sd.png'),
    'ACTOR': _icon('actor.png', ['person.png', 'searchplus.png']),
    'DIRECTOR': _icon('director-chair.png', ['director.png', 'clapperboard.png', 'searchplus.png']),
    'DIRECTOR_CHAIR': _icon('director-chair.png', ['director.png']),
    'SETTINGS': _icon('settings.png', ['DefaultAddonService.png']),
    'DEF_VIDEO': 'DefaultVideo.png',
    'DEF_FOLDER': 'DefaultFolder.png',
    'NEXT': _icon('next.png', ['DefaultIconNext.png', 'book.png']),
    'PREV': _icon('prev.png', ['DefaultIconPrevious.png', 'book.png'])
}