import os
import uuid
import platform
import hashlib
import time
import requests

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcaddon = None
    xbmcvfs = None

SUPABASE_URL = "https://ewthovlfiuipyvfedrut.supabase.co/rest/v1/whitelist"
ANON_KEY = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
    "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV3dGhvdmxmaXVpcHl2ZmVkcnV0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE5ODI0MjgsImV4cCI6MjEwNzU1ODQyOH0."
    "6wbNeQ3l6iHlAk7cnO6FVlFLUtF5Lv3A2_VsLl-o88Y"
)

CACHE_TTL_SECONDS = 300  # 5 minut paměťová cache pro plynulé procházení menu


def log_debug(msg):
    if xbmc:
        xbmc.log(f"[Webshare Whitelist] {msg}", xbmc.LOGINFO)
    else:
        print(f"[Webshare Whitelist] {msg}")


def log_error(msg):
    if xbmc:
        xbmc.log(f"[Webshare Whitelist ERROR] {msg}", xbmc.LOGERROR)
    else:
        print(f"[Webshare Whitelist ERROR] {msg}")


def get_profile_path():
    """Vrátí absolutní cestu ke složce profilu doplňku."""
    if not xbmcaddon or not xbmcvfs:
        return os.path.dirname(os.path.abspath(__file__))
    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        raw_path = addon.getAddonInfo("profile")
        profile_path = xbmcvfs.translatePath(raw_path)
        if not os.path.exists(profile_path):
            os.makedirs(profile_path, exist_ok=True)
        return profile_path
    except Exception as e:
        log_error(f"Nelze získat profile path: {e}")
        return os.path.dirname(os.path.abspath(__file__))


def get_hw_code():
    """
    Vygeneruje nebo načte unikátní identifikátor zařízení (max 10 znaků).
    Ukládá se do souboru device_hw.id v profilu doplňku.
    """
    profile_dir = get_profile_path()
    id_file = os.path.join(profile_dir, "device_hw.id")

    # 1. Zkusíme načíst uložený kód ze souboru
    if os.path.exists(id_file):
        try:
            with open(id_file, "r", encoding="utf-8") as f:
                saved_code = f.read().strip()
            if saved_code:
                short_code = saved_code[:10].upper()
                if short_code != saved_code:
                    with open(id_file, "w", encoding="utf-8") as f:
                        f.write(short_code)
                _sync_settings(short_code)
                return short_code
        except Exception as e:
            log_error(f"Chyba při čtení device_hw.id: {e}")

    # 2. Vygenerujeme nový deterministický kód z hardwarových specifikací (10 znaků)
    try:
        mac_node = str(uuid.getnode())
        sys_name = platform.system()
        node_name = platform.node()
        machine = platform.machine()
        processor = platform.processor()
        kodi_name = xbmc.getInfoLabel("System.FriendlyName") if xbmc else ""
        kodi_os = xbmc.getInfoLabel("System.OSVersionInfo") if xbmc else ""

        raw_components = [
            sys_name,
            node_name,
            machine,
            processor,
            mac_node,
            kodi_name,
            kodi_os
        ]
        raw_string = "|".join(raw_components)
        full_hash = hashlib.sha256(raw_string.encode("utf-8")).hexdigest()
        hw_code = full_hash[:10].upper()
    except Exception as e:
        log_error(f"Chyba při generování hw_code: {e}")
        hw_code = uuid.uuid4().hex[:10].upper()

    # 3. Uložíme kód do souboru
    try:
        with open(id_file, "w", encoding="utf-8") as f:
            f.write(hw_code)
    except Exception as e:
        log_error(f"Nelze zapsat device_hw.id: {e}")

    _sync_settings(hw_code)
    return hw_code


def get_device_name():
    """Získá název zařízení (Kodi FriendlyName -> hostname -> 'Kodi')."""
    name = ""
    if xbmc:
        try:
            name = xbmc.getInfoLabel("System.FriendlyName")
        except Exception:
            pass
    if not name or not name.strip():
        name = platform.node()
    if not name or not name.strip():
        name = os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "Kodi"
    return name.strip()


def get_username():
    """Pro tabulku v DB slouží název zařízení."""
    return get_device_name()


def _sync_settings(hw_code):
    """Zobrazí kód a název zařízení v nastavení doplňku."""
    if not xbmcaddon:
        return
    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        if addon.getSetting("whitelist_hw_code") != hw_code:
            addon.setSetting("whitelist_hw_code", hw_code)
        dev_name = get_device_name()
        if addon.getSetting("whitelist_device_name") != dev_name:
            addon.setSetting("whitelist_device_name", dev_name)
    except Exception:
        pass


def get_headers(extra=None):
    headers = {
        "apikey": ANON_KEY,
        "Authorization": f"Bearer {ANON_KEY}",
    }
    if extra:
        headers.update(extra)
    return headers


def update_last_login(hw_code):
    """
    Zaznamená čas posledního přihlášení do Supabase.
    Vyzkouší RPC metodu record_device_login (obchází RLS), případně přímý PATCH.
    Provádí se tiše s krátkým timeoutem, aby nezdržoval chod doplňku.
    """
    if not hw_code:
        return
    try:
        # 1. Zkusíme RPC funkci (ideální pro Supabase s přísným RLS)
        rpc_url = "https://ewthovlfiuipyvfedrut.supabase.co/rest/v1/rpc/record_device_login"
        resp = requests.post(
            rpc_url,
            headers=get_headers({"Content-Type": "application/json"}),
            json={"p_hw_code": hw_code},
            timeout=3
        )
        if resp.status_code in (200, 204):
            return

        # 2. Fallback na přímý PATCH na tabulku whitelist
        patch_url = f"{SUPABASE_URL}?hw_code=eq.{hw_code}"
        requests.patch(
            patch_url,
            headers=get_headers({"Content-Type": "application/json"}),
            json={"last_login": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
            timeout=3
        )
    except Exception as e:
        log_debug(f"Aktualizace last_login selhala (nefatální): {e}")


def check_whitelist(force_refresh=False):
    """
    Ověří stav schválení zařízení v Supabase databázi.
    Vrací trojici: (is_approved: bool, status: str, is_new: bool)
    status může být:
      - 'approved' (schváleno)
      - 'pending' (čeká na schválení adminem)
      - 'registered' (nově odeslána žádost)
      - 'error' (chyba sítě / serveru)
    """
    hw_code = get_hw_code()
    dev_name = get_device_name()

    # 1. Rychlá kontrola paměťové cache (pokud není vynucen refresh)
    if not force_refresh and xbmcgui:
        try:
            window = xbmcgui.Window(10000)
            cached_approved = window.getProperty("wsc_whitelist_approved")
            cached_time = window.getProperty("wsc_whitelist_time")
            if cached_approved == "1" and cached_time:
                elapsed = time.time() - float(cached_time)
                if elapsed < CACHE_TTL_SECONDS:
                    return True, "approved", False
        except Exception:
            pass

    # 2. SELECT dotaz na stav v Supabase
    select_url = f"{SUPABASE_URL}?hw_code=eq.{hw_code}&select=is_approved,username"
    try:
        resp = requests.get(select_url, headers=get_headers(), timeout=7)
        if resp.status_code != 200:
            log_error(f"Supabase GET selhal (status {resp.status_code}): {resp.text}")
            return False, "error", False

        records = resp.json()
    except Exception as e:
        log_error(f"Chyba při komunikaci se Supabase: {e}")
        return False, "error", False

    # 3. Zpracování existujícího záznamu
    if records and len(records) > 0:
        row = records[0]
        is_approved = bool(row.get("is_approved", False))
        db_username = row.get("username", "")

        if is_approved:
            if xbmcgui:
                try:
                    window = xbmcgui.Window(10000)
                    window.setProperty("wsc_whitelist_approved", "1")
                    window.setProperty("wsc_whitelist_time", str(time.time()))
                except Exception:
                    pass
            update_last_login(hw_code)
            return True, "approved", False
        else:
            if xbmcgui:
                try:
                    xbmcgui.Window(10000).clearProperty("wsc_whitelist_approved")
                except Exception:
                    pass

            # Pokud se změnil název zařízení, aktualizujeme záznam v DB
            if dev_name and dev_name != db_username:
                try:
                    upsert_headers = get_headers({
                        "Content-Type": "application/json",
                        "Prefer": "resolution=merge-duplicates"
                    })
                    requests.post(
                        SUPABASE_URL,
                        headers=upsert_headers,
                        json={"username": dev_name, "hw_code": hw_code, "is_approved": False},
                        timeout=5
                    )
                except Exception as ex:
                    log_debug(f"Aktualizace názvu zařízení selhala: {ex}")

            return False, "pending", False

    # 4. DB nevrátila žádný záznam -> Odeslání nové žádosti (UPSERT / POST)
    try:
        upsert_headers = get_headers({
            "Content-Type": "application/json",
            "Prefer": "resolution=merge-duplicates,return=representation"
        })
        payload = {
            "username": dev_name,
            "hw_code": hw_code,
            "is_approved": False
        }
        post_resp = requests.post(SUPABASE_URL, headers=upsert_headers, json=payload, timeout=7)
        if post_resp.status_code in (200, 201):
            log_debug(f"Úspěšně vytvořena nová žádost o přístup pro {dev_name} ({hw_code})")
            if xbmcgui:
                try:
                    xbmcgui.Window(10000).clearProperty("wsc_whitelist_approved")
                except Exception:
                    pass
            return False, "registered", True
        else:
            log_error(f"POST do Supabase selhal (status {post_resp.status_code}): {post_resp.text}")
            return False, "error", False
    except Exception as e:
        log_error(f"Chyba při odesílání žádosti do Supabase: {e}")
        return False, "error", False


def ensure_access(force_refresh=False, silent=False):
    """
    Zkontroluje přístup. Pokud uživatel nemá přístup, zobrazí stručný dialog a vrátí False.
    Pokud má přístup, vrátí True.
    """
    is_approved, status, is_new = check_whitelist(force_refresh=force_refresh)

    if is_approved:
        return True

    if silent or not xbmcgui:
        return False

    hw_code = get_hw_code()
    dev_name = get_device_name()

    if status == "registered":
        xbmcgui.Dialog().ok(
            "Žádost odeslána",
            f"Zařízení: [B]{dev_name}[/B]\n"
            f"Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"[COLOR orange]Čeká na schválení adminem.[/COLOR]"
        )
    elif status == "pending":
        xbmcgui.Dialog().ok(
            "Čeká na schválení",
            f"Zařízení: [B]{dev_name}[/B]\n"
            f"Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"[COLOR orange]Přístup zatím nebyl schválen.[/COLOR]"
        )
    else:  # status == "error"
        xbmcgui.Dialog().ok(
            "Chyba spojení",
            f"Zařízení: [B]{dev_name}[/B]\n"
            f"Kód: {hw_code}\n\n"
            f"[COLOR red]Nelze ověřit přístup (chyba sítě).[/COLOR]"
        )

    return False


def show_whitelist_status_dialog():
    """
    Manuální kontrola stavu spuštěná z nastavení doplňku.
    """
    if not xbmcgui:
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Whitelist", "Ověřuji stav...")
    dp.update(50, "Kontaktuji server...")

    is_approved, status, is_new = check_whitelist(force_refresh=True)
    dp.close()

    hw_code = get_hw_code()
    dev_name = get_device_name()

    if is_approved:
        xbmcgui.Dialog().ok(
            "Schváleno",
            f"Zařízení: [B]{dev_name}[/B]\n"
            f"Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"[COLOR lime]Přístup je aktivní.[/COLOR]"
        )
    elif status == "registered":
        xbmcgui.Dialog().ok(
            "Žádost odeslána",
            f"Zařízení: [B]{dev_name}[/B]\n"
            f"Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"[COLOR orange]Čeká na schválení adminem.[/COLOR]"
        )
    elif status == "pending":
        xbmcgui.Dialog().ok(
            "Neschváleno",
            f"Zařízení: [B]{dev_name}[/B]\n"
            f"Kód: [COLOR yellow]{hw_code}[/COLOR]\n\n"
            f"[COLOR orange]Čeká na schválení adminem.[/COLOR]"
        )
    else:
        xbmcgui.Dialog().ok(
            "Chyba spojení",
            f"Zařízení: [B]{dev_name}[/B]\n"
            f"Kód: {hw_code}\n\n"
            f"[COLOR red]Nelze se spojit se serverem.[/COLOR]"
        )
