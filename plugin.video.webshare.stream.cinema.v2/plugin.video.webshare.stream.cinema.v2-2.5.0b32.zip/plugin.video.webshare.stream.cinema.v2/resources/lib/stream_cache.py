import json
import re
import time
import struct
import threading
import urllib.request
import urllib.parse

try:
    import xbmc
except ImportError:
    xbmc = None

SUPABASE_URL = "https://ewthovlfiuipyvfedrut.supabase.co/rest/v1"
ANON_KEY = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
    "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV3dGhvdmxmaXVpcHl2ZmVkcnV0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE5ODI0MjgsImV4cCI6MjEwNzU1ODQyOH0."
    "6wbNeQ3l6iHlAk7cnO6FVlFLUtF5Lv3A2_VsLl-o88Y"
)

LANG_MAP = {
    'ces': 'CZ', 'cze': 'CZ', 'cs': 'CZ', 'cz': 'CZ', 'czech': 'CZ',
    'slk': 'SK', 'slo': 'SK', 'sk': 'SK', 'slovak': 'SK',
    'eng': 'EN', 'en': 'EN', 'english': 'EN',
    'deu': 'DE', 'ger': 'DE', 'de': 'DE', 'german': 'DE',
    'fra': 'FR', 'fre': 'FR', 'fr': 'FR', 'french': 'FR',
    'ita': 'IT', 'it': 'IT', 'italian': 'IT',
    'spa': 'ES', 'es': 'ES', 'spanish': 'ES',
    'rus': 'RU', 'ru': 'RU', 'russian': 'RU',
    'jpn': 'JA', 'ja': 'JA', 'japanese': 'JA',
    'kor': 'KO', 'ko': 'KO', 'korean': 'KO',
    'pol': 'PL', 'pl': 'PL', 'polish': 'PL',
    'hun': 'HU', 'hu': 'HU', 'hungarian': 'HU',
    'ukr': 'UK', 'uk': 'UK', 'ukrainian': 'UK',
    'por': 'PT', 'pt': 'PT', 'portuguese': 'PT',
    'hin': 'HI', 'hi': 'HI', 'hindi': 'HI',
    'ara': 'AR', 'ar': 'AR', 'arabic': 'AR',
    'tur': 'TR', 'tr': 'TR', 'turkish': 'TR',
    'chi': 'ZH', 'zho': 'ZH', 'zh': 'ZH', 'chinese': 'ZH',
    'nld': 'NL', 'dut': 'NL', 'nl': 'NL', 'dutch': 'NL',
    'swe': 'SV', 'sv': 'SV', 'swedish': 'SV',
    'nor': 'NO', 'no': 'NO', 'norwegian': 'NO',
    'dan': 'DA', 'da': 'DA', 'danish': 'DA',
    'fin': 'FI', 'fi': 'FI', 'finnish': 'FI',
    'ell': 'EL', 'gre': 'EL', 'el': 'EL', 'greek': 'EL',
    'ron': 'RO', 'rum': 'RO', 'ro': 'RO', 'romanian': 'RO',
    'bul': 'BG', 'bg': 'BG', 'bulgarian': 'BG',
    'hrv': 'HR', 'scr': 'HR', 'hr': 'HR', 'croatian': 'HR',
    'srp': 'SR', 'scc': 'SR', 'sr': 'SR', 'serbian': 'SR',
    'slv': 'SL', 'sl': 'SL', 'slovenian': 'SL',
    'heb': 'HE', 'he': 'HE', 'hebrew': 'HE',
    'tha': 'TH', 'th': 'TH', 'thai': 'TH',
    'vie': 'VI', 'vi': 'VI', 'vietnamese': 'VI',
    'ind': 'ID', 'id': 'ID', 'indonesian': 'ID',
    'lat': 'LA', 'la': 'LA', 'latin': 'LA',
}


def log_info(msg):
    """Logování do konzole / Kodi logu bez zbytečně dlouhých textů."""
    prefix = "[StreamCache] "
    if xbmc:
        xbmc.log(prefix + str(msg), xbmc.LOGINFO)
    else:
        print(prefix + str(msg))


def normalize_lang(code):
    """Převede kód jazyka na standardní 2-písmenný kód."""
    if not code:
        return ""
    clean = str(code).strip().lower()
    if clean in LANG_MAP:
        return LANG_MAP[clean]
    if len(clean) == 2 and clean.isalpha():
        return clean.upper()
    if len(clean) == 3 and clean.isalpha():
        return clean[:2].upper()
    return ""


_session = None

def _get_http_session():
    global _session
    if _session is None:
        try:
            import requests
            _session = requests.Session()
            adapter = requests.adapters.HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=1)
            _session.mount("https://", adapter)
            _session.mount("http://", adapter)
        except Exception:
            _session = False
    return _session


_IN_MEMORY_STREAMS = {}
_IN_MEMORY_EXPIRES = {}
_IN_MEMORY_TTL = 600.0  # 10 minut


def get_cached_streams_batch(file_idents):
    """
    Rychle načte metadata souborů z mezipaměti nebo databáze Supabase pro seznam identů.
    Využívá lokální in-memory cache pro bleskovou odezvu (0ms) při opakovaném načtení
    a persistentní HTTP spojení (Keep-Alive) pro okamžité načtení desítek/stovek identů.
    Vrací slovník: {ident: záznam_z_db, ...}
    """
    if not file_idents:
        return {}

    now = time.time()
    clean_idents = list(dict.fromkeys([str(i).strip() for i in file_idents if i]))
    res = {}
    missing_idents = []

    for f_id in clean_idents:
        if f_id in _IN_MEMORY_STREAMS and now < _IN_MEMORY_EXPIRES.get(f_id, 0):
            res[f_id] = _IN_MEMORY_STREAMS[f_id]
        else:
            missing_idents.append(f_id)

    if not missing_idents:
        return res

    chunk_size = 80
    endpoint = SUPABASE_URL + "/stream_cache"
    headers = {
        "apikey": ANON_KEY,
        "Authorization": "Bearer " + ANON_KEY,
        "Accept": "application/json"
    }

    chunks = [missing_idents[i:i + chunk_size] for i in range(0, len(missing_idents), chunk_size)]

    def _fetch_chunk(chunk):
        idents_param = ",".join([urllib.parse.quote(str(i)) for i in chunk])
        url = endpoint + "?file_ident=in.(" + idents_param + ")&is_passworded=eq.false&select=*"
        sess = _get_http_session()
        if sess:
            try:
                resp = sess.get(url, headers=headers, timeout=2.5)
                if resp.status_code == 200:
                    return resp.json()
            except Exception as se:
                log_info("Session GET selhal, zkouším urllib: " + str(se))

        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                if resp.status == 200:
                    return json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            log_info("Chyba při čtení z DB: " + str(e))
        return []

    if len(chunks) > 1:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(len(chunks), 4)) as pool:
            results_list = list(pool.map(_fetch_chunk, chunks))
    else:
        results_list = [_fetch_chunk(chunks[0])]

    for rows in results_list:
        for r in rows:
            f_id = r.get('file_ident')
            if not f_id:
                continue
            a_info = r.get('audio_info')
            if isinstance(a_info, list) and len(a_info) > 0 and isinstance(a_info[0], dict):
                if a_info[0].get('duration') and not r.get('duration'):
                    r['duration'] = int(a_info[0]['duration'])
                if a_info[0].get('fps') and not r.get('fps'):
                    try:
                        r['fps'] = float(a_info[0]['fps'])
                    except (ValueError, TypeError):
                        pass
            if r.get('fps'):
                try:
                    r['fps'] = float(r['fps'])
                except (ValueError, TypeError):
                    pass
            _IN_MEMORY_STREAMS[f_id] = r
            _IN_MEMORY_EXPIRES[f_id] = now + _IN_MEMORY_TTL
            res[f_id] = r

    return res


def upsert_stream_record(record):
    """
    Vloží nebo aktualizuje záznam o streamu v Supabase.
    """
    if not record or not record.get('file_ident'):
        return False

    endpoint = SUPABASE_URL + "/stream_cache?on_conflict=tmdb_id,season,episode,file_ident"
    headers = {
        "apikey": ANON_KEY,
        "Authorization": "Bearer " + ANON_KEY,
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates"
    }

    sess = _get_http_session()
    if sess:
        try:
            resp = sess.post(endpoint, json=[record], headers=headers, timeout=3.5)
            if resp.status_code in (200, 201, 204):
                return True
            rec_copy = dict(record)
            modified = False
            if 'source' in resp.text and 'source' in rec_copy:
                del rec_copy['source']
                modified = True
            if 'fps' in resp.text and 'fps' in rec_copy:
                del rec_copy['fps']
                modified = True
            if modified:
                resp2 = sess.post(endpoint, json=[rec_copy], headers=headers, timeout=3.5)
                return resp2.status_code in (200, 201, 204)
        except Exception as se:
            log_info("Session POST selhal, zkouším urllib: " + str(se))

    payload = json.dumps([record]).encode('utf-8')
    req = urllib.request.Request(endpoint, data=payload, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status in (200, 201, 204)
    except urllib.error.HTTPError as he:
        err_body = he.read().decode('utf-8', errors='replace')
        rec_copy = dict(record)
        modified = False
        if 'source' in err_body and 'source' in rec_copy:
            del rec_copy['source']
            modified = True
        if 'fps' in err_body and 'fps' in rec_copy:
            del rec_copy['fps']
            modified = True
        if modified:
            payload2 = json.dumps([rec_copy]).encode('utf-8')
            req2 = urllib.request.Request(endpoint, data=payload2, headers=headers)
            try:
                with urllib.request.urlopen(req2, timeout=5) as resp2:
                    return resp2.status in (200, 201, 204)
            except Exception as e2:
                log_info("Chyba při opakovaném zápisu do DB: " + str(e2))
                return False
        log_info("Chyba při zápisu do DB: " + str(he) + " (" + err_body + ")")
        return False
    except Exception as e:
        log_info("Chyba při zápisu do DB: " + str(e))
        return False


def check_and_update_cache(ident, detected_info, tmdb_id=0, season=0, episode=0, file_name="", file_size=0):
    """
    Porovná detekované údaje se záznamem v DB a zaloguje výsledek.
    Pokud data chybí nebo nesedí, pošle aktualizaci do DB.
    """
    if not ident:
        return

    # 1. Zjistíme stávající záznam
    cached_map = get_cached_streams_batch([ident])
    existing = cached_map.get(ident)

    new_q = detected_info.get('quality', '??')
    new_codec = detected_info.get('codec') or ''
    new_hdr = detected_info.get('hdr') or ''
    new_fps = float(detected_info.get('fps') or 0.0)
    new_langs = detected_info.get('audio_languages') or []
    new_subs = detected_info.get('subtitles') or []
    source = detected_info.get('source') or ('hellspy' if ('_' in str(ident) and len(str(ident).split('_')[0]) >= 16) else 'webshare')
    s_num = int(season or 0)
    ep_num = int(episode or 0)
    tmdb_id_int = int(tmdb_id or 0)
    f_size = int(file_size or 0)
    size_mb = int(f_size // (1024 * 1024)) if f_size > 0 else int(detected_info.get('size_mb') or 0)

    if existing:
        old_q = existing.get('quality', '??')
        old_codec = existing.get('video_codec') or ''
        old_fps = float(existing.get('fps') or 0.0)
        
        # Kontrola, zda data sedí
        quality_match = (old_q == new_q or (old_q in ('4K', '1080p', '720p', 'SD') and new_q == '??'))
        codec_match = (not new_codec or not old_codec or old_codec.lower() == new_codec.lower())
        fps_match = (new_fps <= 0 or old_fps > 0)

        if quality_match and codec_match and fps_match:
            log_info(str(ident) + ": Data v DB sedí (" + str(old_q) + ", " + str(old_codec or "kodek OK") + ")")
            return

        # Nesoulad -> aktualizujeme
        log_info(str(ident) + ": Nesoulad dat v DB -> Aktualizuji (" + str(old_q) + " -> " + str(new_q) + ")")
        dur_val = int(detected_info.get('duration') or 0)
        fps_to_save = new_fps or old_fps
        if not dur_val and existing.get('audio_info'):
            old_ai = existing.get('audio_info')
            if isinstance(old_ai, list) and len(old_ai) > 0 and isinstance(old_ai[0], dict):
                dur_val = int(old_ai[0].get('duration') or 0)
                if not fps_to_save and old_ai[0].get('fps'):
                    fps_to_save = float(old_ai[0]['fps'])

        audio_info_payload = []
        ai_entry = {}
        if dur_val > 0:
            ai_entry['duration'] = dur_val
        if fps_to_save > 0:
            ai_entry['fps'] = fps_to_save
        if ai_entry:
            audio_info_payload.append(ai_entry)

        record = {
            "tmdb_id": tmdb_id_int or int(existing.get('tmdb_id') or 0),
            "media_type": existing.get('media_type') or ("tv" if (s_num > 0 or ep_num > 0) else "movie"),
            "season": s_num or int(existing.get('season') or 0),
            "episode": ep_num or int(existing.get('episode') or 0),
            "file_ident": str(ident),
            "source": source or existing.get('source', 'webshare'),
            "file_name": file_name or existing.get('file_name', ''),
            "size_bytes": f_size or int(existing.get('size_bytes') or 0),
            "size_mb": size_mb or int(existing.get('size_mb') or 0),
            "quality": new_q if new_q != '??' else old_q,
            "video_codec": new_codec or old_codec,
            "hdr_format": new_hdr or existing.get('hdr_format'),
            "audio_languages": new_langs or existing.get('audio_languages', []),
            "subtitles": new_subs or existing.get('subtitles', []),
            "audio_info": audio_info_payload,
            "is_passworded": False,
            "verified_count": int(existing.get('verified_count') or 1) + 1
        }
        if fps_to_save > 0:
            record["fps"] = fps_to_save

        upsert_stream_record(record)
        _IN_MEMORY_STREAMS[str(ident)] = record
        _IN_MEMORY_EXPIRES[str(ident)] = time.time() + _IN_MEMORY_TTL
    else:
        # Zcela nový záznam -> nahráváme do DB
        log_info(str(ident) + ": Nahrávám nová data do DB (" + str(new_q) + ", " + str(new_codec or "neznámý") + ")")
        dur_val = int(detected_info.get('duration') or 0)
        fps_to_save = new_fps
        audio_info_payload = []
        ai_entry = {}
        if dur_val > 0:
            ai_entry['duration'] = dur_val
        if fps_to_save > 0:
            ai_entry['fps'] = fps_to_save
        if ai_entry:
            audio_info_payload.append(ai_entry)

        record = {
            "tmdb_id": tmdb_id_int,
            "media_type": "tv" if (s_num > 0 or ep_num > 0) else "movie",
            "season": s_num,
            "episode": ep_num,
            "file_ident": str(ident),
            "source": source,
            "file_name": file_name,
            "size_bytes": f_size,
            "size_mb": size_mb,
            "quality": new_q,
            "video_codec": new_codec,
            "hdr_format": new_hdr,
            "audio_languages": new_langs,
            "subtitles": new_subs,
            "audio_info": audio_info_payload,
            "is_passworded": False,
            "verified_count": 1
        }
        if fps_to_save > 0:
            record["fps"] = fps_to_save

        upsert_stream_record(record)
        _IN_MEMORY_STREAMS[str(ident)] = record
        _IN_MEMORY_EXPIRES[str(ident)] = time.time() + _IN_MEMORY_TTL


# =========================================================================
# ANALYZÁTOR HLAVIČEK SOUBORŮ (HTTP RANGE PROBER: MKV & MP4)
# =========================================================================

def detect_fps_from_name(name):
    """
    Pokusí se extrahovat FPS z názvu souboru (např. 60fps, 50fps, 24fps, HFR).
    """
    if not name:
        return 0.0
    lower = str(name).lower()
    m = re.search(r'\b(23\.976|23\.98|24|25|29\.97|30|48|50|59\.94|60|120)\s*fps\b', lower)
    if m:
        try:
            return float(m.group(1))
        except (ValueError, TypeError):
            pass
    if '60fps' in lower or '60-fps' in lower or '60 fps' in lower:
        return 60.0
    if '50fps' in lower or '50 fps' in lower:
        return 50.0
    if '120fps' in lower:
        return 120.0
    if '24fps' in lower or '24 fps' in lower:
        return 24.0
    if 'hfr' in lower:
        return 60.0
    return 0.0


def probe_stream_metadata(stream_url, timeout=2.5, file_name=""):
    """
    Rychle stáhne prvních 128-384 KB streamu pomocí HTTP Range požadavku a analyzuje kodek,
    rozlišení, HDR, FPS a zvukové stopy bez stahování celého souboru.
    """
    if not stream_url:
        return None

    try:
        from resources.lib import mediainfo
        info = mediainfo.probe(stream_url)
        if info and not info.get('unreachable') and (info.get('width') or info.get('audio')):
            hdr_tag = info.get('hdr') or ('DV' if info.get('dv') else '')
            res = {
                'quality': mediainfo.quality_from_size(info.get('width', 0), info.get('height', 0)) or '??',
                'codec': info.get('vcodec', ''),
                'hdr': hdr_tag,
                'audio_languages': [a['lang'] for a in info.get('audio', []) if a.get('lang')],
                'audio_tracks': info.get('audio', []),
                'subtitles': info.get('subs', []),
                'width': info.get('width', 0),
                'height': info.get('height', 0),
                'duration': int(info.get('duration') or 0),
                'fps': 0.0
            }
            if file_name:
                fn_fps = detect_fps_from_name(file_name)
                if fn_fps > 0:
                    res['fps'] = fn_fps
            return res
        elif info and info.get('unreachable'):
            return None
    except Exception:
        pass

    req = urllib.request.Request(stream_url, headers={
        "Range": "bytes=0-393215",
        "User-Agent": "Kodi/21.0 (Windows NT 10.0; Win64; x64) StreamCinema"
    })
    
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            buf = resp.read()
            if not buf:
                return None
            res = parse_media_buffer(buf)
            if res and res.get('fps', 0.0) <= 0 and file_name:
                fn_fps = detect_fps_from_name(file_name)
                if fn_fps > 0:
                    res['fps'] = fn_fps
            return res
    except Exception as e:
        log_info("Nelze přečíst hlavičku streamu: " + str(e))
        return None


def parse_media_buffer(buf):
    """
    Analyzuje surový binární buffer (EBML MKV nebo MP4 atoms).
    """
    res = {
        'quality': '??',
        'codec': '',
        'hdr': '',
        'audio_languages': [],
        'subtitles': [],
        'width': 0,
        'height': 0,
        'duration': 0,
        'fps': 0.0
    }

    if not buf or len(buf) < 16:
        return res

    # 1. MKV detekce (EBML hlavička 0x1A45DFA3)
    if b'\x1a\x45\xdf\xa3' in buf[:128]:
        parse_mkv_buffer(buf, res)
    # 2. MP4 detekce (ftyp nebo moov atom)
    elif b'ftyp' in buf[:32] or b'moov' in buf[:1024]:
        parse_mp4_buffer(buf, res)

    # Odvození kvality podle rozlišení
    w, h = res.get('width', 0), res.get('height', 0)
    if h >= 2100 or w >= 3800:
        res['quality'] = '4K'
    elif h >= 1000 or w >= 1900:
        res['quality'] = '1080p'
    elif h >= 700 or w >= 1260:
        res['quality'] = '720p'
    elif h > 0 or w > 0:
        res['quality'] = 'SD'

    return res


def parse_mkv_buffer(buf, res):
    """Hledá stopy a vlastnosti uvnitř Matroska (MKV) bufferu."""
    # Detekce kodeku videa
    if b'V_MPEGH/ISO/HEVC' in buf or b'hev1' in buf or b'hvc1' in buf:
        res['codec'] = 'hevc'
    elif b'V_MPEG4/ISO/AVC' in buf or b'avc1' in buf:
        res['codec'] = 'h264'
    elif b'V_AV1' in buf or b'av01' in buf:
        res['codec'] = 'av1'
    elif b'V_VP9' in buf or b'vp09' in buf:
        res['codec'] = 'vp9'
    elif b'XVID' in buf or b'DIVX' in buf or b'V_MS/VFW/FOURCC' in buf:
        res['codec'] = 'xvid'

    # Detekce HDR
    if b'Dolby Vision' in buf or b'dvh1' in buf or b'dvhe' in buf:
        res['hdr'] = 'DV'
    elif b'\x55\xba' in buf:  # Colour element v MKV
        res['hdr'] = 'HDR10'

    # Detekce délky videa (Segment Info -> Duration 0x4489, TimecodeScale 0x2AD7B1)
    try:
        tc_scale = 1000000.0
        tc_m = re.search(rb'\x2a\xd7\xb1([\x81-\x88])', buf)
        if tc_m:
            tc_len = tc_m.group(1)[0] & 0x07
            tc_pos = tc_m.end()
            if tc_pos + tc_len <= len(buf):
                val = int.from_bytes(buf[tc_pos:tc_pos+tc_len], 'big')
                if val > 0:
                    tc_scale = float(val)
        dur_m = re.search(rb'\x44\x89([\x84\x88])', buf)
        if dur_m:
            sz = 4 if dur_m.group(1) == b'\x84' else 8
            pos = dur_m.end()
            if pos + sz <= len(buf):
                raw_dur = struct.unpack('>f' if sz == 4 else '>d', buf[pos:pos+sz])[0]
                if raw_dur > 0:
                    dur_sec = (raw_dur * tc_scale) / 1000000000.0
                    if 10 < dur_sec < 86400:
                        res['duration'] = int(round(dur_sec))
    except Exception:
        pass

    # Hledání PixelWidth (0xB0), PixelHeight (0xBA) a FPS v MKV EBML
    # Prioritně zkusíme najít začátek Tracks (0x16 0x54 0xAE 0x6B)
    tr_pos = buf.find(b'\x16\x54\xae\x6b')
    scan_buf = buf[tr_pos:] if tr_pos != -1 else buf

    def parse_ebml_dim(data, tag_bytes, min_v, max_v):
        for m in re.finditer(re.escape(tag_bytes) + rb'([\x81-\x84])', data):
            length = m.group(1)[0] & 0x07
            pos = m.end()
            if pos + length <= len(data):
                val = int.from_bytes(data[pos:pos+length], 'big')
                if min_v <= val <= max_v:
                    return val
        return 0

    w = parse_ebml_dim(scan_buf, b'\xb0', 320, 7680)
    if w:
        res['width'] = w

    h = parse_ebml_dim(scan_buf, b'\xba', 240, 4320)
    if h:
        res['height'] = h

    # Detekce FPS v MKV (DefaultDuration 0x23E383 = nanosekundy na snímek, nebo FrameRate 0x2383E3 = float)
    try:
        dd_m = re.search(rb'\x23\xe3\x83([\x81-\x88])', scan_buf)
        if dd_m:
            dd_len = dd_m.group(1)[0] & 0x7F
            dd_pos = dd_m.end()
            if dd_pos + dd_len <= len(scan_buf):
                ns_dur = int.from_bytes(scan_buf[dd_pos:dd_pos+dd_len], 'big')
                if 4000000 <= ns_dur <= 200000000:  # 5 fps až 250 fps
                    raw_fps = 1000000000.0 / float(ns_dur)
                    if 5.0 <= raw_fps <= 240.0:
                        res['fps'] = round(raw_fps, 3)
        if not res.get('fps'):
            fr_m = re.search(rb'\x23\x83\xe3([\x84\x88])', scan_buf)
            if fr_m:
                fr_sz = 4 if fr_m.group(1) == b'\x84' else 8
                fr_pos = fr_m.end()
                if fr_pos + fr_sz <= len(scan_buf):
                    raw_fr = struct.unpack('>f' if fr_sz == 4 else '>d', scan_buf[fr_pos:fr_pos+fr_sz])[0]
                    if 5.0 <= raw_fr <= 240.0:
                        res['fps'] = round(raw_fr, 3)
    except Exception:
        pass

    # Jazykové stopy audia a titulků z EBML TrackEntry bloků
    audio_langs = []
    sub_langs = []

    track_chunks = scan_buf.split(b'\xae')
    for chunk in track_chunks[1:]:
        # Zjištění typu stopy: Audio (TrackType 0x02) nebo Titulky (TrackType 0x11 = 17)
        is_audio = (
            b'\x83\x01\x02' in chunk or b'\x83\x02' in chunk
            or any(a in chunk for a in (b'A_AC3', b'A_AAC', b'A_DTS', b'A_TRUEHD', b'A_EAC3', b'A_OPUS', b'A_VORBIS', b'A_MPEG', b'A_FLAC'))
        )
        is_sub = (
            b'\x83\x01\x11' in chunk or b'\x83\x11' in chunk
            or any(s in chunk for s in (b'S_TEXT', b'S_VOBSUB', b'S_HDMV', b'S_IMAGE', b'S_ASS', b'S_SSA'))
        )

        # Hledání EBML tagu jazyka: \x22\xb5\x9c (Language) nebo \x22\xb5\x9d (LanguageIETF)
        lang = None
        m = re.search(rb'\x22\xb5[\x9c\x9d][\x81-\x8f]([a-zA-Z]{2,3})', chunk)
        if m:
            code = m.group(1).decode('ascii', errors='ignore').lower()
            lang = normalize_lang(code)

        if lang:
            if is_audio and lang not in audio_langs:
                audio_langs.append(lang)
            elif is_sub and lang not in sub_langs:
                sub_langs.append(lang)

    if audio_langs:
        res['audio_languages'] = sorted(audio_langs, key=lambda x: (x not in ('CZ', 'SK'), x))
    if sub_langs:
        res['subtitles'] = sorted(sub_langs, key=lambda x: (x not in ('CZ', 'SK'), x))


def parse_mp4_buffer(buf, res):
    """Základní detekce pro MP4 soubory."""
    if b'hvc1' in buf or b'hev1' in buf:
        res['codec'] = 'hevc'
    elif b'avc1' in buf:
        res['codec'] = 'h264'
    elif b'av01' in buf:
        res['codec'] = 'av1'
    elif b'vp09' in buf:
        res['codec'] = 'vp9'
    elif b'mp4v' in buf:
        res['codec'] = 'mpeg4'

    # Detekce délky videa z mvhd atomu
    try:
        mvhd_idx = buf.find(b'mvhd')
        if mvhd_idx != -1 and mvhd_idx + 28 <= len(buf):
            ver = buf[mvhd_idx + 4]
            if ver == 0:
                ts, dur = struct.unpack('>II', buf[mvhd_idx+16:mvhd_idx+24])
            elif ver == 1 and mvhd_idx + 40 <= len(buf):
                ts = struct.unpack('>I', buf[mvhd_idx+24:mvhd_idx+28])[0]
                dur = struct.unpack('>Q', buf[mvhd_idx+28:mvhd_idx+36])[0]
            else:
                ts, dur = 0, 0
            if ts > 0 and dur > 0:
                dur_sec = dur / float(ts)
                if 10 < dur_sec < 86400:
                    res['duration'] = int(round(dur_sec))
    except Exception:
        pass

    # Detekce FPS pro MP4 (mdhd timescale & stts sample_delta)
    try:
        mdhd_idx = buf.find(b'mdhd')
        timescale = 0
        if mdhd_idx != -1 and mdhd_idx + 28 <= len(buf):
            m_ver = buf[mdhd_idx + 4]
            if m_ver == 0:
                timescale = struct.unpack('>I', buf[mdhd_idx+16:mdhd_idx+20])[0]
            elif m_ver == 1 and mdhd_idx + 32 <= len(buf):
                timescale = struct.unpack('>I', buf[mdhd_idx+24:mdhd_idx+28])[0]
        stts_idx = buf.find(b'stts')
        if timescale > 0 and stts_idx != -1 and stts_idx + 20 <= len(buf):
            sample_delta = struct.unpack('>I', buf[stts_idx+16:stts_idx+20])[0]
            if sample_delta > 0:
                raw_fps = float(timescale) / float(sample_delta)
                if 5.0 <= raw_fps <= 240.0:
                    res['fps'] = round(raw_fps, 3)
    except Exception:
        pass

    # Detekce rozlišení z VisualSampleEntry (avc1, hvc1, hev1, av01, vp09, mp4v)
    for codec_tag in (b'avc1', b'hvc1', b'hev1', b'av01', b'vp09', b'mp4v'):
        idx = buf.find(codec_tag)
        if idx != -1 and idx + 32 <= len(buf):
            w = int.from_bytes(buf[idx+28:idx+30], 'big')
            h = int.from_bytes(buf[idx+30:idx+32], 'big')
            if 320 <= w <= 7680 and 240 <= h <= 4320:
                res['width'] = w
                res['height'] = h
                break

    # Záložní detekce z tkhd atomu, pokud sample entry selhalo
    if not res.get('width') or not res.get('height'):
        for m in re.finditer(rb'tkhd([\x00\x01])', buf):
            ver = m.group(1)[0]
            pos = m.start()
            offset_w = pos + 84 if ver == 0 else pos + 96
            offset_h = offset_w + 4
            if offset_h + 2 <= len(buf):
                w = int.from_bytes(buf[offset_w:offset_w+2], 'big')
                h = int.from_bytes(buf[offset_h:offset_h+2], 'big')
                if 320 <= w <= 7680 and 240 <= h <= 4320:
                    res['width'] = w
                    res['height'] = h
                    break

    # Jazyky pro MP4 (pouze ověřené 3-znakové ISO kódy pro zamezení falešných shod)
    found_langs = set()
    for code, clean in (
        ('ces', 'CZ'), ('cze', 'CZ'), ('slk', 'SK'), ('slo', 'SK'),
        ('eng', 'EN'), ('deu', 'DE'), ('pol', 'PL'), ('jpn', 'JA'),
        ('rus', 'RU'), ('fra', 'FR'), ('ita', 'IT'), ('spa', 'ES'),
        ('kor', 'KO'), ('hun', 'HU'), ('ukr', 'UK'), ('por', 'PT')
    ):
        if code.encode('ascii') in buf:
            found_langs.add(clean)
    if found_langs:
        res['audio_languages'] = sorted(list(found_langs), key=lambda x: (x not in ('CZ', 'SK'), x))


# =========================================================================
# OVĚŘOVÁNÍ SOUBORŮ (EXPERIMENTÁLNÍ)
# =========================================================================

def probe_files(files, tmdb_info, ws_token=None, async_mode=False, progress_callback=None, cancel_callback=None, max_probe=None):
    """
    Ověří soubory paralelně (buď synchronně před zobrazením, nebo asynchronně na pozadí).
    Získá technické parametry (rozlišení, kodek, HDR, audio, titulky) a aktualizuje DB i objekty files.
    """
    if not files:
        return files

    def _execute():
        from resources.lib import player
        from concurrent.futures import ThreadPoolExecutor

        tmdb_id = int(tmdb_info.get('id') or tmdb_info.get('tmdb_id') or 0)
        season = int(tmdb_info.get('season') or 0)
        episode = int(tmdb_info.get('episode') or 0)

        # Vybereme soubory (Webshare, Hellspy, Přehraj.to), které dosud NEJSOU v DB
        target_files = [
            f for f in files
            if f.get('ident') and not f.get('from_db') and f.get('source', 'webshare') in ('webshare', 'hellspy', 'prehrajto')
        ]

        # Zkontrolují se všechny soubory, které dosud nemají ověřená metadata v DB
        if max_probe and max_probe > 0:
            target_files = target_files[:max_probe]

        total = len(target_files)
        if total == 0:
            log_info("Všechny soubory jsou již v DB ověřeny nebo nepotřebují síťové sondování, přeskakuji.")
            return

        done_counter = [0]

        def _process(f):
            if cancel_callback and cancel_callback():
                return

            ident = f.get('ident')
            try:
                src_type = f.get('source', 'webshare')
                stream_url = None
                if src_type == 'webshare':
                    stream_url = player.get_webshare_direct_url(ident, wst_token=ws_token, silent=True, timeout=2.0) if ws_token else None
                elif src_type == 'hellspy':
                    try:
                        from resources.lib import hellspy
                        v_id = f.get('video_id') or (ident.split('_')[1] if '_' in str(ident) else '')
                        f_hash = f.get('file_hash') or (ident.split('_')[0] if '_' in str(ident) else '')
                        if v_id and f_hash:
                            stream_url = hellspy.get_hellspy_download_url(v_id, f_hash, timeout=2.5)
                    except Exception as he:
                        log_info(f"Hellspy probe URL chyba: {he}")
                elif src_type == 'prehrajto':
                    try:
                        from resources.lib import prehrajto
                        u, p = prehrajto.get_prehrajto_credentials()
                        if u and p and f.get('id'):
                            session = prehrajto.PrehrajtoSession.get()
                            stream_url = session.get_download_link(f['id'])
                        else:
                            # Bez přihlašovacích údajů síťové sondování neprovádíme (ochrana před 429), jen označíme ověřeno
                            f['verified'] = True
                            return
                    except Exception as pe:
                        log_info(f"Prehrajto probe URL chyba: {pe}")
                else:
                    f['verified'] = True
                    return

                if not stream_url:
                    if src_type == 'hellspy':
                        f['valid'] = False
                    return

                meta = probe_stream_metadata(stream_url, timeout=2.0, file_name=f.get('name', ''))
                if not meta:
                    meta = {
                        'quality': f.get('quality', '??'),
                        'codec': '',
                        'hdr': '',
                        'audio_languages': [f.get('lang')] if f.get('lang') else [],
                        'subtitles': [],
                        'fps': 0.0
                    }
                meta['source'] = src_type

                if meta.get('fps'):
                    f['fps'] = meta['fps']
                elif not f.get('fps'):
                    fn_fps = detect_fps_from_name(f.get('name', ''))
                    if fn_fps > 0:
                        f['fps'] = fn_fps
                        meta['fps'] = fn_fps

                # Promítneme ověřená reálná metadata přímo do položky
                if meta.get('duration'):
                    f['duration'] = meta['duration']
                elif f.get('duration'):
                    meta['duration'] = f.get('duration')
                elif src_type == 'webshare':
                    try:
                        from resources.lib import webshare
                        ws_len = webshare.get_webshare_file_length(ident, ws_token)
                        if ws_len > 0:
                            f['duration'] = ws_len
                            meta['duration'] = ws_len
                    except Exception:
                        pass

                if meta.get('quality') and meta['quality'] != '??':
                    f['quality'] = str(meta['quality']).lstrip('~')
                    f['quality_estimated'] = False
                if meta.get('codec'):
                    f['video_codec'] = meta['codec']
                    f['codec'] = meta['codec']
                if meta.get('hdr'):
                    f['hdr_format'] = meta['hdr']
                    f['hdr'] = meta['hdr']
                if meta.get('audio_languages'):
                    f['audio_languages'] = meta['audio_languages']
                    if 'CZ' in meta['audio_languages']:
                        f['lang'] = 'CZ'
                    elif 'SK' in meta['audio_languages']:
                        f['lang'] = 'SK'
                    elif meta['audio_languages']:
                        f['lang'] = meta['audio_languages'][0]
                if meta.get('subtitles'):
                    f['subtitles'] = meta['subtitles']

                f['from_db'] = True
                f['real_metadata'] = True

                # Uložíme / zaktualizujeme v Supabase DB a lokální RAM cache
                check_and_update_cache(
                    ident=ident,
                    detected_info=meta,
                    tmdb_id=tmdb_id,
                    season=season,
                    episode=episode,
                    file_name=f.get('name', ''),
                    file_size=f.get('size', 0)
                )
            except Exception as e:
                log_info("Chyba při kontrole souboru " + str(ident) + ": " + str(e))
            finally:
                done_counter[0] += 1
                if progress_callback:
                    progress_callback(done_counter[0], total)

        start_time = time.time()
        max_duration = 2.5 if not async_mode else 30.0

        pool = ThreadPoolExecutor(max_workers=10)
        try:
            from concurrent.futures import as_completed
            futures = [pool.submit(_process, f) for f in target_files]
            for fut in as_completed(futures):
                if cancel_callback and cancel_callback():
                    break
                if time.time() - start_time > max_duration:
                    log_info(f"Dosažen časový limit synchronního ověřování ({max_duration}s), pokračuji v zobrazení.")
                    break
        except Exception as e:
            log_info("Chyba při paralelním ověřování: " + str(e))
        finally:
            try:
                pool.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                pool.shutdown(wait=False)

        log_info("Ověřování souborů dokončeno.")

    if async_mode:
        t = threading.Thread(target=_execute, name="StreamCacheProbeWorker", daemon=True)
        t.start()
        return files
    else:
        _execute()
        return files


def start_background_probe_worker(files, tmdb_info, ws_token):
    """Zpětná kompatibilita pro spuštění na pozadí."""
    return probe_files(files, tmdb_info, ws_token, async_mode=True)


def probe_and_update_files_sync(files, tmdb_info, ws_token, progress_callback=None, cancel_callback=None, max_probe=None):
    """Zpětná kompatibilita pro synchronní spuštění."""
    return probe_files(files, tmdb_info, ws_token, async_mode=False, progress_callback=progress_callback, cancel_callback=cancel_callback, max_probe=max_probe)


