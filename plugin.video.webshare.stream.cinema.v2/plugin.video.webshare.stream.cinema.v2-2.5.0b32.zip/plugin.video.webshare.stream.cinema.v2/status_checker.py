import json
import re
import time
import urllib.parse
import xbmc
import xbmcgui
import xbmcaddon

import resources.lib.db as db


def log_debug(msg):
    """Bezpečné logování do Kodi logu."""
    xbmc.log(f"[Webshare StatusChecker] {msg}", xbmc.LOGINFO)


class WebsharePlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.reset_state()

    def reset_state(self):
        """Vynuluje sledované proměnné pro nové video."""
        self.current_tmdb_id = None
        self.current_media_type = "movie"
        self.current_title = ""
        self.current_season = 0
        self.current_episode = 0
        self.current_details = {}
        self.is_tracking = False
        self.last_saved_time = 0
        self.last_known_time = 0
        self.last_known_total_time = 0
        self.seek_attempts = 0
        self.current_file_id = None
        self.current_file_name = ""
        self.current_source = "webshare"
        self.cache_inspected = False
        self.tracks_configured = False

    def start_tracking(self, tmdb_id, media_type, title, season=0, episode=0, details=None):
        """Ruční inicializace dat pro sledování s ošetřením záporných hodnot sezóny/dílu."""
        self.current_tmdb_id = str(tmdb_id) if tmdb_id else None
        normalized = str(media_type or "movie").lower()
        if normalized in {"tv", "tvshow", "series", "episode"} or season > 0 or episode > 0:
            self.current_media_type = "tv"
        else:
            self.current_media_type = "movie"
        self.current_title = title or "Neznámý název"
        self.current_season = max(0, int(season or 0))
        self.current_episode = max(0, int(episode or 0))
        self.current_details = details or {}
        self.is_tracking = True if (self.current_tmdb_id or self.current_file_id) else False
        self.last_known_time = 0
        self.last_known_total_time = 0
        log_debug(
            f"Start tracking: {self.current_title} S{self.current_season}E{self.current_episode} (ID: {self.current_tmdb_id})"
        )

    def check_and_init_tracking(self):
        """Inicializuje sledování pozice a spolehlivý skok na rozkoukaný bod (resume)."""
        if not self.isPlayingVideo():
            return

        if not self.is_tracking:
            # 1. Zkusíme načíst metadata z Window property nastavené přehrávačem
            active_json = xbmcgui.Window(10000).getProperty("webshare_active_media")
            if active_json:
                try:
                    meta = json.loads(active_json)
                    self.current_file_id = meta.get("file_id", "")
                    self.current_file_name = meta.get("file_name", "")
                    self.current_source = meta.get("source", "webshare")
                    if meta.get("tmdb_id") or self.current_file_id:
                        self.start_tracking(
                            tmdb_id=meta.get("tmdb_id"),
                            media_type=meta.get("media_type", "movie"),
                            title=meta.get("title", ""),
                            season=meta.get("season", 0),
                            episode=meta.get("episode", 0),
                            details=meta.get("details", {})
                        )
                except Exception as e:
                    log_debug(f"Chyba při parsování webshare_active_media: {e}")

            # 2. Fallback na Kodi VideoInfoTag
            if not self.is_tracking:
                try:
                    tag = self.getVideoInfoTag()
                    title = tag.getTitle()
                    tmdb_id = tag.getUniqueID("tmdb")
                    season = max(0, tag.getSeason())
                    episode = max(0, tag.getEpisode())
                    media_type = tag.getMediaType() or ("tv" if episode > 0 else "movie")
                    normalized = str(media_type or "movie").lower()
                    if normalized in {"tv", "tvshow", "series", "episode"} or episode > 0 or season > 0:
                        media_type = "tv"
                    else:
                        media_type = "movie"

                    if tmdb_id and title:
                        self.start_tracking(
                            tmdb_id=tmdb_id,
                            media_type=media_type,
                            title=title,
                            season=season,
                            episode=episode,
                        )
                except Exception as e:
                    log_debug(f"Chyba při auto-detekci metadat z Tagu: {e}")

        # 3. Zpracování a ověření seeku (Resume)
        seek_target = xbmcgui.Window(10000).getProperty("webshare_resume_seek")
        if seek_target:
            try:
                seek_sec = float(seek_target)
                if seek_sec > 1:
                    cur_time = self.getTime()
                    # Pokud se video ještě nenachází v požadovaném čase, aplikujeme seek
                    if cur_time < (seek_sec - 5) and self.seek_attempts < 15:
                        log_debug(f"Aplikuji resume skok na {seek_sec}s (pokus {self.seek_attempts + 1}, aktuální čas: {cur_time:.1f}s)")
                        self.seekTime(seek_sec)
                        self.seek_attempts += 1
                        self.last_saved_time = seek_sec
                        self.last_known_time = seek_sec
                    else:
                        log_debug(f"Resume skok dokončen nebo vyčerpány pokusy. Aktuální čas: {cur_time:.1f}s")
                        xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
                        self.seek_attempts = 0
            except Exception as e:
                log_debug(f"Chyba při provádění resume seeku: {e}")

    def update_time_cache(self):
        """Ukládá do paměti aktuální pozici, dokud přehrávač běží."""
        if self.isPlayingVideo():
            try:
                self.last_known_time = self.getTime()
                self.last_known_total_time = self.getTotalTime()

                if not self.tracks_configured and self.last_known_time >= 0.5:
                    self.tracks_configured = True
                    self.apply_auto_audio_and_subtitles()

                if not self.cache_inspected and self.last_known_time >= 1.0 and self.current_file_id:
                    self.cache_inspected = True
                    self.inspect_and_update_stream_cache()
            except Exception:
                pass

    def apply_auto_audio_and_subtitles(self):
        """
        Automaticky nastaví audio a titulky podle preferencí:
        - Pokud je dostupný CZ/SK dabing, zvolí ho a vypne titulky.
        - Pokud CZ/SK dabing není (např. video je v EN): zvolí nejlepší audio (EN/orig)
          a pokud jsou dostupné CZ/SK titulky, vybere je a zapne je.
        """
        try:
            addon = xbmcaddon.Addon()
            enabled = addon.getSetting("auto_audio_subs")
            if enabled and enabled.lower() in ("false", "0"):
                return
        except Exception:
            pass

        try:
            audio_streams = self.getAvailableAudioStreams() or []
            sub_streams = self.getAvailableSubtitleStreams() or []
            if not audio_streams:
                return

            log_debug(f"[AutoAudioSubs] Dostupné audio: {audio_streams}, titulky: {sub_streams}")

            cz_audio_idx = -1
            sk_audio_idx = -1
            en_audio_idx = -1

            for idx, st in enumerate(audio_streams):
                st_lower = str(st).lower().strip()
                tokens = set(re.findall(r'[a-zA-Z0-9]+', st_lower))
                if any(t in ('cz', 'cze', 'ces', 'cs', 'czech') for t in tokens) or 'czech' in st_lower:
                    if cz_audio_idx == -1:
                        cz_audio_idx = idx
                elif any(t in ('sk', 'slk', 'slo', 'slovak') for t in tokens) or 'slovak' in st_lower:
                    if sk_audio_idx == -1:
                        sk_audio_idx = idx
                elif any(t in ('en', 'eng', 'english') for t in tokens) or 'english' in st_lower:
                    if en_audio_idx == -1:
                        en_audio_idx = idx

            has_native_dub = (cz_audio_idx != -1 or sk_audio_idx != -1)

            cur_lang = (xbmc.getInfoLabel('VideoPlayer.AudioLanguage') or '').lower().strip()

            if has_native_dub:
                chosen_idx = cz_audio_idx if cz_audio_idx != -1 else sk_audio_idx
                # Pokud stopa 0 je CZ/SK a už hraje, nepřepínáme zbytečně (zamezí restartu audio sinku a výpadku bufferu)
                is_already_active = False
                if chosen_idx == 0:
                    if not cur_lang or any(x in cur_lang for x in ('ces', 'cze', 'czech', 'cs', 'sk', 'slk', 'slo')):
                        is_already_active = True
                elif cur_lang:
                    chosen_name = str(audio_streams[chosen_idx]).lower()
                    if cur_lang in chosen_name:
                        is_already_active = True

                if not is_already_active:
                    log_debug(f"[AutoAudioSubs] Nalezen CZ/SK dabing (stopa {chosen_idx}: {audio_streams[chosen_idx]}). Přepínám na dabing.")
                    try:
                        self.setAudioStream(chosen_idx)
                    except Exception as e:
                        log_debug(f"[AutoAudioSubs] Chyba setAudioStream: {e}")
                else:
                    log_debug(f"[AutoAudioSubs] CZ/SK dabing již aktivní (stopa {chosen_idx}: {audio_streams[chosen_idx]}), nepřepínám.")

                try:
                    self.showSubtitles(False)
                except Exception:
                    pass
            else:
                if en_audio_idx != -1:
                    is_already_en = (en_audio_idx == 0 and (not cur_lang or any(x in cur_lang for x in ('eng', 'en'))))
                    if not is_already_en:
                        log_debug(f"[AutoAudioSubs] Chybí CZ dabing, volím EN audio (stopa {en_audio_idx}: {audio_streams[en_audio_idx]}).")
                        try:
                            self.setAudioStream(en_audio_idx)
                        except Exception:
                            pass

                cz_sub_idx = -1
                sk_sub_idx = -1
                for idx, st in enumerate(sub_streams):
                    st_lower = str(st).lower().strip()
                    tokens = set(re.findall(r'[a-zA-Z0-9]+', st_lower))
                    if any(t in ('cz', 'cze', 'ces', 'cs', 'czech') for t in tokens) or 'czech' in st_lower:
                        if cz_sub_idx == -1:
                            cz_sub_idx = idx
                    elif any(t in ('sk', 'slk', 'slo', 'slovak') for t in tokens) or 'slovak' in st_lower:
                        if sk_sub_idx == -1:
                            sk_sub_idx = idx

                chosen_sub_idx = cz_sub_idx if cz_sub_idx != -1 else sk_sub_idx
                if chosen_sub_idx != -1:
                    log_debug(f"[AutoAudioSubs] Zapínám CZ/SK titulky (stopa {chosen_sub_idx}: {sub_streams[chosen_sub_idx]}).")
                    try:
                        self.setSubtitleStream(chosen_sub_idx)
                        self.showSubtitles(True)
                    except Exception as e:
                        log_debug(f"[AutoAudioSubs] Chyba při zapnutí titulků: {e}")
                else:
                    log_debug(f"[AutoAudioSubs] Chybí CZ dabing, ale CZ/SK titulky nebyly nalezeny mezi stopami.")
        except Exception as e:
            log_debug(f"[AutoAudioSubs] Výjimka při auto výběru zvuku/titulků: {e}")

    def inspect_and_update_stream_cache(self):
        """Při spuštění souboru získá reálné informace o streamu (kodek, kvalita, jazyky, titulky) a zkontroluje/aktualizuje DB."""
        if not self.current_file_id:
            return

        try:
            from resources.lib import stream_cache

            # 1. Zjištění technických parametrů přímo z Kodi přehrávače
            v_codec = xbmc.getInfoLabel('VideoPlayer.VideoCodec')
            v_res_raw = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
            hdr_type = xbmc.getInfoLabel('VideoPlayer.HdrType')

            v_res_str = str(v_res_raw).lower()
            if '2160' in v_res_str or '4k' in v_res_str:
                quality = '4K'
            elif '1080' in v_res_str:
                quality = '1080p'
            elif '720' in v_res_str:
                quality = '720p'
            elif v_res_str and v_res_str != '0':
                quality = 'SD'
            else:
                quality = '??'

            audio_langs = []
            try:
                streams = self.getAvailableAudioStreams()
                for s in streams:
                    norm = stream_cache.normalize_lang(s)
                    if norm and norm not in audio_langs:
                        audio_langs.append(norm)
            except Exception:
                pass

            sub_langs = []
            try:
                sub_streams = self.getAvailableSubtitleStreams()
                for s in sub_streams:
                    norm = stream_cache.normalize_lang(s)
                    if norm and norm not in sub_langs:
                        sub_langs.append(norm)
            except Exception:
                pass

            detected_info = {
                'quality': quality,
                'codec': v_codec.lower() if v_codec else '',
                'hdr': hdr_type.upper() if hdr_type else '',
                'audio_languages': audio_langs,
                'subtitles': sub_langs,
                'source': self.current_source or 'webshare'
            }

            stream_cache.check_and_update_cache(
                ident=self.current_file_id,
                detected_info=detected_info,
                tmdb_id=int(self.current_tmdb_id or 0),
                season=int(self.current_season or 0),
                episode=int(self.current_episode or 0),
                file_name=self.current_file_name or self.current_title
            )
        except Exception as e:
            log_debug(f"Chyba při inspect_and_update_stream_cache: {e}")

    # =========================================================================
    # DETEKČNÍ METODY (UDÁLOSTI KODI PLAYERU)
    # =========================================================================
    
    def onAVStarted(self):
        """DETEKCE 1: Video se úspěšně načetlo a začalo hrát."""
        log_debug("Událost: onAVStarted - Video začalo hrát.")
        self.check_and_init_tracking()

    def onPlayBackPaused(self):
        """DETEKCE 2: Uživatel video pauznul -> uložit aktuální stav."""
        log_debug("Událost: onPlayBackPaused - Uživatel pozastavil video.")
        self._save_current_position(notify=True)

    def onPlayBackResumed(self):
        """Událost: Uživatel pokračuje v přehrávání po pauze."""
        pass

    def onPlayBackStopped(self):
        """DETEKCE 3: Uživatel ručně ukončil video."""
        log_debug("Událost: onPlayBackStopped - Uživatel ukončil video.")
        self._save_current_position(notify=True)
        self.reset_state()
        xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
        xbmcgui.Window(10000).clearProperty("webshare_active_media")

    def onPlayBackEnded(self):
        """DETEKCE 4: Video dohrálo až do úplného konce."""
        log_debug("Událost: onPlayBackEnded - Video dohrálo do konce.")
        self._save_current_position(force_ended=True, notify=True)
        self.reset_state()
        xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
        xbmcgui.Window(10000).clearProperty("webshare_active_media")

        
    def _save_current_position(self, force_ended=False, notify=False):
        """Interní logika pro výpočet času a uložení do DB bez pádu při zavřeném přehrávači."""
        if not self.is_tracking or not self.current_tmdb_id:
            return

        try:
            # Pokud video ještě běží, načteme přesný čas. Pokud už bylo ukončeno, použijeme chytrou cache.
            if self.isPlayingVideo():
                current_time = self.getTime()
                total_time = self.getTotalTime()
                self.last_known_time = current_time
                self.last_known_total_time = total_time
            else:
                current_time = self.last_known_time
                total_time = self.last_known_total_time

            if force_ended and total_time > 0:
                current_time = total_time

            log_debug(
                f"Ukládám pozici -> TMDB ID: {self.current_tmdb_id} | S{self.current_season}E{self.current_episode} Čas: {current_time:.1f}s / {total_time:.1f}s | Film/Serial: {self.current_title}"
            )


            db.update_watch_status(
                tmdb_id=self.current_tmdb_id,
                media_type=self.current_media_type,
                title=self.current_title,
                resume_time=current_time,
                total_time=total_time,
                season=self.current_season,
                episode=self.current_episode,
                details=self.current_details,
            )
            self.last_saved_time = current_time

            # Zobrazení oznámení při uložení
            if notify:
                try:
                    addon = xbmcaddon.Addon('plugin.video.webshare.stream.cinema.v2')
                    notify_enabled = addon.getSetting('notify_on_save') != 'false'
                except Exception:
                    notify_enabled = True

                if notify_enabled:
                    if (total_time > 0 and (current_time / total_time) >= 0.90) or force_ended:
                        msg = f"Označeno jako zhlédnuté: {self.current_title}"
                        xbmcgui.Dialog().notification("Webshare", msg, xbmcgui.NOTIFICATION_INFO, 3000)
                    elif current_time > 15:
                        s = int(current_time)
                        h = s // 3600
                        m = (s % 3600) // 60
                        sec = s % 60
                        time_str = f"{h:02d}:{m:02d}:{sec:02d}" if h > 0 else f"{m:02d}:{sec:02d}"
                        ep_str = f" (S{self.current_season:02d}E{self.current_episode:02d})" if (self.current_season > 0 and self.current_episode > 0) else ""
                        msg = f"Pozice uložena{ep_str}: {time_str}"
                        xbmcgui.Dialog().notification("Webshare", msg, xbmcgui.NOTIFICATION_INFO, 3000)

        except Exception as e:
            log_debug(f"Chyba při ukládání pozice do DB: {e}")


# =============================================================================
# DETEKCE UDÁLOSTÍ V DIALOGU INFORMACÍ O VIDEU (HERCI & REŽISÉR)
# =============================================================================
last_person_info = None  # (name, person_type, timestamp)


def check_video_info_dialog():
    """
    Sleduje okno Informace o videu (movieinformation / DialogVideoInfo.xml).
    Při kliknutí na herce (panel 50) nebo režiséra (tlačítko 13) Kodi nativně selže v lokální knihovně
    a zobrazí okno 'Nebyly nalezeny žádné výsledky'. Tuto událost zachytíme, zavřeme chybový dialog
    a přímo otevřeme vyhledání a filmografii dané osoby v doplňku Webshare Stream Cinema.
    """
    global last_person_info

    # Bleskový guard: pokud není otevřeno info okno ani dialog s chybou, okamžitě skončíme bez dalších dotazů
    if not (xbmc.getCondVisibility("Window.IsVisible(movieinformation) | Window.IsVisible(yesnodialog) | Window.IsVisible(okdialog)") or 
            xbmcgui.getCurrentWindowDialogId() in (12003, 2003, 10100, 10101)):
        return False

    is_info_visible = (
        xbmc.getCondVisibility("Window.IsVisible(movieinformation)") or
        xbmcgui.getCurrentWindowDialogId() in (12003, 2003)
    )

    if is_info_visible:
        # 1. Kontrola zaměření na herce v panelu (Control ID 50 v Estuary i dalších skinech)
        if xbmc.getCondVisibility("Control.HasFocus(50)"):
            actor_lbl = xbmc.getInfoLabel("Container(50).ListItem.Label")
            if actor_lbl:
                last_person_info = (actor_lbl.strip(), "actor", time.time())
        # 2. Kontrola zaměření na tlačítko režiséra (Control ID 13) nebo pole režiséra (Control ID 147)
        elif (xbmc.getCondVisibility("Control.HasFocus(13)") or 
              xbmc.getCondVisibility("Control.HasFocus(147)")):
            dir_lbl = xbmc.getInfoLabel("ListItem.Director") or xbmc.getInfoLabel("VideoPlayer.Director")
            if dir_lbl:
                first_dir = dir_lbl.split("/")[0].split(",")[0].strip()
                last_person_info = (first_dir or dir_lbl.strip(), "director", time.time())

    # 3. Zachycení vyskakujícího dialogu "Nebyly nalezeny žádné výsledky" (DialogConfirm / DialogOK)
    is_confirm_visible = (
        xbmc.getCondVisibility("Window.IsVisible(yesnodialog)") or
        xbmc.getCondVisibility("Window.IsVisible(okdialog)") or
        xbmcgui.getCurrentWindowDialogId() in (10100, 10101)
    )

    if is_confirm_visible and last_person_info:
        p_name, p_type, p_time = last_person_info
        if (time.time() - p_time) < 3.0:
            last_person_info = None  # Zabránění vícenásobnému spuštění
            type_cs = "herce" if p_type == "actor" else "režiséra"
            log_debug(f"Zachycena událost vyhledání {type_cs}: '{p_name}'. Otevírám filmografii ve Webshare Stream Cinema.")

            # Okamžitě zavřeme dialog s chybou i informační okno
            xbmc.executebuiltin("Dialog.Close(yesnodialog,true)")
            xbmc.executebuiltin("Dialog.Close(okdialog,true)")
            xbmc.executebuiltin("Dialog.Close(10100,true)")
            xbmc.executebuiltin("Dialog.Close(10101,true)")
            xbmc.executebuiltin("Dialog.Close(movieinformation,true)")
            xbmc.executebuiltin("Dialog.Close(12003,true)")

            # Otevřeme výpis filmografie dané osoby z našeho doplňku
            quoted = urllib.parse.quote_plus(p_name)
            target_url = f"plugin://plugin.video.webshare.stream.cinema.v2/?mode=search_person&query={quoted}&person_type={p_type}"
            xbmc.executebuiltin(f"ActivateWindow(Videos,{target_url},return)")
            return True

    return is_info_visible


# =============================================================================
# HLAVNÍ SMYČKA SLUŽBY (RUNNER)
# =============================================================================
if __name__ == "__main__":
    monitor = xbmc.Monitor()
    player = WebsharePlayer()

    # Inicializace zobrazení velikosti bufferu v nastavení doplňku
    try:
        from resources.lib import buffer_manager
        buffer_manager.update_addon_buffer_setting(xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2"))
    except Exception:
        pass

    was_in_webshare_root = False
    last_settings_check = 0
    last_path_check = 0
    exit_to_home_enabled = True
    autostart_attempted = False
    service_start_time = time.time()

    while not monitor.abortRequested():
        now = time.time()

        # Autostart při spuštění Kodi (styl Sosáč)
        if not autostart_attempted and (now - service_start_time) >= 1.5:
            autostart_attempted = True
            try:
                addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
                if addon.getSetting("autostart_on_boot") == "true":
                    log_debug("Autostart při zapnutí Kodi je aktivní. Spouštím Webshare Stream Cinema...")
                    xbmc.executebuiltin("ActivateWindow(Videos,plugin://plugin.video.webshare.stream.cinema.v2/,return)")
            except Exception as e:
                log_debug(f"Chyba při autostartu: {e}")

        # Kontrola čekající úlohy na ověření souborů (běží ve službě, takže main.py nikdy nečeká na vlákno)
        probe_task = xbmcgui.Window(10000).getProperty("webshare_probe_task")
        if probe_task:
            xbmcgui.Window(10000).clearProperty("webshare_probe_task")
            try:
                task_data = json.loads(probe_task)
                t_files = task_data.get('files', [])
                t_info = task_data.get('tmdb_info', {})
                t_tok = task_data.get('ws_token', '')
                from resources.lib import stream_cache
                stream_cache.start_background_probe_worker(t_files, t_info, t_tok)
            except Exception as e:
                log_debug(f"Chyba při spuštění probe tasku ze status_checker: {e}")

        # Kontrola událostí v okně informací o videu (herci / režisér)
        in_info_dialog = check_video_info_dialog()

        # Obnovení nastavení každé 4 sekundy
        if now - last_settings_check > 4.0:
            last_settings_check = now
            try:
                addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
                exit_to_home_enabled = addon.getSetting("exit_to_home") != "false"
            except Exception:
                exit_to_home_enabled = True

        is_playing = player.isPlayingVideo()

        if is_playing:
            was_in_webshare_root = False
            player.check_and_init_tracking()
            if player.is_tracking:
                player.update_time_cache()
                try:
                    curr_time = player.last_known_time
                    if abs(curr_time - player.last_saved_time) > 10:
                        player._save_current_position()
                except Exception:
                    pass
        else:
            # Kontrola návratu z hlavního menu doplňku na domovskou obrazovku Kodi (jednou za sekundu pro úsporu CPU)
            if exit_to_home_enabled and (now - last_path_check >= 1.0):
                last_path_check = now
                try:
                    current_path = xbmc.getInfoLabel("Container.FolderPath") or ""
                    clean_path = current_path.rstrip('/')
                    is_in_root = (clean_path == "plugin://plugin.video.webshare.stream.cinema.v2")
                    is_in_addon = clean_path.startswith("plugin://plugin.video.webshare.stream.cinema.v2")

                    if is_in_root:
                        was_in_webshare_root = True
                    elif is_in_addon:
                        was_in_webshare_root = False
                    elif was_in_webshare_root:
                        # Uživatel byl v kořenovém menu Webshare a stiskl Zpět
                        window_id = xbmcgui.getCurrentWindowId()
                        is_video_nav = (
                            window_id == 10025 or
                            xbmc.getCondVisibility("Window.IsVisible(videos)") or
                            any(clean_path.startswith(prefix) for prefix in (
                                "sources://", "library://", "addons://sources", "special://videonav"
                            ))
                        )
                        was_in_webshare_root = False
                        if is_video_nav:
                            log_debug(
                                f"Detekován odchod z hlavního menu Webshare do '{current_path}' (okno {window_id}). Přepínám na domovskou obrazovku Kodi."
                            )
                            xbmc.executebuiltin("ActivateWindow(home)")
                except Exception:
                    pass

        # Chytrý interval spánku: blesková reakce v dialogu (50ms), plynulost při videu (250ms), úspora CPU v idle (500ms)
        if in_info_dialog:
            sleep_interval = 0.05
        elif is_playing:
            sleep_interval = 0.25
        else:
            sleep_interval = 0.50

        if monitor.waitForAbort(sleep_interval):
            break