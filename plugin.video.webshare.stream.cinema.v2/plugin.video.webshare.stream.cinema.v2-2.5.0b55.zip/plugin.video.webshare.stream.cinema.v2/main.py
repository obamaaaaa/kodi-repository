import sys
import json
import time
import urllib.parse
import urllib.request
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

import resources.lib.db as db
import resources.lib.webshare as webshare
import resources.lib.player as player
import resources.lib.tmdb as tmdb
import resources.lib.whitelist as whitelist
from resources.lib.helper import ICONS, build_item_plot, format_fps
from resources.lib import tv_navigation
from resources.lib.title_cleaner import clean_title_for_kodi, calculate_match_score
import resources.lib.buffer_manager as buffer_manager
import xml.etree.ElementTree as ET

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

def is_popup_dialog_mode():
    """
    Způsob výběru streamu:
    Aktivní je výhradně standardní zobrazení v okně Kodi (klasický seznam s framem a popisky).
    Vyskakovací dialog (popup) zůstává zachován v backendu (funkce show_stream_popup_dialog)
    pro případné budoucí použití.
    """
    return False


def get_search_files_limit():
    """Vrátí nastavený limit počtu načítaných souborů z vyhledávání Webshare/HellSpy/Přehraj.to."""
    try:
        val = ADDON.getSetting('search_files_limit')
        if val:
            return max(5, min(100, int(float(val))))
    except Exception:
        pass
    return 20

def format_season_count(count):
    """Vrátí správně skloňovaný počet sérií v češtině (1 série, 2-4 série, 5+ sérií)."""
    try:
        n = int(count)
    except (ValueError, TypeError):
        return f"{count} sérií" if count else "? sérií"

    if n == 1:
        return "1 série"
    elif 2 <= n <= 4:
        return f"{n} série"
    else:
        return f"{n} sérií"

limit_to_search = 20
limit_to_search_quick = 5

def safe_set_genres(info_tag, raw_genres):
    """Bezpečně nastaví žánry do VideoInfoTag. Přijímá list řetězců, list slovníků [{'name': '...'}], čárkami oddělený string atd."""
    if not raw_genres or not info_tag:
        return
    clean_genres = []
    if isinstance(raw_genres, str):
        raw_genres = [g.strip() for g in raw_genres.split(',') if g.strip()]
    if isinstance(raw_genres, (list, tuple)):
        for g in raw_genres:
            if isinstance(g, dict):
                name = g.get('name') or ''
                if name:
                    clean_genres.append(str(name).strip())
            elif g is not None:
                s = str(g).strip()
                if s:
                    clean_genres.append(s)
    if clean_genres:
        try:
            info_tag.setGenres(clean_genres)
        except Exception:
            pass


def get_ws_token():
    """Vrátí uložený token z paměti Kodi, nebo provede nový login"""
    window = xbmcgui.Window(10000)  # Hlavní okno Kodi (drží paměť po dobu běhu Kodi)
    token = window.getProperty('ws_token')
    
    if not token:
        ws_user = ADDON.getSetting('username')
        ws_pass = ADDON.getSetting('password')
        token = webshare.login(ws_user, ws_pass)
        if token:
            window.setProperty('ws_token', token)
            
    return token

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def check_first_run_and_status():
    first_run = ADDON.getSetting('first_run_done')

    if first_run != 'true':
        ADDON.setSetting('first_run_done', 'true')
        whitelist.get_hw_code()
        dialog_ok("Vítejte v doplňku Webshare", "Doplněk byl úspěšně nainstalován. Prosím, nastavte své přihlašovací údaje a TMDB API klíč v nastavení doplňku.")
        ADDON.openSettings()
        return

    # Předání požadavku na ověření klíčů běžící službě status_checker na pozadí
    # (okamžitě pokračuje na zobrazení hlavní nabídky bez čekání)
    xbmcgui.Window(10000).setProperty("webshare_check_credentials", "1")

def log_debug(msg):
    s = str(msg).strip()
    if not s.startswith('['):
        s = f"[Webshare] {s}"
    xbmc.log(s, xbmc.LOGINFO)

def log_error(msg):
    s = str(msg).strip()
    if not s.startswith('['):
        s = f"[Webshare CHYBA] {s}"
    xbmc.log(s, xbmc.LOGERROR)

def log_timing(msg):
    s = str(msg).strip()
    if not s.startswith('['):
        s = f"[Webshare ČASOVÁNÍ] {s}"
    xbmc.log(s, xbmc.LOGINFO)

def dialog_ok(title, message):
    xbmcgui.Dialog().ok(title, message);

def dialog_notif(title, message, notif_type=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(title, message, notif_type, 5000);


def show_loading_dialog(title, message="Načítám..."):
    """Zobrazí loading dialog s textem o probíhající operaci."""
    dialog = xbmcgui.DialogProgress()
    dialog.create(title, message)
    return dialog


def close_loading_dialog(dialog):
    """Zavře loading dialog, pokud existuje."""
    if dialog:
        try:
            dialog.close()
        except Exception:
            pass


def update_loading_dialog(dialog, percent, message):
    """Aktualizuje progress dialog a jeho text. Vrátí True, pokud byl dialog zrušen."""
    if dialog:
        try:
            if dialog.iscanceled():
                return True
            dialog.update(percent, message)
            return dialog.iscanceled()
        except Exception:
            pass
    return False


def is_loading_cancelled(dialog):
    """Ověří, zda uživatel stiskl Zrušit na dialogu."""
    if dialog:
        try:
            return bool(dialog.iscanceled())
        except Exception:
            pass
    return False





def apply_view_mode(mode_id=50, wait=False):
    """Aktivuje vybraný styl zobrazení v Kodi (50 = Estuary StreamCinema 3-sloupcový seznam s pravým panelem).

    wait=True: po endOfDirectory Kodi asynchronně načítá seznam a může přebít náš režim
    uloženým pohledem. Proto opakujeme SetViewMode, dokud není cílový pohled opravdu viditelný.
    """
    try:
        if not wait:
            xbmc.executebuiltin(f"Container.SetViewMode({mode_id})")
            return
        stable = 0
        for _ in range(30):
            if xbmc.getCondVisibility(f"Control.IsVisible({mode_id})"):
                stable += 1
                if stable >= 5:
                    return
            else:
                stable = 0
                xbmc.executebuiltin(f"Container.SetViewMode({mode_id})")
            xbmc.sleep(100)
    except Exception:
        pass


_STREAM_SEARCH_CACHE = {}
_STREAM_SEARCH_CACHE_TTL = 900  # 15 minut


def get_progress_label_suffix(tmdb_id, media_type, total_episodes=0):
    """Vrátí řetězec s procenty rozkoukání pro film nebo seriál."""
    if not tmdb_id:
        return ""
    
    if media_type == "tv":
        pct = db.get_tv_show_progress(tmdb_id, total_episodes)
        if pct >= 100:
            return " [COLOR lime](Zhlédnuto)[/COLOR]"
        elif pct > 0:
            return f" [COLOR orange]({pct}%)[/COLOR]"
    else:
        st = db.get_item_watch_status(tmdb_id, 0, 0)
        if st:
            if st.get('watched'):
                return " [COLOR lime](Zhlédnuto)[/COLOR]"
            elif st.get('total_time', 0) > 0 and st.get('resume_time', 0) > 15:
                pct = int((st['resume_time'] / st['total_time']) * 100)
                return f" [COLOR orange]({pct}%)[/COLOR]"
    return ""


def apply_budget_and_vote_properties(li, info_tag, item_or_details):
    """Nastaví properties pro rozpočet (USD i CZK), počet hodnocení TMDB a statistiky seriálů."""
    if not item_or_details:
        return

    # 1. Rozpočet (USD a CZK)
    b_fmt = item_or_details.get('budget_formatted')
    b_czk = item_or_details.get('budget_czk')
    raw_b = item_or_details.get('budget') or 0
    if not b_fmt and raw_b and raw_b > 0:
        if raw_b >= 1000000:
            b_fmt = f"${raw_b / 1000000:.1f}M".replace(".0M", "M")
        elif raw_b >= 1000:
            b_fmt = f"${raw_b / 1000:.0f}k"
        else:
            b_fmt = f"${raw_b:,}"

        czk_val = raw_b * 23.5
        if czk_val >= 1000000000:
            b_czk = f"{czk_val / 1000000000:.1f} mld CZK".replace(".0 mld", " mld")
        elif czk_val >= 1000000:
            b_czk = f"{czk_val / 1000000:.1f} mil CZK".replace(".0 mil", " mil")
        elif czk_val >= 1000:
            b_czk = f"{czk_val / 1000:.0f} tis CZK"
        else:
            b_czk = f"{int(czk_val)} CZK"

    if b_fmt:
        li.setProperty('Budget', b_fmt)
    if b_czk:
        li.setProperty('Budget_CZK', b_czk)

    # 2. Počet hodnocení
    v_fmt = item_or_details.get('votes_formatted')
    v_cnt = item_or_details.get('vote_count') or 0
    if not v_fmt and v_cnt and v_cnt > 0:
        v_num_str = f"{v_cnt:,}".replace(",", ".")
        v_fmt = f"({v_num_str} hodnocení)"

    if v_fmt:
        li.setProperty('VotesFormatted', v_fmt)
    if v_cnt and info_tag:
        try:
            info_tag.setVotes(int(v_cnt))
        except Exception:
            pass

    # 3. Pro seriály: počet sérií a epizod + stav seriálu pro pravý panel
    num_seasons = item_or_details.get('number_of_seasons') or 0
    num_episodes = item_or_details.get('number_of_episodes') or 0
    raw_status = str(item_or_details.get('status') or '').strip()

    status_cz_map = {
        'Returning Series': 'Vysílá se',
        'Ended': 'Ukončeno',
        'Canceled': 'Zrušeno',
        'In Production': 'V produkci',
        'Planned': 'Plánováno',
        'Pilot': 'Pilot'
    }
    status_cz = status_cz_map.get(raw_status, raw_status)

    if num_seasons > 0 or num_episodes > 0:
        if num_seasons == 1:
            s_str = "1 série"
        elif 2 <= num_seasons <= 4:
            s_str = f"{num_seasons} série"
        elif num_seasons > 4:
            s_str = f"{num_seasons} sérií"
        else:
            s_str = ""

        if num_episodes == 1:
            e_str = "1 díl"
        elif 2 <= num_episodes <= 4:
            e_str = f"{num_episodes} díly"
        elif num_episodes > 4:
            e_str = f"{num_episodes} dílů"
        else:
            e_str = ""

        if s_str and e_str:
            stats_str = f"{s_str} • {e_str}"
        else:
            stats_str = s_str or e_str

        li.setProperty('Series_Stats', stats_str)
        if status_cz:
            li.setProperty('Series_Status', f"Stav: {status_cz}")
        elif e_str and not s_str:
            li.setProperty('Series_Status', f"Celkem {e_str}")


def select_single_display_language(langs_iterable, target_category=None):
    """
    Vybere přesně JEDEN prioritní jazyk pro zobrazení (CZ > CZ TIT > SK > EN > PL).
    V kategorii 'subtitled' preferuje titulky (CZ TIT > SK TIT > EN TIT > CZ > SK > EN > PL).
    Vrací naformátovaný barevný štítek pro jeden jazyk, např. '[COLOR lime][CZ][/COLOR]', nebo ''.
    """
    all_extracted = set()
    for l_item in (langs_iterable or []):
        if not l_item:
            continue
        parts = [p.strip().upper() for p in str(l_item).split('/') if p.strip()]
        for p in parts:
            if p and p != '??':
                all_extracted.add(p)

    if not all_extracted:
        return ""

    def _sort_key(l):
        if target_category == "subtitled":
            if 'TIT' in l or 'SUB' in l:
                if 'CZ' in l: return 0
                if 'SK' in l: return 1
                return 2
            if l == 'CZ': return 3
            if l == 'SK': return 4
            if l == 'EN': return 5
            if l == 'PL': return 6
            return 7
        else:
            if l == 'CZ': return 0
            if 'TIT' in l or 'SUB' in l:
                if 'CZ' in l: return 1
                if 'SK' in l: return 2
                return 3
            if l == 'SK': return 4
            if l == 'EN': return 5
            if l == 'PL': return 6
            return 7

    sorted_langs = sorted(list(all_extracted), key=_sort_key)
    best_lang = sorted_langs[0]

    if best_lang == 'CZ':
        return "[COLOR lime][CZ][/COLOR]"
    elif 'TIT' in best_lang or 'SUB' in best_lang:
        disp_tit = "CZ TIT" if best_lang in ('TIT', 'CZ TIT', 'SUB', 'CZ SUB') else best_lang
        return f"[COLOR yellow][{disp_tit}][/COLOR]"
    elif best_lang == 'SK':
        return "[COLOR yellow][SK][/COLOR]"
    elif best_lang == 'EN':
        return "[COLOR blue][EN][/COLOR]"
    elif best_lang == 'PL':
        return "[COLOR lightgray][PL][/COLOR]"
    else:
        return f"[COLOR gray][{best_lang}][/COLOR]"


def build_media_item_label(item, media_type, ws_token, prefix="", target_category=None):
    """
    Sestaví popisek a jazykový řetězec pro film nebo seriál s ověřením dostupnosti na Webshare.
    Zajistí jednotné formátování jak v kategoriích (populární atd.), tak ve vyhledávání.
    """
    total_episodes = item.get('number_of_episodes', 0)
    progress_suffix = get_progress_label_suffix(item.get('id'), media_type, total_episodes)

    if media_type == 'tv':
        show_p = db.get_tv_show_progress(item.get('id'), total_episodes)
        is_watched = (show_p >= 100)
    else:
        st = db.get_item_watch_status(item.get('id'), 0, 0)
        is_watched = bool(st and st.get('watched'))

    pref_str = f"{prefix} " if prefix else ""
    raw_title = item.get('title', '')
    title_text = clean_title_for_kodi(
        raw_title,
        english_title=item.get('english_title', ''),
        original_title=item.get('original_title', ''),
        year=item.get('year', ''),
        media_type=media_type
    )
    disp_title = f"[COLOR gray]{title_text}[/COLOR]" if is_watched else title_text
    item_year = item.get('year', '')

    tmdb_id = str(item.get('id') or '')
    cached_avail = db.get_availability_cache(media_type, tmdb_id, ttl_seconds=86400) if tmdb_id else None

    if media_type == "tv":
        if cached_avail and isinstance(cached_avail, dict):
            series_check = cached_avail
        else:
            series_check = webshare.check_tv_series(item, token=ws_token, limit=get_search_files_limit(), target_category=target_category)
            if tmdb_id and series_check:
                db.set_availability_cache('tv', tmdb_id, series_check)

        season_count = item.get('number_of_seasons') or 0
        season_text = format_season_count(season_count) if season_count else "? sérií"
        series_lang = series_check.get('lang', '??')
        all_langs = series_check.get('all_langs') or ([series_lang] if series_lang != '??' else [])
        if series_check.get('available'):
            season_part = f" • [COLOR lime]{season_text}[/COLOR]" if season_text else ""
            label = f"{pref_str}{disp_title}{progress_suffix}{season_part}"
            lang_candidates = all_langs if all_langs else ([series_lang] if series_lang != '??' else [])
            lang_str = select_single_display_language(lang_candidates, target_category=target_category)
            if not lang_str and series_lang and series_lang != '??':
                lang_str = select_single_display_language([series_lang], target_category=target_category)
            if any(l in ('CZ', 'SK') for l in all_langs):
                item['has_dubbing'] = True
            if any('TIT' in l or 'SUB' in l for l in all_langs):
                item['has_subtitles'] = True
        else:
            label = f"[COLOR gray]{pref_str}{title_text}{progress_suffix} • {season_text} • S01E01 nenalezen[/COLOR]"
            lang_str = "[COLOR gray]S01E01 nenalezen[/COLOR]"
    else:
        if cached_avail and isinstance(cached_avail, dict):
            valid_files = cached_avail.get('valid_files', [])
        else:
            available_files = webshare.search_and_verify_movie_quick(item, token=ws_token, media_type=media_type, limit=limit_to_search_quick, target_category=target_category).get("files", [])
            valid_files = [f for f in available_files if f.get('valid', True)]

            # Rychlá kontrola dostupnosti dabingu na HellSpy (pokud na Webshare dabing není nebo je prázdno)
            if ADDON.getSetting('source_hellspy') == 'true':
                has_cz_audio = any(('CZ' in str(f.get('lang', '')).upper() and 'TIT' not in str(f.get('lang', '')).upper()) for f in valid_files)
                if not has_cz_audio and (not valid_files or target_category in ('dubbed', None)):
                    try:
                        from resources.lib import hellspy
                        hs_files = hellspy.search_hellspy(item, media_type='movie', limit=3)
                        valid_hs = [f for f in hs_files if f.get('valid', True)]
                        if valid_hs:
                            valid_files.extend(valid_hs)
                    except Exception:
                        pass

            # Rychlá kontrola mezipaměti Supabase pro nalezené identy (0ms RAM cache / Keep-Alive)
            if valid_files:
                try:
                    from resources.lib import stream_cache
                    f_ids = [f.get('ident') for f in valid_files if f.get('ident')]
                    if f_ids:
                        c_meta = stream_cache.get_cached_streams_batch(f_ids)
                        for f in valid_files:
                            c_rec = c_meta.get(f.get('ident'))
                            if c_rec:
                                if c_rec.get('audio_languages'):
                                    f['audio_languages'] = c_rec['audio_languages']
                                    if 'CZ' in c_rec['audio_languages']:
                                        f['lang'] = 'CZ'
                                    elif 'SK' in c_rec['audio_languages']:
                                        f['lang'] = 'SK'
                                if c_rec.get('subtitles'):
                                    f['subtitles'] = c_rec['subtitles']
                                    if any(s.lower() in ('cz', 'sk', 'cze', 'slo', 'slk', 'cs') for s in c_rec['subtitles']):
                                        if 'TIT' not in str(f.get('lang', '')):
                                            f['lang'] = str(f.get('lang', 'EN')) + '/CZ TIT'
                except Exception:
                    pass

            # Rychlá sonda 1. Webshare souboru pro kategorii s titulky (pokud titulky zatím z názvu ani DB neznáme)
            if target_category == 'subtitled' and valid_files and ws_token:
                has_subs_yet = any(('TIT' in str(f.get('lang', '')).upper() or 'SUB' in str(f.get('lang', '')).upper() or any('cz' in str(s).lower() or 'sk' in str(s).lower() for s in f.get('subtitles', []))) for f in valid_files)
                if not has_subs_yet:
                    top_ws = next((f for f in valid_files if f.get('source', 'webshare') == 'webshare' and f.get('ident')), None)
                    if top_ws:
                        try:
                            from resources.lib import player, stream_cache
                            s_url = player.get_webshare_direct_url(top_ws['ident'], wst_token=ws_token, silent=True, timeout=1.2)
                            if s_url:
                                p_meta = stream_cache.probe_stream_metadata(s_url, timeout=1.0, file_name=top_ws.get('name', ''))
                                if p_meta and p_meta.get('subtitles'):
                                    if any(s.lower() in ('cz', 'sk', 'cze', 'slo', 'slk', 'cs') for s in p_meta['subtitles']):
                                        top_ws['subtitles'] = p_meta['subtitles']
                                        top_ws['lang'] = 'EN/CZ TIT'
                                        stream_cache.check_and_update_cache(top_ws['ident'], p_meta, tmdb_id=item.get('id', 0), file_name=top_ws.get('name', ''), file_size=top_ws.get('size', 0))
                        except Exception:
                            pass

            if tmdb_id:
                # Uložíme kompaktní reprezentaci nalezených souborů (jen ident, lang, quality, valid)
                cache_files = [{'ident': f.get('ident'), 'lang': f.get('lang'), 'quality': f.get('quality'), 'valid': f.get('valid', True)} for f in valid_files]
                db.set_availability_cache('movie', tmdb_id, {'valid_files': cache_files})

        if not valid_files:
            label = f"[COLOR grey]NEDOSTUPNÉ: {pref_str}{title_text}{progress_suffix}[/COLOR]"
            lang_str = "[COLOR gray]NENALEZENO[/COLOR]"
        else:
            langs_set = set()
            for f in valid_files:
                raw_lang = str(f.get('lang', '')).upper().strip()
                if raw_lang and raw_lang != '??':
                    parts = [p.strip() for p in raw_lang.split('/') if p.strip()]
                    for p in parts:
                        if p != '??':
                            langs_set.add(p)
                for sub in f.get('subtitles', []):
                    s_low = str(sub).lower()
                    if s_low in ('cz', 'cze', 'cs'):
                        langs_set.add('CZ TIT')
                    elif s_low in ('sk', 'slo', 'slk'):
                        langs_set.add('SK TIT')

            if 'CZ' in langs_set or 'SK' in langs_set:
                item['has_dubbing'] = True
            if any('TIT' in l or 'SUB' in l for l in langs_set):
                item['has_subtitles'] = True

            lang_str = select_single_display_language(langs_set, target_category=target_category)
            label = f"{pref_str}{disp_title}{progress_suffix}"

    return label, lang_str, is_watched


def verify_media_items_batch(items, default_media_type, ws_token, prefix="", loading=None, title_msg="", target_category=None):
    """
    Ověří položky buď paralelně (podle nastavení 'exp_parallel_search'),
    nebo sekvenčně (spolehlivý fallback).
    Vrací: (verified_items, ws_wall_time, slowest_item)
    kde verified_items je seznam [(item, label, lang_str, is_w), ...] v původním pořadí.
    """
    total = len(items)
    if total == 0:
        return [], 0.0, ("", 0.0)

    exp_parallel = ADDON.getSetting('exp_parallel_search')
    is_parallel = (exp_parallel != "false")

    thread_count = 16

    def _verify_single(idx, item):
        t0 = time.time()
        mtype = item.get('media_type') or default_media_type
        pfx = ('[F]' if mtype == 'movie' else '[S]') if prefix == 'auto' else prefix
        lbl, l_str, is_w = build_media_item_label(item, mtype, ws_token, prefix=pfx, target_category=target_category)
        dur = time.time() - t0
        return idx, item, lbl, l_str, is_w, dur

    results = [None] * total
    slowest_item = ["", 0.0]
    t_start = time.time()

    if is_parallel and total > 1:
        try:
            with ThreadPoolExecutor(max_workers=min(thread_count, total)) as executor:
                future_map = {executor.submit(_verify_single, i, itm): i for i, itm in enumerate(items)}
                completed = 0
                for future in as_completed(future_map):
                    if loading and is_loading_cancelled(loading):
                        break
                    try:
                        idx, itm, lbl, l_str, is_w, dur = future.result()
                        results[idx] = (itm, lbl, l_str, is_w)
                        if dur > slowest_item[1]:
                            slowest_item[0] = itm.get('title', '')
                            slowest_item[1] = dur
                    except Exception as e:
                        log_error(f"Chyba při paralelním ověřování položky: {e}")

                    completed += 1
                    if loading:
                        pct = 10 + int((completed / total) * 85)
                        orig_idx = future_map[future]
                        cur_title = items[orig_idx].get('title', '')
                        update_loading_dialog(loading, pct, f"{title_msg}\n({completed}/{total}) Hotovo: {cur_title}")
        except Exception as e:
            log_error(f"Selhání paralelního zpracování, přepínám na sekvenční: {e}")
            results = [None] * total

    # Sekvenční zpracování (pokud je paralelní vypnuté, nebo pro položky, které nebyly dokončeny)
    for idx, item in enumerate(items):
        if results[idx] is not None:
            continue
        if loading and is_loading_cancelled(loading):
            break
        if loading:
            pct = 10 + int(((idx + 1) / total) * 85)
            item_title = item.get('title', '')
            update_loading_dialog(loading, pct, f"{title_msg}\n({idx + 1}/{total}) Zpracovávám: {item_title}")
        idx, item, lbl, l_str, is_w, dur = _verify_single(idx, item)
        results[idx] = (item, lbl, l_str, is_w)
        if dur > slowest_item[1]:
            slowest_item[0] = item.get('title', '')
            slowest_item[1] = dur

    verified = [r for r in results if r is not None]
    ws_wall_time = time.time() - t_start
    return verified, ws_wall_time, (slowest_item[0], slowest_item[1])


def tmdb_list_menu(media_type, category, genre_id=None, page=1, similar_id=None, item_title="", year=None, genre_name=None, prev_page=None):
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        log_error("Není zadán TMDB API klíč v nastavení doplňku.")
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, "movies" if media_type == "movie" else "tvshows")

    try:
        page = int(page)
    except (TypeError, ValueError):
        page = 1
    if page < 1:
        page = 1

    try:
        items_per_page = int(float(ADDON.getSetting('items_per_page') or 30))
    except Exception:
        items_per_page = 30

    cat_cz = {
        'newest_dubbed': 'nejnovější s dabingem',
        'newest_subtitled': 'nejnovější s titulky',
        'popular': 'populární',
        'trending': 'trendy',
        'top_rated': 'nejlépe hodnocené',
        'new': 'novinky',
        'genre': 'kategorii',
        'year': 'rok',
        'similar': 'podobné tituly'
    }.get(category, category)

    type_cz = "filmy" if media_type == "movie" else "seriály"
    if category == "newest_dubbed":
        loading_text = f"Načítám nejnovější {type_cz} s dabingem..."
    elif category == "newest_subtitled":
        loading_text = f"Načítám nejnovější {type_cz} s titulky..."
    elif category == "similar" and item_title:
        loading_text = f"Hledám tituly podobné: {item_title}..."
    elif category == "year" and year:
        loading_text = f"Načítám {type_cz} z roku {year}..."
    elif category == "genre" and genre_name:
        loading_text = f"Načítám {type_cz} v kategorii {genre_name}..."
    elif category in ("trending", "top_rated"):
        loading_text = f"Načítám {cat_cz} {type_cz} z TMDB..."
    else:
        loading_text = f"Načítám seznam {type_cz} z TMDB..."

    loading = show_loading_dialog("Načítám", loading_text)
    ws_token = get_ws_token()

    # Zobrazení tlačítka Zpět
    if page > 1:
        prev_p = int(prev_page or (page - 1))
        prev_li = xbmcgui.ListItem(label=f"Zpět ({prev_p})")
        prev_li.setArt({'icon': ICONS.get('BOOK', ''), 'thumb': ICONS.get('BOOK', '')})
        prev_params = {
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": category,
            "page": prev_p
        }
        if genre_id: prev_params["genre_id"] = genre_id
        if similar_id: prev_params["similar_id"] = similar_id
        if item_title: prev_params["title"] = item_title
        if year: prev_params["year"] = year
        if genre_name: prev_params["genre_name"] = genre_name
        prev_url = build_url(prev_params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=prev_url, listitem=prev_li, isFolder=True)

    is_filter_cat = category in ("newest_dubbed", "newest_subtitled")
    target_cat = "dubbed" if category == "newest_dubbed" else ("subtitled" if category == "newest_subtitled" else None)
    target_count = min(items_per_page, 25) if is_filter_cat else items_per_page
    max_pages = 6 if is_filter_cat else 1

    current_tmdb_page = page
    pages_scanned = 0
    all_passed_items = []
    skipped_items = []
    cancelled = False
    t_tmdb_total = 0.0
    t_ws_total = 0.0
    slowest_item = ("", 0.0)

    try:
        while len(all_passed_items) < target_count and pages_scanned < max_pages:
            if is_loading_cancelled(loading):
                cancelled = True
                break

            pct = 10 + int((len(all_passed_items) / max(1, target_count)) * 80)
            status_msg = f"Hledám na TMDB & Webshare (nalezeno {len(all_passed_items)}/{target_count})..." if is_filter_cat else "Načítám položky z TMDB..."
            update_loading_dialog(loading, pct, status_msg)

            t0_tmdb = time.time()
            batch_items = tmdb.fetch_tmdb_items(
                media_type,
                category,
                tmdb_key,
                genre_id=genre_id,
                page=current_tmdb_page,
                similar_id=similar_id,
                year=year,
                count=20 if is_filter_cat else items_per_page
            )
            t_tmdb_total += (time.time() - t0_tmdb)

            if not batch_items:
                break

            title_msg = f"Ověřuji dostupnost... (nalezeno {len(all_passed_items)}/{target_count})" if is_filter_cat else "Ověřuji dostupnost na Webshare..."
            verified_batch, ws_t, slow_t = verify_media_items_batch(
                batch_items, media_type, ws_token, prefix="", loading=loading, title_msg=title_msg, target_category=target_cat
            )
            t_ws_total += ws_t
            if slow_t[1] > slowest_item[1]:
                slowest_item = slow_t

            if is_loading_cancelled(loading):
                cancelled = True

            for item, label, lang_str, is_w in verified_batch:
                if "NENALEZENO" in lang_str or "nenalezen" in lang_str.lower() or "NEDOSTUPNÉ:" in label:
                    skipped_items.append(item)
                    continue

                if category == "newest_dubbed":
                    has_dub = item.get('has_dubbing', False)
                    if not has_dub:
                        if ("[CZ]" in lang_str or "[SK]" in lang_str) and "TIT" not in lang_str:
                            has_dub = True
                    if not has_dub:
                        skipped_items.append(item)
                        continue

                if category == "newest_subtitled":
                    has_sub = item.get('has_subtitles', False)
                    if not has_sub:
                        if "TIT" in lang_str or "SUB" in lang_str:
                            has_sub = True
                    if not has_sub:
                        skipped_items.append(item)
                        continue

                all_passed_items.append((item, label, lang_str, is_w))
                if len(all_passed_items) >= target_count:
                    break

            current_tmdb_page += 1
            pages_scanned += 1
            if not is_filter_cat:
                break

    finally:
        close_loading_dialog(loading)

    if cancelled and len(all_passed_items) == 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not all_passed_items and not cancelled:
        if category == "similar":
            dialog_notif("Podobné tituly", "Nebyly nalezeny žádné podobné tituly", xbmcgui.NOTIFICATION_INFO)
        li = xbmcgui.ListItem(label="Nic nenalezeno")
        li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    added_count = 0
    for item, label, lang_str, is_w in all_passed_items:
        clean_year = str(item.get('year', '')).strip()
        label2_val = f"{lang_str}  •  {clean_year}" if (lang_str and clean_year) else (lang_str or clean_year)
        li = xbmcgui.ListItem(label=label, label2=label2_val)
        li.setProperty('item_languages', lang_str)
        info_tag = li.getVideoInfoTag()
        apply_budget_and_vote_properties(li, info_tag, item)
        info_tag.setUniqueID(str(item['id']), type='tmdb')
        info_tag.setTitle(item['title'])
        info_tag.setOriginalTitle(item['original_title'])

        plot_text = build_item_plot(
            item.get('overview', ''),
            release_date=item.get('release_date'),
            english_title=item.get('english_title'),
            main_title=item.get('title')
        )
        info_tag.setPlot(plot_text)
        info_tag.setPlotOutline(item.get('tagline', ''))
        info_tag.setRating(float(item.get('rating', 0.0)))
        info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')
        info_tag.setIMDBNumber(item.get('imdb_id', ''))

        if str(item.get('year', '')).isdigit():
            info_tag.setYear(int(item['year']))
        if item.get('release_date'):
            info_tag.setPremiered(item['release_date'])
        if item.get('runtime', 0) > 0:
            info_tag.setDuration(item['runtime'] * 60)
        if item.get('genres'):
            safe_set_genres(info_tag, item['genres'])
        if item.get('directors'):
            info_tag.setDirectors(item['directors'])
        if item.get('cast'):
            actors = [xbmc.Actor(name=a['name'], role=a['role'], thumbnail=a['thumbnail']) for a in item['cast']]
            info_tag.setCast(actors)
        
        art = {}
        if item.get('poster'):
            art['poster'] = item['poster']
            art['thumb'] = item['poster']
            art['icon'] = item['poster']
        if item.get('fanart'):
            art['fanart'] = item['fanart']
        li.setArt(art)

        if media_type == 'tv':
            show_p = db.get_tv_show_progress(item['id'], item.get('number_of_episodes', 0))
            is_w = (show_p >= 100)
            is_r = (0 < show_p < 100)
            li.addContextMenuItems(make_tv_context_menu(
                item['id'], item['title'], is_watched=is_w, is_resume=is_r,
                year=item.get('year', ''), poster=item.get('poster', ''), fanart=item.get('fanart', '')
            ))
            if is_w:
                info_tag.setPlaycount(1)
        else:
            st = db.get_item_watch_status(item['id'], 0, 0)
            is_w = bool(st and st.get('watched'))
            is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
            li.addContextMenuItems(make_movie_context_menu(
                item['id'], item['title'], is_watched=is_w, is_resume=is_r,
                collection_id=item.get('collection_id'), collection_name=item.get('collection_name'),
                year=item.get('year', ''), poster=item.get('poster', ''), fanart=item.get('fanart', '')
            ))
            if is_w:
                info_tag.setPlaycount(1)
            elif is_r:
                info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

        url = build_url({
            "mode": "search_webshare",
            "title": item['title'],
            "original_title": item.get('original_title') or item['title'],
            "year": item['year'],
            "media_type": media_type,
            "tmdb_id": item['id'],
            "poster": item.get('poster', ''),
            "fanart": item.get('fanart', ''),
            "overview": item.get('overview', '')
        })
        
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        added_count += 1

    if skipped_items:
        for s_itm in skipped_items:
            s_title = s_itm.get('title') or s_itm.get('name', 'Neznámý')
            s_year = str(s_itm.get('year', '')).strip()
            s_year_tag = f" ({s_year})" if s_year else ""
            m_type_str = "Seriál" if media_type == 'tv' else "Film"
            log_debug(f"[Vynecháno] {m_type_str} '{s_title}'{s_year_tag}: Žádný stream nenalezen na aktivních zdrojích, vynecháno ze seznamu.")
        log_debug(f"[Seznam] Zobrazeno {added_count} z {len(all_passed_items) + len(skipped_items)} ověřovaných titulů.")

    # Tlačítko Další
    can_show_next = (is_filter_cat and (len(all_passed_items) >= target_count or pages_scanned >= max_pages)) or (not is_filter_cat and added_count >= 10)
    if not cancelled and can_show_next:
        next_page = current_tmdb_page if is_filter_cat else (page + 1)
        next_li = xbmcgui.ListItem(label=f"Další ({next_page})")
        next_li.setArt({'icon': ICONS.get('NEXT', ICONS.get('BOOK', '')), 'thumb': ICONS.get('NEXT', ICONS.get('BOOK', ''))})
        next_params = {
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": category,
            "page": next_page,
            "prev_page": page
        }
        if genre_id: next_params["genre_id"] = genre_id
        if genre_name: next_params["genre_name"] = genre_name
        if similar_id: next_params["similar_id"] = similar_id
        if item_title: next_params["title"] = item_title
        if year: next_params["year"] = year
        next_url = build_url(next_params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    apply_view_mode(50)
    t_total = time.time() - t_start
    t_kodi = max(0.0, t_total - t_tmdb_total - t_ws_total)
    avg_ws = (t_ws_total / max(1, added_count)) if added_count > 0 else 0
    slow_str = f" | Nejpomalejší ověření: '{slowest_item[0]}' ({slowest_item[1]:.2f}s)" if slowest_item[1] >= 0.5 else ""
    log_timing(
        f"Načtení {media_type} ('{category}', str. {page}, {added_count} ks): "
        f"TMDB API={t_tmdb_total:.2f}s | Webshare ověření={t_ws_total:.2f}s (průměr {avg_ws:.2f}s/ks){slow_str} | "
        f"Kodi GUI={t_kodi:.2f}s | CELKEM={t_total:.2f}s"
    )
    
def movie_collection_menu(collection_id, collection_name=""):
    """Zobrazí všechny díly filmové série (kolekce) z TMDB seřazené chronologicky."""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, "movies")
    disp_coll_name = collection_name if collection_name else "Filmová série"
    loading = show_loading_dialog("Načítám", f"Načítám celou sérii: {disp_coll_name}...")
    try:
        real_coll_name, items = tmdb.get_collection_items(collection_id, tmdb_key)
    finally:
        update_loading_dialog(loading, 15, "Ověřuji dostupnost dílů na Webshare.cz...")

    if is_loading_cancelled(loading):
        close_loading_dialog(loading)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not items:
        close_loading_dialog(loading)
        dialog_notif("Série", "V této sérii nebyly nalezeny žádné filmy", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    ws_token = get_ws_token()
    title_msg = f"Ověřuji dostupnost série: {real_coll_name}"
    verified_items, _, _ = verify_media_items_batch(
        items, "movie", ws_token, prefix="", loading=loading, title_msg=title_msg
    )

    if is_loading_cancelled(loading):
        close_loading_dialog(loading)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    for item, label, lang_str, is_w in verified_items:
        clean_year = str(item.get('year', '')).strip()
        label2_val = f"{lang_str}  •  {clean_year}" if (lang_str and clean_year) else (lang_str or clean_year)
        li = xbmcgui.ListItem(label=label, label2=label2_val)
        li.setProperty('item_languages', lang_str)
        info_tag = li.getVideoInfoTag()
        apply_budget_and_vote_properties(li, info_tag, item)
        info_tag.setUniqueID(str(item['id']), type='tmdb')
        info_tag.setTitle(item['title'])
        info_tag.setOriginalTitle(item['original_title'])

        plot_text = build_item_plot(
            item.get('overview', ''),
            release_date=item.get('release_date'),
            english_title=item.get('english_title'),
            main_title=item.get('title')
        )
        info_tag.setPlot(plot_text)
        info_tag.setPlotOutline(item.get('tagline', ''))
        info_tag.setMediaType('movie')
        if item.get('rating', 0) > 0:
            info_tag.setRating(item['rating'])
        if item.get('genres'):
            safe_set_genres(info_tag, item['genres'])
        if item.get('directors'):
            info_tag.setDirectors(item['directors'])
        if item.get('cast'):
            cast_actors = [
                xbmc.Actor(name=a['name'], role=a.get('role', ''), thumbnail=a.get('thumbnail', ''))
                for a in item['cast'][:10]
            ]
            info_tag.setCast(cast_actors)
        if item.get('runtime', 0) > 0:
            info_tag.setDuration(item['runtime'] * 60)
        if item.get('release_date'):
            info_tag.setPremiered(item['release_date'])
        if str(item.get('year', '')).isdigit():
            info_tag.setYear(int(item['year']))

        art = {}
        if item.get('poster'):
            art['poster'] = item['poster']
            art['thumb'] = item['poster']
            art['icon'] = item['poster']
        if item.get('fanart'):
            art['fanart'] = item['fanart']
        li.setArt(art)

        st = db.get_item_watch_status(item['id'], 0, 0)
        is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
        if is_w:
            info_tag.setPlaycount(1)
        elif is_r:
            info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

        li.addContextMenuItems(make_movie_context_menu(
            item['id'], item['title'], is_watched=is_w, is_resume=is_r,
            collection_id=collection_id, collection_name=real_coll_name,
            year=item.get('year', ''), poster=item.get('poster', ''), fanart=item.get('fanart', '')
        ))

        url = build_url({
            "mode": "search_webshare",
            "title": item['title'],
            "original_title": item.get('original_title') or item['title'],
            "year": item['year'],
            "media_type": "movie",
            "tmdb_id": item['id'],
            "poster": item.get('poster', ''),
            "fanart": item.get('fanart', ''),
            "overview": item.get('overview', '')
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    close_loading_dialog(loading)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    apply_view_mode(50)


def main_menu():
    check_first_run_and_status()
    buffer_manager.update_addon_buffer_setting(ADDON)
    
    exp_adv = (ADDON.getSetting('exp_advanced_search') == 'true')
    items = [
        ("[B]Hledat[/B]", ICONS['SEARCH'], {"mode": "search"}),
    ]
    if exp_adv:
        items.append(("[B]Pokročilé hledání[/B]", ICONS['SEARCH_PLUS'], {"mode": "advanced_search_menu"}))
    items.extend([
        ("Filmy", ICONS['FILM'], {"mode": "movies_menu"}),
        ("Seriály", ICONS['THEATRE'], {"mode": "tv_menu"}),
        ("Historie", ICONS['HISTORY'], {"mode": "history"}),
        ("Nastavení", ICONS['SETTINGS'], {"mode": "open_settings"}),
    ])

    skin_st = get_skin_status()
    if skin_st != "active":
        skin_lbl = "[COLOR lime]★ Aktivovat vzhled Stream Cinema[/COLOR]" if skin_st == "installed" else "[COLOR orange]★ Nainstalovat vzhled Stream Cinema[/COLOR]"
        items.append((skin_lbl, ICONS['STAR'], {"mode": "install_skin"}))


    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        is_folder = params["mode"] not in ["open_settings"]
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)
    check_buffer_recommendation()

def sub_menu(media_type):
    """Podnabídka pro Filmy nebo Seriály"""
    type_label = "filmy" if media_type == "movie" else "seriály"
    
    items = [
        ("Nejnovější s dabingem", ICONS['CZ'], {"mode": "tmdb_list", "media_type": media_type, "category": "newest_dubbed"}),
        ("Nejnovější s titulky", ICONS['SUBTITLES'], {"mode": "tmdb_list", "media_type": media_type, "category": "newest_subtitled"}),
        ("Trendy tento týden", ICONS['TRENDING'], {"mode": "tmdb_list", "media_type": media_type, "category": "trending"}),
        (f"Populární {type_label}", ICONS['POPULAR'], {"mode": "tmdb_list", "media_type": media_type, "category": "popular"}),
        ("Novinky na TMDB", ICONS['NEWS'], {"mode": "tmdb_list", "media_type": media_type, "category": "new"}),
        ("Nejlépe hodnocené", ICONS['STAR'], {"mode": "tmdb_list", "media_type": media_type, "category": "top_rated"}),
        ("Podle roku", ICONS['CALENDAR'], {"mode": "years_menu", "media_type": media_type}),
        ("Podle žánru", ICONS['GENRES'], {"mode": "genres_menu", "media_type": media_type})
    ]

    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    check_buffer_recommendation()


def years_menu(media_type):
    """Seznam roků pro vyhledávání filmů/seriálů od roku 2026 dolů."""
    type_label = "Filmy" if media_type == "movie" else "Seriály"
    
    current_year = 2026
    min_year = 1940
    
    for y in range(current_year, min_year - 1, -1):
        li = xbmcgui.ListItem(label=f"{type_label} z roku {y}", label2=str(y))
        li.setArt({
            'icon': ICONS.get('CALENDAR', ''),
            'thumb': ICONS.get('CALENDAR', '')
        })
        url = build_url({
            "mode": "tmdb_list",
            "media_type": media_type,
            "category": "year",
            "year": str(y)
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu(media_type):
    """Seznam žánrů/kategorií z TMDB"""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    url = f"https://api.themoviedb.org/3/genre/{media_type}/list?api_key={tmdb_key}&language=cs-CZ"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as response:
            data = json.loads(response.read().decode('utf-8'))
            genres = data.get("genres", [])

            import unicodedata
            processed = []
            for genre in genres:
                gid = genre.get("id")
                raw_name = genre.get("name", "")
                clean_name = tmdb.translate_genre(genre_id=gid, name=raw_name)
                processed.append({"id": gid, "name": clean_name})

            # Řazení žánrů podle české abecedy
            processed.sort(key=lambda g: unicodedata.normalize('NFKD', g['name']).encode('ascii', 'ignore').decode().lower())

            for genre in processed:
                li = xbmcgui.ListItem(label=genre["name"])
                li.setArt({
                    'icon': ICONS['GENRES'],
                    'thumb': ICONS['GENRES']
                })
                item_url = build_url({
                    "mode": "tmdb_list",
                    "media_type": media_type,
                    "category": "genre",
                    "genre_id": genre["id"],
                    "genre_name": genre["name"]
                })
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_url, listitem=li, isFolder=True)

    except Exception as e:
        dialog_notif("Chyba", f"Nelze načíst žánry: {e}", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(HANDLE)

def search_tmdb_menu(query):
    """Vyhledá položky v TMDB a zobrazí je s prefixem [F]/[S]."""
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        log_error("Není zadán TMDB API klíč v nastavení doplňku.")
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, "movies")

    loading = show_loading_dialog("Vyhledávám", f"Vyhledávám (TMDB): {query}")
    t_tmdb_start = time.time()
    try:
        items = tmdb.search_tmdb_items(
            query,
            tmdb_key
        )
    finally:
        close_loading_dialog(loading)
    t_tmdb = time.time() - t_tmdb_start

    if is_loading_cancelled(loading):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
        
    if not items:
        li = xbmcgui.ListItem(label="Nic nenalezeno")
        li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        log_timing(f"Hledání '{query}': 0 položek | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
        return

    ws_token = get_ws_token()
    total = len(items)
    loading = show_loading_dialog("Vytvářím", "Ověřuji dostupnost a jazyky na Webshare.cz...")
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    try:
        title_msg = f"Ověřuji dostupnost '{query}' na Webshare..."
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            items, 'movie', ws_token, prefix="auto", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        # Řazení vyhledaných výsledků:
        # 1. Nalezené / dostupné na Webshare mají absolutní přednost před nedostupnými
        # 2. Skóre shody s vyhledávaným dotazem (přesný název > začíná na dotaz > obsažená slova > preference typu média s/f)
        # 3. Hodnocení / rating TMDB
        def search_rank_key(res_tuple):
            itm, lbl, l_str, is_w = res_tuple
            is_avail = not ("NENALEZENO" in l_str or "nenalezen" in l_str.lower() or "NEDOSTUPNÉ:" in lbl)
            avail_score = 1 if is_avail else 0
            match_score = calculate_match_score(query, itm)
            rating = float(itm.get('rating') or 0.0)
            year_val = int(itm.get('year')) if str(itm.get('year', '')).isdigit() else 0
            return (-avail_score, -match_score, -rating, -year_val)

        sorted_verified_items = sorted(verified_items, key=search_rank_key)

        for item, label, lang_str, is_w in sorted_verified_items:
            media_type = item.get('media_type', 'movie')

            clean_year = str(item.get('year', '')).strip()
            label2_val = f"{lang_str}  •  {clean_year}" if (lang_str and clean_year) else (lang_str or clean_year)
            li = xbmcgui.ListItem(label=label, label2=label2_val)
            li.setProperty('item_languages', lang_str)
            info_tag = li.getVideoInfoTag()
            apply_budget_and_vote_properties(li, info_tag, item)
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            plot_text = build_item_plot(
                item.get('overview', ''),
                release_date=item.get('release_date'),
                english_title=item.get('english_title'),
                main_title=item.get('title')
            )
            info_tag.setPlot(plot_text)
            info_tag.setPlotOutline(item['tagline'])
            info_tag.setRating(float(item['rating']))
            info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')

            if item['year'].isdigit():
                info_tag.setYear(int(item['year']))
            if item['release_date']:
                info_tag.setPremiered(item['release_date'])
            if item['runtime'] > 0:
                info_tag.setDuration(item['runtime'] * 60)
            if item['genres']:
                safe_set_genres(info_tag, item['genres'])
            if item['directors']:
                info_tag.setDirectors(item['directors'])
            if item['cast']:
                actors = [
                    xbmc.Actor(
                        name=actor['name'],
                        role=actor['role'],
                        thumbnail=actor['thumbnail']
                    )
                    for actor in item['cast']
                ]
                info_tag.setCast(actors)

            art = {}
            if item['poster']:
                art['poster'] = item['poster']
                art['thumb'] = item['poster']
                art['icon'] = item['poster']
            if item['fanart']:
                art['fanart'] = item['fanart']
            li.setArt(art)

            if media_type == 'tv':
                show_p = db.get_tv_show_progress(item['id'], item.get('number_of_episodes', 0))
                is_w = (show_p >= 100)
                is_r = (0 < show_p < 100)
                li.addContextMenuItems(make_tv_context_menu(
                    item['id'], item['title'], is_watched=is_w, is_resume=is_r,
                    year=item.get('year', ''), poster=item.get('poster', ''), fanart=item.get('fanart', '')
                ))
                if is_w:
                    info_tag.setPlaycount(1)
            else:
                st = db.get_item_watch_status(item['id'], 0, 0)
                is_w = bool(st and st.get('watched'))
                is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
                li.addContextMenuItems(make_movie_context_menu(
                    item['id'], item['title'], is_watched=is_w, is_resume=is_r,
                    collection_id=item.get('collection_id'), collection_name=item.get('collection_name'),
                    year=item.get('year', ''), poster=item.get('poster', ''), fanart=item.get('fanart', '')
                ))
                if is_w:
                    info_tag.setPlaycount(1)
                elif is_r:
                    info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "original_title": item.get('original_title') or item['title'],
                "year": item['year'],
                "media_type": media_type,
                "tmdb_id": item['id'],
                "poster": item.get('poster', ''),
                "fanart": item.get('fanart', ''),
                "overview": item.get('overview', '')
            })

            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1
    finally:
        close_loading_dialog(loading)

    if cancelled and added_count == 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    apply_view_mode(50)
    t_total = time.time() - t_start
    t_kodi = max(0.0, t_total - t_tmdb - t_ws_total)
    avg_ws = (t_ws_total / total) if total > 0 else 0
    slow_str = f" | Nejpomalejší ověření: '{slowest_item[0]}' ({slowest_item[1]:.2f}s)" if (total > 0 and slowest_item[1] >= 0.5) else ""
    log_timing(
        f"Hledání '{query}' ({total} položek): "
        f"TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s (průměr {avg_ws:.2f}s/ks){slow_str} | "
        f"Kodi GUI={t_kodi:.2f}s | CELKEM={t_total:.2f}s"
    )

def show_advanced_search_menu():
    """Zobrazí nabídku pokročilého hledání (podle herce nebo režiséra)."""
    items = [
        ("Hledat podle herce", ICONS['ACTOR'], {"mode": "advanced_search_input", "person_type": "actor"}),
        ("Hledat podle režiséra", ICONS['DIRECTOR'], {"mode": "advanced_search_input", "person_type": "director"}),
    ]
    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon, 'thumb': icon})
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def search_person_menu(query, person_type="actor"):
    """Vyhledá osobu a přímo zobrazí její filmografii (s prvním tlačítkem s informacemi)."""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    loading = show_loading_dialog("Vyhledávám", f"Vyhledávám osobu: {query}")
    try:
        persons = tmdb.search_tmdb_person(query, tmdb_key)
    finally:
        close_loading_dialog(loading)

    if not persons:
        dialog_ok("Hledání", f"Pro dotaz '{query}' nebyla nalezena žádná osoba.")
        return

    # Vybereme nejlepší shodu (první položka má nejvyšší popularitu v TMDB)
    best_person = persons[0]
    q_lower = query.strip().lower()
    for p in persons:
        if p.get('name', '').strip().lower() == q_lower:
            best_person = p
            break

    show_person_credits_menu(
        person_id=best_person['id'],
        person_name=best_person['name'],
        person_type=person_type,
        page=1,
        person_profile=best_person.get('profile', ''),
        known_for=best_person.get('known_for_str', '')
    )


def show_person_credits_menu(person_id, person_name, person_type, page=1, person_profile="", known_for=""):
    """Zobrazí filmy a seriály dané osoby (herec/režisér) od nejnovějších po nejstarší s ověřením na Webshare."""
    t_start = time.time()
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        dialog_notif("TMDB Chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, "movies")

    type_title = "Herec" if person_type == "actor" else "Režisér"
    loading = show_loading_dialog("Načítám", f"Načítám filmografii: {person_name} ({type_title})...")
    t_tmdb_start = time.time()
    try:
        all_items = tmdb.get_person_movie_credits(person_id, person_type, tmdb_key)
    finally:
        close_loading_dialog(loading)
    t_tmdb = time.time() - t_tmdb_start

    if not all_items:
        dialog_ok("Filmografie", f"Pro '{person_name}' nebyly nalezeny žádné tituly.")
        return

    try:
        items_per_page = int(float(ADDON.getSetting('items_per_page') or 20))
    except Exception:
        items_per_page = 20

    total_items = len(all_items)
    start_idx = (page - 1) * items_per_page
    end_idx = start_idx + items_per_page
    page_items = all_items[start_idx:end_idx]

    if not page_items:
        dialog_ok("Filmografie", "Žádné další tituly na této stránce.")
        return

    # 1. PRVNÍ TLAČÍTKO: Informační záhlaví s fotkou osoby, jménem a celkovým počtem titulů
    if page == 1:
        header_label = f"[B]{person_name}[/B] [COLOR gray]({type_title} • Celkem {total_items} filmů a seriálů)[/COLOR]"
        header_label2 = f"Známé z: {known_for}" if known_for else "Filmy a seriály od nejnovějších po nejstarší"
        header_li = xbmcgui.ListItem(label=header_label, label2=header_label2)
        fallback_person_icon = ICONS.get('ACTOR', '') if person_type == 'actor' else ICONS.get('DIRECTOR', '')
        head_img = person_profile or fallback_person_icon
        first_fanart = page_items[0].get('fanart', '') if page_items else ''
        header_li.setArt({
            'icon': head_img,
            'thumb': head_img,
            'poster': head_img,
            'fanart': first_fanart,
        })
        info_url = build_url({
            "mode": "person_info_dialog",
            "person_name": person_name,
            "person_type": person_type,
            "total_items": str(total_items),
            "known_for": known_for
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=info_url, listitem=header_li, isFolder=False)

    ws_token = get_ws_token()
    first_year = page_items[0].get('year', '') if page_items else ''
    first_year_suffix = f" ({first_year}...)" if first_year else ""
    loading = show_loading_dialog("Ověřuji", f"Ověřuji dostupnost na Webshare{first_year_suffix}")
    t_ws_total = 0.0
    slowest_item = ("", 0.0)
    added_count = 0
    cancelled = False
    try:
        title_msg = f"Ověřuji tituly: {person_name} (str. {page})..."
        verified_items, t_ws_total, slowest_item = verify_media_items_batch(
            page_items, 'movie', ws_token, prefix="auto", loading=loading, title_msg=title_msg
        )
        if is_loading_cancelled(loading):
            cancelled = True

        for item, base_label, lang_str, is_w in verified_items:
            mtype = item.get('media_type', 'movie')
            char = item.get('character', '')

            # V závorce jakou roli hrál
            if person_type == 'actor' and char:
                role_bracket = f"({char})"
            elif person_type == 'director':
                role_bracket = "(Režie)"
            else:
                role_bracket = ""

            role_tag = f" [COLOR lightgray]{role_bracket}[/COLOR]" if role_bracket else ""
            label = f"{base_label}{role_tag}"
            clean_year = str(item.get('year', '')).strip()
            label2_val = f"{lang_str}  •  {clean_year}" if (lang_str and clean_year) else (lang_str or clean_year)

            li = xbmcgui.ListItem(label=label, label2=label2_val)
            default_icon = ICONS.get('FILM', '') if mtype == 'movie' else ICONS.get('THEATRE', '')
            poster_art = item.get('poster') or default_icon
            fanart_art = item.get('fanart') or ''

            li.setArt({
                'icon': poster_art,
                'thumb': poster_art,
                'poster': poster_art,
                'fanart': fanart_art,
            })
            li.setProperty('item_languages', lang_str)
            info_tag = li.getVideoInfoTag()
            apply_budget_and_vote_properties(li, info_tag, item)
            info_tag.setTitle(item['title'])
            info_tag.setOriginalTitle(item['original_title'])
            plot_text = build_item_plot(
                item.get('overview', ''),
                release_date=item.get('release_date'),
                english_title=item.get('english_title'),
                main_title=item.get('title')
            )
            info_tag.setPlot(plot_text)
            if item.get('rating'):
                info_tag.setRating(float(item['rating']))
            info_tag.setMediaType('tvshow' if mtype == 'tv' else 'movie')
            if item.get('year') and str(item['year']).isdigit():
                info_tag.setYear(int(item['year']))
            if item.get('release_date'):
                info_tag.setPremiered(item['release_date'])

            if person_type == 'actor' and char:
                info_tag.setCast([xbmc.Actor(name=person_name, role=char, thumbnail=person_profile or '')])
            elif person_type == 'director':
                info_tag.setDirectors([person_name])

            url = build_url({
                "mode": "search_webshare",
                "title": item['title'],
                "original_title": item['original_title'],
                "year": item['year'],
                "tmdb_id": item['id'],
                "media_type": mtype,
                "poster": poster_art,
                "fanart": fanart_art,
                "overview": item.get('overview', '')
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        if not cancelled and end_idx < total_items:
            next_li = xbmcgui.ListItem(label=f"Další ({page + 1})")
            next_li.setArt({'icon': ICONS.get('NEXT', ICONS.get('BOOK', '')), 'thumb': ICONS.get('NEXT', ICONS.get('BOOK', ''))})
            next_url = build_url({
                "mode": "person_credits",
                "person_id": person_id,
                "person_name": person_name,
                "person_type": person_type,
                "page": page + 1,
                "person_profile": person_profile,
                "known_for": known_for
            })
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        apply_view_mode(50)
        t_total = time.time() - t_start
        log_timing(f"Tituly pro '{person_name}' ({person_type}, str. {page}, {len(page_items)} ks z {total_items}): TMDB={t_tmdb:.2f}s | WS={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)

def show_tv_series_menu(item):
    """Zobrazí seznam sezón seriálu s procenty zhlédnutí pro každou sérii."""
    t_start = time.time()
    title = item.get('title', '')
    loading = show_loading_dialog("Načítám", f"Načítám sezóny seriálu {title}...")
    try:
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        if not tmdb_key:
            log_error("Není zadán TMDB API klíč")
            dialog_notif("TMDB chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmcplugin.setContent(HANDLE, "seasons")

        ws_token = get_ws_token()
        if not ws_token:
            log_error("Není dostupný Webshare token")
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        t_tmdb_start = time.time()
        seasons = tmdb.get_tv_seasons(item.get('id'), tmdb_key)
        t_tmdb = time.time() - t_tmdb_start

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        if not seasons:
            li = xbmcgui.ListItem(label="Žádné sezóny nenalezeny")
            li.setArt({'icon': ICONS.get('THEATRE', ''), 'thumb': ICONS.get('THEATRE', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            log_timing(f"Sezóny pro '{title}': 0 sezón | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
            return

        num_seasons = len(seasons)
        t_ws_start = time.time()
        cancelled = False

        update_loading_dialog(loading, 30, f"Ověřuji dostupnost {num_seasons} sezón...")

        def _check_season(s):
            s_num = s.get('season_number', 0)
            res = webshare.check_tv_episode_availability(
                item, s_num, 1, item.get('year', ''), ws_token, limit=get_search_files_limit()
            )
            return s_num, res

        season_results = {}
        if num_seasons > 0:
            with ThreadPoolExecutor(max_workers=min(10, num_seasons)) as pool:
                for s_num, res in pool.map(_check_season, seasons):
                    season_results[s_num] = res

        t_ws_total = time.time() - t_ws_start
        added_count = 0

        for i, season in enumerate(seasons):
            if is_loading_cancelled(loading):
                cancelled = True
                break

            season_number = season.get('season_number', 0)
            ep_count = season.get('episode_count', 0)
            first_ep_result = season_results.get(season_number, {})
            is_season_available = bool(first_ep_result.get('available'))
            season_lang = first_ep_result.get('lang', '') if is_season_available else None
            
            if not is_season_available:
                log_debug(f"[Dostupnost] Seriál '{title}' Sezóna {season_number}: Nedostupná (žádný stream pro 1. díl).")

            # Výpočet procenta rozkoukání celé série
            season_pct = db.get_tv_season_progress(item.get('id'), season_number, ep_count)
            is_season_watched = (season_pct >= 100)
            if is_season_watched:
                season_pct_str = " [COLOR lime](Zhlédnuto)[/COLOR]"
            elif season_pct > 0:
                season_pct_str = f" [COLOR orange]({season_pct}%)[/COLOR]"
            else:
                season_pct_str = ""
            
            # Sestavení popisku: pokud není 1. díl dostupný, celá série je šedá, ale stále rozkliknutelná
            base_label = tv_navigation.build_season_label(item.get('title', ''), season, lang=season_lang, is_available=is_season_available)
            if is_season_watched and is_season_available:
                label = f"[COLOR gray]{base_label}[/COLOR]{season_pct_str}"
            else:
                label = f"{base_label}{season_pct_str}"
            label2 = season.get('overview', '') or ('Dostupná' if is_season_available else 'Nedostupná')


            li = xbmcgui.ListItem(label=label, label2=label2)
            season_poster = season.get('poster') or item.get('poster', '')
            season_fanart = item.get('fanart', '')
            li.setArt({
                'icon': season_poster or ICONS.get('THEATRE', ''),
                'thumb': season_poster or ICONS.get('THEATRE', ''),
                'poster': season_poster,
                'fanart': season_fanart,
            })
            li.setProperty('season_number', str(season_number))
            if season_lang:
                li.setProperty('season_lang', season_lang)

            season_plot = season.get('overview', '') or item.get('overview', '')
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('season')
            info_tag.setTvShowTitle(item.get('title', ''))
            info_tag.setTitle(base_label)
            full_season_plot = build_item_plot(
                season_plot,
                release_date=season.get('air_date'),
                main_title=base_label
            )
            if full_season_plot:
                info_tag.setPlot(full_season_plot)
            if season_number > 0:
                info_tag.setSeason(season_number)
            if season.get('air_date'):
                info_tag.setPremiered(season.get('air_date'))
            if season_pct >= 100:
                info_tag.setPlaycount(1)

            li.addContextMenuItems(make_season_context_menu(item.get('id'), season_number, item.get('title', ''), is_watched=(season_pct >= 100)))

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "tv_season_selected",
                    "title": item.get('title', ''),
                    "original_title": item.get('original_title', item.get('title', '')),
                    "year": item.get('year', ''),
                    "tmdb_id": item.get('id'),
                    "season_number": season_number,
                    "poster": season_poster,
                    "fanart": season_fanart,
                    "overview": season_plot,
                }),
                listitem=li,
                isFolder=True,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        apply_view_mode(50)
        t_total = time.time() - t_start
        log_timing(f"Sezóny pro '{title}' ({num_seasons} sezón): TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)

def show_tv_episode_menu(show_item, season_number):
    """Zobrazí epizody sezóny, ověří dostupnost na Webshare a označí nedostupné šedě."""
    t_start = time.time()
    title = show_item.get('title', '')
    loading = show_loading_dialog("Načítám", f"Načítám epizody sezóny {season_number}...")
    try:
        tmdb_key = ADDON.getSetting('tmdb_api_key')
        if not tmdb_key:
            log_error("Není zadán TMDB API klíč")
            dialog_notif("TMDB chyba", "Není zadán TMDB API klíč", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmcplugin.setContent(HANDLE, "episodes")

        ws_token = get_ws_token()
        if not ws_token:
            log_error("Není dostupný Webshare token")
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        t_tmdb_start = time.time()
        season_data = tmdb.get_season_details(show_item.get('id'), season_number, tmdb_key)
        t_tmdb = time.time() - t_tmdb_start

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        episodes = season_data.get('episodes', [])
        if not episodes:
            li = xbmcgui.ListItem(label="Žádné epizody nenalezeny")
            li.setArt({'icon': ICONS.get('THEATRE', ''), 'thumb': ICONS.get('THEATRE', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            log_timing(f"Epizody pro '{title}' S{season_number}: 0 epizod | TMDB API={t_tmdb:.2f}s | CELKEM={time.time() - t_start:.2f}s")
            return

        num_episodes = len(episodes)
        t_ws_start = time.time()
        cancelled = False

        update_loading_dialog(loading, 30, f"Ověřuji dostupnost {num_episodes} epizod...")

        def _check_ep(ep):
            ep_num = ep.get('episode_number', 0)
            res = webshare.check_tv_episode_availability(
                show_item,
                season_number,
                ep_num,
                show_item.get('year', ''),
                ws_token,
                limit=get_search_files_limit(),
            )
            return ep_num, res

        episode_results = {}
        if num_episodes > 0:
            with ThreadPoolExecutor(max_workers=min(15, num_episodes)) as pool:
                for ep_num, res in pool.map(_check_ep, episodes):
                    episode_results[ep_num] = res

        # Obohacení jazyků epizod ze StreamCache DB (pokud existují skutečné audio/titulky)
        try:
            from resources.lib import stream_cache
            candidate_idents = [res.get('ident') for res in episode_results.values() if res and res.get('ident')]
            if candidate_idents:
                cached_data = stream_cache.get_cached_streams_batch(candidate_idents)
                for ep_num, res in episode_results.items():
                    c_ident = res.get('ident')
                    if c_ident and c_ident in cached_data:
                        c_info = cached_data[c_ident]
                        a_langs = [str(l).upper() for l in c_info.get('audio_languages') or []]
                        s_langs = [str(l).upper() for l in c_info.get('subtitles') or []]
                        
                        if 'CZ' in a_langs:
                            res['lang'] = 'CZ'
                        elif 'SK' in a_langs:
                            res['lang'] = 'SK'
                        elif 'CZ' in s_langs:
                            res['lang'] = 'CZ TIT'
                        elif 'SK' in s_langs:
                            res['lang'] = 'SK TIT'
                        elif a_langs:
                            res['lang'] = " / ".join(a_langs[:2])
                        elif s_langs:
                            res['lang'] = f"T: {s_langs[0]}"
        except Exception as e:
            log_debug(f"Chyba při zjišťování jazyků epizod z DB: {e}")

        t_ws_total = time.time() - t_ws_start
        added_count = 0

        # Výpočet indikátoru dalšího dílu na řadě (">>")
        ep_watch_statuses = []
        for ep in episodes:
            ep_num = ep.get('episode_number', 0)
            st = db.get_item_watch_status(show_item.get('id'), season_number, ep_num)
            w = bool(st and st.get('watched'))
            r = bool(st and st.get('resume_time', 0) > 15 and not w)
            ep_watch_statuses.append((w, r))

        next_up_index = None
        # 1. Pokud je nějaký díl v této sérii rozkoukaný, má přednost
        for idx, (w, r) in enumerate(ep_watch_statuses):
            if r:
                next_up_index = idx
                break

        # 2. Jinak první nezhlédnutý díl za posledním zhlédnutým dílem
        if next_up_index is None:
            watched_indices = [idx for idx, (w, r) in enumerate(ep_watch_statuses) if w]
            if watched_indices:
                last_watched_idx = max(watched_indices)
                for idx in range(last_watched_idx + 1, len(episodes)):
                    if not ep_watch_statuses[idx][0]:
                        next_up_index = idx
                        break
            elif season_number > 1:
                # Pokud v této sezóně není zhlédnuto nic, ale předchozí sezóna byla sledována
                try:
                    prev_progress = db.get_tv_season_progress(show_item.get('id'), season_number - 1, 1)
                    if prev_progress > 0 and len(episodes) > 0 and not ep_watch_statuses[0][0]:
                        next_up_index = 0
                except Exception:
                    pass

        for i, episode in enumerate(episodes):
            if is_loading_cancelled(loading):
                cancelled = True
                break

            episode_number = episode.get('episode_number', 0)
            ep_status = db.get_item_watch_status(show_item.get('id'), season_number, episode_number)

            ep_result = episode_results.get(episode_number, {})
            is_ep_available = bool(ep_result.get('available'))
            ep_lang = ep_result.get('lang', '') if is_ep_available else None

            if not is_ep_available:
                ep_name_val = episode.get('name') or f"Díl {episode_number}"
                log_debug(f"[Dostupnost] Epizoda '{title}' S{season_number:02d}E{episode_number:02d} ({ep_name_val}): Nedostupná (žádný stream).")

            is_ep_watched = bool(ep_status and ep_status.get('watched'))
            is_ep_resume = bool(ep_status and ep_status.get('resume_time', 0) > 15 and not is_ep_watched)

            # Sestavení popisku: pokud je zhlédnuto, název dílu je šedý a má (Zhlédnuto)
            base_label = tv_navigation.build_episode_label(episode, is_available=is_ep_available, lang=ep_lang, is_watched=is_ep_watched)

            if is_ep_watched:
                label = base_label
            elif is_ep_resume and ep_status.get('total_time', 0) > 0:
                pct = int((ep_status['resume_time'] / ep_status['total_time']) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label

            is_this_next_up = (i == next_up_index and not is_ep_watched)
            if is_this_next_up:
                label = f"[B][COLOR lime]>>[/COLOR][/B] {label}"

            label2 = f"Jazyk: {ep_lang}" if is_ep_available else (episode.get('overview', '') or "Nedostupné")

            still_path = episode.get('still_path') or ''
            show_poster = show_item.get('poster') or ''
            show_fanart = show_item.get('fanart') or ''
            ep_image = f"https://image.tmdb.org/t/p/w500{still_path}" if still_path else show_poster
            ep_air_date = episode.get('air_date') or ''
            ep_year = ep_air_date[:4] if ep_air_date else ''

            li = xbmcgui.ListItem(label=label, label2=label2)
            if is_this_next_up:
                li.setProperty("is_next_episode", "true")
            li.addContextMenuItems(make_episode_context_menu(
                show_item.get('id'), season_number, episode_number, show_item.get('title', ''),
                is_watched=is_ep_watched, is_resume=is_ep_resume,
                year=ep_year, poster=ep_image, fanart=show_fanart
            ))
            art = {
                'icon': ep_image or ICONS.get('THEATRE', ''),
                'thumb': ep_image or ICONS.get('THEATRE', ''),
                'poster': ep_image or show_poster or ICONS.get('THEATRE', ''),
                'fanart': f"https://image.tmdb.org/t/p/w1280{still_path}" if still_path else show_fanart
            }
            li.setArt(art)
            li.setProperty('episode_number', str(episode_number))
            li.setProperty('season_number', str(season_number))

            ep_name = episode.get('name', '') or f"Epizoda {episode_number}"
            ep_plot = episode.get('overview', '') or show_item.get('overview', '')

            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('episode')
            info_tag.setTvShowTitle(show_item.get('title', ''))
            info_tag.setTitle(ep_name)
            full_ep_plot = build_item_plot(
                ep_plot,
                release_date=episode.get('air_date'),
                english_title=episode.get('english_name') or '',
                main_title=ep_name
            )
            if full_ep_plot:
                info_tag.setPlot(full_ep_plot)
            info_tag.setSeason(season_number)
            info_tag.setEpisode(episode_number)
            if is_ep_watched:
                info_tag.setPlaycount(1)
            elif is_ep_resume:
                info_tag.setResumePoint(ep_status['resume_time'], ep_status.get('total_time', 0))
            if episode.get('air_date'):
                info_tag.setPremiered(episode.get('air_date'))
            if episode.get('vote_average'):
                try:
                    info_tag.setRating(float(episode.get('vote_average', 0)))
                except (TypeError, ValueError):
                    pass
            if episode.get('runtime'):
                info_tag.setDuration(int(episode.get('runtime')) * 60)

            guest_stars = []
            for actor in episode.get('guest_stars', [])[:5]:
                if actor.get('name'):
                    p_path = actor.get('profile_path')
                    actor_thumb = f"https://image.tmdb.org/t/p/w185{p_path}" if p_path else ""
                    guest_stars.append(xbmc.Actor(name=actor.get('name', ''), role=actor.get('character', ''), thumbnail=actor_thumb))
            if guest_stars:
                info_tag.setCast(guest_stars)

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "tv_episode_selected",
                    "title": show_item.get('title', ''),
                    "original_title": show_item.get('original_title', show_item.get('title', '')),
                    "year": show_item.get('year', ''),
                    "tmdb_id": show_item.get('id'),
                    "season_number": season_number,
                    "episode_number": episode_number,
                    "episode_name": ep_name,
                    "episode_plot": ep_plot,
                    "episode_still": f"https://image.tmdb.org/t/p/w500{still_path}" if still_path else '',
                    "poster": show_poster,
                    "fanart": show_fanart,
                }),
                listitem=li,
                isFolder=True,
            )
            added_count += 1

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        apply_view_mode(50)
        t_total = time.time() - t_start
        log_timing(f"Epizody pro '{title}' S{season_number} ({num_episodes} dílů): TMDB API={t_tmdb:.2f}s | Webshare ověření={t_ws_total:.2f}s | CELKEM={t_total:.2f}s")
    finally:
        close_loading_dialog(loading)
        
IMPORTANT_DISPLAY_LANGS = {'CZ', 'SK', 'EN', 'PL', 'DE'}

def filter_display_languages(langs, original_language=""):
    """
    Filtruje jazyky pro zobrazení: zachovává pouze nejdůležitější jazyky (CZ, SK, EN, PL, DE)
    a případně originální jazyk titulu (např. JA pro japonské anime).
    Odstraňuje useless jazyky (FR, IT, RU, KO, atd.), které zbytečně zaplňují popis.
    """
    if not langs:
        return []

    allowed = set(IMPORTANT_DISPLAY_LANGS)
    if original_language:
        ol = str(original_language).upper().strip()
        if len(ol) == 2:
            allowed.add(ol)
        elif ol in ('JAPANESE', 'JPN'):
            allowed.add('JA')
        elif ol in ('KOREAN', 'KOR'):
            allowed.add('KO')
        elif ol in ('FRENCH', 'FRA', 'FRE'):
            allowed.add('FR')
        elif ol in ('SPANISH', 'SPA'):
            allowed.add('ES')
        elif ol in ('ITALIAN', 'ITA'):
            allowed.add('IT')
        elif ol in ('RUSSIAN', 'RUS'):
            allowed.add('RU')

    filtered = []
    for l in langs:
        l_up = str(l).upper().strip()
        if l_up in allowed and l_up not in filtered:
            filtered.append(l_up)

    priority = {'CZ': 0, 'SK': 1, 'EN': 2, 'PL': 3, 'DE': 4}
    filtered.sort(key=lambda x: priority.get(x, 5))
    return filtered


def sort_all_languages(langs):
    """
    Seřadí všechny jazyky pro výpis v popisu tak, aby prioritní jazyky (CZ, SK, EN, PL, DE)
    byly na začátku a všechny ostatní jazyky (RU, FR, ES, JA, atd.) následovaly abecedně.
    Žádný jazyk se nezahazuje.
    """
    if not langs:
        return []
    unique = []
    for l in langs:
        l_up = str(l).upper().strip()
        if l_up and l_up not in unique:
            unique.append(l_up)
    priority = {'CZ': 0, 'SK': 1, 'EN': 2, 'PL': 3, 'DE': 4}
    unique.sort(key=lambda x: (priority.get(x, 10), x))
    return unique


def build_stream_details_plot(file_item, base_plot="", original_language=""):
    """Vytvoří přehledný text s podrobnostmi o streamu (kodek, kvalita, HDR, audio, titulky, velikost) pro zobrazení v levém panelu."""
    q = file_item.get('quality') or ''
    codec = file_item.get('video_codec') or file_item.get('codec') or ''
    hdr = file_item.get('hdr_format') or file_item.get('hdr') or ''
    size_mb = file_item.get('size_mb')
    audio_langs = file_item.get('audio_languages') or []
    subtitles = file_item.get('subtitles') or []
    lang_raw = file_item.get('lang', '')
    orig_lang = file_item.get('original_language') or original_language or ''

    # Pokud známe opravdová ověřená metadata (z DB nebo po synchronním probe), hlavička bude tmavě zelená, jinak žlutá
    has_real_metadata = bool(file_item.get('real_metadata') or file_item.get('from_db'))
    header_color = "darkgreen" if has_real_metadata else "yellow"

    lines = []
    lines.append(f"[COLOR {header_color}][B]PODROBNOSTI SOUBORU:[/B][/COLOR]")
    
    is_ver = bool(file_item.get('verified') or file_item.get('vip') or file_item.get('real_metadata') or file_item.get('from_db'))
    ver_status = "[COLOR lime][B]● Ověřeno[/B][/COLOR]" if is_ver else "[COLOR yellow][B]○ Neověřeno[/B][/COLOR]"
    lines.append(f"  • Stav: {ver_status}")

    src = str(file_item.get('source', 'webshare')).lower()
    if src == 'hellspy':
        source_color = "deepskyblue"
        source_name = "HellSpy"
    elif src == 'prehrajto':
        source_color = "coral"
        source_name = "Přehraj.to"
    elif src in ('streamtape', 'mixdrop', 'filemoon'):
        source_color = "gold"
        source_name = src.capitalize()
    else:
        source_color = "dodgerblue"
        source_name = "Webshare"
    lines.append(f"  • Zdroj: [COLOR {source_color}][B]{source_name}[/B][/COLOR]")

    fps_val = file_item.get('fps')
    fps_text = format_fps(fps_val) if fps_val else ""

    qual_parts = []
    if q and q != '??':
        qual_parts.append(f"[COLOR lime][B]{q}[/B][/COLOR]")
    if codec:
        qual_parts.append(f"[[B]{codec.upper()}[/B]]")
    if hdr:
        qual_parts.append(f"[[COLOR magenta][B]{hdr.upper()}[/B][/COLOR]]")
    if fps_text:
        qual_parts.append(f"[[COLOR cyan][B]{fps_text}[/B][/COLOR]]")
    if qual_parts:
        lines.append("  • Kvalita: " + " ".join(qual_parts))

    if fps_text:
        lines.append(f"  • FPS: [COLOR cyan][B]{fps_text}[/B][/COLOR]")

    if size_mb is not None:
        if size_mb >= 1024:
            size_formatted = f"{size_mb / 1024:.2f} GB"
        else:
            size_formatted = f"{size_mb:.0f} MB"
        lines.append(f"  • Velikost: [B]{size_formatted}[/B]")

    f_dur = file_item.get('duration') or 0
    if size_mb and f_dur and f_dur > 30:
        br_calc = (float(size_mb) * 8.0) / float(f_dur)
        br_str = f"{br_calc:.0f} Mb/s" if br_calc >= 10.0 else f"{br_calc:.1f} Mb/s"
        lines.append(f"  • Propustnost: [COLOR #ECEFF1][B]{br_str}[/B][/COLOR]")

    # 1. Výpis všech detekovaných jazyků audia (žádný jazyk se neignoruje v popisu)
    # Řazení: CZ, SK, EN, PL, DE mají přednost, zbytek následuje abecedně
    all_audio = sort_all_languages(audio_langs)
    if not all_audio and lang_raw:
        raw_clean = str(lang_raw).upper().strip()
        if 'TIT' in raw_clean:
            # Jedná se o titulky, audio je původní nebo EN
            if orig_lang and str(orig_lang).upper() not in ('CZ', 'SK'):
                all_audio = [str(orig_lang).upper()]
            else:
                all_audio = ['EN']
        elif 'CZ' in raw_clean:
            all_audio = ['CZ']
        elif 'SK' in raw_clean:
            all_audio = ['SK']
        elif 'EN' in raw_clean:
            all_audio = ['EN']
        elif raw_clean != 'NEZNÁMÝ':
            all_audio = [raw_clean]

    if all_audio:
        audio_str = ", ".join(all_audio)
        lines.append(f"  • Audio: [COLOR lime]{audio_str}[/COLOR]")

    # 2. Výpis všech detekovaných titulků s fallbackem na název souboru
    all_subs = sort_all_languages(subtitles)
    if not all_subs:
        fn_lower = file_item.get('name', '').lower()
        if any(k in fn_lower for k in ('cz sk', 'cz-sk', 'cz/sk', 'cz+sk', 'cz, sk')):
            all_subs = ['CZ', 'SK']
        elif lang_raw and 'TIT' in str(lang_raw).upper():
            all_subs = ['SK' if ('sktit' in fn_lower or 'sk tit' in fn_lower) else 'CZ']
        elif any(k in fn_lower for k in ('cz tit', 'cztit', 'titulky', 'sktit', 'sk tit', '.tit.')):
            all_subs = ['SK' if ('sktit' in fn_lower or 'sk tit' in fn_lower) else 'CZ']

    if all_subs:
        sub_txt = ", ".join(all_subs)
        lines.append(f"  • Titulky: [COLOR cyan]{sub_txt}[/COLOR]")

    # 3. Skutečná délka videa
    f_dur = file_item.get('duration') or 0
    if f_dur and f_dur > 0:
        d_min = int(round(f_dur / 60.0))
        d_h = d_min // 60
        d_m = d_min % 60
        dur_full = f"{d_h}h {d_m:02d}m ({int(f_dur // 60)} min)" if d_h > 0 else f"{d_m} min"
        lines.append(f"  • Skutečná délka: [B]{dur_full}[/B]")

    fname = file_item.get('name', '')
    if fname:
        lines.append(f"[COLOR gray]Soubor: {fname}[/COLOR]")

    if base_plot:
        lines.append("-------------")
        lines.append(base_plot)

    return "\n".join(lines)


def handle_play_next_episode(params):
    """
    Spustí přehrávání další epizody vyvolané doplňkem service.upnext (nebo přímým odkazem).
    Pokud je voláno z UpNext (HANDLE == -1), automaticky vyhledá streamy a rovnou spustí
    nejlepší dostupný stream přes xbmc.Player().play(). Pokud je HANDLE >= 0, otevře seznam streamů.
    """
    tmdb_id = params.get("tmdb_id")
    season = int(params.get("season", 0))
    episode = int(params.get("episode", 0))
    title = params.get("title", "")
    log_debug(f"[UpNext Debug] Požadavek na spuštění další epizody: {title} S{season:02d}E{episode:02d} (TMDB ID: {tmdb_id}, HANDLE={HANDLE})")

    if not tmdb_id or season <= 0 or episode <= 0:
        log_error(f"[UpNext Debug] Neplatné parametry pro play_next_episode: {params}")
        dialog_notif("Up Next", "Neplatné parametry další epizody.", xbmcgui.NOTIFICATION_ERROR)
        return

    show_item = {"id": tmdb_id, "title": title, "name": title}

    if HANDLE >= 0:
        # Standardní navigace v Kodi seznamu
        show_tv_episode_files(show_item, season, episode)
        return

    # HANDLE == -1 -> Vyvoláno z přehrávače / service.upnext! Spouštíme přehrávání přímo!
    # 1. Okamžitě pozastavíme stávající video, pokud hraje, aby nedošlo k doběhnutí na konec (EOF)
    # a následnému zavření přehrávače / návratu do předchozí složky dříve, než se stihne vyhledat stream!
    try:
        cur_player = xbmc.Player()
        if cur_player.isPlayingVideo():
            log_debug("[UpNext Debug] Přehrávač stále hraje - pozastavuji (pause) video, aby nedošlo k ukončení před nalezením dalšího dílu.")
            cur_player.pause()
    except Exception as e:
        log_debug(f"[UpNext Debug] Nelze pozastavit přehrávač: {e}")

    # Zobrazíme decentní systémový indikátor načítání na pozadí (neblokuje GUI ani přehrávač)
    upnext_bg = None
    try:
        upnext_bg = xbmcgui.DialogProgressBG()
        upnext_bg.create("Up Next", f"Načítám další epizodu S{season:02d}E{episode:02d}...")
    except Exception:
        pass

    ws_token = get_ws_token()
    if not ws_token:
        if upnext_bg:
            try: upnext_bg.close()
            except Exception: pass
        log_error("[UpNext Debug] Chybí Webshare token pro automatické přehrání dalšího dílu")
        dialog_notif("Up Next", "Není přihlášen Webshare účet.", xbmcgui.NOTIFICATION_ERROR)
        return

    # 2. Kontrola rychlé mezipaměti streamů
    cache_id = tmdb_id or title
    cache_key = f"tv_{cache_id}_s{season}_e{episode}"
    now_ts = time.time()
    cached_entry = _STREAM_SEARCH_CACHE.get(cache_key)
    valid_files = []
    tmdb_details = {}

    if cached_entry and (now_ts - cached_entry[0] < _STREAM_SEARCH_CACHE_TTL):
        log_debug(f"[UpNext Debug] Načítám streamy pro další epizodu {cache_key} z rychlé mezipaměti (0.0s)")
        valid_files = [dict(f) for f in cached_entry[1]]
        tmdb_details = cached_entry[2]
    else:
        search_limit = get_search_files_limit()
        log_debug(f"[UpNext Debug] Hledám streamy pro automatické přehrání {title} S{season:02d}E{episode:02d}...")

        try:
            res = webshare.search_and_verify_episode(
                show_item,
                season,
                episode,
                token=ws_token,
                limit=search_limit
            )
            for f in res.get("files", []):
                if f.get('valid') and f.get('size_mb', 0) >= 30:
                    f['source'] = 'webshare'
                    valid_files.append(f)
        except Exception as we:
            log_debug(f"[UpNext Debug] Webshare hledání selhalo: {we}")

        if not valid_files:
            try:
                if ADDON.getSetting('source_prehrajto') != 'false':
                    from resources.lib import prehrajto
                    p_files = prehrajto.search_prehrajto(show_item, media_type='tv', season=season, episode=episode, limit=search_limit)
                    valid_files.extend([f for f in p_files if f.get('valid') and f.get('size_mb', 0) >= 30])
            except Exception as pe:
                log_debug(f"[UpNext Debug] Přehrajto hledání selhalo: {pe}")

        if not valid_files:
            try:
                if ADDON.getSetting('source_hellspy') == 'true':
                    from resources.lib import hellspy
                    hs_files = hellspy.search_hellspy(show_item, media_type='tv', season=season, episode=episode, limit=search_limit)
                    valid_files.extend([f for f in hs_files if f.get('valid') and f.get('size_mb', 0) >= 30])
            except Exception as he:
                log_debug(f"[UpNext Debug] Hellspy hledání selhalo: {he}")

    if not valid_files:
        if upnext_bg:
            try: upnext_bg.close()
            except Exception: pass
        log_error(f"[UpNext Debug] Pro epizodu {title} S{season:02d}E{episode:02d} nebyl nalezen žádný funkční stream.")
        dialog_notif("Up Next", f"Pro S{season:02d}E{episode:02d} nebyl nalezen stream.", xbmcgui.NOTIFICATION_WARNING)
        return

    # Načteme metadata epizody pro zobrazení v přehrávači
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if tmdb_key:
        try:
            s_det = tmdb.get_season_details(tmdb_id, season, tmdb_key)
            for ep in s_det.get('episodes', []):
                if ep.get('episode_number') == episode:
                    show_item['episode_name'] = ep.get('name', '')
                    show_item['episode_plot'] = ep.get('overview', '')
                    if ep.get('still_path'):
                        st_s = str(ep['still_path'])
                        show_item['episode_still'] = st_s if st_s.startswith('http') else f"https://image.tmdb.org/t/p/w500{st_s}"
                    break
        except Exception as te:
            log_debug(f"[UpNext Debug] Chyba načtení detailů epizody: {te}")

    sorted_files = webshare.sort_webshare_files(valid_files)
    best_stream = sorted_files[0]
    log_debug(f"[UpNext Debug] Spouštím nejlepší stream: {best_stream.get('name')} ({best_stream.get('quality')}, {best_stream.get('lang')})")

    if upnext_bg:
        try:
            upnext_bg.update(100, f"Spouštím: {best_stream.get('name', '')[:40]}...")
            upnext_bg.close()
        except Exception:
            pass

    player.play_webshare_video(
        file_id=best_stream.get('ident', ''),
        file_name=best_stream.get('name', ''),
        tmdb_info=show_item,
        season=season,
        episode=episode,
        wst_token=ws_token,
        tmdb_details=tmdb_details,
        episode_name=show_item.get('episode_name', ''),
        episode_plot=show_item.get('episode_plot', ''),
        episode_still=show_item.get('episode_still', ''),
        media_type="tv",
        from_popup=True
    )


def show_tv_episode_files(show_item, season_number, episode_number):
    """Zobrazí dostupné soubory pro epizodu a předá sezónu i díl do přehrávače."""
    loading = show_loading_dialog("Načítám", f"Kontroluji epizodu {season_number}x{episode_number}...")
    try:
        ws_token = get_ws_token()
        if not ws_token:
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            return

        xbmcplugin.setContent(HANDLE, "videos")

        cache_id = show_item.get('id') or show_item.get('title')
        cache_key = f"tv_{cache_id}_s{season_number}_e{episode_number}"
        now_ts = time.time()
        cached_entry = _STREAM_SEARCH_CACHE.get(cache_key)
        valid_files = []
        tmdb_details = {}

        if cached_entry and (now_ts - cached_entry[0] < _STREAM_SEARCH_CACHE_TTL):
            log_debug(f"Načítám streamy pro epizodu {cache_key} z rychlé mezipaměti (0.0s)")
            valid_files = [dict(f) for f in cached_entry[1]]
            tmdb_details = cached_entry[2]
            ws_tot, pt_tot, hs_tot, en_tot = cached_entry[3]
            ws_inv, pt_inv, hs_inv, en_inv = cached_entry[4]
        else:
            search_limit = get_search_files_limit()
            update_loading_dialog(loading, 25, "Hledám streamy epizody (Webshare, HellSpy, Přehraj.to)...")

            # Paralelní vyhledávání epizody napříč všemi aktivními zdroji + načtení TMDB detailů
            from concurrent.futures import ThreadPoolExecutor

            def _task_ep_webshare():
                res = webshare.search_and_verify_episode(
                    show_item,
                    season_number,
                    episode_number,
                    token=ws_token,
                    limit=search_limit
                )
                out = []
                inv = 0
                raw_list = res.get("files", [])
                for f in raw_list:
                    if f.get('valid') and f.get('size_mb', 0) >= 30:
                        f['source'] = 'webshare'
                        out.append(f)
                    else:
                        inv += 1
                return out, len(raw_list), inv

            def _task_ep_prehrajto():
                if ADDON.getSetting('source_prehrajto') == 'false':
                    return [], 0, 0
                try:
                    from resources.lib import prehrajto
                    p_files = prehrajto.search_prehrajto(
                        show_item,
                        media_type='tv',
                        season=season_number,
                        episode=episode_number,
                        year=show_item.get('year', ''),
                        limit=search_limit
                    )
                    out = [f for f in p_files if f.get('valid') and f.get('size_mb', 0) >= 30]
                    return out, len(p_files), len(p_files) - len(out)
                except Exception as e:
                    log_debug(f"Chyba při vyhledávání epizody na Přehraj.to: {e}")
                    return [], 0, 0

            def _task_ep_hellspy():
                if ADDON.getSetting('source_hellspy') != 'true':
                    return [], 0, 0
                try:
                    from resources.lib import hellspy
                    hs_files = hellspy.search_hellspy(
                        show_item,
                        media_type='tv',
                        season=season_number,
                        episode=episode_number,
                        year=show_item.get('year', ''),
                        limit=search_limit
                    )
                    out = [f for f in hs_files if f.get('valid') and f.get('size_mb', 0) >= 30]
                    return out, len(hs_files), len(hs_files) - len(out)
                except Exception as e:
                    log_debug(f"Chyba při vyhledávání epizody na HellSpy: {e}")
                    return [], 0, 0

            def _task_ep_english():
                if ADDON.getSetting('source_english') != 'true':
                    return [], 0, 0
                try:
                    from resources.lib import english_sources
                    en_files = english_sources.search_english(
                        show_item,
                        media_type='tv',
                        season=season_number,
                        episode=episode_number,
                        year=show_item.get('year', ''),
                        limit=search_limit
                    )
                    out = [f for f in en_files if f.get('valid')]
                    return out, len(en_files), len(en_files) - len(out)
                except Exception as e:
                    log_debug(f"Chyba při vyhledávání epizody na anglických zdrojích: {e}")
                    return [], 0, 0

            def _task_ep_tmdb():
                tmdb_key = ADDON.getSetting('tmdb_api_key')
                tmdb_id = show_item.get('id', '')
                if tmdb_key and tmdb_id:
                    return tmdb.get_item_details(media_type='tv', tmdb_id=tmdb_id, api_key=tmdb_key) or {}
                return {}

            with ThreadPoolExecutor(max_workers=5) as pool:
                fut_ws = pool.submit(_task_ep_webshare)
                fut_pt = pool.submit(_task_ep_prehrajto)
                fut_hs = pool.submit(_task_ep_hellspy)
                fut_en = pool.submit(_task_ep_english)
                fut_tmdb = pool.submit(_task_ep_tmdb)

                ws_f, ws_tot, ws_inv = fut_ws.result()
                pt_f, pt_tot, pt_inv = fut_pt.result()
                hs_f, hs_tot, hs_inv = fut_hs.result()
                en_f, en_tot, en_inv = fut_en.result()

                valid_files.extend(ws_f)
                valid_files.extend(pt_f)
                valid_files.extend(hs_f)
                valid_files.extend(en_f)
                tmdb_details = fut_tmdb.result()

            if valid_files:
                _STREAM_SEARCH_CACHE[cache_key] = (
                    now_ts,
                    [dict(f) for f in valid_files],
                    tmdb_details,
                    (ws_tot, pt_tot, hs_tot, en_tot),
                    (ws_inv, pt_inv, hs_inv, en_inv)
                )

        show_str = show_item.get('title') or show_item.get('name', 'Seriál')
        ep_tag = f"S{season_number:02d}E{episode_number:02d}"
        if not valid_files:
            if is_loading_cancelled(loading):
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            close_loading_dialog(loading)
            log_debug(f"[Nenalezeno] '{show_str}' {ep_tag}: Žádný platný soubor nenalezen na žádném z aktivních zdrojů.")
            li = xbmcgui.ListItem(label="Žádné vhodné soubory nenalezeny")
            li.setArt({'icon': ICONS.get('SEARCH', ''), 'thumb': ICONS.get('SEARCH', '')})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=build_url({"mode": "main"}), listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(HANDLE)
            return

        # Obohacení z mezipaměti Supabase (pokud data existují v DB)
        db_found_count = 0
        total_idents_checked = 0
        try:
            from resources.lib import stream_cache
            file_idents = [f.get('ident') for f in valid_files if f.get('ident')]
            total_idents_checked = len(file_idents)
            cached_streams = stream_cache.get_cached_streams_batch(file_idents)
            for f in valid_files:
                ident = f.get('ident')
                if ident in cached_streams:
                    cs = cached_streams[ident]
                    f['from_db'] = True
                    f['real_metadata'] = True
                    db_found_count += 1
                    if cs.get('fps'):
                        try:
                            f['fps'] = float(cs['fps'])
                        except (ValueError, TypeError):
                            pass
                    if cs.get('quality') and cs['quality'] != '??':
                        f['quality'] = str(cs['quality']).lstrip('~')
                        f['quality_estimated'] = False
                    if cs.get('video_codec'):
                        f['video_codec'] = cs['video_codec']
                        f['codec'] = cs['video_codec']
                    if cs.get('hdr_format'):
                        f['hdr_format'] = cs['hdr_format']
                        f['hdr'] = cs['hdr_format']
                    if cs.get('audio_languages'):
                        f['audio_languages'] = cs['audio_languages']
                        if 'CZ' in cs['audio_languages']:
                            f['lang'] = 'CZ'
                        elif 'SK' in cs['audio_languages']:
                            f['lang'] = 'SK'
                        elif cs['audio_languages']:
                            f['lang'] = cs['audio_languages'][0]
                    if cs.get('subtitles'):
                        f['subtitles'] = cs['subtitles']
                    if cs.get('duration'):
                        f['duration'] = cs['duration']
        except Exception as e:
            log_debug(f"Chyba při obohacení epizod z DB cache: {e}")

        # Kontrola parametrů streamů pouze pro soubory, které ještě NEJSOU v DB (ze Supabase neověřujeme znova!)
        files_to_probe = [
            f for f in valid_files
            if f.get('ident') and not f.get('from_db') and f.get('source', 'webshare') == 'webshare'
        ]
        probe_count = len(files_to_probe)
        probed_status_msg = ""
        if files_to_probe and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 70, f"Ověřuji parametry streamů ({probe_count} nových souborů)...")
                from resources.lib import stream_cache
                probe_info = {
                    'id': show_item.get('id', ''),
                    'season': season_number,
                    'episode': episode_number
                }
                def _probe_progress(cur, tot):
                    pct = 70 + int(15 * cur / max(1, tot))
                    update_loading_dialog(loading, pct, f"Ověřuji stream {cur}/{tot}...")

                stream_cache.probe_and_update_files_sync(
                    valid_files,
                    probe_info,
                    ws_token,
                    progress_callback=_probe_progress,
                    cancel_callback=lambda: is_loading_cancelled(loading),
                    max_probe=None
                )
                probed_status_msg = f"{probe_count} nových souborů ověřeno ze sítě"
            except Exception as e:
                log_debug(f"Chyba při synchronním ověření epizod: {e}")
                probed_status_msg = f"Chyba při sondování: {e}"
        else:
            if not files_to_probe:
                probed_status_msg = "Přeskočeno (všechny soubory načteny ze Supabase DB nebo externí)"
            else:
                probed_status_msg = "Zrušeno uživatelem"

        try:
            ep_runtime = int(float(show_item.get('runtime') or tmdb_details.get('runtime') or 0))
        except (ValueError, TypeError):
            ep_runtime = 0
        rejected_by_dur = []
        if ep_runtime and ep_runtime > 0:
            exp_sec = float(ep_runtime) * 60.0
            filtered_by_dur = []
            for f in valid_files:
                f_dur = f.get('duration', 0)
                ok, diff_pct = webshare.is_duration_within_tolerance(f_dur, exp_sec, tolerance=0.08, file_name=f.get('name', ''), media_type='tv')
                if ok:
                    filtered_by_dur.append(f)
                else:
                    rejected_by_dur.append((f.get('name', ''), f_dur, diff_pct))

            if rejected_by_dur:
                rej_cnt = len(rejected_by_dur)
                log_debug(f"[Filtrace délky] Vyřazeno {rej_cnt} souborů kvůli neshodě délky epizody s TMDB ({ep_runtime} min):")
                for r_name, r_dur, r_diff in rejected_by_dur[:5]:
                    d_min = int(r_dur // 60)
                    d_pct = int(r_diff * 100)
                    log_debug(f"  - {r_name} (délka: {d_min} min, rozdíl: {d_pct}%)")

            if filtered_by_dur:
                valid_files = filtered_by_dur
            else:
                log_debug("[Filtrace délky] Žádná epizoda neprošla tolerancí, ponechávám původní soubory.")

        webshare.estimate_missing_qualities(valid_files, runtime_minutes=ep_runtime, media_type='tv')
        if ep_runtime > 0:
            for f in valid_files:
                if not f.get('duration') or f.get('duration') <= 0:
                    f['duration'] = float(ep_runtime) * 60.0

        added_count = 0
        cancelled = False
        sorted_files = webshare.sort_webshare_files(valid_files)

        # Výchozí je vyskakovací popup dialog. Do složky jde pouze při explicitní volbě 'Seznam v okně'.
        if is_popup_dialog_mode():
            close_loading_dialog(loading)
            show_stream_popup_dialog(show_item, sorted_files, media_type='tv', season=season_number, episode=episode_number, tmdb_details=tmdb_details)
            return

        orig_lang = show_item.get('original_language') or tmdb_details.get('original_language') or ''
        show_title = show_item.get('title', '')
        ep_name = show_item.get('episode_name', '')
        ep_plot = show_item.get('episode_plot', '')
        ep_full_title = f"{show_title} - S{season_number:02d}E{episode_number:02d} - {ep_name}" if ep_name else f"{show_title} - S{season_number:02d}E{episode_number:02d}"

        for file_item in sorted_files:
            if is_loading_cancelled(loading):
                cancelled = True
                break
            file_item['original_language'] = orig_lang
            props = build_stream_row_properties(file_item)
            li = xbmcgui.ListItem(label=props['label'])
            stream_icon = props['icon'] or ICONS.get('FILM', '')

            li.setArt({
                'icon': stream_icon,
                'thumb': show_item.get('episode_still') or show_item.get('poster') or stream_icon,
                'fanart': show_item.get('fanart') or ''
            })
            li.setProperty("is_stream", "true")
            li.setProperty("stream_line1", props['line1'])
            li.setProperty("stream_line2", props['line2'])
            li.setProperty("stream_verified", props['verified'])
            li.setProperty("stream_quality_icon", stream_icon)
            li.setProperty("webshare_name", file_item.get('name', ''))
            li.setProperty('IsPlayable', 'true')

            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('episode')
            info_tag.setTvShowTitle(show_title)
            info_tag.setTitle(ep_full_title)
            info_tag.setPlot(build_stream_details_plot(file_item, ep_plot, original_language=orig_lang))
            info_tag.setSeason(season_number)
            info_tag.setEpisode(episode_number)
            f_dur = file_item.get('duration') or 0
            if f_dur and f_dur > 0:
                info_tag.setDuration(int(f_dur))

            v_codec = file_item.get('video_codec') or file_item.get('codec') or ''
            if v_codec:
                li.setProperty('video_codec', v_codec)
            hdr = file_item.get('hdr_format') or file_item.get('hdr') or ''
            if hdr:
                li.setProperty('hdr_type', hdr)
            q_val = str(file_item.get('quality', '')).replace('~', '')
            w, h = 0, 0
            if q_val == '4K':
                w, h = 3840, 2160
            elif q_val == '1080p':
                w, h = 1920, 1080
            elif q_val == '720p':
                w, h = 1280, 720
            elif q_val in ('SD', '480p', '576p'):
                w, h = 720, 576

            if w > 0 or v_codec:
                try:
                    vs = xbmc.VideoStreamDetail()
                    if w > 0:
                        vs.setWidth(w)
                        vs.setHeight(h)
                    if v_codec:
                        vs.setCodec(v_codec)
                    fps_val = file_item.get('fps')
                    if fps_val and float(fps_val) > 0:
                        try:
                            vs.setFrameRate(float(fps_val))
                        except Exception:
                            pass
                    info_tag.addVideoStream(vs)
                except Exception:
                    pass

            f_dur = file_item.get('duration') or 0
            if f_dur and f_dur > 0:
                info_tag.setDuration(int(f_dur))
            elif ep_runtime:
                info_tag.setDuration(int(ep_runtime) * 60)

            for a_lang in (file_item.get('audio_languages') or []):
                try:
                    info_tag.addAudioStream(xbmc.AudioStreamDetail(language=str(a_lang).lower()))
                except Exception:
                    pass
            for s_lang in (file_item.get('subtitles') or []):
                try:
                    info_tag.addSubtitleStream(xbmc.SubtitleStreamDetail(language=str(s_lang).lower()))
                except Exception:
                    pass
    
            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "webshare_file_selected",
                    "webshare_id": file_item.get('ident', ''),
                    "name": file_item.get('name', ''),
                    "lang": file_item.get('lang', ''),
                    "quality": file_item.get('quality', ''),
                    "tmdb_info": {
                        **show_item,
                        "media_type": "tv",
                        "season": season_number,
                        "episode": episode_number,
                        "episode_name": ep_name,
                        "episode_plot": ep_plot,
                        "episode_still": show_item.get('episode_still', ''),
                        "source": file_item.get('source', 'webshare')
                    },
                    "season_number": season_number,
                    "episode_number": episode_number,
                    "tmdb_details": tmdb_details,
                    "episode_name": ep_name,
                    "episode_plot": ep_plot,
                    "episode_still": show_item.get('episode_still', ''),
                }),
                listitem=li,
                isFolder=False,
            )
            added_count += 1

        total_raw = ws_tot + pt_tot + hs_tot + en_tot
        total_inv = ws_inv + pt_inv + hs_inv + en_inv + len(rejected_by_dur)
        db_pct = round((db_found_count / max(1, total_idents_checked)) * 100, 1) if total_idents_checked > 0 else 0
        src_parts = []
        if ws_tot: src_parts.append(f"Webshare: {ws_tot}")
        if pt_tot: src_parts.append(f"Přehraj.to: {pt_tot}")
        if hs_tot: src_parts.append(f"HellSpy: {hs_tot}")
        if en_tot: src_parts.append(f"EN: {en_tot}")
        src_str = " (" + ", ".join(src_parts) + ")" if src_parts else ""

        log_debug(
            f"\n========================================================================\n"
            f"[PŘEHLED STREAMŮ] Seriál: {show_str} {ep_tag}\n"
            f"  • Získáno celkem ze všech zdrojů: {total_raw} souborů{src_str}\n"
            f"  • Neplatných / vyřazených: {total_inv} (validace názvu, velikost < 30MB, neshoda délky TMDB: {len(rejected_by_dur)})\n"
            f"  • Načtení ze Supabase: {db_found_count}/{total_idents_checked} souborů načteno z DB ({db_pct}% nalezeno)\n"
            f"  • Metadata probe: {probed_status_msg}\n"
            f"  • Celkem zobrazeno v Kodi: {added_count} streamů\n"
            f"========================================================================"
        )

        if cancelled and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.setProperty(HANDLE, 'is_stream_list', 'true')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        close_loading_dialog(loading)
        apply_view_mode(55, wait=True)
    except Exception as e:
        log_error(f"Chyba při zobrazení epizod: {e}")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    finally:
        close_loading_dialog(loading)


def get_stream_quality_icon(f):
    """Vrátí cestu k odznaku kvality (4k, 4k-hdr, fhd, hd, sd) ze složky media/quality."""
    import os
    q = str(f.get('quality', '')).upper()
    hdr = str(f.get('hdr', '') or f.get('hdr_format', '')).upper()
    name = str(f.get('name', '')).upper()
    is_hdr = bool('HDR' in hdr or 'DV' in hdr or 'VISION' in hdr or 'HLG' in hdr or 'HDR' in name or 'DV' in name)
    suffix = "-hdr.png" if is_hdr else ".png"

    if '4K' in q or '2160' in q:
        key = "4k"
    elif '2K' in q or '1440' in q:
        key = "2k"
    elif '1080' in q or 'FHD' in q:
        key = "fhd"
    elif '720' in q or 'HD' in q:
        key = "hd"
    else:
        key = "sd"

    addon_path = ADDON.getAddonInfo('path')
    icon_path = os.path.join(addon_path, 'resources', 'media', 'quality', key + suffix)
    if xbmcvfs.exists(icon_path):
        return icon_path
    return ""


def build_stream_row_properties(f):
    """
    Sestaví data pro dvouřádkové zobrazení streamu v okně Kodi:
    - line1: Všechny nalezené jazyky (CZ, SK, EN, PL...) • Kvalita (4K UHD, 1080p FHD...) • Velikost v GB/MB • Zdroj
    - line2: Celý původní název souboru (šedě)
    - verified: ● Ověřeno / ○ Neověřeno
    - icon: Absolutní cesta k barevné ikoně kvality z resources/media/quality/
    - label: Jednořádková záložní varianta pro neupravené skiny
    """
    raw_langs = []
    if f.get('audio_languages'):
        raw_langs.extend(f['audio_languages'])
    elif f.get('lang'):
        for p in str(f['lang']).split('/'):
            if p.strip() and p.strip() != '??':
                raw_langs.append(p.strip())
    else:
        det_lang = webshare.detect_language(f.get('name', ''))
        if det_lang and det_lang != '??':
            raw_langs.extend([p.strip() for p in det_lang.split('/') if p.strip()])

    audio_only = [l for l in raw_langs if 'TIT' not in str(l).upper() and 'SUB' not in str(l).upper()]
    subs_from_langs = [l for l in raw_langs if 'TIT' in str(l).upper() or 'SUB' in str(l).upper()]

    priority = {'CZ': 0, 'SK': 1, 'EN': 2, 'PL': 3, 'DE': 4}
    unique_audio = []
    for l in audio_only:
        up = str(l).upper().strip()
        if up and up not in unique_audio:
            unique_audio.append(up)
    unique_audio.sort(key=lambda x: (priority.get(x, 10), x))

    formatted_langs = []
    for a in unique_audio:
        if a == 'CZ': formatted_langs.append("[COLOR lime][B]CZ[/B][/COLOR]")
        elif a == 'SK': formatted_langs.append("[COLOR yellow][B]SK[/B][/COLOR]")
        elif a == 'EN': formatted_langs.append("[COLOR #80D8FF][B]EN[/B][/COLOR]")
        elif a == 'PL': formatted_langs.append("[COLOR #FF5252][B]PL[/B][/COLOR]")
        elif a == 'DE': formatted_langs.append("[COLOR #FFB74D][B]DE[/B][/COLOR]")
        else: formatted_langs.append(f"[COLOR #80D8FF][B]{a}[/B][/COLOR]")

    subs_list_raw = f.get('subtitles') or []
    has_cz_audio = 'CZ' in unique_audio
    has_cz_subs = (
        any('cz' in str(s).lower() or 'cze' in str(s).lower() for s in subs_list_raw)
        or any('CZ' in str(s).upper() for s in subs_from_langs)
        or 'titulky' in str(f.get('name', '')).lower()
        or 'cz tit' in str(f.get('name', '')).lower()
    )
    if not has_cz_audio and has_cz_subs:
        tag = "+ CZ TIT" if formatted_langs else "CZ TIT"
        formatted_langs.append(f"[COLOR cyan][B]{tag}[/B][/COLOR]")
    elif not has_cz_audio and not has_cz_subs and (any('sk' in str(s).lower() or 'slo' in str(s).lower() for s in subs_list_raw) or any('SK' in str(s).upper() for s in subs_from_langs)):
        tag = "+ SK TIT" if formatted_langs else "SK TIT"
        formatted_langs.append(f"[COLOR cyan][B]{tag}[/B][/COLOR]")

    langs_text = " ".join(formatted_langs) if formatted_langs else "[COLOR lightgray][B]??[/B][/COLOR]"

    q_val = str(f.get('quality', '')).upper()
    quality_badge = ""
    if '4K' in q_val or '2160' in q_val:
        quality_badge = "[COLOR red][B]4K UHD[/B][/COLOR]"
    elif '2K' in q_val or '1440' in q_val:
        quality_badge = "[COLOR #B388FF][B]2K QHD[/B][/COLOR]"
    elif '1080' in q_val or 'FHD' in q_val:
        quality_badge = "[COLOR deepskyblue][B]1080p FHD[/B][/COLOR]"
    elif '720' in q_val or 'HD' in q_val:
        quality_badge = "[COLOR lime][B]720p HD[/B][/COLOR]"
    elif 'SD' in q_val or '480' in q_val or '576' in q_val or 'KN' in q_val or 'KINO' in q_val or 'CAM' in q_val:
        q_label = "KINO" if ('KN' in q_val or 'KINO' in q_val or 'CAM' in q_val) else "SD"
        quality_badge = f"[COLOR #B0BEC5][B]{q_label}[/B][/COLOR]"
    elif f.get('quality_estimated') or q_val.startswith('~'):
        q_clean = q_val.lstrip('~')
        if q_clean:
            quality_badge = f"[COLOR #B0BEC5][B]~{q_clean}[/B][/COLOR]"

    size_mb = float(f.get('size_mb') or 0.0)
    if size_mb <= 0 and f.get('size'):
        size_mb = float(f.get('size')) / (1024.0 * 1024.0)

    if size_mb >= 1000:
        size_gb = size_mb / 1024.0
        size_str = "[COLOR #ECEFF1][B]" + f"{size_gb:.1f}" + " GB[/B][/COLOR]"
    elif size_mb > 0:
        size_str = "[COLOR #ECEFF1][B]" + str(int(size_mb)) + " MB[/B][/COLOR]"
    else:
        size_str = ""

    src_val = str(f.get('source', 'webshare')).lower()
    if src_val == 'hellspy':
        src_tag = "[COLOR deepskyblue][B]HellSpy[/B][/COLOR]"
    elif src_val == 'prehrajto':
        src_tag = "[COLOR coral][B]Přehraj.to[/B][/COLOR]"
    elif src_val in ('streamtape', 'mixdrop', 'filemoon'):
        src_tag = "[COLOR gold][B]" + src_val.capitalize() + "[/B][/COLOR]"
    else:
        src_tag = "[COLOR #00B0FF][B]Webshare[/B][/COLOR]"

    dur_sec = 0.0
    for k_dur in ('duration', 'duration_sec', 'length', 'time'):
        val_dur = f.get(k_dur)
        if val_dur:
            try:
                dur_sec = float(val_dur)
                if dur_sec > 0:
                    break
            except (ValueError, TypeError):
                pass

    dur_text = ""
    dur_int = int(round(dur_sec))
    if dur_int >= 3600:
        h_dur = dur_int // 3600
        m_dur = (dur_int % 3600) // 60
        dur_text = f"{h_dur}h {m_dur:02d}m"
    elif dur_int > 0:
        m_dur = dur_int // 60
        dur_text = f"{m_dur} min"

    bitrate_str = ""
    if size_mb > 0 and dur_sec > 30:
        br_val = (size_mb * 8.0) / dur_sec
        if br_val >= 10.0:
            bitrate_str = f"[COLOR #ECEFF1][B]{br_val:.0f} Mb/s[/B][/COLOR]"
        elif br_val >= 0.1:
            bitrate_str = f"[COLOR #ECEFF1][B]{br_val:.1f} Mb/s[/B][/COLOR]"

    is_verified = bool(f.get('verified') or f.get('vip') or f.get('real_metadata') or f.get('from_db'))
    if is_verified:
        if dur_text:
            verified_badge = f"[COLOR lime][B]●[/B][/COLOR] [COLOR #ECEFF1][B]{dur_text}[/B][/COLOR]"
        else:
            verified_badge = "[COLOR lime][B]● Ověřeno[/B][/COLOR]"
    else:
        if dur_text:
            verified_badge = f"[COLOR yellow][B]○[/B][/COLOR] [COLOR #B0BEC5]{dur_text}[/COLOR]"
        else:
            verified_badge = "[COLOR yellow][B]○ Neověřeno[/B][/COLOR]"

    top_parts = [p for p in (langs_text, quality_badge, size_str, bitrate_str, src_tag) if p]
    line1 = "   •   ".join(top_parts)
    line2 = str(f.get('name', '')).strip()

    icon_path = get_stream_quality_icon(f)

    all_parts = [p for p in (langs_text, quality_badge, size_str, bitrate_str, src_tag, verified_badge) if p]
    fallback_label = "   •   ".join(all_parts)

    return {
        'line1': line1,
        'line2': line2,
        'verified': verified_badge,
        'icon': icon_path,
        'label': fallback_label
    }


def build_stream_dialog_labels(f):
    """
    Sestaví 4 přehledné řádky streamu se VŠEMI informacemi:
    Řádek 1 (stream_line1): Všechny audio jazyky (CZ, SK, EN, ...), Odhad/Kvalita, Velikost v GB/MB, Zdroj, VIP/Ověřeno
    Řádek 2 (stream_line2): Obraz: přesné rozlišení, video kodek, HDR/DV, FPS, datový tok (Mb/s), délka
    Řádek 3 (stream_line3): Detailní zvukové stopy a všechny jazyky titulků
    Řádek 4 (stream_line4): Celý původní název souboru
    Postranní panel (stream_info): Kompletní souhrn včetně FPS, všech jazyků, kodeků a parametrů.
    """
    # 1. Jazyky audia (všechny nalezené jazyky bez ořezávání)
    raw_langs = f.get('audio_languages') or ([f.get('lang')] if f.get('lang') else [])
    if not raw_langs:
        det_lang = webshare.detect_language(f.get('name', ''))
        if det_lang:
            raw_langs = [det_lang]

    # Seřazení: CZ, SK, EN, PL, DE napřed, pak ostatní
    sorted_langs = sort_all_languages(raw_langs)

    formatted_langs = []
    for l_code in sorted_langs:
        code_str = str(l_code).upper().strip()
        if code_str == 'CZ':
            formatted_langs.append("[COLOR lime][B]CZ[/B][/COLOR]")
        elif code_str == 'SK':
            formatted_langs.append("[COLOR yellow][B]SK[/B][/COLOR]")
        elif code_str == 'EN':
            formatted_langs.append("[COLOR #80D8FF][B]EN[/B][/COLOR]")
        elif code_str in ('CZ TIT', 'SK TIT'):
            formatted_langs.append(f"[COLOR cyan][B]{code_str}[/B][/COLOR]")
        elif code_str == 'PL':
            formatted_langs.append("[COLOR #FF5252][B]PL[/B][/COLOR]")
        elif code_str == 'DE':
            formatted_langs.append("[COLOR #FFB74D][B]DE[/B][/COLOR]")
        elif code_str:
            formatted_langs.append(f"[COLOR #80D8FF][B]{code_str}[/B][/COLOR]")

    # Pokud v audiu není čeština, ale stream má CZ titulky, přidáme štítek + CZ TIT
    subs_list_raw = f.get('subtitles') or []
    has_cz_audio = 'CZ' in sorted_langs or 'CZ' in raw_langs
    has_cz_subs = any('CZ' in str(s).upper() for s in subs_list_raw) or 'titulky' in str(f.get('name', '')).lower() or 'cz tit' in str(f.get('name', '')).lower()
    if not has_cz_audio and has_cz_subs and not any('CZ TIT' in str(l) for l in sorted_langs):
        formatted_langs.append("[COLOR cyan][B]+ CZ TIT[/B][/COLOR]")

    langs_text = " ".join(formatted_langs) if formatted_langs else "[COLOR lightgray][B]??[/B][/COLOR]"

    # Kvalita badge (sladěno s paletou originálního seznamu: 4k červená, 2k fialová, fhd modrá, hd zelená, sd/kino šedá)
    q_val = str(f.get('quality', '')).upper()
    quality_badge = ""
    if '4K' in q_val or '2160' in q_val:
        quality_badge = "[COLOR red][B]4K UHD[/B][/COLOR]"
    elif '2K' in q_val or '1440' in q_val:
        quality_badge = "[COLOR #B388FF][B]2K QHD[/B][/COLOR]"
    elif '1080' in q_val or 'FHD' in q_val:
        quality_badge = "[COLOR deepskyblue][B]1080p FHD[/B][/COLOR]"
    elif '720' in q_val or 'HD' in q_val:
        quality_badge = "[COLOR lime][B]720p HD[/B][/COLOR]"
    elif 'SD' in q_val or '480' in q_val or '576' in q_val or 'KN' in q_val or 'KINO' in q_val or 'CAM' in q_val:
        q_label = "KINO" if ('KN' in q_val or 'KINO' in q_val or 'CAM' in q_val) else "SD"
        quality_badge = f"[COLOR #B0BEC5][B]{q_label}[/B][/COLOR]"
    elif f.get('quality_estimated') or q_val.startswith('~'):
        q_clean = q_val.lstrip('~')
        if q_clean:
            quality_badge = f"[COLOR #B0BEC5][B]~{q_clean}[/B][/COLOR]"

    # Velikost souboru
    size_mb = float(f.get('size_mb') or 0.0)
    if size_mb <= 0 and f.get('size'):
        size_mb = float(f.get('size')) / (1024.0 * 1024.0)

    if size_mb >= 1000:
        size_gb = size_mb / 1024.0
        size_str = "[COLOR #ECEFF1][B]" + f"{size_gb:.1f}" + " GB[/B][/COLOR]"
        size_clean = f"{size_gb:.2f} GB"
    elif size_mb > 0:
        size_str = "[COLOR #ECEFF1][B]" + str(int(size_mb)) + " MB[/B][/COLOR]"
        size_clean = f"{int(size_mb)} MB"
    else:
        size_str = ""
        size_clean = ""

    # Zdroj (tag s unikátní barvou)
    src_val = str(f.get('source', 'webshare')).lower()
    if src_val == 'hellspy':
        src_tag = "[COLOR deepskyblue][B]HellSpy[/B][/COLOR]"
        src_simple = "HellSpy"
    elif src_val == 'prehrajto':
        src_tag = "[COLOR coral][B]Přehraj.to[/B][/COLOR]"
        src_simple = "Přehraj.to"
    elif src_val in ('streamtape', 'mixdrop', 'filemoon'):
        src_tag = "[COLOR gold][B]" + src_val.capitalize() + "[/B][/COLOR]"
        src_simple = src_val.capitalize()
    else:
        src_tag = "[COLOR #00B0FF][B]Webshare[/B][/COLOR]"
        src_simple = "Webshare"

    # Ověření: zelený kruh pro ověřeno (DB/probe), žlutý kruh pro neověřeno (odhad)
    is_verified = bool(f.get('verified') or f.get('vip') or f.get('real_metadata') or f.get('from_db'))
    if is_verified:
        verified_badge = "[COLOR lime][B]● Ověřeno[/B][/COLOR]"
    else:
        verified_badge = "[COLOR yellow][B]○ Neověřeno[/B][/COLOR]"

    top_parts = [p for p in (quality_badge, langs_text, size_str, src_tag, verified_badge) if p]
    line1 = "   •   ".join(top_parts)

    # 2. Obrazové parametry (Řádek 2 - barevně strukturované)
    w = int(f.get('width') or 0)
    h = int(f.get('height') or 0)
    if w > 0 and h > 0:
        res_str = f"{w}×{h}"
    elif '4K' in q_val or '2160' in q_val:
        res_str = "3840×2160"
    elif '1080' in q_val or 'FHD' in q_val:
        res_str = "1920×1080"
    elif '720' in q_val or 'HD' in q_val:
        res_str = "1280×720"
    elif 'SD' in q_val:
        res_str = "720×576"
    else:
        res_str = ""

    # Video kodek
    v_codec = str(f.get('video_codec') or f.get('codec') or '').upper()
    if not v_codec:
        fn_low = str(f.get('name', '')).lower()
        if 'hevc' in fn_low or 'x265' in fn_low or 'h265' in fn_low:
            v_codec = 'HEVC'
        elif 'x264' in fn_low or 'h264' in fn_low or 'avc' in fn_low:
            v_codec = 'AVC'
        elif 'av1' in fn_low:
            v_codec = 'AV1'
        elif 'xvid' in fn_low or 'divx' in fn_low:
            v_codec = 'XviD'

    # HDR / DV
    hdr_val = str(f.get('hdr_format') or f.get('hdr') or '').upper()
    if not hdr_val:
        fn_low = str(f.get('name', '')).lower()
        if 'dolby vision' in fn_low or 'dovi' in fn_low or ' dv ' in fn_low:
            hdr_val = 'Dolby Vision'
        elif 'hdr10+' in fn_low:
            hdr_val = 'HDR10+'
        elif 'hdr' in fn_low:
            hdr_val = 'HDR10'

    # FPS (snímková frekvence)
    fps_val = f.get('fps')
    fps_str = format_fps(fps_val) if fps_val else ""

    # Datový tok (bitrate)
    dur_sec = float(f.get('duration') or 0.0)
    if dur_sec > 0 and size_mb > 0:
        br_val = (size_mb * 8.0) / dur_sec
        bitrate_str = f"Tok: {br_val:.1f} Mb/s"
    else:
        bitrate_str = ""

    # Délka videa
    dur_int = int(dur_sec)
    if dur_int >= 3600:
        h_dur = dur_int // 3600
        m_dur = (dur_int % 3600) // 60
        duration_str = f"Délka: {h_dur}h {m_dur:02d}m"
    elif dur_int > 0:
        m_dur = dur_int // 60
        duration_str = f"Délka: {m_dur} min"
    else:
        duration_str = ""

    v_parts = []
    if res_str:
        v_parts.append(f"[COLOR #E0E0E0]{res_str}[/COLOR]")
    if v_codec:
        v_parts.append(f"[COLOR #81D4FA]{v_codec}[/COLOR]")
    if hdr_val:
        v_parts.append(f"[COLOR magenta][B]{hdr_val}[/B][/COLOR]")
    if fps_str:
        v_parts.append(f"[COLOR cyan]{fps_str}[/COLOR]")
    if bitrate_str:
        v_parts.append(f"[COLOR #B0BEC5]{bitrate_str}[/COLOR]")
    if duration_str:
        v_parts.append(f"[COLOR #CFD8DC]{duration_str}[/COLOR]")

    line2 = ("[COLOR #4FC3F7][B]Obraz:[/B][/COLOR] " + " • ".join(v_parts)) if v_parts else ""

    # 3. Zvukové stopy a titulky (Řádek 3 - pestřejší barvy podle jazyka)
    audio_tracks = f.get('audio_tracks') or []
    track_boxes = []
    if audio_tracks:
        for tr in audio_tracks:
            c_tag = tr.get('codec', '')
            ch_tag = tr.get('channels', '')
            l_tag = str(tr.get('lang', '')).upper().strip()
            box_text = " ".join([x for x in (c_tag, ch_tag, l_tag) if x])
            if box_text:
                if 'CZ' in box_text:
                    track_boxes.append(f"[COLOR lime][{box_text}][/COLOR]")
                elif 'SK' in box_text:
                    track_boxes.append(f"[COLOR yellow][{box_text}][/COLOR]")
                elif 'EN' in box_text:
                    track_boxes.append(f"[COLOR #80D8FF][{box_text}][/COLOR]")
                else:
                    track_boxes.append(f"[COLOR #CFD8DC][{box_text}][/COLOR]")
    if not track_boxes and sorted_langs:
        for al in sorted_langs:
            al_up = str(al).upper().strip()
            if al_up == 'CZ':
                track_boxes.append("[COLOR lime][CZ][/COLOR]")
            elif al_up == 'SK':
                track_boxes.append("[COLOR yellow][SK][/COLOR]")
            elif al_up == 'EN':
                track_boxes.append("[COLOR #80D8FF][EN][/COLOR]")
            else:
                track_boxes.append(f"[COLOR #CFD8DC][{al_up}][/COLOR]")
    audio_str = " ".join(track_boxes)

    # Titulky (všechny dostupné bez ořezu)
    subs_list = sort_all_languages(f.get('subtitles') or [])
    if not subs_list:
        fn_low = str(f.get('name', '')).lower()
        if 'sktit' in fn_low or 'sk tit' in fn_low:
            subs_list = ['SK']
        elif 'titulky' in fn_low or 'tit' in fn_low or 'cz tit' in fn_low:
            subs_list = ['CZ']
    subs_boxes = ["[" + str(s).upper() + "]" for s in subs_list]
    subs_str = " ".join(subs_boxes)

    a_parts = []
    if audio_str:
        a_parts.append(f"[COLOR #FFD54F][B]Zvuk:[/B][/COLOR] {audio_str}")
    if subs_str:
        a_parts.append(f"[COLOR #26C6DA][B]Titulky:[/B][/COLOR] [COLOR cyan]{subs_str}[/COLOR]")
    line3 = "   •   ".join(a_parts)

    # 4. Název souboru (Řádek 4)
    clean_fn = str(f.get('name', '')).strip()
    line4 = f"[COLOR #90A4AE]Soubor:[/COLOR] [COLOR #ECEFF1]{clean_fn}[/COLOR]"

    # Souhrn pro postranní panel (všechny informace podrobně s barevnými popisky)
    badge_quality = q_val if q_val else "HD"
    badge_str = f"{badge_quality} • {src_simple}"
    info_lines = []
    if size_clean:
        info_lines.append(f"[COLOR #90A4AE][B]Velikost:[/B][/COLOR] [COLOR white]{size_clean}[/COLOR]")
    if res_str:
        info_lines.append(f"[COLOR #90A4AE][B]Rozlišení:[/B][/COLOR] [COLOR #ECEFF1]{res_str}[/COLOR]")
    if v_codec:
        info_lines.append(f"[COLOR #90A4AE][B]Video kodek:[/B][/COLOR] [COLOR #81D4FA]{v_codec}[/COLOR]")
    if hdr_val:
        info_lines.append(f"[COLOR #90A4AE][B]HDR formát:[/B][/COLOR] [COLOR magenta]{hdr_val}[/COLOR]")
    if fps_str:
        info_lines.append(f"[COLOR #90A4AE][B]Snímky:[/B][/COLOR] [COLOR cyan]{fps_str}[/COLOR]")
    if bitrate_str:
        clean_bitrate = bitrate_str.replace('Tok: ', '')
        info_lines.append(f"[COLOR #90A4AE][B]Datový tok:[/B][/COLOR] [COLOR #FFE082]{clean_bitrate}[/COLOR]")
    if duration_str:
        clean_dur = duration_str.replace('Délka: ', '')
        info_lines.append(f"[COLOR #90A4AE][B]Délka:[/B][/COLOR] [COLOR #ECEFF1]{clean_dur}[/COLOR]")
    if sorted_langs:
        langs_text_clean = ', '.join(sorted_langs)
        info_lines.append(f"[COLOR #90A4AE][B]Audio jazyky:[/B][/COLOR] [COLOR #80D8FF]{langs_text_clean}[/COLOR]")
    if audio_str:
        info_lines.append(f"[COLOR #90A4AE][B]Audio stopy:[/B][/COLOR] {audio_str}")
    if subs_list:
        subs_text_clean = ', '.join(subs_list)
        info_lines.append(f"[COLOR #90A4AE][B]Titulky:[/B][/COLOR] [COLOR cyan]{subs_text_clean}[/COLOR]")
    if is_verified:
        info_lines.append("[COLOR #90A4AE][B]Stav:[/B][/COLOR] [COLOR lime][B]● Ověřená metadata[/B][/COLOR]")
    else:
        info_lines.append("[COLOR #90A4AE][B]Stav:[/B][/COLOR] [COLOR yellow][B]○ Neověřená metadata[/B][/COLOR]")

    info_str = "\n".join(info_lines)

    # Fallback pro label2 v běžných skinech
    fallback_l2 = line2 + ("\n" + line3 if line3 else "") + "\n" + line4
    return {
        'line1': line1,
        'line2': line2,
        'line3': line3,
        'line4': line4,
        'badge': badge_str,
        'info': info_str,
        'label': line1,
        'label2': fallback_l2.strip()
    }


def show_stream_popup_dialog(item, sorted_files, media_type="movie", season=0, episode=0, tmdb_details=None):
    """
    Otevře moderní vyskakovací dialog (popup) pro výběr streamu.
    V přizpůsobeném skinu zobrazuje 4 samostatné řádky:
    1. Řádek: Jazyk, rozlišení, velikost, zdroj
    2. Řádek: Technické specifikace obrazu (rozlišení, kodek, HDR, bitrate, délka)
    3. Řádek: Zvukové stopy a titulky
    4. Řádek: Celý název souboru
    Plus postranní panel s plakátem a souhrnem.
    Na nulté pozici je rozsáhlé centrum filtrů a řazení streamů.
    """
    if not sorted_files:
        dialog_ok("Vyber stream", "Nebyly nalezeny žádné vhodné streamy.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        return

    active_filter = None
    sort_mode = "quality"  # 'quality', 'size_desc', 'size_asc', 'cz_first'

    while True:
        # 1. Filtrování
        filtered_files = list(sorted_files)
        if active_filter == "cz":
            filtered_files = [f for f in sorted_files if f.get('lang') == 'CZ' or 'CZ' in (f.get('audio_languages') or [])]
        elif active_filter == "sk":
            filtered_files = [f for f in sorted_files if f.get('lang') == 'SK' or 'SK' in (f.get('audio_languages') or [])]
        elif active_filter == "cz_sk":
            filtered_files = [f for f in sorted_files if f.get('lang') in ('CZ', 'SK') or 'CZ' in (f.get('audio_languages') or []) or 'SK' in (f.get('audio_languages') or [])]
        elif active_filter == "subs_cz":
            filtered_files = [f for f in sorted_files if 'CZ' in (f.get('subtitles') or []) or 'titulky' in str(f.get('name', '')).lower()]
        elif active_filter == "4k":
            filtered_files = [f for f in sorted_files if any(q in str(f.get('quality', '')).upper() for q in ('4K', '2160'))]
        elif active_filter == "1080p":
            filtered_files = [f for f in sorted_files if any(q in str(f.get('quality', '')).upper() for q in ('1080', 'FHD'))]
        elif active_filter == "720p_sd":
            filtered_files = [f for f in sorted_files if any(q in str(f.get('quality', '')).upper() for q in ('720', 'HD', 'SD', '480', '576'))]
        elif active_filter == "webshare":
            filtered_files = [f for f in sorted_files if f.get('source', 'webshare') == 'webshare']
        elif active_filter == "hellspy":
            filtered_files = [f for f in sorted_files if f.get('source') == 'hellspy']
        elif active_filter == "prehrajto":
            filtered_files = [f for f in sorted_files if f.get('source') == 'prehrajto']

        # 2. Řazení
        if sort_mode == "size_desc":
            filtered_files.sort(key=lambda x: float(x.get('size_mb') or (float(x.get('size') or 0)/(1024.0*1024.0))), reverse=True)
        elif sort_mode == "size_asc":
            filtered_files.sort(key=lambda x: float(x.get('size_mb') or (float(x.get('size') or 0)/(1024.0*1024.0))))
        elif sort_mode == "cz_first":
            def cz_rank(x):
                langs = x.get('audio_languages') or ([x.get('lang')] if x.get('lang') else [])
                if 'CZ' in langs:
                    return 0
                if 'SK' in langs:
                    return 1
                return 2
            filtered_files.sort(key=cz_rank)

        # Poster pro pravý panel
        movie_poster = ""
        if tmdb_details and tmdb_details.get('poster'):
            movie_poster = tmdb_details.get('poster')
        elif item.get('poster'):
            movie_poster = item.get('poster')
        elif item.get('thumb'):
            movie_poster = item.get('thumb')

        rows = []
        # První řádek: Ovládací centrum filtrů a řazení
        filter_badge = f" [COLOR #FFD54F][{active_filter.upper()}][/COLOR]" if active_filter else ""
        sort_badge = " • Řazení: " + {
            'quality': 'Dle kvality',
            'size_desc': 'Od největšího',
            'size_asc': 'Od nejmenšího (úspora dat)',
            'cz_first': 'CZ dabing první'
        }.get(sort_mode, sort_mode)

        filter_label = f"[B][COLOR #00E5FF][FILTRY A ŘAZENÍ STREAMŮ][/COLOR][/B]{filter_badge}  ({len(filtered_files)}/{len(sorted_files)})"
        filter_sub = f"Klikněte zde pro změnu jazyka, rozlišení, zdroje nebo řazení{sort_badge}"
        filter_name = active_filter if active_filter else 'Všechny streamy'
        sort_badge_clean = sort_badge.strip(' • ')
        top_filter_item = xbmcgui.ListItem(label=filter_label, label2=filter_sub)
        top_filter_item.setProperty('stream_badge', 'NASTAVENÍ FILTRŮ')
        top_filter_item.setProperty('stream_info', f"[COLOR #90A4AE][B]Aktivní filtr:[/B][/COLOR] [COLOR #00E5FF]{filter_name}[/COLOR]\n[COLOR #90A4AE][B]Řazení:[/B][/COLOR] [COLOR white]{sort_badge_clean}[/COLOR]\n[COLOR #90A4AE][B]Nalezeno streamů:[/B][/COLOR] [COLOR lime]{len(filtered_files)}[/COLOR]")
        filter_icon = ICONS.get('SEARCHPLUS') or ICONS.get('FILM', '')
        if filter_icon:
            top_filter_item.setProperty('stream_icon', filter_icon)
        if movie_poster:
            top_filter_item.setArt({'thumb': filter_icon or movie_poster, 'poster': movie_poster, 'icon': filter_icon or movie_poster})
        rows.append(top_filter_item)

        for f in filtered_files:
            meta = build_stream_dialog_labels(f)
            row_li = xbmcgui.ListItem(label=meta['label'], label2=meta['label2'])
            # Nastavení specifických vlastností pro upravený skin
            row_li.setProperty('stream_line1', meta['line1'])
            row_li.setProperty('stream_line2', meta['line2'])
            row_li.setProperty('stream_line3', meta['line3'])
            row_li.setProperty('stream_line4', meta['line4'])
            row_li.setProperty('stream_badge', meta['badge'])
            row_li.setProperty('stream_info', meta['info'])

            # Ikona kvality (např. hd.png, fhd-hdr.png z resources/media/quality)
            icon = get_stream_quality_icon(f)
            if icon:
                row_li.setProperty('stream_icon', icon)

            art_dict = {}
            if icon:
                art_dict['icon'] = icon
                art_dict['thumb'] = icon
            if movie_poster:
                art_dict['poster'] = movie_poster
            if art_dict:
                row_li.setArt(art_dict)

            rows.append(row_li)

        dialog_title = "Vyber stream"
        idx = xbmcgui.Dialog().select(dialog_title, rows, useDetails=True)
        if idx < 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
            return

        if idx == 0:
            menu_options = [
                "━━━ FILTRY JAZYKA ━━━",
                "  • Pouze CZ dabing",
                "  • Pouze SK dabing",
                "  • CZ nebo SK dabing",
                "  • Pouze streamy s CZ titulky",
                "━━━ FILTRY KVALITY ━━━",
                "  • Pouze 4K UHD",
                "  • Pouze 1080p Full HD",
                "  • Pouze 720p HD a SD",
                "━━━ FILTRY ZDROJE ━━━",
                "  • Pouze Webshare",
                "  • Pouze HellSpy",
                "  • Pouze Přehraj.to",
                "━━━ ŘAZENÍ STREAMŮ ━━━",
                "  • Dle kvality (výchozí)",
                "  • Od největšího (nejvyšší datový tok)",
                "  • Od nejmenšího (úspora dat)",
                "  • Přednostně CZ dabing",
                "━━━ AKCE ━━━",
                "  ✖ Zrušit všechny filtry",
                "  🔄 Znovu načíst streamy ze všech serverů"
            ]
            m_idx = xbmcgui.Dialog().select("Možnosti a filtry streamů", menu_options)
            if m_idx < 0:
                continue

            # Jazyky
            if m_idx == 1:
                active_filter = "cz"
            elif m_idx == 2:
                active_filter = "sk"
            elif m_idx == 3:
                active_filter = "cz_sk"
            elif m_idx == 4:
                active_filter = "subs_cz"
            # Kvality
            elif m_idx == 6:
                active_filter = "4k"
            elif m_idx == 7:
                active_filter = "1080p"
            elif m_idx == 8:
                active_filter = "720p_sd"
            # Zdroje
            elif m_idx == 10:
                active_filter = "webshare"
            elif m_idx == 11:
                active_filter = "hellspy"
            elif m_idx == 12:
                active_filter = "prehrajto"
            # Řazení
            elif m_idx == 14:
                sort_mode = "quality"
            elif m_idx == 15:
                sort_mode = "size_desc"
            elif m_idx == 16:
                sort_mode = "size_asc"
            elif m_idx == 17:
                sort_mode = "cz_first"
            # Akce
            elif m_idx == 19:
                active_filter = None
            elif m_idx == 20:
                cache_id = item.get('id') or item.get('title')
                c_key = f"tv_{cache_id}_s{season}_e{episode}" if media_type == 'tv' else f"movie_{cache_id}"
                _STREAM_SEARCH_CACHE.pop(c_key, None)
                if media_type == 'tv':
                    show_tv_episode_files(item, season, episode)
                else:
                    show_webshare_results_menu(item)
                return
            continue

        selected_file = filtered_files[idx - 1]
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        player.play_webshare_video(
            file_id=selected_file.get('ident', ''),
            file_name=selected_file.get('name', ''),
            tmdb_info={**item, "source": selected_file.get('source', 'webshare')},
            season=season,
            episode=episode,
            wst_token=get_ws_token(),
            tmdb_details=tmdb_details,
            media_type=media_type,
            from_popup=True
        )
        return


def show_webshare_results_menu(item):
    """Zobrazí seznam Webshare souborů po výběru filmu seřazený podle jazyka."""
    media_type = item.get("media_type", "movie")

    if media_type == "tv":
        show_tv_series_menu(item)
        return

    loading = show_loading_dialog("Načítám", "Kontroluji dostupné Webshare soubory...")
    try:
        ws_token = get_ws_token()
        if not ws_token:
            close_loading_dialog(loading)
            dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
            return

        xbmcplugin.setContent(HANDLE, "videos")

        if is_loading_cancelled(loading):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        cache_id = item.get('id') or item.get('title')
        cache_key = f"movie_{cache_id}"
        now_ts = time.time()
        cached_entry = _STREAM_SEARCH_CACHE.get(cache_key)
        valid_files = []
        tmdb_details = {}

        if cached_entry and (now_ts - cached_entry[0] < _STREAM_SEARCH_CACHE_TTL):
            log_debug(f"Načítám streamy pro film {cache_key} z rychlé mezipaměti (0.0s)")
            valid_files = [dict(f) for f in cached_entry[1]]
            tmdb_details = cached_entry[2]
            ws_tot, pt_tot, hs_tot, en_tot = cached_entry[3]
            ws_inv, pt_inv, hs_inv, en_inv = cached_entry[4]
        else:
            search_limit = get_search_files_limit()
            update_loading_dialog(loading, 25, "Hledám streamy (Webshare, HellSpy, Přehraj.to)...")

            # Paralelní vyhledávání napříč všemi aktivními zdroji + načtení TMDB detailů
            from concurrent.futures import ThreadPoolExecutor

            def _task_webshare():
                res = webshare.search_and_verify_movie(item, token=ws_token, media_type=media_type, limit=search_limit)
                out = []
                inv = 0
                raw_list = res.get("files", [])
                for f in raw_list:
                    if f.get('valid') and f.get('size_mb', 0) >= 50:
                        f['source'] = 'webshare'
                        out.append(f)
                    else:
                        inv += 1
                return out, len(raw_list), inv

            def _task_prehrajto():
                if ADDON.getSetting('source_prehrajto') == 'false':
                    return [], 0, 0
                try:
                    from resources.lib import prehrajto
                    p_files = prehrajto.search_prehrajto(item, media_type='movie', limit=search_limit)
                    out = [f for f in p_files if f.get('valid') and f.get('size_mb', 0) >= 50]
                    return out, len(p_files), len(p_files) - len(out)
                except Exception as e:
                    log_debug(f"Chyba při vyhledávání na Přehraj.to: {e}")
                    return [], 0, 0

            def _task_hellspy():
                if ADDON.getSetting('source_hellspy') != 'true':
                    return [], 0, 0
                try:
                    from resources.lib import hellspy
                    hs_files = hellspy.search_hellspy(item, media_type='movie', limit=search_limit)
                    out = [f for f in hs_files if f.get('valid') and f.get('size_mb', 0) >= 50]
                    return out, len(hs_files), len(hs_files) - len(out)
                except Exception as e:
                    log_debug(f"Chyba při vyhledávání na HellSpy: {e}")
                    return [], 0, 0

            def _task_english():
                if ADDON.getSetting('source_english') != 'true':
                    return [], 0, 0
                try:
                    from resources.lib import english_sources
                    en_files = english_sources.search_english(item, media_type='movie', limit=search_limit)
                    out = [f for f in en_files if f.get('valid')]
                    return out, len(en_files), len(en_files) - len(out)
                except Exception as e:
                    log_debug(f"Chyba při vyhledávání na anglických zdrojích: {e}")
                    return [], 0, 0

            def _task_tmdb():
                tmdb_key = ADDON.getSetting('tmdb_api_key')
                tmdb_id = item.get('id', '')
                if tmdb_key and tmdb_id:
                    return tmdb.get_item_details(media_type='movie', tmdb_id=tmdb_id, api_key=tmdb_key) or {}
                return {}

            with ThreadPoolExecutor(max_workers=5) as pool:
                fut_ws = pool.submit(_task_webshare)
                fut_pt = pool.submit(_task_prehrajto)
                fut_hs = pool.submit(_task_hellspy)
                fut_en = pool.submit(_task_english)
                fut_tmdb = pool.submit(_task_tmdb)

                ws_f, ws_tot, ws_inv = fut_ws.result()
                pt_f, pt_tot, pt_inv = fut_pt.result()
                hs_f, hs_tot, hs_inv = fut_hs.result()
                en_f, en_tot, en_inv = fut_en.result()

                valid_files.extend(ws_f)
                valid_files.extend(pt_f)
                valid_files.extend(hs_f)
                valid_files.extend(en_f)
                tmdb_details = fut_tmdb.result()

            if valid_files:
                _STREAM_SEARCH_CACHE[cache_key] = (
                    now_ts,
                    [dict(f) for f in valid_files],
                    tmdb_details,
                    (ws_tot, pt_tot, hs_tot, en_tot),
                    (ws_inv, pt_inv, hs_inv, en_inv)
                )

        try:
            movie_runtime = int(float(tmdb_details.get('runtime') or item.get('runtime') or 0))
        except (ValueError, TypeError):
            movie_runtime = 0

        # Obohacení z mezipaměti Supabase (pokud data existují v DB)
        db_found_count = 0
        total_idents_checked = 0
        try:
            from resources.lib import stream_cache
            file_idents = [f.get('ident') for f in valid_files if f.get('ident')]
            total_idents_checked = len(file_idents)
            cached_streams = stream_cache.get_cached_streams_batch(file_idents)
            for f in valid_files:
                ident = f.get('ident')
                if ident in cached_streams:
                    cs = cached_streams[ident]
                    f['from_db'] = True
                    f['real_metadata'] = True
                    db_found_count += 1
                    if cs.get('fps'):
                        try:
                            f['fps'] = float(cs['fps'])
                        except (ValueError, TypeError):
                            pass
                    if cs.get('quality') and cs['quality'] != '??':
                        f['quality'] = str(cs['quality']).lstrip('~')
                        f['quality_estimated'] = False
                    if cs.get('video_codec'):
                        f['video_codec'] = cs['video_codec']
                        f['codec'] = cs['video_codec']
                    if cs.get('hdr_format'):
                        f['hdr_format'] = cs['hdr_format']
                        f['hdr'] = cs['hdr_format']
                    if cs.get('audio_languages'):
                        f['audio_languages'] = cs['audio_languages']
                        if 'CZ' in cs['audio_languages']:
                            f['lang'] = 'CZ'
                        elif 'SK' in cs['audio_languages']:
                            f['lang'] = 'SK'
                        elif cs['audio_languages']:
                            f['lang'] = cs['audio_languages'][0]
                    if cs.get('subtitles'):
                        f['subtitles'] = cs['subtitles']
                    if cs.get('duration'):
                        f['duration'] = cs['duration']
        except Exception as e:
            log_debug(f"Chyba při obohacení filmů z DB cache: {e}")

        # Kontrola parametrů streamů pouze pro soubory, které ještě NEJSOU v DB (ze Supabase neověřujeme znova!)
        files_to_probe = [
            f for f in valid_files
            if f.get('ident') and not f.get('from_db') and f.get('source', 'webshare') == 'webshare'
        ]
        probe_count = len(files_to_probe)
        probed_status_msg = ""
        if files_to_probe and not is_loading_cancelled(loading):
            try:
                update_loading_dialog(loading, 70, f"Ověřuji parametry streamů ({probe_count} nových souborů)...")
                from resources.lib import stream_cache
                probe_info = {
                    'id': item.get('id', ''),
                    'season': None,
                    'episode': None
                }
                def _probe_progress(cur, tot):
                    pct = 70 + int(15 * cur / max(1, tot))
                    update_loading_dialog(loading, pct, f"Ověřuji stream {cur}/{tot}...")

                stream_cache.probe_and_update_files_sync(
                    valid_files,
                    probe_info,
                    ws_token,
                    progress_callback=_probe_progress,
                    cancel_callback=lambda: is_loading_cancelled(loading),
                    max_probe=None
                )
                probed_status_msg = f"{probe_count} nových souborů ověřeno ze sítě"
            except Exception as e:
                log_debug(f"Chyba při synchronním ověření filmů: {e}")
                probed_status_msg = f"Chyba při sondování: {e}"
        else:
            if not files_to_probe:
                probed_status_msg = "Přeskočeno (všechny soubory načteny ze Supabase DB nebo externí)"
            else:
                probed_status_msg = "Zrušeno uživatelem"

        # Filtrace souborů podle délky oproti TMDB (tolerance 8%, u režisérských/prodloužených verzí až 18%)
        rejected_by_dur = []
        if movie_runtime and movie_runtime > 0:
            exp_sec = float(movie_runtime) * 60.0
            filtered_by_dur = []
            for f in valid_files:
                f_dur = f.get('duration', 0)
                ok, diff_pct = webshare.is_duration_within_tolerance(f_dur, exp_sec, tolerance=0.08, file_name=f.get('name', ''), media_type='movie')
                if ok:
                    filtered_by_dur.append(f)
                else:
                    rejected_by_dur.append((f.get('name', ''), f_dur, diff_pct))

            if rejected_by_dur:
                rej_cnt = len(rejected_by_dur)
                log_debug(f"[Filtrace délky] Vyřazeno {rej_cnt} souborů kvůli neshodě délky s TMDB ({movie_runtime} min):")
                for r_name, r_dur, r_diff in rejected_by_dur[:5]:
                    d_min = int(r_dur // 60)
                    d_pct = int(r_diff * 100)
                    log_debug(f"  - {r_name} (délka: {d_min} min, rozdíl: {d_pct}%)")

            if filtered_by_dur:
                valid_files = filtered_by_dur
            else:
                log_debug("[Filtrace délky] Žádný soubor neprošel tolerancí 8%, ponechávám původní soubory.")

        # 2. Odhad chybějících kvalit a seřazení podle nastavení uživatele
        webshare.estimate_missing_qualities(valid_files, runtime_minutes=movie_runtime, media_type='movie')
        if movie_runtime > 0:
            for f in valid_files:
                if not f.get('duration') or f.get('duration') <= 0:
                    f['duration'] = float(movie_runtime) * 60.0
        sorted_files = webshare.sort_webshare_files(valid_files)

        # Výchozí je vyskakovací popup dialog. Do složky jde pouze při explicitní volbě 'Seznam v okně'.
        if is_popup_dialog_mode():
            close_loading_dialog(loading)
            show_stream_popup_dialog(item, sorted_files, media_type='movie', season=0, episode=0, tmdb_details=tmdb_details)
            return

        update_loading_dialog(loading, 80, "Vytvářím seznam položek...")

        # 4. Vykreslení položek v Kodi
        p_path = tmdb_details.get('poster_path')
        b_path = tmdb_details.get('backdrop_path')
        movie_poster = item.get('poster') or (("https://image.tmdb.org/t/p/w500" + p_path) if p_path else '')
        movie_fanart = item.get('fanart') or (("https://image.tmdb.org/t/p/w1280" + b_path) if b_path else '')
        movie_plot = tmdb_details.get('overview', '') or item.get('overview', '') or item.get('plot', '')
        movie_genres = [tmdb.translate_genre(g.get('id'), g.get('name')) for g in tmdb_details.get('genres', [])] if tmdb_details.get('genres') else []
        movie_rating = float(tmdb_details.get('vote_average') or item.get('rating', 0.0) or 0.0)
        orig_lang = item.get('original_language') or tmdb_details.get('original_language') or ''

        added_count = 0
        cancelled = False
        for index, file_item in enumerate(sorted_files):
            if is_loading_cancelled(loading):
                cancelled = True
                break
            percent = 80 + int(20 * (index + 1) / max(1, len(sorted_files)))
            if update_loading_dialog(loading, percent, f"Přidávám položku {index + 1}/{len(sorted_files)}"):
                cancelled = True
                break
            file_item['original_language'] = orig_lang
            props = build_stream_row_properties(file_item)
            li = xbmcgui.ListItem(label=props['label'])
            stream_icon = props['icon'] or ICONS.get('FILM', '')

            li.setArt({
                'icon': stream_icon,
                'thumb': movie_poster or stream_icon,
                'fanart': movie_fanart or ''
            })
            li.setProperty("is_stream", "true")
            li.setProperty("stream_line1", props['line1'])
            li.setProperty("stream_line2", props['line2'])
            li.setProperty("stream_verified", props['verified'])
            li.setProperty("stream_quality_icon", stream_icon)
            li.setProperty("webshare_name", file_item.get('name', ''))
            li.setProperty("webshare_valid", "true" if file_item.get('valid', False) else "false")
            li.setProperty("webshare_lang", file_item.get('lang', ''))
            li.setProperty("webshare_quality", file_item.get('quality', ''))
            li.setProperty("webshare_size_mb", str(file_item.get('size_mb', '')))
            li.setProperty('IsPlayable', 'true')
            info_tag = li.getVideoInfoTag()
            b_src = item if item.get('budget_formatted') else tmdb_details
            apply_budget_and_vote_properties(li, info_tag, b_src)
            info_tag.setMediaType('movie')
            movie_title = item.get('title', '')
            info_tag.setTitle(movie_title)
            info_tag.setPlot(build_stream_details_plot(file_item, movie_plot, original_language=orig_lang))
            if movie_genres:
                safe_set_genres(info_tag, movie_genres)
            f_dur = file_item.get('duration') or 0
            if f_dur and f_dur > 0:
                info_tag.setDuration(int(f_dur))
            elif movie_runtime:
                info_tag.setDuration(int(movie_runtime) * 60)
            if movie_rating > 0:
                info_tag.setRating(movie_rating)
            if str(item.get('year', '')).isdigit():
                info_tag.setYear(int(item.get('year')))

            v_codec = file_item.get('video_codec') or file_item.get('codec') or ''
            if v_codec:
                li.setProperty('video_codec', v_codec)
            hdr = file_item.get('hdr_format') or file_item.get('hdr') or ''
            if hdr:
                li.setProperty('hdr_type', hdr)
            q_val = str(file_item.get('quality', '')).replace('~', '')
            w, h = 0, 0
            if q_val == '4K':
                w, h = 3840, 2160
            elif q_val == '1080p':
                w, h = 1920, 1080
            elif q_val == '720p':
                w, h = 1280, 720
            elif q_val in ('SD', '480p', '576p'):
                w, h = 720, 576

            if w > 0 or v_codec:
                try:
                    vs = xbmc.VideoStreamDetail()
                    if w > 0:
                        vs.setWidth(w)
                        vs.setHeight(h)
                    if v_codec:
                        vs.setCodec(v_codec)
                    fps_val = file_item.get('fps')
                    if fps_val and float(fps_val) > 0:
                        try:
                            vs.setFrameRate(float(fps_val))
                        except Exception:
                            pass
                    info_tag.addVideoStream(vs)
                except Exception:
                    pass

            for a_lang in (file_item.get('audio_languages') or []):
                try:
                    info_tag.addAudioStream(xbmc.AudioStreamDetail(language=str(a_lang).lower()))
                except Exception:
                    pass
            for s_lang in (file_item.get('subtitles') or []):
                try:
                    info_tag.addSubtitleStream(xbmc.SubtitleStreamDetail(language=str(s_lang).lower()))
                except Exception:
                    pass

            xbmcplugin.addDirectoryItem(
                handle=HANDLE,
                url=build_url({
                    "mode": "webshare_file_selected",
                    "webshare_id": file_item.get('ident', ''),
                    "name": file_item.get('name', ''),
                    "lang": file_item.get('lang', ''),
                    "quality": file_item.get('quality', ''),
                    "tmdb_info": {**item, "source": file_item.get('source', 'webshare')},
                    "tmdb_details": tmdb_details
                }),
                listitem=li,
                isFolder=False
            )
            added_count += 1

        total_raw = ws_tot + pt_tot + hs_tot + en_tot
        total_inv = ws_inv + pt_inv + hs_inv + en_inv + len(rejected_by_dur)
        db_pct = round((db_found_count / max(1, total_idents_checked)) * 100, 1) if total_idents_checked > 0 else 0
        src_parts = []
        if ws_tot: src_parts.append(f"Webshare: {ws_tot}")
        if pt_tot: src_parts.append(f"Přehraj.to: {pt_tot}")
        if hs_tot: src_parts.append(f"HellSpy: {hs_tot}")
        if en_tot: src_parts.append(f"EN: {en_tot}")
        src_str = " (" + ", ".join(src_parts) + ")" if src_parts else ""
        movie_title_log = item.get('title') or item.get('name') or 'Film'
        movie_year_log = str(item.get('year', '')).strip()
        movie_year_tag = f" ({movie_year_log})" if movie_year_log else ""

        log_debug(
            f"\n========================================================================\n"
            f"[PŘEHLED STREAMŮ] Film: {movie_title_log}{movie_year_tag}\n"
            f"  • Získáno celkem ze všech zdrojů: {total_raw} souborů{src_str}\n"
            f"  • Neplatných / vyřazených: {total_inv} (validace názvu, velikost < 50MB, neshoda délky TMDB: {len(rejected_by_dur)})\n"
            f"  • Načtení ze Supabase: {db_found_count}/{total_idents_checked} souborů načteno z DB ({db_pct}% nalezeno)\n"
            f"  • Metadata probe: {probed_status_msg}\n"
            f"  • Celkem zobrazeno v Kodi: {added_count} streamů\n"
            f"========================================================================"
        )

        if (cancelled or is_loading_cancelled(loading)) and added_count == 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        xbmcplugin.setProperty(HANDLE, 'is_stream_list', 'true')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        close_loading_dialog(loading)
        apply_view_mode(55, wait=True)
    except Exception as e:
        log_error(f"Chyba při zobrazení filmů: {e}")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    finally:
        close_loading_dialog(loading)


def show_webshare_account_info():
    """Zobrazí informace o účtu Webshare."""
    ws_token = get_ws_token()

    if not ws_token:
        dialog_notif("Webshare chyba", "Není dostupný Webshare token", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        response = requests.post(
            "https://webshare.cz/api/user_data/",
            headers={
                "Accept": "text/xml; charset=UTF-8",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            },
            data={"wst": ws_token},
            timeout=10,
        )

        root = ET.fromstring(response.text)

        status = root.findtext("status")
        if status != "OK":
            message = root.findtext("message") or "Neznámá chyba"
            dialog_notif("Webshare chyba", message, xbmcgui.NOTIFICATION_ERROR)
            return

        username = root.findtext("username") or "-"
        vip = root.findtext("vip") == "1"
        vip_until = root.findtext("vip_until") or "-"
        vip_days = root.findtext("vip_days") or "0"
        points = root.findtext("points") or "0"

        if vip:
            vip_text = f"[COLOR green]ANO[/COLOR]\nPlatnost do: {vip_until}\nZbývá: {vip_days} dní"
        else:
            vip_text = "[COLOR red]NE[/COLOR]"

        info_message = (
            f"Uživatel: {username}\n"
            f"VIP: {vip_text}\n"
            f"Body: {points}"
        )

        dialog_ok("Informace o účtu Webshare", info_message)

    except Exception as e:
        dialog_notif("Webshare chyba", str(e), xbmcgui.NOTIFICATION_ERROR)


def run_speed_test():
    """Spustí test rychlosti stahování z Webshare s možností kdykoliv jej zrušit."""
    dp = xbmcgui.DialogProgress()
    dp.create("Test rychlosti Webshare", "Připojování a získávání testovacího odkazu...")

    ws_token = get_ws_token()
    is_vip = False
    username = ""

    # 1. Zjištění stavu účtu (VIP / Free)
    if ws_token:
        try:
            r = requests.post(
                "https://webshare.cz/api/user_data/",
                data={"wst": ws_token},
                timeout=4,
            )
            if r.status_code == 200:
                root = ET.fromstring(r.text)
                is_vip = root.findtext("vip") == "1"
                username = root.findtext("username") or ""
        except Exception:
            pass

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    dp.update(5, "Získávám přímý odkaz ze serverů Webshare...")

    # 2. Získání testovacího odkazu (vyhledáním velkého souboru nebo fallback)
    test_ident = None
    try:
        search_data = {'what': 'mkv', 'limit': 10, 'sort': 'size', 'category': 'video'}
        if ws_token:
            search_data['wst'] = ws_token
        r = requests.post("https://webshare.cz/api/search/", data=search_data, timeout=6)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            if root.findtext('status') == 'OK':
                for f in root.findall('file'):
                    size = int(f.findtext('size', '0'))
                    if size >= 200 * 1024 * 1024:
                        test_ident = f.findtext('ident')
                        break
    except Exception:
        pass

    if not test_ident:
        test_ident = "a663e0f1lw"

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    link_data = {'ident': test_ident}
    if ws_token:
        link_data['wst'] = ws_token

    download_url = None
    try:
        r = requests.post("https://webshare.cz/api/file_link/", data=link_data, timeout=6)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            if root.findtext('status') == 'OK':
                download_url = root.findtext('link')
    except Exception as e:
        log_error(f"Chyba při získávání testovacího odkazu: {e}")

    if not download_url:
        dp.close()
        dialog_ok("Chyba testu rychlosti", "Nepodařilo se získat odkaz pro stahování z Webshare.")
        return

    if dp.iscanceled():
        dp.close()
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    dp.update(10, "Spouštím stahování a měření rychlosti...")

    test_duration = 10.0  # Max délka testu v sekundách
    max_bytes = 150 * 1024 * 1024  # Max limit dat (150 MB)
    chunk_size = 128 * 1024  # 128 KB chunk

    total_bytes = 0
    bytes_since_update = 0
    speeds = []
    start_time = None
    was_cancelled = False

    try:
        with requests.get(download_url, stream=True, timeout=8) as resp:
            resp.raise_for_status()
            start_time = time.time()
            last_update_time = start_time

            for chunk in resp.iter_content(chunk_size=chunk_size):
                if dp.iscanceled():
                    was_cancelled = True
                    break

                if not chunk:
                    continue

                total_bytes += len(chunk)
                bytes_since_update += len(chunk)
                now = time.time()
                dt = now - last_update_time

                # Průběžná aktualizace dialogu každých ~0.3 s
                if dt >= 0.3:
                    current_spd = bytes_since_update / dt
                    speeds.append(current_spd)
                    bytes_since_update = 0
                    last_update_time = now

                    elapsed = now - start_time
                    percent = min(99, int((elapsed / test_duration) * 100))

                    curr_mbps = (current_spd * 8) / (1024 * 1024)
                    curr_mbs = current_spd / (1024 * 1024)
                    avg_spd = total_bytes / elapsed if elapsed > 0 else 0
                    avg_mbps = (avg_spd * 8) / (1024 * 1024)
                    down_mb = total_bytes / (1024 * 1024)
                    rem_sec = max(0.0, test_duration - elapsed)

                    dp.update(
                        percent,
                        f"Rychlost: [COLOR lime]{curr_mbps:.1f} Mb/s[/COLOR] ({curr_mbs:.1f} MB/s)\n"
                        f"Průměr: {avg_mbps:.1f} Mb/s  •  Staženo: {down_mb:.1f} MB\n"
                        f"Zbývá: {rem_sec:.1f} s  (Stiskněte Zrušit pro ukončení)"
                    )

                if (now - start_time) >= test_duration or total_bytes >= max_bytes:
                    break

    except Exception as e:
        log_error(f"Chyba při běhu testu rychlosti: {e}")
        if not was_cancelled and total_bytes == 0:
            dp.close()
            dialog_ok("Chyba testu", f"Během stahování došlo k chybě:\n{e}")
            return
    finally:
        dp.close()

    if not start_time:
        dialog_notif("Test rychlosti", "Test byl zrušen.")
        return

    elapsed = max(0.1, time.time() - start_time)
    avg_speed = total_bytes / elapsed
    max_speed = max(speeds) if speeds else avg_speed

    avg_mbps = (avg_speed * 8) / (1024 * 1024)
    avg_mbs = avg_speed / (1024 * 1024)
    max_mbps = (max_speed * 8) / (1024 * 1024)
    max_mbs = max_speed / (1024 * 1024)
    down_mb = total_bytes / (1024 * 1024)

    if total_bytes == 0 and was_cancelled:
        dialog_notif("Test rychlosti", "Test byl zrušen před zahájením stahování.")
        return

    # Text doporučení a hodnocení
    if avg_mbps >= 60:
        eval_text = "[COLOR lime]Vynikající rychlost[/COLOR]\nPlynulé přehrávání i nejnáročnějších 4K HDR a REMUX filmů."
    elif avg_mbps >= 25:
        eval_text = "[COLOR lime]Velmi dobrá rychlost[/COLOR]\nBezproblémové pro 1080p a většinu 4K filmů."
    elif avg_mbps >= 10:
        eval_text = "[COLOR yellow]Průměrná rychlost[/COLOR]\nVhodné pro 720p / 1080p s nižším datovým tokem, 4K se může sekat."
    else:
        eval_text = "[COLOR red]Nízká rychlost[/COLOR]\nMůže docházet k načítání (zkontrolujte VIP účet či Wi-Fi/kabel)."

    title_dialog = "Test rychlosti (Ukončen)" if was_cancelled else "Výsledek testu rychlosti"
    header_line = "Test byl předčasně ukončen uživatelem.\nNaměřené hodnoty do ukončení:" if was_cancelled else "Měření stahování z Webshare dokončeno:"

    msg = (
        f"{header_line}\n\n"
        f"• Průměrná rychlost: [COLOR lime]{avg_mbps:.2f} Mb/s[/COLOR]  ({avg_mbs:.2f} MB/s)\n"
        f"• Maximální rychlost: [COLOR lime]{max_mbps:.2f} Mb/s[/COLOR]  ({max_mbs:.2f} MB/s)\n"
        f"• Staženo: {down_mb:.1f} MB za {elapsed:.1f} s\n"
        f"Doporučení:\n{eval_text}"
    )

    dialog_ok(title_dialog, msg)


def test_hellspy_connection():
    """Otestuje funkčnost připojení k HellSpy (vyhledávání, API i dostupnost CDN streamu)."""
    dp = xbmcgui.DialogProgress()
    dp.create("HellSpy Test připojení", "Testuji připojení k HellSpy.to...")
    try:
        from resources.lib import hellspy
        import time

        dp.update(25, "1/3: Testuji dostupnost webu a vyhledávání...")
        t0 = time.time()
        res = hellspy.search_hellspy_raw("matrix", limit=1, timeout=7)
        t_search = time.time() - t0

        if not res:
            dp.close()
            dialog_ok(
                "HellSpy Test připojení",
                "[COLOR orange]Částečná odezva:[/COLOR]\n\n"
                "Server HellSpy odpověděl, ale vyhledávání nevrátilo žádný výsledek.\n"
                "Web může být dočasně přetížený nebo provádí údržbu."
            )
            return

        dp.update(65, "2/3: Testuji oficiální download & stream API...")
        v = res[0]
        t1 = time.time()
        dl_url = hellspy.get_hellspy_download_url(v.get('id'), v.get('fileHash'), timeout=7)
        t_api = time.time() - t1

        if not dl_url:
            dp.close()
            dialog_ok(
                "HellSpy Test připojení",
                f"[COLOR orange]Pozor:[/COLOR]\n\n"
                f"• Vyhledávání: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
                f"• Stream API: [COLOR red]Chyba[/COLOR] (nepodařilo se získat odkaz z CDN)\n\n"
                f"Zkuste test opakovat za malou chvíli."
            )
            return

        dp.update(90, "3/3: Ověřuji přímý stream na CDN...")
        t2 = time.time()
        cdn_ok = False
        try:
            req = urllib.request.Request(dl_url, headers={
                "User-Agent": hellspy.USER_AGENT,
                "Range": "bytes=0-100"
            })
            with urllib.request.urlopen(req, timeout=5) as c_resp:
                if c_resp.status in (200, 206):
                    cdn_ok = True
        except Exception as ce:
            log_debug(f"HellSpy CDN test: {ce}")
            cdn_ok = False
        t_cdn = time.time() - t2

        dp.close()

        total_time = t_search + t_api + t_cdn
        status_cdn = f"[COLOR lime]Funkční[/COLOR] (HTTP 206, {t_cdn:.2f} s)" if cdn_ok else "[COLOR yellow]Částečně dostupné[/COLOR]"

        dialog_ok(
            "HellSpy Test připojení - OK",
            f"• Vyhledávání videí: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
            f"• Oficiální stream API: [COLOR lime]OK[/COLOR] ({t_api:.2f} s)\n"
            f"• CDN přehrávání: {status_cdn}\n"
            f"• Celková odezva: [B]{total_time:.2f} s[/B]\n"
        )

    except Exception as e:
        dp.close()
        log_error(f"Chyba při testu HellSpy připojení: {e}")
        dialog_ok(
            "HellSpy Test připojení",
            f"[COLOR red][B]Test připojení k HellSpy selhal![/B][/COLOR]\n\n"
            f"Chyba: {e}\n\n"
            f"Zkontrolujte připojení k internetu nebo dostupnost serveru hellspy.to."
        )


def test_prehrajto_connection():
    """Otestuje funkčnost připojení k Přehraj.to (vyhledávání i přímý CDN stream)."""
    dp = xbmcgui.DialogProgress()
    dp.create("Přehraj.to Test připojení", "Testuji připojení k Prehrajto.cz...")
    try:
        from resources.lib import prehrajto
        import time

        dp.update(25, "1/3: Testuji dostupnost webu a vyhledávání...")
        t0 = time.time()
        res = prehrajto.search_prehrajto_raw("matrix", limit=1, timeout=7)
        t_search = time.time() - t0

        if not res:
            dp.close()
            dialog_ok(
                "Přehraj.to Test připojení",
                "[COLOR orange]Částečná odezva:[/COLOR]\n\n"
                "Server Prehrajto.cz neodpověděl nebo je dočasně přetížený (HTTP 429).\n"
                "Zkuste test opakovat za malou chvíli."
            )
            return

        dp.update(65, "2/3: Testuji extrakci přímého streamu...")
        card = res[0]
        t1 = time.time()
        stream_url = prehrajto.get_prehrajto_direct_url(card.get('href'), timeout=7)
        t_stream = time.time() - t1

        if not stream_url:
            dp.close()
            dialog_ok(
                "Přehraj.to Test připojení",
                f"[COLOR orange]Pozor:[/COLOR]\n\n"
                f"• Vyhledávání: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
                f"• Extrakce streamu: [COLOR red]Chyba[/COLOR] (nepodařilo se získat odkaz z videa)\n\n"
                f"Zkuste test opakovat za malou chvíli."
            )
            return

        dp.update(90, "3/3: Ověřuji přímý CDN stream...")
        t2 = time.time()
        cdn_ok = False
        try:
            req = urllib.request.Request(stream_url, headers={
                "User-Agent": prehrajto.USER_AGENT,
                "Referer": "https://prehrajto.cz/",
                "Range": "bytes=0-100"
            })
            with urllib.request.urlopen(req, timeout=5) as c_resp:
                if c_resp.status in (200, 206):
                    cdn_ok = True
        except Exception as ce:
            log_debug(f"Prehraj.to CDN test: {ce}")
            cdn_ok = False
        t_cdn = time.time() - t2

        dp.close()

        total_time = t_search + t_stream + t_cdn
        if cdn_ok:
            status_cdn = "[COLOR lime]Funkční[/COLOR] (HTTP 206, " + f"{t_cdn:.2f}" + " s)"
        else:
            status_cdn = "[COLOR yellow]Částečně dostupné[/COLOR]"

        dialog_ok(
            "Přehraj.to Test připojení - OK",
            f"• Vyhledávání videí: [COLOR lime]OK[/COLOR] ({t_search:.2f} s)\n"
            f"• Extrakce CDN streamu: [COLOR lime]OK[/COLOR] ({t_stream:.2f} s)\n"
            f"• CDN přehrávání: {status_cdn}\n"
            f"• Celková odezva: [B]{total_time:.2f} s[/B]\n"
        )

    except Exception as e:
        dp.close()
        log_error(f"Chyba při testu Přehraj.to připojení: {e}")
        dialog_ok(
            "Přehraj.to Test připojení",
            f"[COLOR red][B]Test připojení k Přehraj.to selhal![/B][/COLOR]\n\n"
            f"Chyba: {e}\n\n"
            f"Zkontrolujte připojení k internetu nebo dostupnost serveru prehrajto.cz."
        )


def test_english_connection():
    """Otestuje funkčnost resolverů pro anglické zdroje (Streamtape, Mixdrop, Filemoon)."""
    dp = xbmcgui.DialogProgress()
    dp.create("Anglické zdroje - Test", "Testuji dostupnost resolverů...")
    try:
        dp.update(30, "1/2: Kontroluji modul ResolveURL...")
        has_resolveurl = False
        resolveurl_ver = ""
        try:
            import importlib
            res_mod = importlib.import_module("resolveurl")
            if res_mod:
                has_resolveurl = True
                resolveurl_ver = getattr(res_mod, '__version__', 'instalován')
        except Exception:
            pass

        dp.update(70, "2/2: Kontroluji vestavěné resolvery (Streamtape, Mixdrop)...")
        from resources.lib import english_sources

        dp.close()

        if has_resolveurl:
            res_url_txt = "[COLOR lime]Ano (" + str(resolveurl_ver) + ")[/COLOR]"
        else:
            res_url_txt = "[COLOR yellow]Ne (použijí se vestavěné resolvery)[/COLOR]"

        dialog_ok(
            "Anglické zdroje - OK",
            f"• Podporované servery: [B]Streamtape, Mixdrop, Filemoon[/B]\n"
            f"• ResolveURL modul: {res_url_txt}\n"
            f"• Vestavěný Dean Edwards JS unpacker: [COLOR lime]Aktivní[/COLOR]\n"
            f"• Vestavěný Streamtape extractor: [COLOR lime]Aktivní[/COLOR]\n"
        )
    except Exception as e:
        dp.close()
        log_error(f"Chyba při testu anglických zdrojů: {e}")
        dialog_ok(
            "Anglické zdroje - Test",
            f"[COLOR red][B]Chyba při inicializaci anglických zdrojů![/B][/COLOR]\n\n"
            f"Chyba: {e}"
        )


def check_buffer_recommendation():
    """Zkontroluje velikost vyrovnávací paměti Kodi a pokud je tovární/malá (< 40MB), nabídne uživateli optimalizaci."""
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty('buffer_prompt_shown_this_session') == 'true':
            return

        dismissed = ADDON.getSetting('buffer_warning_dismissed')
        if str(dismissed).lower() == 'true':
            return

        buf_info = buffer_manager.get_current_buffer_info()
        if buf_info.get('is_small', False):
            window.setProperty('buffer_prompt_shown_this_session', 'true')
            curr_mb = buf_info.get('memory_size_mb', 20)
            heading = "Optimalizace bufferu"
            msg = (
                f"Buffer Kodi je pouze {curr_mb} MB (může se sekat 4K/FHD).\n\n"
                "Nastavit doporučených 150 MB RAM?"
            )
            dialog = xbmcgui.Dialog()
            try:
                # Kodi C++ API vyžaduje poziční argumenty: (heading, message, customlabel, nolabel, yeslabel)
                choice = dialog.yesnocustom(
                    heading,
                    msg,
                    "Nezobrazovat",
                    "Později",
                    "Nastavit 150 MB"
                )
            except Exception:
                res = dialog.yesno(heading, msg, "Zrušit", "Nastavit 150 MB")
                choice = 1 if res else 0

            if choice == 1:
                success, err = buffer_manager.set_buffer_size(150, buffermode=1, readfactor=20)
                if success:
                    buffer_manager.update_addon_buffer_setting(ADDON)
                    dialog_ok("Buffer nastaven", "Nastaveno [B]150 MB[/B]. Změna platí po restartu Kodi.")
                else:
                    dialog_ok("Chyba", f"Zápis selhal: {err}")
            elif choice == 2:
                ADDON.setSetting('buffer_warning_dismissed', 'true')
                dialog_notif("Buffer", "Upozornění vypnuto.")
    except Exception as e:
        log_error(f"Chyba při kontrole bufferu: {e}")


def configure_buffer_dialog():
    """Interaktivní dialog pro správu a nastavení vyrovnávací paměti Kodi."""
    try:
        buf_info = buffer_manager.get_current_buffer_info()
        curr_mb = buf_info.get('memory_size_mb', 20)
        has_custom = buf_info.get('configured', False)
        b_mode = buf_info.get('buffermode', 1)
        r_factor = buf_info.get('readfactor', 4)

        status_tag = f"{curr_mb} MB"
        if not has_custom:
            status_tag += " (výchozí)"
        else:
            status_tag += f" (vlastní, mód {b_mode})"

        options = [
            f"Info o bufferu ({status_tag})",
            "500 MB [Ultra - pro PC a 4K REMUX]",
            "250 MB [Velký - pro výkonná PC/TV]",
            "150 MB [Doporučeno pro 4K/FullHD]",
            "80 MB [Úsporný - pro slabší TV]",
            "20 MB [Výchozí]",
            "Znovu zapnout upozornění při startu"
        ]

        dialog = xbmcgui.Dialog()
        idx = dialog.select(f"Buffer (Aktuálně: {curr_mb} MB)", options)
        if idx < 0:
            return

        if idx == 0:
            ram_est = curr_mb * 3
            is_sm = buf_info.get('is_small', False)
            status_desc = "Malý (může se sekat)" if is_sm else "Optimální"
            as_path = buffer_manager.get_advancedsettings_path() or "neexistuje"

            info_msg = (
                f"• Velikost: [B]{curr_mb} MB[/B] (RAM: ~{ram_est} MB)\n"
                f"• Stahování: [B]{r_factor}x[/B] | Mód: [B]{b_mode}[/B]\n"
                f"• Stav: [B]{status_desc}[/B]\n"
                f"• Soubor: {as_path}"
            )
            dialog_ok("Info o bufferu", info_msg)
            return

        if idx == 1:
            target_mb = 500
        elif idx == 2:
            target_mb = 250
        elif idx == 3:
            target_mb = 150
        elif idx == 4:
            target_mb = 80
        elif idx == 5:
            target_mb = 20
        elif idx == 6:
            ADDON.setSetting('buffer_warning_dismissed', 'false')
            xbmcgui.Window(10000).clearProperty('buffer_prompt_shown_this_session')
            dialog_notif("Buffer", "Upozornění zapnuto.")
            return

        success, err = buffer_manager.set_buffer_size(target_mb, buffermode=1, readfactor=20)
        if success:
            buffer_manager.update_addon_buffer_setting(ADDON)
            dialog_ok("Buffer nastaven", f"Nastaveno [B]{target_mb} MB[/B]. Změna platí po restartu Kodi.")
        else:
            dialog_ok("Chyba", f"Zápis selhal: {err}")
    except Exception as e:
        log_error(f"Chyba při nastavování bufferu: {e}")
        dialog_ok("Chyba", str(e))
        
def make_movie_context_menu(tmdb_id, title, is_watched=False, is_resume=False, collection_id=None, collection_name=None, year="", poster="", fanart=""):
    """Vytvoří položky kontextového menu pro film."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    quoted_year = urllib.parse.quote_plus(str(year or ""))
    quoted_poster = urllib.parse.quote_plus(poster or "")
    quoted_fanart = urllib.parse.quote_plus(fanart or "")

    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit jako nezhlédnuté", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit jako zhlédnuté", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))

    if not collection_id and tmdb_id:
        cached_d = db.get_cache(f"tmdb_movie_{tmdb_id}_cs-CZ", ttl_days=7) or db.get_cache(f"tmdb_movie_{tmdb_id}")
        if isinstance(cached_d, dict):
            coll = cached_d.get('belongs_to_collection')
            if isinstance(coll, dict) and coll.get('id'):
                collection_id = coll.get('id')
                collection_name = coll.get('name')

    if collection_id:
        coll_title_quoted = urllib.parse.quote_plus(collection_name if collection_name else "Filmová série")
        coll_url = f"{base_url}?mode=movie_collection&collection_id={collection_id}&collection_name={coll_title_quoted}"
        menu.append(("Zobrazit celou sérii", f"ActivateWindow(Videos,{coll_url},return)"))

    if db.is_favorite(str(tmdb_id), 'movie'):
        rem_fav_url = f"{base_url}?mode=remove_favorite&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat z oblíbených", f"RunPlugin({rem_fav_url})"))
    else:
        add_fav_url = f"{base_url}?mode=add_favorite&media_type=movie&tmdb_id={tmdb_id}&title={quoted_title}&year={quoted_year}&poster={quoted_poster}&fanart={quoted_fanart}"
        menu.append(("Přidat do oblíbených", f"RunPlugin({add_fav_url})"))

    similar_url = f"{base_url}?mode=tmdb_list&media_type=movie&category=similar&similar_id={tmdb_id}&title={quoted_title}"
    menu.append(("Podobné tituly", f"ActivateWindow(Videos,{similar_url},return)"))
    menu.append(("Rozšířené informace", f"RunScript(script.embuary.info,call=movie,tmdb_id={tmdb_id})"))

    return menu

def make_tv_context_menu(tmdb_id, title, is_watched=False, is_resume=False, year="", poster="", fanart=""):
    """Vytvoří položky kontextového menu pro seriál."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    quoted_year = urllib.parse.quote_plus(str(year or ""))
    quoted_poster = urllib.parse.quote_plus(poster or "")
    quoted_fanart = urllib.parse.quote_plus(fanart or "")

    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit seriál jako nezhlédnutý", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Označit seriál jako zhlédnutý", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))

    if db.is_favorite(str(tmdb_id), 'tv'):
        rem_fav_url = f"{base_url}?mode=remove_favorite&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}"
        menu.append(("Odebrat seriál z oblíbených", f"RunPlugin({rem_fav_url})"))
    else:
        add_fav_url = f"{base_url}?mode=add_favorite&media_type=tv&tmdb_id={tmdb_id}&title={quoted_title}&year={quoted_year}&poster={quoted_poster}&fanart={quoted_fanart}"
        menu.append(("Přidat seriál do oblíbených", f"RunPlugin({add_fav_url})"))

    similar_url = f"{base_url}?mode=tmdb_list&media_type=tv&category=similar&similar_id={tmdb_id}&title={quoted_title}"
    menu.append(("Podobné tituly", f"ActivateWindow(Videos,{similar_url},return)"))
    menu.append(("Rozšířené info (Embuary)", f"RunScript(script.embuary.info,call=tv,tmdb_id={tmdb_id})"))

    return menu

def handle_context_search_person(tmdb_id, media_type, role_type):
    """Obsluha výběru herce nebo režiséra z kontextové nabídky titulu."""
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key or not tmdb_id:
        return
    details = tmdb.get_item_details(media_type, tmdb_id, tmdb_key)
    if not details:
        dialog_notif("Chyba", "Nepodařilo se načíst detaily z TMDB", xbmcgui.NOTIFICATION_ERROR)
        return

    if role_type == "actor":
        cast = details.get('cast', [])
        if not cast:
            dialog_notif("Obsazení", "Nebyly nalezeny informace o hercích", xbmcgui.NOTIFICATION_INFO)
            return
        options = []
        for a in cast:
            a_name = a.get('name', '')
            a_role = a.get('role', '')
            options.append(f"{a_name} ({a_role})" if a_role else a_name)
        idx = xbmcgui.Dialog().select("Vyberte herce / herečku", options)
        if idx >= 0:
            selected_actor = cast[idx]['name']
            quoted = urllib.parse.quote_plus(selected_actor)
            target_url = f"plugin://plugin.video.webshare.stream.cinema.v2/?mode=search_person&query={quoted}&person_type=actor"
            xbmc.executebuiltin(f"ActivateWindow(Videos,{target_url},return)")
    else:
        directors = details.get('directors', [])
        if not directors:
            dialog_notif("Režie", "Nebyl nalezen režisér", xbmcgui.NOTIFICATION_INFO)
            return
        if len(directors) == 1:
            target_director = directors[0]
        else:
            idx = xbmcgui.Dialog().select("Vyberte režiséra", directors)
            if idx < 0:
                return
            target_director = directors[idx]
        quoted = urllib.parse.quote_plus(target_director)
        target_url = f"plugin://plugin.video.webshare.stream.cinema.v2/?mode=search_person&query={quoted}&person_type=director"
        xbmc.executebuiltin(f"ActivateWindow(Videos,{target_url},return)")

def make_season_context_menu(tmdb_id, season_number, title, is_watched=False):
    """Vytvoří položky kontextového menu pro sérii seriálu."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&title={quoted_title}"
        menu.append(("Označit sérii jako nezhlédnutou", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&title={quoted_title}"
        menu.append(("Označit sérii jako zhlédnutou", f"RunPlugin({watch_url})"))
    return menu

def make_episode_context_menu(tmdb_id, season_number, episode_number, title, is_watched=False, is_resume=False, year="", poster="", fanart=""):
    """Vytvoří položky kontextového menu pro epizodu seriálu."""
    menu = []
    base_url = sys.argv[0]
    quoted_title = urllib.parse.quote_plus(title or "")
    quoted_year = urllib.parse.quote_plus(str(year or ""))
    quoted_poster = urllib.parse.quote_plus(poster or "")
    quoted_fanart = urllib.parse.quote_plus(fanart or "")
    if is_watched:
        unwatch_url = f"{base_url}?mode=mark_unwatched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Označit díl jako nezhlédnutý", f"RunPlugin({unwatch_url})"))
    else:
        watch_url = f"{base_url}?mode=mark_watched&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Označit díl jako zhlédnutý", f"RunPlugin({watch_url})"))
    if is_resume:
        remove_url = f"{base_url}?mode=remove_resume&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Odebrat z rozkoukaných", f"RunPlugin({remove_url})"))

    if db.is_favorite(str(tmdb_id), 'tv', season=season_number, episode=episode_number):
        rem_fav_url = f"{base_url}?mode=remove_favorite&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}"
        menu.append(("Odebrat díl z oblíbených", f"RunPlugin({rem_fav_url})"))
    else:
        add_fav_url = f"{base_url}?mode=add_favorite&media_type=tv&tmdb_id={tmdb_id}&season={season_number}&episode={episode_number}&title={quoted_title}&year={quoted_year}&poster={quoted_poster}&fanart={quoted_fanart}"
        menu.append(("Přidat díl do oblíbených", f"RunPlugin({add_fav_url})"))

    return menu

def favorites_menu():
    """Zobrazí seznam oblíbených filmů, seriálů a jednotlivých epizod s plnými metadaty a obrázky."""
    xbmcplugin.setContent(HANDLE, "movies")
    favs = db.get_favorites()
    if not favs:
        li = xbmcgui.ListItem(label="[COLOR gray]Zatím žádné oblíbené položky[/COLOR]")
        li.setArt({'icon': ICONS.get('LOVE', ''), 'thumb': ICONS.get('LOVE', '')})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    tmdb_key = ADDON.getSetting('tmdb_api_key')

    for it in favs:
        tmdb_id = it.get('tmdb_id')
        media_type = it.get('media_type', 'movie')
        title = it.get('title', 'Neznámý')
        season = int(it.get('season') or 0)
        episode = int(it.get('episode') or 0)
        year_str = str(it.get('year') or '')
        poster = it.get('poster') or ''
        fanart = it.get('fanart') or ''
        overview = it.get('overview') or ''
        details = it.get('details_parsed') or {}

        needs_update = False
        mtype = 'tv' if media_type in ('tv', 'series') else 'movie'

        # Pokud chybí poster nebo metadata, dotáhneme z TMDB cache nebo TMDB API
        if (not poster or not overview or not year_str or not details) and tmdb_key and tmdb_id:
            cache_key = f"tmdb_{mtype}_{tmdb_id}_cs-CZ"
            cached = db.get_cache(cache_key, ttl_days=7) or db.get_cache(f"tmdb_{mtype}_{tmdb_id}")
            if not cached:
                try:
                    cached = tmdb.get_item_details(mtype, tmdb_id, tmdb_key)
                except Exception:
                    cached = {}

            if cached and isinstance(cached, dict):
                details = {**cached, **details}
                p_path = cached.get('poster_path')
                b_path = cached.get('backdrop_path')
                if not poster and p_path:
                    poster = f"https://image.tmdb.org/t/p/w500{p_path}"
                    needs_update = True
                elif not poster and cached.get('poster'):
                    poster = cached.get('poster')
                    needs_update = True

                if not fanart and b_path:
                    fanart = f"https://image.tmdb.org/t/p/w1280{b_path}"
                    needs_update = True
                elif not fanart and cached.get('fanart'):
                    fanart = cached.get('fanart')
                    needs_update = True

                if not overview and cached.get('overview'):
                    overview = cached.get('overview')
                    needs_update = True

                if not year_str:
                    rd = cached.get('release_date') or cached.get('first_air_date') or ''
                    if rd:
                        year_str = rd[:4]
                        needs_update = True

                if title in ('Neznámý', 'Neznámý název', ''):
                    tmdb_title = cached.get('title') or cached.get('name')
                    if tmdb_title:
                        title = tmdb_title
                        needs_update = True

            if season > 0 and episode > 0:
                try:
                    season_info = tmdb.get_season_episodes(tmdb_id, season, tmdb_key)
                    for ep in season_info.get('episodes', []):
                        if ep.get('episode_number') == episode:
                            still_p = ep.get('still_path')
                            if still_p and (not poster or poster.endswith('None')):
                                poster = f"https://image.tmdb.org/t/p/w500{still_p}"
                                needs_update = True
                            if ep.get('overview') and not overview:
                                overview = ep.get('overview')
                                needs_update = True
                            if ep.get('air_date') and not year_str:
                                year_str = ep.get('air_date')[:4]
                                needs_update = True
                            details['episode_name'] = ep.get('name')
                            details['still_path'] = still_p
                            break
                except Exception:
                    pass

            if needs_update:
                db.add_favorite(
                    tmdb_id=tmdb_id, media_type=media_type, title=title,
                    year=year_str, poster=poster, fanart=fanart, overview=overview,
                    season=season, episode=episode, details=details
                )

        default_icon = ICONS.get('FILM', '') if media_type == 'movie' else ICONS.get('THEATRE', '')
        poster_art = poster if poster else default_icon
        fanart_art = fanart if fanart else ''
        clean_year = year_str.strip() if year_str else ""
        label2_val = clean_year

        if media_type == 'movie':
            tag = "[COLOR lime][F][/COLOR] "
            label = f"{tag}{title}"
            li = xbmcgui.ListItem(label=label, label2=label2_val)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('movie')
            if tmdb_id:
                info_tag.setUniqueID(str(tmdb_id), type='tmdb')
            info_tag.setTitle(title)

            orig_t = details.get('original_title') or title
            info_tag.setOriginalTitle(orig_t)
            rel_date = details.get('release_date') or ''
            en_t = details.get('english_title') or (orig_t if details.get('original_language') == 'en' else '')
            plot_text = build_item_plot(
                overview,
                release_date=rel_date,
                english_title=en_t,
                main_title=title
            )
            info_tag.setPlot(plot_text)
            info_tag.setPlotOutline(details.get('tagline', ''))
            if clean_year.isdigit():
                info_tag.setYear(int(clean_year))
            if rel_date:
                info_tag.setPremiered(rel_date)

            rating_val = details.get('rating') or details.get('vote_average') or 0
            if rating_val:
                try:
                    info_tag.setRating(float(rating_val))
                except (ValueError, TypeError):
                    pass
            runtime = details.get('runtime') or 0
            if runtime:
                try:
                    info_tag.setDuration(int(runtime) * 60)
                except (ValueError, TypeError):
                    pass
            if details.get('genres'):
                safe_set_genres(info_tag, details['genres'])
            if details.get('directors'):
                info_tag.setDirectors(details['directors'])
            if details.get('cast'):
                actors = [xbmc.Actor(name=a['name'], role=a.get('role', ''), thumbnail=a.get('thumbnail', '')) for a in details['cast'] if a.get('name')]
                info_tag.setCast(actors)

            apply_budget_and_vote_properties(li, info_tag, details)

            st = db.get_item_watch_status(tmdb_id, 0, 0)
            is_w = bool(st and st.get('watched'))
            is_r = bool(st and st.get('resume_time', 0) > 15 and not is_w)
            if is_w:
                info_tag.setPlaycount(1)
            elif is_r:
                info_tag.setResumePoint(st['resume_time'], st.get('total_time', 0))

            li.addContextMenuItems(make_movie_context_menu(
                tmdb_id, title, is_watched=is_w, is_resume=is_r,
                year=clean_year, poster=poster, fanart=fanart
            ))
            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": orig_t,
                "year": clean_year,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
                "poster": poster,
                "fanart": fanart,
                "overview": overview
            })
            is_folder = True

        elif media_type == 'tv' and season == 0 and episode == 0:
            tag = "[COLOR lime][S][/COLOR] "
            season_cnt = details.get('number_of_seasons') or 0
            season_cnt_str = format_season_count(season_cnt) if season_cnt else ""
            season_part = f" • [COLOR lime]{season_cnt_str}[/COLOR]" if season_cnt_str else ""
            label = f"{tag}{title}{season_part}"
            li = xbmcgui.ListItem(label=label, label2=label2_val)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('tvshow')
            if tmdb_id:
                info_tag.setUniqueID(str(tmdb_id), type='tmdb')
            info_tag.setTitle(title)

            orig_t = details.get('original_name') or details.get('original_title') or title
            info_tag.setOriginalTitle(orig_t)
            first_air = details.get('first_air_date') or ''
            en_t = details.get('english_title') or (orig_t if details.get('original_language') == 'en' else '')
            plot_text = build_item_plot(
                overview,
                release_date=first_air,
                english_title=en_t,
                main_title=title
            )
            info_tag.setPlot(plot_text)
            info_tag.setPlotOutline(details.get('tagline', ''))
            if clean_year.isdigit():
                info_tag.setYear(int(clean_year))
            if first_air:
                info_tag.setPremiered(first_air)

            rating_val = details.get('rating') or details.get('vote_average') or 0
            if rating_val:
                try:
                    info_tag.setRating(float(rating_val))
                except (ValueError, TypeError):
                    pass
            if details.get('genres'):
                safe_set_genres(info_tag, details['genres'])
            if details.get('cast'):
                actors = [xbmc.Actor(name=a['name'], role=a.get('role', ''), thumbnail=a.get('thumbnail', '')) for a in details['cast'] if a.get('name')]
                info_tag.setCast(actors)

            apply_budget_and_vote_properties(li, info_tag, details)

            show_p = db.get_tv_show_progress(tmdb_id, details.get('number_of_episodes', 0))
            is_w = (show_p >= 100)
            is_r = (0 < show_p < 100)
            if is_w:
                info_tag.setPlaycount(1)

            li.addContextMenuItems(make_tv_context_menu(
                tmdb_id, title, is_watched=is_w, is_resume=is_r,
                year=clean_year, poster=poster, fanart=fanart
            ))
            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": orig_t,
                "year": clean_year,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
                "poster": poster,
                "fanart": fanart,
                "overview": overview
            })
            is_folder = True

        else:
            ep_tag = f"S{season:02d}E{episode:02d}"
            ep_name = details.get('episode_name') or f"Díl {episode}"
            label = f"[COLOR lime][E][/COLOR] {title} - {ep_tag} • {ep_name}"
            li = xbmcgui.ListItem(label=label, label2=label2_val)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('episode')
            if tmdb_id:
                info_tag.setUniqueID(str(tmdb_id), type='tmdb')
            info_tag.setTvShowTitle(title)
            info_tag.setTitle(f"{ep_tag} {ep_name}")
            info_tag.setSeason(season)
            info_tag.setEpisode(episode)
            info_tag.setPlot(overview)
            if clean_year.isdigit():
                info_tag.setYear(int(clean_year))

            ep_status = db.get_item_watch_status(tmdb_id, season, episode)
            is_w = bool(ep_status and ep_status.get('watched'))
            is_r = bool(ep_status and ep_status.get('resume_time', 0) > 15 and not is_w)
            if is_w:
                info_tag.setPlaycount(1)
            elif is_r:
                info_tag.setResumePoint(ep_status['resume_time'], ep_status.get('total_time', 0))

            li.addContextMenuItems(make_episode_context_menu(
                tmdb_id, season, episode, title, is_watched=is_w, is_resume=is_r,
                year=clean_year, poster=poster, fanart=fanart
            ))
            url = build_url({
                "mode": "tv_episode_selected",
                "title": title,
                "original_title": title,
                "year": clean_year,
                "tmdb_id": tmdb_id,
                "season_number": season,
                "episode_number": episode,
                "poster": poster,
                "fanart": fanart,
                "overview": overview
            })
            is_folder = True

        art = {
            'poster': poster_art,
            'thumb': poster_art,
            'icon': poster_art,
        }
        if fanart_art:
            art['fanart'] = fanart_art
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    apply_view_mode(50)


def show_history_menu():
    items = [
        ("Rozkoukané filmy a seriály", ICONS['RESUME'], {"mode": "history_resume_menu"}),
        ("Zhlédnuté filmy a seriály", ICONS['WATCHED'], {"mode": "history_watched_menu"}),
        ("Zobrazit seznam oblíbených", ICONS['LOVE'], {"mode": "favorites_menu"}),
        ("Historie přehrávání (poslední díly a filmy)", ICONS['HISTORY'], {"mode": "history_playback_log"}),
        ("Historie vyhledávání", ICONS['SEARCH'], {"mode": "history_search"}),
    ]


    for label, icon, params in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({
            'icon': icon,
            'thumb': icon
        })
        url = build_url(params)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)
    
def show_search_history():
    """Zobrazí seznam naposledy hledaných výrazů z DB a možnosti správy."""
    handle = int(sys.argv[1])
    base_url = sys.argv[0]

    # Nastavení typu obsahu pro Kodi
    xbmcplugin.setContent(handle, "files")

    # 1. Nové vyhledávání (použije mode == "search", který vyvolá Dialog.input)
    new_search_url = f"{base_url}?mode=search"
    item_new = xbmcgui.ListItem(label="[B]Nové Hledání[/B]")
    item_new.setArt({"icon": ICONS.get('SEARCH', 'DefaultAddonsSearch.png'), "thumb": ICONS.get('SEARCH', 'DefaultAddonsSearch.png')})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=new_search_url, listitem=item_new, isFolder=True
    )

    # 2. Načtení historie z DB
    history_items = db.get_search_history(limit=20)

    for query in history_items:
        encoded_query = urllib.parse.quote_plus(query)
        item_url = f"{base_url}?mode=search_predefined&search_arg={encoded_query}"

        if query.startswith("[H] "):
            item_icon = ICONS.get('ACTOR', ICONS.get('HISTORY', 'DefaultFolder.png'))
        elif query.startswith("[R] "):
            item_icon = ICONS.get('DIRECTOR', ICONS.get('HISTORY', 'DefaultFolder.png'))
        else:
            item_icon = ICONS.get('HISTORY', 'DefaultFolder.png')

        list_item = xbmcgui.ListItem(label=query)
        list_item.setArt({"icon": item_icon, "thumb": item_icon})

        delete_url = f"{base_url}?mode=delete_search&query={encoded_query}"
        list_item.addContextMenuItems(
            [("Smazat z historie", f"RunPlugin({delete_url})")]
        )

        xbmcplugin.addDirectoryItem(
            handle=handle, url=item_url, listitem=list_item, isFolder=True
        )

    xbmcplugin.endOfDirectory(handle)

    
def format_seconds(seconds):
    """Pomocná funkce pro převod sekund na HH:MM:SS."""
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"

def history_resume_menu():
    """
    Zobrazí seznam rozkoukaných filmů a seriálů s procenty, časy a plakáty.
    - Film: Otevře dostupné soubory filmu (search_webshare) a při přehrání nabídne pokračovat
    - Seriál: Otevře seznam sérií daného seriálu s indikátory rozkoukání
    """
    xbmcplugin.setContent(HANDLE, "movies")
    items = db.get_in_progress_items(limit=50)

    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádné rozkoukané položky[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api_key = ADDON.getSetting('tmdb_api_key')

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        details = item.get('details', {}) or {}

        # Pokud chybí metadata v DB, dotáhneme z TMDB a uložíme do DB
        if not details.get('poster') and tmdb_id and api_key:
            tmdb_details = tmdb.get_item_details(media_type, tmdb_id, api_key)
            if tmdb_details:
                details = {**tmdb_details, **details}
                db.save_item_metadata(tmdb_id, media_type, title, details=details)

        year_val = details.get('year') or details.get('release_date', '')[:4] or details.get('first_air_date', '')[:4] or ''
        year_str = year_val if year_val else "N/A"
        poster = details.get('poster') or details.get('thumb') or ''
        poster_p = details.get('poster_path')
        if not poster and poster_p:
            poster = f"https://image.tmdb.org/t/p/w500{poster_p}"
        fanart = details.get('fanart') or ''
        backdrop_p = details.get('backdrop_path')
        if not fanart and backdrop_p:
            fanart = f"https://image.tmdb.org/t/p/original{backdrop_p}"

        if media_type == "tv":
            num_eps = details.get('number_of_episodes') or 0
            show_pct = db.get_tv_show_progress(tmdb_id, num_eps)
            season_cnt = details.get('number_of_seasons') or 0
            season_cnt_str = format_season_count(season_cnt)
            season_text = f" • [COLOR lime]{season_cnt_str}[/COLOR]" if season_cnt else ""

            last_s = item.get('season', 0)
            last_e = item.get('episode', 0)
            ep_info = f" • [COLOR yellow]Naposledy: S{last_s:02d}E{last_e:02d}[/COLOR]" if (last_s > 0 and last_e > 0) else ""
            
            label = f"{title} [COLOR orange]({show_pct}%)[/COLOR]{season_text}{ep_info}"

            li = xbmcgui.ListItem(label=label, label2=str(year_val))
            li.addContextMenuItems(make_tv_context_menu(tmdb_id, title, is_watched=False, is_resume=True, year=year_val, poster=poster, fanart=fanart))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or details.get('original_name') or title,
                "year": year_val,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
            })
        else:
            resume_time = item.get('resume_time', 0)
            total_time = item.get('total_time', 0)
            pct = int((resume_time / total_time) * 100) if total_time > 0 else 0
            time_str = f" • {format_seconds(resume_time)} / {format_seconds(total_time)}" if total_time > 0 else ""
            label = f"{title} [COLOR orange]({pct}%)[/COLOR]{time_str}"

            li = xbmcgui.ListItem(label=label, label2=str(year_val))
            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=False, is_resume=True, year=year_val, poster=poster, fanart=fanart))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or title,
                "year": year_val,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
            })

        info_tag = li.getVideoInfoTag()
        if tmdb_id:
            info_tag.setUniqueID(str(tmdb_id), type='tmdb')
        info_tag.setTitle(title)
        orig_t = details.get('original_title') or details.get('original_name') or title
        info_tag.setOriginalTitle(orig_t)
        rel_date = details.get('release_date') or details.get('first_air_date') or ''
        en_t = details.get('english_title') or (orig_t if details.get('original_language') == 'en' else '')
        full_plot = build_item_plot(
            details.get('overview', ''),
            release_date=rel_date,
            english_title=en_t,
            main_title=title
        )
        info_tag.setPlot(full_plot)
        info_tag.setPlotOutline(details.get('tagline', ''))
        info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')
        if str(year_val).isdigit():
            info_tag.setYear(int(year_val))
        if rel_date:
            info_tag.setPremiered(rel_date)
        if details.get('rating') or details.get('vote_average'):
            try:
                info_tag.setRating(float(details.get('rating') or details.get('vote_average') or 0))
            except (ValueError, TypeError):
                pass
        if details.get('runtime'):
            try:
                info_tag.setDuration(int(details['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        if details.get('genres'):
            safe_set_genres(info_tag, details['genres'])
        if details.get('directors'):
            info_tag.setDirectors(details['directors'])
        if details.get('cast'):
            actors = [xbmc.Actor(name=a['name'], role=a.get('role', ''), thumbnail=a.get('thumbnail', '')) for a in details['cast'] if a.get('name')]
            info_tag.setCast(actors)
        if item.get('resume_time', 0) > 0:
            info_tag.setResumePoint(item['resume_time'], item.get('total_time', 0))

        apply_budget_and_vote_properties(li, info_tag, details)

        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    apply_view_mode(50)



def history_watched_menu():
    """Zobrazí seznam zhlédnutých filmů a dokončených seriálů s plnými metadaty a plakáty."""
    xbmcplugin.setContent(HANDLE, "movies")
    items = db.get_watched_items(limit=50)

    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádné zhlédnuté položky[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api_key = ADDON.getSetting('tmdb_api_key')

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        details = item.get('details', {}) or {}

        if not details.get('poster') and tmdb_id and api_key:
            tmdb_details = tmdb.get_item_details(media_type, tmdb_id, api_key)
            if tmdb_details:
                details = {**tmdb_details, **details}
                db.save_item_metadata(tmdb_id, media_type, title, details=details)

        year_val = details.get('year') or details.get('release_date', '')[:4] or details.get('first_air_date', '')[:4] or ''
        year_str = year_val if year_val else "N/A"
        poster = details.get('poster') or details.get('thumb') or ''
        poster_p = details.get('poster_path')
        if not poster and poster_p:
            poster = f"https://image.tmdb.org/t/p/w500{poster_p}"
        fanart = details.get('fanart') or ''
        backdrop_p = details.get('backdrop_path')
        if not fanart and backdrop_p:
            fanart = f"https://image.tmdb.org/t/p/original{backdrop_p}"

        if media_type == "tv":
            season_cnt = details.get('number_of_seasons') or 0
            season_cnt_str = format_season_count(season_cnt)
            season_text = f" • [COLOR lime]{season_cnt_str}[/COLOR]" if season_cnt else ""
            label = f"[COLOR gray]{title}[/COLOR] [COLOR lime](Zhlédnuto - Celý seriál)[/COLOR]{season_text}"
            li = xbmcgui.ListItem(label=label, label2=str(year_val))
            li.addContextMenuItems(make_tv_context_menu(tmdb_id, title, is_watched=True, is_resume=False, year=year_val, poster=poster, fanart=fanart))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or details.get('original_name') or title,
                "year": year_val,
                "media_type": "tv",
                "tmdb_id": tmdb_id,
            })
        else:
            label = f"[COLOR gray]{title}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR]"
            li = xbmcgui.ListItem(label=label, label2=str(year_val))

            li.addContextMenuItems(make_movie_context_menu(tmdb_id, title, is_watched=True, is_resume=False, year=year_val, poster=poster, fanart=fanart))

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "original_title": details.get('original_title') or title,
                "year": year_val,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
            })

        info_tag = li.getVideoInfoTag()
        if tmdb_id:
            info_tag.setUniqueID(str(tmdb_id), type='tmdb')
        info_tag.setTitle(title)
        orig_t = details.get('original_title') or details.get('original_name') or title
        info_tag.setOriginalTitle(orig_t)
        rel_date = details.get('release_date') or details.get('first_air_date') or ''
        en_t = details.get('english_title') or (orig_t if details.get('original_language') == 'en' else '')
        full_plot = build_item_plot(
            details.get('overview', ''),
            release_date=rel_date,
            english_title=en_t,
            main_title=title
        )
        info_tag.setPlot(full_plot)
        info_tag.setPlotOutline(details.get('tagline', ''))
        info_tag.setMediaType('tvshow' if media_type == 'tv' else 'movie')
        info_tag.setPlaycount(1)

        if str(year_val).isdigit():
            info_tag.setYear(int(year_val))
        if rel_date:
            info_tag.setPremiered(rel_date)
        if details.get('rating') or details.get('vote_average'):
            try:
                info_tag.setRating(float(details.get('rating') or details.get('vote_average') or 0))
            except (ValueError, TypeError):
                pass
        if details.get('runtime'):
            try:
                info_tag.setDuration(int(details['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        if details.get('genres'):
            safe_set_genres(info_tag, details['genres'])
        if details.get('directors'):
            info_tag.setDirectors(details['directors'])
        if details.get('cast'):
            actors = [xbmc.Actor(name=a['name'], role=a.get('role', ''), thumbnail=a.get('thumbnail', '')) for a in details['cast'] if a.get('name')]
            info_tag.setCast(actors)

        apply_budget_and_vote_properties(li, info_tag, details)

        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    apply_view_mode(50)



def history_playback_log():
    """Zobrazí chronologický přehled nedávno přehrávaných videí (filmů i konkrétních epizod)."""
    xbmcplugin.setContent(HANDLE, "movies")
    items = db.get_playback_history(limit=50)

    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Žádná historie přehrávání[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    api_key = ADDON.getSetting('tmdb_api_key')

    for item in items:
        tmdb_id = item.get('tmdb_id')
        media_type = item.get('media_type', 'movie')
        title = item.get('title', 'Neznámý název')
        season = int(item.get('season') or 0)
        episode = int(item.get('episode') or 0)
        is_watched = item.get('watched', False)
        resume_time = item.get('resume_time', 0)
        total_time = item.get('total_time', 0)
        details = item.get('details', {}) or {}

        # Pokud chybí metadata v DB, dotáhneme z TMDB nebo cache
        if (not details.get('poster') or not details.get('overview')) and tmdb_id and api_key:
            mtype = 'tv' if media_type in ('tv', 'series', 'episode') else 'movie'
            cached = db.get_cache(f"tmdb_{mtype}_{tmdb_id}_cs-CZ", ttl_days=7) or db.get_cache(f"tmdb_{mtype}_{tmdb_id}")
            if not cached:
                try:
                    cached = tmdb.get_item_details(mtype, tmdb_id, api_key)
                except Exception:
                    cached = {}
            if cached and isinstance(cached, dict):
                details = {**cached, **details}
                db.save_item_metadata(tmdb_id, mtype, title, details=details)

        year_val = details.get('year') or details.get('release_date', '')[:4] or details.get('first_air_date', '')[:4] or ''
        year_str = year_val if year_val else "N/A"
        poster = details.get('poster') or details.get('thumb') or ''
        poster_p = details.get('poster_path')
        if not poster and poster_p:
            poster = f"https://image.tmdb.org/t/p/w500{poster_p}"
        fanart = details.get('fanart') or ''
        backdrop_p = details.get('backdrop_path')
        if not fanart and backdrop_p:
            fanart = f"https://image.tmdb.org/t/p/original{backdrop_p}"

        if media_type == "tv" and season > 0 and episode > 0:
            ep_tag = f"S{season:02d}E{episode:02d}"
            base_label = f"{title} - {ep_tag}"
            if is_watched:
                label = f"[COLOR gray]{base_label}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR]"
            elif resume_time > 15 and total_time > 0:
                pct = int((resume_time / total_time) * 100)
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]"
            else:
                label = base_label

            url = build_url({
                "mode": "tv_episode_selected",
                "title": title,
                "tmdb_id": tmdb_id,
                "season_number": season,
                "episode_number": episode,
                "year": year_val
            })
            li = xbmcgui.ListItem(label=label, label2=str(year_val))
            li.addContextMenuItems(make_episode_context_menu(
                tmdb_id, season, episode, title,
                is_watched=is_watched,
                is_resume=(resume_time > 15 and not is_watched),
                year=year_val, poster=poster, fanart=fanart
            ))
        else:
            base_label = title
            if is_watched:
                label = f"[COLOR gray]{base_label}[/COLOR] [COLOR lime](Zhlédnuto)[/COLOR]"
            elif resume_time > 15 and total_time > 0:
                pct = int((resume_time / total_time) * 100)
                time_str = f" • {format_seconds(resume_time)} / {format_seconds(total_time)}"
                label = f"{base_label} [COLOR orange]({pct}%)[/COLOR]{time_str}"
            else:
                label = base_label

            url = build_url({
                "mode": "search_webshare",
                "title": title,
                "media_type": "movie",
                "tmdb_id": tmdb_id,
                "year": year_val
            })
            li = xbmcgui.ListItem(label=label, label2=str(year_val))
            li.addContextMenuItems(make_movie_context_menu(
                tmdb_id, title,
                is_watched=is_watched,
                is_resume=(resume_time > 15 and not is_watched),
                year=year_val, poster=poster, fanart=fanart
            ))

        info_tag = li.getVideoInfoTag()
        if tmdb_id:
            info_tag.setUniqueID(str(tmdb_id), type='tmdb')
        info_tag.setTitle(title)
        orig_t = details.get('original_title') or details.get('original_name') or title
        info_tag.setOriginalTitle(orig_t)
        rel_date = details.get('release_date') or details.get('first_air_date') or ''
        en_t = details.get('english_title') or (orig_t if details.get('original_language') == 'en' else '')
        full_plot = build_item_plot(
            details.get('overview', ''),
            release_date=rel_date,
            english_title=en_t,
            main_title=title
        )
        info_tag.setPlot(full_plot)
        info_tag.setPlotOutline(details.get('tagline', ''))
        info_tag.setMediaType('episode' if (media_type == 'tv' and season > 0 and episode > 0) else ('tvshow' if media_type == 'tv' else 'movie'))
        if is_watched:
            info_tag.setPlaycount(1)
        if resume_time > 0:
            info_tag.setResumePoint(resume_time, total_time)
        if str(year_val).isdigit():
            info_tag.setYear(int(year_val))
        if rel_date:
            info_tag.setPremiered(rel_date)
        if details.get('rating') or details.get('vote_average'):
            try:
                info_tag.setRating(float(details.get('rating') or details.get('vote_average') or 0))
            except (ValueError, TypeError):
                pass
        if details.get('runtime'):
            try:
                info_tag.setDuration(int(details['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        if details.get('genres'):
            safe_set_genres(info_tag, details['genres'])
        if details.get('directors'):
            info_tag.setDirectors(details['directors'])
        if details.get('cast'):
            actors = [xbmc.Actor(name=a['name'], role=a.get('role', ''), thumbnail=a.get('thumbnail', '')) for a in details['cast'] if a.get('name')]
            info_tag.setCast(actors)

        apply_budget_and_vote_properties(li, info_tag, details)

        art = {}
        if poster:
            art['poster'] = poster
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    apply_view_mode(50)
    
def get_skin_status():
    """
    Zkontroluje stav doporučeného vzhledu 'skin.estuary.streamcinema':
    - 'active': Vzhled je nainstalovaný a aktuálně aktivní
    - 'installed': Vzhled je nainstalovaný v Kodi (ale není aktivní)
    - 'not_installed': Vzhled není v systému nainstalován
    """
    try:
        current_skin = xbmc.getSkinDir()
        if current_skin == "skin.estuary.streamcinema":
            return "active"

        # Kontrola, zda existuje addon v Kodi registru
        if xbmc.getCondVisibility("System.HasAddon(skin.estuary.streamcinema)"):
            return "installed"

        # Kontrola přímo na disku ve složce addons
        addons_dir = xbmcvfs.translatePath("special://home/addons/skin.estuary.streamcinema")
        if xbmcvfs.exists(addons_dir):
            return "installed"

        return "not_installed"
    except Exception as e:
        log_debug(f"Chyba při zjišťování stavu skinu: {e}")
        return "not_installed"


def activate_streamcinema_skin():
    """Aktivuje vzhled skin.estuary.streamcinema a povolí jej v Kodi."""
    try:
        # 1. Povolení doplňku přes JSON-RPC pro případ, že byl zakázaný
        try:
            xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": "skin.estuary.streamcinema", "enabled": True},
                "id": 1
            }))
        except Exception:
            pass

        # 2. Nastavení skinu v Kodi
        xbmc.executebuiltin("SetGUISkin(skin.estuary.streamcinema)")
        try:
            xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0",
                "method": "Settings.SetSettingValue",
                "params": {"setting": "lookandfeel.skin", "value": "skin.estuary.streamcinema"},
                "id": 2
            }))
        except Exception:
            pass
        return True
    except Exception as e:
        log_error(f"Chyba při aktivaci skinu: {e}")
        return False


def install_and_activate_skin(show_progress=True):
    """
    Spolehlivě stáhne, nainstaluje a aktivuje skin.estuary.streamcinema.
    Řeší problém, kdy selhává standardní InstallAddon(...) z důvodu neaktualizovaného repozitáře.
    """
    import zipfile
    import io

    status = get_skin_status()
    if status == "active":
        dialog_notif("Vzhled Stream Cinema", "Vzhled je již nainstalován a aktivní.", xbmcgui.NOTIFICATION_INFO)
        return True

    if status == "installed":
        activate_streamcinema_skin()
        return True

    dp = xbmcgui.DialogProgress() if show_progress else None
    if dp:
        dp.create("Instalace vzhledu", "Připojuji k repozitáři...")
        dp.update(10, "Zjišťuji dostupnou verzi vzhledu...")

    download_urls = [
        "https://obamaaaaa.github.io/kodi-repository/skin.estuary.streamcinema/skin.estuary.streamcinema-1.0.4.zip",
        "https://raw.githubusercontent.com/obamaaaaa/kodi-repository/main/repo/skin.estuary.streamcinema/skin.estuary.streamcinema-1.0.4.zip",
        "https://raw.githubusercontent.com/obamaaaaa/kodi-repository/main/skin.estuary.streamcinema/skin.estuary.streamcinema-1.0.4.zip",
    ]

    # Zkusíme zjistit nejnovější verzi z addons.xml repozitáře
    try:
        repo_xml_url = "https://obamaaaaa.github.io/kodi-repository/addons.xml"
        req = urllib.request.Request(repo_xml_url, headers={"User-Agent": "Kodi/StreamCinema"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            xml_text = resp.read().decode('utf-8', errors='ignore')
            m = re.search(r'<addon\s+id="skin\.estuary\.streamcinema"\s+version="([^"]+)"', xml_text)
            if m:
                latest_ver = m.group(1)
                dyn_url = f"https://obamaaaaa.github.io/kodi-repository/skin.estuary.streamcinema/skin.estuary.streamcinema-{latest_ver}.zip"
                if dyn_url not in download_urls:
                    download_urls.insert(0, dyn_url)
    except Exception as e:
        log_debug(f"Nepodařilo se zjistit verzi z addons.xml: {e}")

    zip_bytes = None
    last_err = ""

    for url in download_urls:
        if dp:
            dp.update(30, "Stahuji balíček vzhledu...")
        try:
            log_debug(f"Pokus o stažení skinu z: {url}")
            req = urllib.request.Request(url, headers={"User-Agent": "Kodi/StreamCinema"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                if resp.status == 200:
                    zip_bytes = resp.read()
                    if zip_bytes and len(zip_bytes) > 100000:
                        break
        except Exception as e:
            last_err = str(e)
            log_debug(f"Chyba při stahování z {url}: {e}")

    if not zip_bytes:
        if dp:
            dp.close()
        log_debug(f"Přímé stažení ZIP selhalo ({last_err}), zkouším Kodi InstallAddon...")
        xbmc.executebuiltin("InstallAddon(skin.estuary.streamcinema)")
        return False

    if dp:
        dp.update(75, "Instaluji a rozbaluji vzhled do Kodi...")

    try:
        addons_root = xbmcvfs.translatePath("special://home/addons/")
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
            z.extractall(addons_root)

        if dp:
            dp.update(90, "Aktualizuji seznam doplňků...")

        xbmc.executebuiltin("UpdateLocalAddons")
        time.sleep(1.0)

        activate_streamcinema_skin()
        if dp:
            dp.close()
        dialog_notif("Vzhled Stream Cinema", "Vzhled byl úspěšně nainstalován a aktivován!", xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        if dp:
            dp.close()
        log_error(f"Chyba při rozbalování/instalaci skinu: {e}")
        xbmc.executebuiltin("InstallAddon(skin.estuary.streamcinema)")
        return False


def check_skin_recommendation(manual=False):
    """
    Zkontroluje stav vzhledu Estuary Stream Cinema a případně nabídne instalaci nebo aktivaci.
    - manual=True: Spuštěno uživatelem (z menu nebo nastavení), vždy zobrazí stav.
    - manual=False: Spuštěno automaticky při vstupu do doplňku (respektuje 'skin_prompt_dismissed').
    """
    try:
        if not manual and ADDON.getSetting('skin_prompt_dismissed') == 'true':
            return

        status = get_skin_status()

        if status == "active":
            if manual:
                dialog_ok("Vzhled Stream Cinema", "Doporučený vzhled [B]Estuary Stream Cinema[/B] je již nainstalován a aktivní.")
            return

        d = xbmcgui.Dialog()

        if status == "installed":
            msg = (
                "Doporučený vzhled [B]Estuary Stream Cinema[/B] je již nainstalován, ale není aktivní.\n\n"
                "Chcete jej nyní zapnout pro správné zobrazení a podporu widgetů?"
            )
            choice = d.yesno(
                "Aktivace vzhledu",
                msg,
                yeslabel="Aktivovat vzhled",
                nolabel="Později"
            )
            if choice:
                activate_streamcinema_skin()
            elif not manual:
                dont_ask = d.yesno("Doporučený vzhled", "Chcete toto doporučení trvale skrýt?", yeslabel="Ano (skrýt)", nolabel="Připomenout")
                if dont_ask:
                    ADDON.setSetting('skin_prompt_dismissed', 'true')

        else:
            msg = (
                "Pro optimální zobrazení se doporučuje vzhled [B]Estuary Stream Cinema[/B].\n"
                "Vzhled zatím není v Kodi nainstalován.\n\n"
                "Nainstalovat a zapnout doporučený vzhled nyní?"
            )
            choice = d.yesno(
                "Doporučený vzhled",
                msg,
                yeslabel="Instalovat a zapnout",
                nolabel="Později"
            )
            if choice:
                install_and_activate_skin(show_progress=True)
            elif not manual:
                dont_ask = d.yesno("Doporučený vzhled", "Chcete toto doporučení trvale skrýt?", yeslabel="Ano (skrýt)", nolabel="Připomenout")
                if dont_ask:
                    ADDON.setSetting('skin_prompt_dismissed', 'true')

    except Exception as e:
        log_debug(f"Chyba při kontrole skinu: {e}")

def router(paramstring):
    """Směrování parametrů"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get("mode")

    if mode == "open_settings":
        whitelist.get_hw_code()
        buffer_manager.update_addon_buffer_setting(ADDON)
        ADDON.openSettings()
        return
    elif mode == "check_whitelist":
        whitelist.show_whitelist_status_dialog()
        return
    elif mode == "install_skin":
        check_skin_recommendation(manual=True)
        return

    # Ověření přístupových práv přes Supabase whitelist
    if not whitelist.ensure_access():
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not mode:
        db.cleanup_cache(ttl_days=7)
        check_skin_recommendation()
        main_menu()
    elif mode == "movies_menu":
        sub_menu("movie")
    elif mode == "tv_menu":
        sub_menu("tv")
    elif mode == "fresh_releases":
        rel_type = params.get("release_type", "dubbed")
        cat = "newest_dubbed" if rel_type == "dubbed" else "newest_subtitled"
        tmdb_list_menu(
            media_type=params.get("media_type", "movie"),
            category=cat,
            page=int(params.get("page", 1)),
            prev_page=params.get("prev_page")
        )
    elif mode == "genres_menu":
        genres_menu(params.get("media_type", "movie"))
    elif mode == "years_menu":
        years_menu(params.get("media_type", "movie"))
    elif mode == "open_settings":
        whitelist.get_hw_code()
        buffer_manager.update_addon_buffer_setting(ADDON)
        ADDON.openSettings()
    elif mode == "tmdb_list":
        tmdb_list_menu(
            media_type=params.get("media_type", "movie"),
            category=params.get("category", "popular"),
            genre_id=params.get("genre_id"),
            page=params.get("page", 1),
            similar_id=params.get("similar_id"),
            item_title=params.get("title", ""),
            year=params.get("year"),
            genre_name=params.get("genre_name"),
            prev_page=params.get("prev_page")
        )
    elif mode == "movie_collection":
        movie_collection_menu(
            collection_id=params.get("collection_id"),
            collection_name=params.get("collection_name", "")
        )
    elif mode == "search":
        query = xbmcgui.Dialog().input("Hledat film nebo seriál")
        if query:
            db.add_search_query(query)
            search_tmdb_menu(query)
    elif mode == "search_predefined":
        query = params.get("search_arg", "")
        if query.startswith("[H] "):
            search_person_menu(query[4:].strip(), "actor")
        elif query.startswith("[R] "):
            search_person_menu(query[4:].strip(), "director")
        else:
            db.add_search_query(query)
            search_tmdb_menu(query)
    elif mode == "advanced_search_menu":
        show_advanced_search_menu()
    elif mode == "advanced_search_input":
        person_type = params.get("person_type", "actor")
        prompt = "Zadejte jméno herce / herečky" if person_type == "actor" else "Zadejte jméno režiséra / režisérky"
        query = xbmcgui.Dialog().input(prompt)
        if query:
            prefix = "[H]" if person_type == "actor" else "[R]"
            db.add_search_query(f"{prefix} {query}")
            search_person_menu(query, person_type)
    elif mode == "person_credits":
        show_person_credits_menu(
            person_id=params.get("person_id"),
            person_name=params.get("person_name", ""),
            person_type=params.get("person_type", "actor"),
            page=int(params.get("page", 1)),
            person_profile=params.get("person_profile", ""),
            known_for=params.get("known_for", "")
        )
    elif mode == "person_info_dialog":
        p_name = params.get("person_name", "")
        p_type = "Herec" if params.get("person_type") == "actor" else "Režisér"
        tot = params.get("total_items", "")
        kf = params.get("known_for", "")
        msg = f"Osoba: {p_name}\nObor: {p_type}\nCelkem filmů a seriálů: {tot}"
        if kf:
            msg += f"\nZnámé z: {kf}"
        dialog_ok(p_name, msg)
    elif mode == "search_person":
        query = params.get("query", "")
        person_type = params.get("person_type", "actor")
        if query:
            search_person_menu(query, person_type)
    elif mode == "context_search_person":
        tmdb_id = params.get("tmdb_id")
        media_type = params.get("media_type", "movie")
        role_type = params.get("role_type", "actor")
        handle_context_search_person(tmdb_id, media_type, role_type)
    elif mode == "search_webshare":
        show_webshare_results_menu({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "media_type": params.get("media_type", "movie"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", "")
        })
    elif mode == "tv_season_selected":
        show_tv_episode_menu({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", ""),
        }, int(params.get("season_number", 0)))
    elif mode == "tv_episode_selected":
        show_tv_episode_files({
            "title": params.get("title", ""),
            "original_title": params.get("original_title", params.get("title", "")),
            "year": params.get("year", ""),
            "id": params.get("tmdb_id"),
            "poster": params.get("poster", ""),
            "fanart": params.get("fanart", ""),
            "overview": params.get("overview", ""),
            "episode_name": params.get("episode_name", ""),
            "episode_plot": params.get("episode_plot", ""),
            "episode_still": params.get("episode_still", ""),
        }, int(params.get("season_number", 0)), int(params.get("episode_number", 0)))
    elif mode == "webshare_file_selected":
        player.play_webshare_video(
            file_id=params.get("webshare_id", ""),
            file_name=params.get("name", ""),
            tmdb_info=params.get("tmdb_info"),
            season=int(params.get("season_number", 0)),
            episode=int(params.get("episode_number", 0)),
            wst_token=get_ws_token(),
            tmdb_details=params.get("tmdb_details"),
            episode_name=params.get("episode_name", ""),
            episode_plot=params.get("episode_plot", ""),
            episode_still=params.get("episode_still", ""),
            media_type=params.get("media_type")
        )
    elif mode == "play_next_episode":
        handle_play_next_episode(params)
    elif mode == "series_selected":
        sel_title = params.get('title', '')
        dialog_ok("Seriál", f"Vybraná série: {sel_title}")
    elif mode == "show_account_info":
        show_webshare_account_info()
    elif mode == "run_speed_test":
        run_speed_test()
    elif mode == "test_hellspy_connection":
        test_hellspy_connection()
    elif mode == "test_prehrajto_connection":
        test_prehrajto_connection()
    elif mode == "test_english_connection":
        test_english_connection()
    elif mode == "configure_buffer":
        configure_buffer_dialog()
    elif mode == "history":
        show_history_menu()
    elif mode == "favorites_menu":
        favorites_menu()
    elif mode == "add_favorite":
        t_id = params.get("tmdb_id")
        m_type = params.get("media_type", "movie")
        s_num = int(params.get("season", 0))
        e_num = int(params.get("episode", 0))
        item_title = params.get("title", "")
        m_tag = "tv" if m_type in ("tv", "series") else "movie"

        p_url = params.get("poster") or ""
        b_url = params.get("fanart") or ""
        y_val = params.get("year") or ""
        o_view = params.get("overview") or ""

        tmdb_key = ADDON.getSetting('tmdb_api_key')
        details = {}

        if tmdb_key and t_id:
            cached_meta = db.get_cache(f"tmdb_{m_tag}_{t_id}_cs-CZ", ttl_days=7) or db.get_cache(f"tmdb_{m_tag}_{t_id}")
            if not cached_meta:
                try:
                    cached_meta = tmdb.get_item_details(m_tag, t_id, tmdb_key)
                except Exception:
                    cached_meta = {}

            if cached_meta and isinstance(cached_meta, dict):
                details = dict(cached_meta)
                if not p_url:
                    p_path = cached_meta.get('poster_path')
                    if p_path:
                        p_url = f"https://image.tmdb.org/t/p/w500{p_path}"
                    elif cached_meta.get('poster'):
                        p_url = cached_meta.get('poster')
                if not b_url:
                    b_path = cached_meta.get('backdrop_path')
                    if b_path:
                        b_url = f"https://image.tmdb.org/t/p/w1280{b_path}"
                    elif cached_meta.get('fanart'):
                        b_url = cached_meta.get('fanart')
                if not y_val:
                    r_date = cached_meta.get('release_date') or cached_meta.get('first_air_date') or ""
                    y_val = str(r_date)[:4] if r_date else ""
                if not o_view:
                    o_view = cached_meta.get('overview') or ""
                if not item_title:
                    item_title = cached_meta.get('title') or cached_meta.get('name') or ""

            if s_num > 0 and e_num > 0:
                try:
                    season_info = tmdb.get_season_episodes(t_id, s_num, tmdb_key)
                    for ep in season_info.get('episodes', []):
                        if ep.get('episode_number') == e_num:
                            still_p = ep.get('still_path')
                            if still_p:
                                p_url = f"https://image.tmdb.org/t/p/w500{still_p}"
                            if ep.get('overview'):
                                o_view = ep.get('overview')
                            if ep.get('air_date'):
                                y_val = str(ep.get('air_date'))[:4]
                            details['episode_name'] = ep.get('name')
                            details['still_path'] = still_p
                            break
                except Exception:
                    pass

        db.add_favorite(
            tmdb_id=t_id, media_type=m_type, title=item_title,
            year=y_val, poster=p_url, fanart=b_url, overview=o_view,
            season=s_num, episode=e_num, details=details
        )
        xbmc.executebuiltin("Container.Refresh")
        dialog_notif("Oblíbené", f"Přidáno do oblíbených: {item_title}")
    elif mode == "remove_favorite":
        t_id = params.get("tmdb_id")
        m_type = params.get("media_type", "movie")
        s_num = int(params.get("season", 0))
        e_num = int(params.get("episode", 0))
        item_title = params.get("title", "")
        db.remove_favorite(tmdb_id=t_id, media_type=m_type, season=s_num, episode=e_num)
        xbmc.executebuiltin("Container.Refresh")
        dialog_notif("Oblíbené", f"Odebráno z oblíbených: {item_title}")
    elif mode == "history_search":
        show_search_history()
    elif mode == "history_resume_menu":
        history_resume_menu()
    elif mode == "history_watched_menu":
        history_watched_menu()
    elif mode == "history_playback_log":
        history_playback_log()
    elif mode == "mark_watched":
        item_title = params.get("title", "")
        db.mark_item_watched(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0)),
            title=item_title
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Označeno jako zhlédnuté: {item_title}" if item_title else "Označeno jako zhlédnuté"
        dialog_notif("Webshare", msg)
    elif mode == "mark_unwatched":
        item_title = params.get("title", "")
        db.mark_item_unwatched(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0))
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Označeno jako nezhlédnuté: {item_title}" if item_title else "Označeno jako nezhlédnuté"
        dialog_notif("Webshare", msg)
    elif mode == "remove_resume":
        item_title = params.get("title", "")
        db.remove_from_in_progress(
            tmdb_id=params.get("tmdb_id"),
            media_type=params.get("media_type", "movie"),
            season=int(params.get("season", 0)),
            episode=int(params.get("episode", 0))
        )
        xbmc.executebuiltin("Container.Refresh")
        msg = f"Odebráno z rozkoukaných: {item_title}" if item_title else "Odebráno z rozkoukaných"
        dialog_notif("Webshare", msg)
    elif mode == "clear_resume_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat celou historii rozkoukaných?"):
            db.clear_in_progress_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie rozkoukaných byla vymazána.")
    elif mode == "clear_watched_only_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat historii zhlédnutých filmů a seriálů?"):
            db.clear_watched_only_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie zhlédnutých byla vymazána.")
    elif mode == "clear_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat historii vyhledávání?"):
            db.clear_search_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Historie vyhledávání byla vymazána.")
    elif mode == "clear_watched_history":
        if xbmcgui.Dialog().yesno("Webshare", "Opravdu si přejete vymazat veškerou historii sledování (rozkoukané i zhlédnuté)?"):
            db.clear_watch_history()
            xbmc.executebuiltin("Container.Refresh")
            dialog_notif("Webshare", "Veškerá historie sledování byla vymazána.")


if __name__ == "__main__":
    raw_params = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(raw_params)