from concurrent.futures import ThreadPoolExecutor

import re
import requests
import xbmc
from . import db
from .title_cleaner import clean_title_for_kodi, has_unrenderable_chars, transliterate_all
try:
    from main import log_debug
except ImportError:
    def log_debug(msg):
        xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)
        
TMDB_BASE_URL = "https://api.themoviedb.org/3"
IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

GENRE_TRANSLATIONS = {
    # TMDB Genre IDs
    878: "Sci-Fi",
    10759: "Akční a dobrodružný",
    10762: "Pro děti",
    10763: "Zpravodajský",
    10764: "Reality show",
    10765: "Sci-Fi a Fantasy",
    10766: "Telenovely",
    10767: "Talk show",
    10768: "Válečný a politický",

    # Textové názvy
    "vědeckofantastický": "Sci-Fi",
    "vedeckofantasticky": "Sci-Fi",
    "science fiction": "Sci-Fi",
    "sci-fi": "Sci-Fi",
    "action & adventure": "Akční a dobrodružný",
    "actions & adventure": "Akční a dobrodružný",
    "action and adventure": "Akční a dobrodružný",
    "kids": "Pro děti",
    "news": "Zpravodajský",
    "reality": "Reality show",
    "sci-fi & fantasy": "Sci-Fi a Fantasy",
    "soap": "Telenovely",
    "talk": "Talk show",
    "war & politics": "Válečný a politický",
}

def translate_genre(genre_id=None, name=""):
    """Převede název žánru / ID na srozumitelný český tvar (např. Sci-Fi místo Vědeckofantastický)."""
    if genre_id is not None:
        try:
            gid = int(genre_id)
            if gid in GENRE_TRANSLATIONS:
                return GENRE_TRANSLATIONS[gid]
        except (ValueError, TypeError):
            pass

    if name:
        clean = str(name).strip()
        lower = clean.lower()
        if lower in GENRE_TRANSLATIONS:
            return GENRE_TRANSLATIONS[lower]
        return clean

    return ""

def get_item_details(media_type, tmdb_id, api_key):
    """Načte podrobné informace s využitím modulu db.py"""
    url = f"{TMDB_BASE_URL}/{media_type}/{tmdb_id}"
    params = {
        'api_key': api_key,
        'language': 'cs-CZ',
        'append_to_response': 'credits,translations'
    }
    
    # 1. Čistý klíč nezávislý na API klíči (např. "tmdb_movie_634649_cs-CZ")
    cache_key = f"tmdb_{media_type}_{tmdb_id}_cs-CZ"

    cached_data = db.get_cache(cache_key, ttl_days=7)
    if cached_data is not None:
        return cached_data

    try:
        r = requests.get(url, params=params, timeout=5)
        if r.status_code == 200:
            data = r.json()
            if not data.get('overview'):
                translations = data.get('translations', {}).get('translations', [])
                for t in translations:
                    if t.get('iso_639_1') == 'en':
                        t_data = t.get('data', {})
                        t_overview = t_data.get('overview', '')
                        if t_overview:
                            data['overview'] = t_overview
                            break
            if not data.get('tagline'):
                translations = data.get('translations', {}).get('translations', [])
                for t in translations:
                    if t.get('iso_639_1') == 'en':
                        t_data = t.get('data', {})
                        t_tagline = t_data.get('tagline', '')
                        if t_tagline:
                            data['tagline'] = t_tagline
                            break
            db.set_cache(cache_key, data)
            return data
    except Exception as e:
        log_debug(f"Chyba při načítání detailu ID {tmdb_id}: {e}")

    return {}

def _process_tmdb_item(item, media_type, api_key):
    # OK
    """Pomocná funkce pro paralelní zpracování jedné položky."""
    tmdb_id = item.get('id')
    details = get_item_details(media_type, tmdb_id, api_key)
    
    raw_title = item.get('title') or item.get('name', 'Neznámý název')
    raw_original_title = item.get('original_title') or item.get('original_name', '')
    release_date = item.get('release_date') or item.get('first_air_date', '')
    year = release_date[:4] if release_date else 'N/A'

    # Získání anglického názvu z translations pro spolehlivý překlad asijských/cizojazyčných děl
    english_title = ""
    translations = details.get('translations', {}).get('translations', [])
    for t in translations:
        if t.get('iso_639_1') == 'en':
            t_data = t.get('data', {})
            english_title = t_data.get('title') or t_data.get('name') or ''
            if english_title:
                break

    if not english_title and item.get('original_language') == 'en':
        english_title = raw_original_title

    # Ošetření názvů: pokud obsahují znaky (Hangul/CJK), které Kodi zobrazuje jako obdélníky,
    # použijeme anglický název nebo provedeme romanizaci (např. '아씨마님' -> 'Assimanim').
    clean_title = clean_title_for_kodi(
        raw_title,
        english_title=english_title,
        original_title=raw_original_title,
        year=year,
        media_type=media_type
    )

    clean_orig_title = clean_title_for_kodi(
        raw_original_title,
        english_title=english_title,
        original_title=raw_original_title,
        year=year,
        media_type=media_type
    )

    runtime = details.get('runtime') if media_type == 'movie' else (
        details.get('episode_run_time', [0])[0] if details.get('episode_run_time') else 0
    )
    
    genres = [translate_genre(genre_id=g.get('id'), name=g.get('name')) for g in details.get('genres', [])]
    
    credits = details.get('credits', {})
    cast = []
    for actor in credits.get('cast', [])[:20]:
        p_path = actor.get('profile_path')
        cast.append({
            'name': actor.get('name'),
            'role': actor.get('character', ''),
            'thumbnail': (IMAGE_BASE_URL + "w185" + str(p_path)) if p_path else ''
        })
    
    directors = [crew['name'] for crew in credits.get('crew', []) if crew.get('job') in ('Director', 'Creator')]
    if not directors and details.get('created_by'):
        directors = [c.get('name') for c in details.get('created_by', []) if c.get('name')]

    poster_path = item.get('poster_path')
    backdrop_path = item.get('backdrop_path')
    
    parsed_item = {
        'id': tmdb_id,
        'title': clean_title,
        'original_title': clean_orig_title,
        'raw_title': raw_title,
        'raw_original_title': raw_original_title,
        'english_title': english_title,
        'year': year,
        'release_date': release_date,
        'rating': round(item.get('vote_average', 0), 1),
        'overview': item.get('overview') or details.get('overview', ''),
        'tagline': details.get('tagline', ''),
        'runtime': runtime or 0,
        'genres': genres,
        'cast': cast,
        'directors': directors,
        'poster': f"{IMAGE_BASE_URL}w500{poster_path}" if poster_path else '',
        'fanart': f"{IMAGE_BASE_URL}w1280{backdrop_path}" if backdrop_path else '',
        'number_of_seasons': details.get('number_of_seasons') or 0,
        'number_of_episodes': details.get('number_of_episodes') or 0
    }
    
    # Pro search potřebujeme vědět, zda jde o movie nebo tv
    if 'media_type' in item:
        parsed_item['media_type'] = item['media_type']
    else:
        parsed_item['media_type'] = media_type

    return parsed_item

def get_season_details(series_id, season_number, api_key):
    """Načte detail jedné sezóny seriálu z TMDB s mezipamětí a fallbackem na EN pro chybějící popisky/názvy."""
    cache_key = f"tmdb_tv_{series_id}_season_{season_number}_v2"
    cached = db.get_cache(cache_key, ttl_days=7)
    if cached is not None:
        return cached

    url = f"{TMDB_BASE_URL}/tv/{series_id}/season/{season_number}"
    params = {
        'api_key': api_key,
        'language': 'cs-CZ',
    }
    data_cs = {}
    try:
        r = requests.get(url, params=params, timeout=5)
        if r.status_code == 200:
            data_cs = r.json()
    except Exception as e:
        xbmc.log(f"[TMDB] Chyba při načítání sezóny {season_number} pro seriál {series_id}: {e}", xbmc.LOGINFO)

    if not data_cs:
        return {}

    episodes = data_cs.get('episodes') or []
    need_en = False
    if not data_cs.get('overview'):
        need_en = True
    else:
        for ep in episodes:
            ep_name = ep.get('name', '').strip().lower()
            ep_num = ep.get('episode_number', 0)
            if not ep.get('overview') or not ep_name or ep_name in (f"epizoda {ep_num}", f"díl {ep_num}", f"episode {ep_num}"):
                need_en = True
                break

    if need_en:
        try:
            params_en = {'api_key': api_key, 'language': 'en-US'}
            r_en = requests.get(url, params=params_en, timeout=5)
            if r_en.status_code == 200:
                data_en = r_en.json()
                if not data_cs.get('overview') and data_en.get('overview'):
                    data_cs['overview'] = data_en.get('overview')
                en_eps = {ep.get('episode_number'): ep for ep in data_en.get('episodes', [])}
                for ep in episodes:
                    ep_num = ep.get('episode_number', 0)
                    en_ep = en_eps.get(ep_num)
                    if en_ep:
                        if not ep.get('overview') and en_ep.get('overview'):
                            ep['overview'] = en_ep.get('overview')
                        ep_name = ep.get('name', '').strip()
                        if (not ep_name or ep_name.lower() in (f"epizoda {ep_num}", f"díl {ep_num}", f"episode {ep_num}")) and en_ep.get('name'):
                            ep['name'] = en_ep.get('name')
        except Exception as e:
            xbmc.log(f"[TMDB] Chyba při načítání EN fallbacku pro sezónu {season_number}: {e}", xbmc.LOGINFO)

    db.set_cache(cache_key, data_cs)
    return data_cs


def get_tv_seasons(series_id, api_key):
    """Vrátí seznam sezón pro seriál včetně osnovních metadat bleskově přímo z detailů seriálu."""
    details = get_item_details('tv', series_id, api_key)
    raw_seasons = details.get('seasons') or []
    seasons = []
    series_overview = details.get('overview', '')

    if raw_seasons:
        for s in raw_seasons:
            season_number = s.get('season_number', 0)
            poster_path = s.get('poster_path')
            poster = f"{IMAGE_BASE_URL}w500{poster_path}" if poster_path else ''
            default_name = "Speciály" if season_number == 0 else f"Sezóna {season_number}"
            overview = s.get('overview', '') or series_overview
            seasons.append({
                'season_number': season_number,
                'name': s.get('name') or default_name,
                'overview': overview,
                'air_date': s.get('air_date', ''),
                'episode_count': s.get('episode_count') or 0,
                'poster': poster,
                'episodes': [],
            })
    else:
        season_count = details.get('number_of_seasons') or 0
        for season_number in range(1, season_count + 1):
            seasons.append({
                'season_number': season_number,
                'name': f"Sezóna {season_number}",
                'overview': series_overview,
                'air_date': '',
                'episode_count': 0,
                'poster': '',
                'episodes': [],
            })

    # Seřadit tak, aby sezóna 0 byla na začátku (nebo podle season_number)
    seasons.sort(key=lambda x: x.get('season_number', 0))
    return seasons


def fetch_tmdb_items(media_type, category, api_key, genre_id=None, page=1, similar_id=None, year=None, count=30):
    if category == "popular":
        url = f"{TMDB_BASE_URL}/{media_type}/popular"
        params = {'api_key': api_key, 'language': 'cs-CZ'}
    elif category == "trending":
        url = f"{TMDB_BASE_URL}/trending/{media_type}/week"
        params = {'api_key': api_key, 'language': 'cs-CZ'}
    elif category == "top_rated":
        url = f"{TMDB_BASE_URL}/{media_type}/top_rated"
        params = {'api_key': api_key, 'language': 'cs-CZ'}
    elif category == "new":
        endpoint = "now_playing" if media_type == "movie" else "on_the_air"
        url = f"{TMDB_BASE_URL}/{media_type}/{endpoint}"
        params = {'api_key': api_key, 'language': 'cs-CZ'}
    elif category == "genre":
        url = f"{TMDB_BASE_URL}/discover/{media_type}"
        params = {'api_key': api_key, 'language': 'cs-CZ', 'with_genres': genre_id}
    elif category == "year":
        url = f"{TMDB_BASE_URL}/discover/{media_type}"
        if media_type == "movie":
            params = {'api_key': api_key, 'language': 'cs-CZ', 'primary_release_year': year, 'sort_by': 'popularity.desc'}
        else:
            params = {'api_key': api_key, 'language': 'cs-CZ', 'first_air_date_year': year, 'sort_by': 'popularity.desc'}
    elif category == "similar":
        if not similar_id:
            return []
        url = f"{TMDB_BASE_URL}/{media_type}/{similar_id}/recommendations"
        params = {'api_key': api_key, 'language': 'cs-CZ'}
    else:
        return []
        
    try:
        results = []
        if category == "similar":
            p_params = dict(params)
            p_params['page'] = page
            r = requests.get(url, params=p_params, timeout=10)
            if r.status_code == 200:
                results = r.json().get('results', [])
            # Fallback pro 'similar': pokud recommendations nic nevrátí, zkusit endpoint /similar
            if not results and int(page) == 1:
                try:
                    url_fallback = f"{TMDB_BASE_URL}/{media_type}/{similar_id}/similar"
                    r_fb = requests.get(url_fallback, params=p_params, timeout=10)
                    if r_fb.status_code == 200:
                        results = r_fb.json().get('results', [])
                except Exception as e_fb:
                    log_debug(f"Chyba při fallbacku na similar pro {similar_id}: {e_fb}")
        else:
            start_idx = (int(page) - 1) * count
            end_idx = start_idx + count
            p_start = (start_idx // 20) + 1
            p_end = ((end_idx - 1) // 20) + 1

            def _fetch_page(p_num):
                p_params = dict(params)
                p_params['page'] = p_num
                try:
                    res = requests.get(url, params=p_params, timeout=8)
                    if res.status_code == 200:
                        return p_num, res.json().get('results', [])
                except Exception as e:
                    log_debug(f"Chyba při dotazu na TMDB str. {p_num}: {e}")
                return p_num, []

            pages_to_fetch = list(range(p_start, p_end + 1))
            page_results = {}
            with ThreadPoolExecutor(max_workers=len(pages_to_fetch)) as p_exec:
                for p_num, r_list in p_exec.map(_fetch_page, pages_to_fetch):
                    page_results[p_num] = r_list

            combined = []
            for p_num in pages_to_fetch:
                combined.extend(page_results.get(p_num, []))

            offset = start_idx - (p_start - 1) * 20
            results = combined[offset : offset + count]
        
        # Paralelní načtení detailů pro všechny položky najednou
        items = []
        with ThreadPoolExecutor(max_workers=min(15, max(1, len(results)))) as executor:
            futures = [
                executor.submit(_process_tmdb_item, item, media_type, api_key)
                for item in results
            ]
            for future in futures:
                items.append(future.result())

        return items
    except Exception as e:
        log_debug(f"Chyba při komunikaci s TMDB: {e}")
        return []
    
def search_tmdb_items(query, api_key, page=1):
    if not query:
        return []

    # Očištění dotazu od přípon typu (s), [s], (f), [f], (seriál), (film) pro API dotaz
    clean_query = re.sub(r'[\(\[\{]\s*(?:s|f|seri[aá]l|film)\s*[\)\]\}]', '', query, flags=re.I).strip()
    if not clean_query:
        clean_query = query.strip()

    wants_tv = bool(re.search(r'[\(\[\{]\s*(?:s|seri[aá]l)\s*[\)\]\}]', query, re.I))
    wants_movie = bool(re.search(r'[\(\[\{]\s*(?:f|film)\s*[\)\]\}]', query, re.I))

    # Pořadí dotazování: pokud uživatel zadal (s), prohledáváme nejprve seriály
    if wants_tv:
        media_types = ("tv", "movie")
    elif wants_movie:
        media_types = ("movie", "tv")
    else:
        media_types = ("tv", "movie")

    all_items = []
    for media_type in media_types:
        url = f"{TMDB_BASE_URL}/search/{media_type}"
        params = {
            'api_key': api_key,
            'language': 'cs-CZ',
            'query': clean_query,
            'page': page
        }
        try:
            r = requests.get(url, params=params, timeout=10)
            r.raise_for_status()
            results = r.json().get('results', [])

            # Paralelní načtení detailů pro vyhledané položky
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = [
                    executor.submit(_process_tmdb_item, item, media_type, api_key)
                    for item in results
                ]
                for future in futures:
                    all_items.append(future.result())

        except Exception as e:
            log_debug(f"Chyba při vyhledávání v TMDB pro typ {media_type}: {e}")

    return all_items


def search_tmdb_person(query, api_key):
    """Vyhledá osoby (herce, režiséry) na TMDB."""
    if not query:
        return []
    url = f"{TMDB_BASE_URL}/search/person"
    params = {
        'api_key': api_key,
        'query': query,
        'language': 'cs-CZ',
    }
    try:
        r = requests.get(url, params=params, timeout=8)
        if r.status_code == 200:
            data = r.json()
            results = []
            for p in data.get('results', []):
                profile_path = p.get('profile_path')
                known_for = [k.get('title') or k.get('name') for k in p.get('known_for', []) if (k.get('title') or k.get('name'))]
                results.append({
                    'id': p.get('id'),
                    'name': p.get('name', ''),
                    'known_for_department': p.get('known_for_department', ''),
                    'profile': f"{IMAGE_BASE_URL}w300{profile_path}" if profile_path else '',
                    'known_for_str': ", ".join(known_for[:3]) if known_for else ''
                })
            return results
    except Exception as e:
        log_debug(f"Chyba při hledání osoby '{query}': {e}")
    return []


def get_person_movie_credits(person_id, person_type, api_key):
    """
    Načte kompletní filmografii (filmy a seriály) dané osoby z TMDB (combined_credits), seřazenou od nejnovějších po nejstarší.
    Pro herce (actor) vrátí položky s rolí (character).
    Pro režiséra (director) vrátí režírované položky.
    """
    cache_key = f"tmdb_person_{person_id}_combined_credits"
    cached = db.get_cache(cache_key, ttl_days=3)
    if cached is not None:
        data = cached
    else:
        url = f"{TMDB_BASE_URL}/person/{person_id}/combined_credits"
        params = {
            'api_key': api_key,
            'language': 'cs-CZ',
        }
        try:
            r = requests.get(url, params=params, timeout=10)
            if r.status_code == 200:
                data = r.json()
                db.set_cache(cache_key, data)
            else:
                data = {}
        except Exception as e:
            log_debug(f"Chyba při načítání kreditů osoby ID {person_id}: {e}")
            data = {}

    if not data:
        return []

    if person_type == 'director':
        raw_items = [c for c in data.get('crew', []) if c.get('job') == 'Director']
    else:
        raw_items = data.get('cast', [])

    items_map = {}
    for m in raw_items:
        m_id = m.get('id')
        if not m_id:
            continue

        item_media_type = m.get('media_type', 'movie')
        if item_media_type not in ('movie', 'tv'):
            continue

        unique_key = f"{item_media_type}_{m_id}"
        char = (m.get('character') or '').strip()
        job = (m.get('job') or '').strip()

        if unique_key in items_map:
            if char and char not in items_map[unique_key].get('character', ''):
                existing_char = items_map[unique_key].get('character', '')
                new_char = f"{existing_char}, {char}" if existing_char else char
                items_map[unique_key]['character'] = new_char
                if person_type == 'actor':
                    items_map[unique_key]['role_display'] = f"Role: {new_char}"
            continue

        if item_media_type == 'tv':
            raw_title = m.get('name') or m.get('original_name') or 'Neznámý seriál'
            raw_orig_title = m.get('original_name') or raw_title
            rel_date = m.get('first_air_date') or ''
        else:
            raw_title = m.get('title') or m.get('original_title') or 'Neznámý film'
            raw_orig_title = m.get('original_title') or raw_title
            rel_date = m.get('release_date') or ''

        year = rel_date[:4] if rel_date else ''
        poster_path = m.get('poster_path')
        backdrop_path = m.get('backdrop_path')

        clean_title = clean_title_for_kodi(raw_title, original_title=raw_orig_title, year=year, media_type=item_media_type)
        clean_orig = clean_title_for_kodi(raw_orig_title, original_title=raw_orig_title, year=year, media_type=item_media_type)

        role_display = f"Role: {char}" if (person_type == 'actor' and char) else ("Režie" if person_type == 'director' else "")

        poster_url = (IMAGE_BASE_URL + "w500" + str(poster_path)) if poster_path else ''
        fanart_url = (IMAGE_BASE_URL + "w1280" + str(backdrop_path)) if backdrop_path else ''

        items_map[unique_key] = {
            'id': m_id,
            'title': clean_title,
            'original_title': clean_orig,
            'raw_title': raw_title,
            'raw_original_title': raw_orig_title,
            'english_title': '',
            'year': year,
            'release_date': rel_date,
            'rating': round(m.get('vote_average', 0), 1),
            'overview': m.get('overview', ''),
            'tagline': '',
            'runtime': 0,
            'genres': [],
            'cast': [{'name': m.get('name', ''), 'role': char, 'thumbnail': ''}] if char else [],
            'directors': [m.get('name', '')] if person_type == 'director' else [],
            'poster': poster_url,
            'fanart': fanart_url,
            'media_type': item_media_type,
            'character': char,
            'job': job,
            'role_display': role_display,
        }

    item_list = list(items_map.values())
    item_list.sort(key=lambda x: x.get('release_date') or '0000-00-00', reverse=True)
    return item_list