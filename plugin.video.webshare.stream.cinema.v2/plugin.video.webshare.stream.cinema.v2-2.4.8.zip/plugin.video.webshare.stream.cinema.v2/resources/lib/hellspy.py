import json
import re
import urllib.parse
import urllib.request
import xbmc
from resources.lib import webshare

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

def log_debug(msg):
    try:
        from main import log_debug as _log
        _log(msg)
    except Exception:
        xbmc.log("[HellSpy] " + str(msg), xbmc.LOGINFO)

def search_hellspy_raw(query, limit=40, timeout=5):
    """
    Vyhledá videa na Hellspy.to pomocí zadaného dotazu.
    Vrací seznam slovníků:
    [{'id': 6594255, 'fileHash': '...', 'title': '...', 'size': 1234567, 'duration': 1348}]
    """
    if not query:
        return []

    encoded_query = urllib.parse.quote_plus(str(query).strip())
    url = "https://hellspy.to/?query=" + encoded_query

    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "cs,sk,en;q=0.9",
        "Referer": "https://hellspy.to/"
    })

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            html = response.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as he:
        if he.code == 429:
            log_debug(f"Hellspy 429 (Too Many Requests) u dotazu '{query}'")
        else:
            log_debug(f"Chyba při vyhledávání na Hellspy ({query}): HTTP {he.code}")
        return []
    except Exception as e:
        log_debug("Chyba při vyhledávání na Hellspy: " + str(e))
        return []

    # V Next.js SSR HTML vyhledáme objekty typu GWSearchVideo
    pattern = r'\{[^{}]*?\\?"objectType\\?":\s*\\?"GWSearchVideo\\?"[^{}]*?\}'
    matches = re.findall(pattern, html)
    if not matches:
        return []

    results = []
    seen_ids = set()

    for m in matches:
        clean = m.replace('\\"', '"').replace(r'\u0026', '&')
        try:
            data = json.loads(clean)
            v_id = data.get('id')
            v_hash = data.get('fileHash')
            title = data.get('title')
            if v_id and v_hash and title and v_id not in seen_ids:
                seen_ids.add(v_id)
                results.append({
                    'id': v_id,
                    'fileHash': v_hash,
                    'title': title,
                    'size': int(data.get('size', 0)),
                    'duration': data.get('duration', 0)
                })
                if len(results) >= limit:
                    break
        except Exception:
            continue

    return results

def get_hellspy_download_url(video_id, file_hash, timeout=5.0):
    """
    Získá přímý odkaz na originální plný soubor z oficiálního download endpointu Hellspy:
    https://api.hellspy.to/gw/video/{video_id}/{file_hash}/download
    Tento endpoint vrací 302 přesměrování přímo na CDN onecdn1.net, kde je soubor
    v plné kvalitě (MKV/MP4, původní zvukové stopy i titulky), a netrpí na chybu 401.
    """
    if not video_id or not file_hash:
        return None

    dl_url = f"https://api.hellspy.to/gw/video/{video_id}/{file_hash}/download"

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None

    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(dl_url, headers={
        "User-Agent": USER_AGENT,
        "Referer": "https://hellspy.to/"
    })

    try:
        opener.open(req, timeout=timeout)
        return dl_url
    except urllib.error.HTTPError as he:
        if he.code in (301, 302, 303, 307):
            loc = he.headers.get("Location")
            if loc:
                log_debug(f"Hellspy download redirect získán: {loc[:70]}...")
                return loc
    except Exception as e:
        log_debug(f"Chyba při volání Hellspy download endpointu: {e}")

    return None

def get_hellspy_direct_url(file_hash, video_id, timeout=8.0, verify_stream=True):
    """
    Získá přímý streamovací odkaz z Hellspy.to pro daný fileHash a video ID.
    Nejprve zkusí oficiální download endpoint (přímý CDN odkaz na plnou kvalitu bez transkódování,
    který netrpí na 401 chyby transkodéru).
    Pokud selže, použije konverze z webového přehrávače.
    """
    if not file_hash or not video_id:
        return None

    # Normalizace pořadí argumentů (video_id bývá čistě číslo, file_hash hex řetězec)
    v_id = str(video_id).strip()
    f_hash = str(file_hash).strip()
    if f_hash.isdigit() and not v_id.isdigit():
        v_id, f_hash = f_hash, v_id

    # 1. Priorita: Přímý originální stream přes oficiální download endpoint
    dl_url = get_hellspy_download_url(v_id, f_hash, timeout=min(timeout, 5.0))
    if dl_url:
        if not verify_stream:
            return dl_url
        try:
            req = urllib.request.Request(dl_url, headers={
                "User-Agent": USER_AGENT,
                "Range": "bytes=0-100"
            })
            with urllib.request.urlopen(req, timeout=2.5) as resp:
                if resp.status in (200, 206):
                    log_debug(f"Hellspy přímý originální stream ověřen (HTTP {resp.status}).")
                    return dl_url
        except Exception as e:
            log_debug(f"Hellspy přímý stream z download endpointu neprošel ověřením: {e}. Zkouším konverze...")

    # 2. Záloha: Konverze z Next.js detailu videa (transkódované streamy)
    url = "https://hellspy.to/video/" + str(f_hash) + "/" + str(v_id)
    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    })

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            html = response.read().decode('utf-8', errors='replace')
    except Exception as e:
        log_debug("Chyba při získávání detailu videa Hellspy: " + str(e))
        return None

    # Hledáme blok "conversions":{...}
    pattern = r'\\?"conversions\\?":\s*(\{.*?\})'
    match = re.search(pattern, html)
    if not match:
        log_debug("V odpovědi Hellspy nebyly nalezeny konverze videa.")
        return None

    raw_conv = match.group(1)
    clean_conv = raw_conv.replace('\\"', '"').replace(r'\u0026', '&')
    try:
        convs = json.loads(clean_conv)
        if not convs:
            return None

        # Priorita rozlišení - seřadíme kandidáty
        priority_keys = ["2160", "4k", "1080", "720", "480", "360"]
        ordered_candidates = []
        seen_urls = set()

        for p in priority_keys:
            for k, stream_url in convs.items():
                if p in str(k).lower() and stream_url and stream_url not in seen_urls:
                    ordered_candidates.append((k, stream_url))
                    seen_urls.add(stream_url)

        for k, stream_url in convs.items():
            if stream_url and stream_url not in seen_urls:
                ordered_candidates.append((k, stream_url))
                seen_urls.add(stream_url)

        if not ordered_candidates:
            return None

        if not verify_stream:
            return ordered_candidates[0][1]

        # Rychlý Range požadavek pro ověření dostupnosti na CDN (ochrana před 401 Unauthorized / mrtvými nodami)
        for q_label, candidate_url in ordered_candidates:
            try:
                head_req = urllib.request.Request(candidate_url, headers={
                    "User-Agent": USER_AGENT,
                    "Referer": "https://hellspy.to/",
                    "Range": "bytes=0-100"
                })
                with urllib.request.urlopen(head_req, timeout=2.0) as check_resp:
                    if check_resp.status in (200, 206, 302):
                        log_debug(f"Hellspy konverze {q_label} ověřena jako funkční (HTTP {check_resp.status}).")
                        return candidate_url
            except urllib.error.HTTPError as he:
                log_debug(f"Hellspy konverze {q_label} selhala s HTTP {he.code} ({candidate_url[:60]}...). Zkouším další...")
                continue
            except Exception as ce:
                log_debug(f"Hellspy konverze {q_label} ověření selhalo: {ce}. Zkouším další...")
                continue

        log_debug("Žádná konverze Hellspy nevrátila funkční HTTP stav (všechny vrátily chybu, např. 401).")
        return None

    except Exception as e:
        log_debug("Chyba při parsování konverzí Hellspy: " + str(e))

    return None

def search_hellspy(title_or_item, media_type='movie', season=None, episode=None, year="", limit=20):
    """
    Univerzální vyhledávač pro Hellspy (pro filmy i seriálové epizody).
    """
    queries = []
    target_titles = []
    s_int = int(season) if season is not None else None
    e_int = int(episode) if episode is not None else None
    y = str(year or (title_or_item.get('year', '') if isinstance(title_or_item, dict) else '')).strip()

    if media_type == 'tv' or (s_int is not None and e_int is not None):
        if isinstance(title_or_item, dict):
            show_title = (title_or_item.get('title') or title_or_item.get('name') or '').strip()
            title_en = (title_or_item.get('english_title') or title_or_item.get('original_title') or title_or_item.get('original_name') or '').strip()
            title_orig = (title_or_item.get('original_title') or title_or_item.get('original_name') or '').strip()
            target_titles = list(filter(None, list(dict.fromkeys([
                show_title,
                title_en,
                title_orig,
                title_or_item.get('english_title', '').strip(),
                title_or_item.get('title', '').strip(),
                title_or_item.get('name', '').strip(),
                title_or_item.get('original_title', '').strip()
            ]))))
        else:
            show_title = str(title_or_item or '').strip()
            title_en = ""
            title_orig = ""
            target_titles = [show_title] if show_title else []

        se_q = "S" + str(s_int).zfill(2) + "E" + str(e_int).zfill(2)
        alt_q = str(s_int) + "x" + str(e_int).zfill(2)
        queries = []
        if show_title:
            queries.append((show_title + " " + se_q, "CZ"))
            queries.append((show_title + " " + alt_q, "CZ"))
        if title_en and title_en != show_title:
            queries.append((title_en + " " + se_q, "EN"))
            queries.append((title_en + " " + alt_q, "EN"))
        if title_orig and title_orig != show_title and title_orig != title_en:
            queries.append((title_orig + " " + se_q, "ORIG"))
            queries.append((title_orig + " " + alt_q, "ORIG"))
    else:
        tmdb_item = title_or_item if isinstance(title_or_item, dict) else {'title': title_or_item, 'year': year}
        y = str(year or tmdb_item.get('year', '')).strip()
        title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
        title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()
        title_orig = (tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()

        target_titles = list(filter(None, list(dict.fromkeys([
            title_cz,
            title_en,
            title_orig,
            tmdb_item.get('english_title', '').strip(),
            tmdb_item.get('title', '').strip(),
            tmdb_item.get('original_title', '').strip()
        ]))))

        if title_cz:
            if y:
                queries.append((title_cz + " " + y, "CZ"))
            queries.append((title_cz, "CZ"))
        if title_en and title_en != title_cz:
            if y:
                queries.append((title_en + " " + y, "EN"))
            queries.append((title_en, "EN"))
        if title_orig and title_orig != title_cz and title_orig != title_en:
            if y:
                queries.append((title_orig + " " + y, "ORIG"))
            queries.append((title_orig, "ORIG"))

    found_files = {}
    import time
    for idx, (q_str, search_language) in enumerate(queries):
        if idx > 0:
            time.sleep(0.4)
        raw_items = search_hellspy_raw(q_str, limit=limit)
        for it in raw_items:
            key = str(it['fileHash']) + "_" + str(it['id'])
            if key not in found_files:
                it['_search_language'] = search_language
                found_files[key] = it
        if len(found_files) >= limit:
            break

    results = []
    for key, f in found_files.items():
        title = f.get('title', '').strip()
        clean_title = re.sub(r'[\s._-]+$', '', title)
        filename = clean_title if '.' in clean_title[-5:] else (clean_title + ".mp4")
        search_language = f.get('_search_language')

        valid, reason = webshare.validate_file(
            filename,
            False,
            target_titles if len(target_titles) > 1 else (target_titles[0] if target_titles else filename),
            y,
            media_type='tv' if (s_int is not None and e_int is not None) else 'movie',
            target_season=s_int,
            target_episode=e_int
        )

        lang = webshare.detect_language(filename, search_language=search_language)
        quality = webshare.detect_quality(filename)
        size_mb = round(f.get('size', 0) / (1024 * 1024), 2)

        results.append({
            'name': filename,
            'ident': key,
            'file_hash': f.get('fileHash'),
            'video_id': f.get('id'),
            'source': 'hellspy',
            'size_mb': size_mb,
            'size': f.get('size', 0),
            'valid': valid,
            'reason': reason,
            'lang': lang,
            'quality': quality,
            'duration': int(f.get('duration') or 0)
        })

    return results

def search_hellspy_movies(tmdb_item, limit=20):
    """Zpětná kompatibilita pro filmy."""
    return search_hellspy(tmdb_item, media_type='movie', limit=limit)

def search_hellspy_episodes(show_title, season_number, episode_number, year="", limit=20):
    """Zpětná kompatibilita pro seriály."""
    return search_hellspy(show_title, media_type='tv', season=season_number, episode=episode_number, year=year, limit=limit)
