import time
import datetime
import threading
import xbmc
import xbmcaddon
from resources.lib import db
from resources.lib import webshare

_current_session_id = 0
_lock = threading.Lock()

def _log(msg):
    s = str(msg).strip()
    xbmc.log(s, xbmc.LOGINFO)

def cancel():
    """Okamžitě přeruší jakoukoli probíhající kontrolu souborů na pozadí."""
    global _current_session_id
    with _lock:
        _current_session_id = time.time()

def get_item_ttl_seconds(item):
    """
    Vrátí TTL v sekundách pro kontrolu dostupnosti:
    - 10 dní pro starší tituly (rok vydání <= aktuální rok - 3)
    - 2 dny pro novinky a tituly bez známého roku
    """
    try:
        current_year = datetime.datetime.now().year
        raw_year = str(item.get('year') or item.get('release_date', '')[:4] or '').strip()
        if raw_year.isdigit():
            y = int(raw_year)
            if y > 1900 and y <= (current_year - 3):
                return 10 * 86400  # 10 dní
    except Exception:
        pass
    return 2 * 86400  # 2 dny

def start_background_check(items, media_type, ws_token=None):
    """
    Nastartuje pomalou a důkladnou kontrolu zobrazených položek na pozadí.
    Předchozí běžící úloha se okamžitě přeruší (nový session_id).
    """
    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        if addon.getSetting('bg_verify_enabled') == 'false':
            return
    except Exception:
        pass

    if not items:
        return

    global _current_session_id
    with _lock:
        session_id = time.time()
        _current_session_id = session_id

    # Extrahujeme čisté položky (pokud je předán list n-tic nebo objektů)
    clean_items = []
    for it in items:
        if isinstance(it, (tuple, list)) and len(it) > 0 and isinstance(it[0], dict):
            clean_items.append(it[0])
        elif isinstance(it, dict):
            clean_items.append(it)

    if not clean_items:
        return

    worker = threading.Thread(
        target=_worker_loop,
        args=(clean_items, media_type, ws_token, session_id),
        name=f"SC-BgVerifier-{int(session_id)}",
        daemon=True
    )
    worker.start()

def _worker_loop(items, media_type, ws_token, session_id):
    global _current_session_id

    total_items = len(items)
    planned_files = total_items * 10

    _log(f"[Background Verifier] Začíná kontrola souborů na pozadí. Celkem položek ke kontrole: {total_items} (plánováno cca {planned_files} souborů)...")

    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        hs_enabled = (addon.getSetting('source_hellspy') == 'true')
    except Exception:
        hs_enabled = False

    monitor = xbmc.Monitor()
    checked_files_total = 0
    interrupted = False

    try:
        for item in items:
            # 1. Rychlá kontrola přerušení před každým titulem
            if _current_session_id != session_id or monitor.abortRequested() or xbmc.Player().isPlaying():
                interrupted = True
                break

            tmdb_id = str(item.get('id') or '')
            if not tmdb_id:
                continue

            ttl = get_item_ttl_seconds(item)

            # Kontrola DB mezipaměti: pokud byl titul v rámci platného TTL již hloubkově ověřen, přeskočíme ho
            cached = db.get_availability_cache(media_type, tmdb_id, ttl_seconds=ttl)
            if cached and isinstance(cached, dict) and cached.get('deep_verified'):
                continue

            # Mírná pomalá pauza před Webshare (600 ms, kontrolovaná po 100 ms)
            for _ in range(6):
                if _current_session_id != session_id or monitor.abortRequested() or xbmc.Player().isPlaying():
                    interrupted = True
                    break
                time.sleep(0.1)
            if interrupted:
                break

            m_type = item.get('media_type') or media_type or 'movie'
            has_cz_audio = False

            if m_type == 'tv':
                try:
                    # Důkladná kontrola seriálu (10 souborů)
                    series_check = webshare.check_tv_series(item, token=ws_token, limit=10)
                    all_files = series_check.get('all_files', [])
                    count = len(all_files) if all_files else 10
                    checked_files_total += count

                    all_langs = series_check.get('all_langs') or []
                    if any(l in ('CZ', 'SK') for l in all_langs):
                        has_cz_audio = True

                    # Pokud není CZ dabing a HellSpy je aktivní, prohledáme velmi pomalu HellSpy
                    if not has_cz_audio and hs_enabled:
                        # Extra pomalá prodleva pro HellSpy (1.8 s), aby nehrozil rate-limit
                        for _ in range(18):
                            if _current_session_id != session_id or monitor.abortRequested() or xbmc.Player().isPlaying():
                                interrupted = True
                                break
                            time.sleep(0.1)
                        if interrupted:
                            break

                        try:
                            from resources.lib import hellspy
                            hs_files = hellspy.search_hellspy(item, media_type='tv', season=1, episode=1, limit=10)
                            checked_files_total += len(hs_files)
                            for hf in hs_files:
                                lang_h = str(hf.get('lang', '')).upper()
                                if 'CZ' in lang_h or 'SK' in lang_h:
                                    has_cz_audio = True
                                    if 'CZ' not in all_langs:
                                        all_langs.append('CZ')
                            series_check['all_langs'] = all_langs
                        except Exception:
                            pass

                    series_check['deep_verified'] = True
                    series_check['deep_timestamp'] = int(time.time())
                    db.set_availability_cache('tv', tmdb_id, series_check)
                except Exception as e:
                    _log(f"[Background Verifier] Chyba při kontrole seriálu {tmdb_id}: {e}")

            else:
                try:
                    # Důkladná kontrola filmu (10 souborů)
                    res = webshare.search_and_verify_movie(item, token=ws_token, media_type='movie', limit=10)
                    ws_files = res.get('files', []) if isinstance(res, dict) else (res or [])
                    valid_files = [f for f in ws_files if f.get('valid', True)]
                    checked_files_total += len(ws_files)

                    has_cz_audio = any(('CZ' in str(f.get('lang', '')).upper() and 'TIT' not in str(f.get('lang', '')).upper()) for f in valid_files)

                    # Pokud na Webshare není CZ dabing, prohledáme HellSpy
                    if not has_cz_audio and hs_enabled:
                        # Extra pomalá prodleva pro HellSpy (1.8 s)
                        for _ in range(18):
                            if _current_session_id != session_id or monitor.abortRequested() or xbmc.Player().isPlaying():
                                interrupted = True
                                break
                            time.sleep(0.1)
                        if interrupted:
                            break

                        try:
                            from resources.lib import hellspy
                            hs_files = hellspy.search_hellspy(item, media_type='movie', limit=10)
                            checked_files_total += len(hs_files)
                            valid_hs = [f for f in hs_files if f.get('valid', True)]
                            if valid_hs:
                                valid_files.extend(valid_hs)
                        except Exception:
                            pass

                    # Uložíme zkontrolovaná data do cache
                    cache_files = [{'ident': f.get('ident'), 'lang': f.get('lang'), 'quality': f.get('quality'), 'valid': f.get('valid', True)} for f in valid_files]
                    db.set_availability_cache('movie', tmdb_id, {
                        'valid_files': cache_files,
                        'deep_verified': True,
                        'deep_timestamp': int(time.time())
                    })
                except Exception as e:
                    _log(f"[Background Verifier] Chyba při kontrole filmu {tmdb_id}: {e}")

    finally:
        if interrupted:
            _log(f"[Background Verifier] Kontrola na pozadí přerušena (uživatel navigoval jinam / spustil přehrávání). Zkontrolováno celkem: {checked_files_total} souborů.")
        else:
            _log(f"[Background Verifier] Kontrola na pozadí dokončena. Zkontrolováno celkem: {checked_files_total} souborů.")

