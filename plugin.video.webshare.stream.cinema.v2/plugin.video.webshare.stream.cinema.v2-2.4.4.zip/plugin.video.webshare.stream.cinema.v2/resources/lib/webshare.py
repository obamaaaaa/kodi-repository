import hashlib
import os
import re
import unicodedata
import difflib
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
import time
import requests
import xbmc
try:
    import xbmcaddon
except ImportError:
    xbmcaddon = None

try:
    from .title_cleaner import clean_title_for_kodi, has_unrenderable_chars
except ImportError:
    try:
        from resources.lib.title_cleaner import clean_title_for_kodi, has_unrenderable_chars
    except ImportError:
        def clean_title_for_kodi(t, **kwargs): return t
        def has_unrenderable_chars(t): return False

try:
    from . import db
except ImportError:
    try:
        from resources.lib import db
    except ImportError:
        db = None

try:
    from main import log_debug
except ImportError:
    def log_debug(msg):
        xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)

TIMEOUT = 10

# Session s HTTP poolováním pro podporu paralelních vláken
session = requests.Session()
adapter = requests.adapters.HTTPAdapter(pool_connections=50, pool_maxsize=50, max_retries=1)
session.mount('https://', adapter)
session.mount('http://', adapter)

_search_cache = {}
_CACHE_TTL = 900  # 15 minut v sekundách

def _is_setting_enabled(setting_id, default=True):
    if not xbmcaddon:
        return default
    try:
        addon = xbmcaddon.Addon()
        val = addon.getSetting(setting_id)
        if val == "" or val is None:
            return default
        return val.lower() == "true"
    except Exception:
        return default

VIDEO_EXTENSIONS = {'.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.flv', '.webm', '.ts'}

TECHNICAL_WORDS = {
    '1080p', '720p', '2160p', '4k', '2k', '8k', 'uhd', 'sd', '576p', '480p', '480i', '576i', '1080i', 'fhd', 'hd',
    'bluray', 'blu-ray', 'bdrip', 'brrip', 'webrip', 'web-dl', 'webdl', 'hdtv', 'dvdrip', 'dvd', 'remux',
    'cam', 'ts', 'hdts', 'hdcam', 'telesync', 'telecine', 'screener', 'scr', 'dvdscr', 'tvrip', 'vhs', 'vhstrip', 'r5', 'line', 'microhd',
    'x264', 'x265', 'h264', 'h265', 'hevc', 'avc', 'xvid', 'divx', 'av1', 'vc1', 'mpeg2', 'mkv', 'mp4', 'avi',
    '10bit', '8bit', 'hdr', 'hdr10', 'hdr10plus', 'dv', 'dovi', 'sdr', 'dolby', 'vision', 'atmos',
    'cz', 'sk', 'en', 'eng', 'cs', 'cze', 'ces', 'slk', 'slo', 'de', 'deu', 'ger', 'fr', 'fra', 'fre',
    'it', 'ita', 'es', 'spa', 'pl', 'pol', 'rus', 'ru', 'hu', 'hun', 'jp', 'jpn', 'cn', 'chi', 'kor', 'ko', 'ro', 'ukr', 'ua',
    'tit', 'titulky', 'subs', 'subbed', 'sub', 'cztit', 'sktit',
    'dab', 'dabing', 'czdab', 'skdab', 'dual', 'multi', 'audio', 'forced', 'vostfr',
    'dts', 'dtshd', 'truehd', 'ac3', 'dd5', 'dd', 'ddp', 'eac3', 'aac', 'mp3', 'flac', '5.1', '7.1', '2.0',
    'extended', 'unrated', 'directors', 'cut', 'remastered', 'imax', 'proper', 'repack', 'rerip',
    'complete', 'internal', 'limited', 'uncut', 'theatrical', 'edition', 'version', 'final', 'special',
    'definitive', 'collector', 'collectors', 'restored', 'criterion', 'bonus', 'prehled', 'sample', 'trailer',
    'cd1', 'cd2', 'part1', 'part2', 'part', 'cd', 'diska', 'diskb', 'disk1', 'disk2', 'disc1', 'disc2',
    'czsk', 'skcz', 'czen', 'encz', 'film', 'movie', 'kino', 'cinema',
    'by', 'rip', 'upload', 'reupload', 'hunys', 'kvak', 'kodi',
    'yify', 'rarbg', 'ettv', 'eztv', 'sparks', 'geckos', 'amiable', 'rovers', 'fleet', 'fgt', 'ntb', 'flux', 'kogi', 'chd', 'evo', 'ethd', 'bst'
}

ARTICLES_AND_STOPWORDS = {
    'the', 'a', 'an', 'le', 'la', 'les', 'der', 'die', 'das',
    'and', 'i', 'of', 'in', 'on', 'at', 'to', 'for', 'with', 'from',
    'o', 've', 'ze', 'se', 'do', 'na', 'k', 's', 'u'
}

TECH_CUT_PATTERN = r'\b(1080p|720p|2160p|4k|2k|uhd|fhd|hd|sd|576p|480p|bluray|blu-ray|bdrip|brrip|webrip|web-dl|webdl|hdtv|dvdrip|dvd|remux|x264|x265|h264|h265|hevc|avc|xvid|divx|av1|hdr|hdr10|dovi|dv|dts|ac3|atmos|aac|mp3|czdab|skdab|cz|sk|en|titulky|tit|subs)\b'

def strip_kodi_tags(text):
    """Odstraní [COLOR ...] a [/COLOR], [B] a [/B] pro výpočet reálné viditelné délky textu."""
    if not text:
        return ""
    return re.sub(r'\[/?(?:color[^\]]*|b|i)\]', '', text, flags=re.IGNORECASE)

def pad_kodi_column(colored_text, target_width):
    """
    Zarovná text obsahující Kodi formátovací tagy ([COLOR ...], [B], ...)
    na požadovanou viditelnou šířku přidáním mezer na konec.
    """
    vis_len = len(strip_kodi_tags(colored_text))
    needed_spaces = max(0, target_width - vis_len)
    return colored_text + (" " * needed_spaces)

def build_webshare_file_label(file_item):
    """Vytvoří popisek souboru pro Kodi v požadovaném formátu se zarovnanými sloupci:
    [AUDIO]  [TITULKY]  [KVALITA]  [VELIKOST]  Název souboru
    """
    lang_raw = str(file_item.get('lang', 'Neznámý')).upper()
    name = file_item.get('name', '')
    
    audio_langs = file_item.get('audio_languages') or []
    subtitles = file_item.get('subtitles') or []
    codec = file_item.get('codec') or file_item.get('video_codec') or ''
    hdr = file_item.get('hdr') or file_item.get('hdr_format') or ''

    orig_l = str(file_item.get('original_language') or '').upper().strip()
    priority = {'CZ': 0, 'SK': 1, 'EN': 2, 'PL': 3, 'DE': 4}

    # 1. Jazyk audia (CZ, SK, EN, PL, DE, RU, UK... max 2 jazyky ve štítku)
    filtered_audio = []
    if audio_langs:
        for l in audio_langs:
            l_up = str(l).upper().strip()
            if 2 <= len(l_up) <= 3 and l_up not in filtered_audio:
                filtered_audio.append(l_up)
        filtered_audio.sort(key=lambda x: priority.get(x, 99))
    label_audio = filtered_audio[:2]

    if label_audio:
        parts = []
        for l_up in label_audio:
            if l_up == 'CZ':
                parts.append("[COLOR lime]CZ[/COLOR]")
            elif l_up == 'SK':
                parts.append("[COLOR yellow]SK[/COLOR]")
            elif l_up == 'EN':
                parts.append("[COLOR blue]EN[/COLOR]")
            elif l_up == 'PL':
                parts.append("[COLOR red]PL[/COLOR]")
            elif l_up == 'DE':
                parts.append("[COLOR orange]DE[/COLOR]")
            else:
                parts.append(f"[COLOR cyan]{l_up}[/COLOR]")
        lang_str = " ".join(parts)
    elif lang_raw in ('CZ', 'SK', 'EN', 'PL', 'DE', 'CZ TIT', 'SK TIT') or (orig_l and lang_raw == orig_l):
        if lang_raw == 'CZ':
            lang_str = "[COLOR lime]CZ[/COLOR]"
        elif lang_raw in ('CZ TIT', 'SK TIT'):
            # Pro titulkové verze zobrazujeme v audio sloupci původní jazyk (či EN)
            if orig_l and orig_l not in ('CZ', 'SK'):
                lang_str = f"[COLOR blue]{orig_l}[/COLOR]"
            else:
                lang_str = "[COLOR blue]EN[/COLOR]"
        elif lang_raw == 'SK':
            lang_str = "[COLOR yellow]SK[/COLOR]"
        elif lang_raw == 'EN':
            lang_str = "[COLOR blue]EN[/COLOR]"
        elif lang_raw == 'PL':
            lang_str = "[COLOR red]PL[/COLOR]"
        elif lang_raw == 'DE':
            lang_str = "[COLOR orange]DE[/COLOR]"
        else:
            lang_str = f"[COLOR cyan]{lang_raw}[/COLOR]"
    else:
        lang_str = f"[COLOR gray]{lang_raw}[/COLOR]" if lang_raw and lang_raw != 'NEZNÁMÝ' else ""

    col_audio = pad_kodi_column(lang_str, 6) + "  "

    # 2. Titulky (azurová cyan barva, max 2 jazyky, pevná šířka 11 znaků + 2 mezery)
    filtered_subs = []
    if subtitles:
        for s in subtitles:
            s_up = str(s).upper().strip()
            if 2 <= len(s_up) <= 3 and s_up not in filtered_subs:
                filtered_subs.append(s_up)
        filtered_subs.sort(key=lambda x: priority.get(x, 99))

    if not filtered_subs:
        name_lower = name.lower()
        if lang_raw == 'CZ TIT' or 'cz tit' in name_lower or 'cztit' in name_lower:
            filtered_subs = ['CZ']
        elif lang_raw == 'SK TIT' or 'sktit' in name_lower or 'sk tit' in name_lower:
            filtered_subs = ['SK']
        elif any(k in name_lower for k in ('titulky', '.tit.', ' cz subs', '_cz_sub')):
            filtered_subs = ['CZ']

    label_subs = filtered_subs[:2]
    if label_subs:
        sub_list = ", ".join(label_subs)
        sub_str = f"[COLOR cyan][T: {sub_list}][/COLOR]"
        col_subs = pad_kodi_column(sub_str, 11) + "  "
    else:
        col_subs = " " * 13

    # 3. Kvalita (pevná šířka 6 znaků + 2 mezery)
    quality = file_item.get('quality') or detect_quality(name)
    is_estimated = file_item.get('quality_estimated', False) or str(quality).startswith('~')

    if is_estimated:
        quality_str = f"[COLOR lightgray]{quality}[/COLOR]"
    elif quality == "4K":
        quality_str = f"[COLOR lime]{quality}[/COLOR]"
    elif quality == "1080p":
        quality_str = f"[COLOR yellow]{quality}[/COLOR]"
    elif quality == "720p":
        quality_str = f"[COLOR orange]{quality}[/COLOR]"
    elif quality in ("SD", "KN", "CAM"):
        quality_str = f"[COLOR gray]{quality}[/COLOR]"
    else:
        quality_str = f"[COLOR gray]{quality}[/COLOR]"

    col_quality = pad_kodi_column(quality_str, 6) + "  "

    # 4. Velikost souboru (pevná šířka 10 znaků + 2 mezery)
    size = file_item.get('size_mb')
    if size is not None:
        size_fmt = f"{size:.0f}" if size >= 10 else f"{size:.1f}"
        size_str = f"[COLOR gray][{size_fmt:>5} MB][/COLOR]"
    else:
        size_str = "[COLOR gray][    ? MB][/COLOR]"
        
    col_size = pad_kodi_column(size_str, 10) + "  "

    # 5. Zdroj (HellSpy / Přehraj.to / Anglické zdroje) + Název souboru
    source_prefix = ""
    file_src = str(file_item.get('source', '')).lower()
    if file_src == 'hellspy':
        source_prefix = "[COLOR deepskyblue][HellSpy][/COLOR] "
    elif file_src == 'prehrajto':
        source_prefix = "[COLOR coral][Přehraj.to][/COLOR] "
    elif file_src == 'streamtape':
        source_prefix = "[COLOR gold][Streamtape][/COLOR] "
    elif file_src == 'mixdrop':
        source_prefix = "[COLOR gold][Mixdrop][/COLOR] "
    elif file_src == 'filemoon':
        source_prefix = "[COLOR gold][Filemoon][/COLOR] "

    return f"{col_audio}{col_subs}{col_quality}{col_size}{source_prefix}{name}"

def detect_quality(filename):
    """Detekuje kvalitu/rozlišení videa podle názvu souboru"""
    fn = filename.lower()
    
    if re.search(r'\b(3840x2160|2160p|4k|uhd)\b', fn) or '3840x2160' in fn:
        return "4K"
    elif re.search(r'\b(1920x1080|1080p|1080i|fhd)\b', fn) or '1920x1080' in fn:
        return "1080p"
    elif re.search(r'\b(1280x720|720p|hd)\b', fn) or '1280x720' in fn:
        return "720p"
    elif re.search(r'\b(cam|camrip|hdcam|ts|hdts|telesync)\b', fn):
        return "CAM"
    elif re.search(r'\b(480p|576p|dvd|dvdrip|sd)\b', fn):
        return "SD"
    elif re.search(r'\b(kinorip|kino)\b', fn):
        return "KN"
        
    return "??"

def estimate_missing_qualities(files, runtime_minutes=None, media_type='movie'):
    """
    Pokud existují v seznamu položky s platnými kvalitami,
    odhadne chybějící kvalitu u ostatních souborů podle velikosti a délky.
    Tipnutá kvalita se označí prefixem '~' (např. '~1080p') a zobrazí se světle šedě.
    """
    if not files:
        return files

    runtime = runtime_minutes if (runtime_minutes and runtime_minutes > 0) else (45 if media_type == 'tv' else 100)

    # Shromáždíme referenční velikosti pro známé kvality
    quality_sizes = {}
    for f in files:
        q = f.get('quality', '')
        if q in ('4K', '1080p', '720p', 'SD') and f.get('size_mb', 0) > 0:
            quality_sizes.setdefault(q, []).append(f['size_mb'])

    medians = {q: sorted(sizes)[len(sizes) // 2] for q, sizes in quality_sizes.items()}
    has_enough_references = (len(medians) >= 2 or sum(len(s) for s in quality_sizes.values()) >= 3)

    for f in files:
        q = f.get('quality', '')
        if q in ('??', '', 'Neznámá', None):
            size_mb = f.get('size_mb', 0)
            if size_mb <= 0:
                continue

            best_q = None
            if has_enough_references and medians:
                import math
                best_q = min(medians.keys(), key=lambda k: abs(math.log(max(size_mb, 1) / max(medians[k], 1))))

            mb_per_min = size_mb / max(runtime, 1)
            if not best_q:
                if media_type == 'tv':
                    if size_mb >= 3500 or mb_per_min >= 50:
                        best_q = '4K'
                    elif size_mb >= 900 or mb_per_min >= 18:
                        best_q = '1080p'
                    elif size_mb >= 350 or mb_per_min >= 7:
                        best_q = '720p'
                    else:
                        best_q = 'SD'
                else:
                    if size_mb >= 10000 or mb_per_min >= 80:
                        best_q = '4K'
                    elif size_mb >= 1800 or mb_per_min >= 16:
                        best_q = '1080p'
                    elif size_mb >= 750 or mb_per_min >= 7:
                        best_q = '720p'
                    else:
                        best_q = 'SD'

            if best_q:
                f['quality'] = f"~{best_q}"
                f['quality_estimated'] = True
                f['base_quality'] = best_q

    return files
def detect_language(filename, search_language=None, original_language=None):
    """Detekuje jazykovou stopu a titulky podle názvu souboru."""
    fn = filename.lower()
    boundary = r'(?<![a-z0-9])(?:{0})(?![a-z0-9])'

    # Detekce titulků
    has_cz_tit = bool(re.search(boundary.format(r'(?:cz|czech)[\s._-]?(?:tit|titulky|subs?)|cztit|czech_tit'), fn, re.IGNORECASE))
    has_sk_tit = bool(re.search(boundary.format(r'(?:sk|slovak)[\s._-]?(?:tit|titulky|subs?)|sktit'), fn, re.IGNORECASE))
    has_en_tit = bool(re.search(boundary.format(r'(?:en|eng|english)[\s._-]?(?:tit|titulky|subs?)|entit'), fn, re.IGNORECASE))

    # Detekce CZ / SK / EN audia
    has_sk_audio = False
    if re.search(boundary.format(r'(?:sk|slovak)[\s._-]?(?:dab(?:ing)?)|skdab|slovak_dab'), fn, re.IGNORECASE):
        has_sk_audio = True
    elif not has_sk_tit and re.search(boundary.format(r'sk|slovak'), fn, re.IGNORECASE):
        has_sk_audio = True

    has_cz_audio = False
    if re.search(boundary.format(r'(?:cz|czech)[\s._-]?(?:dab(?:ing)?)|czdab|czech_dab'), fn, re.IGNORECASE):
        has_cz_audio = True
    elif not has_sk_audio and re.search(boundary.format(r'dabing'), fn, re.IGNORECASE):
        has_cz_audio = True
    elif not has_cz_tit and re.search(boundary.format(r'cz|czech'), fn, re.IGNORECASE):
        has_cz_audio = True

    has_en_audio = bool(re.search(boundary.format(r'(?:eng|english)[\s._-]?dab(?:ing)?|eng|english|en'), fn, re.IGNORECASE))

    # Další jazyky audia (korejština, japonština, ruština atd.)
    other_langs = []
    if re.search(boundary.format(r'kor|korean|ko'), fn, re.IGNORECASE):
        other_langs.append('KO')
    if re.search(boundary.format(r'jap|japanese|jpn|ja'), fn, re.IGNORECASE):
        other_langs.append('JA')
    if re.search(boundary.format(r'rus|russian|ru'), fn, re.IGNORECASE):
        other_langs.append('RU')
    if re.search(boundary.format(r'ukr|ukrainian|uk'), fn, re.IGNORECASE):
        other_langs.append('UK')
    if re.search(boundary.format(r'pol|polish|pl'), fn, re.IGNORECASE):
        other_langs.append('PL')
    if re.search(boundary.format(r'ger|german|de|deutsch'), fn, re.IGNORECASE):
        other_langs.append('DE')
    if re.search(boundary.format(r'fre|french|fr|vostfr'), fn, re.IGNORECASE):
        other_langs.append('FR')
    if re.search(boundary.format(r'spa|spanish|es|esp'), fn, re.IGNORECASE):
        other_langs.append('ES')
    if re.search(boundary.format(r'ita|italian|it'), fn, re.IGNORECASE):
        other_langs.append('IT')

    has_multi = bool(re.search(boundary.format(r'dual|multi'), fn, re.IGNORECASE))

    langs = []
    # 1. CZ audio a titulky
    if has_cz_audio:
        langs.append("CZ")
    if has_cz_tit:
        langs.append("CZ TIT")

    # 2. SK audio a titulky
    if has_sk_audio and "CZ" not in langs:
        langs.append("SK")
    if has_sk_tit and "CZ TIT" not in langs and "SK" not in langs:
        langs.append("SK TIT")

    # 3. EN audio
    if has_en_audio:
        langs.append("EN")

    # 4. Ostatní zjištěné jazyky
    for ol in other_langs:
        if ol not in langs:
            langs.append(ol)

    # 5. Pokud je přítomen tag multi/dual a nemáme detekovaný žádný konkrétní jazyk
    if has_multi and not langs:
        langs.append("MULTI")

    # Pokud v názvu žádný jazyk nebyl:
    if not langs:
        if original_language:
            orig = str(original_language).upper().strip()
            if orig in ('CS', 'CZE'):
                return "CZ"
            if orig in ('SK', 'SVK'):
                return "SK"
            if orig in ('EN', 'KO', 'JA', 'RU', 'UK', 'PL', 'DE', 'FR', 'ES', 'IT'):
                return orig
        # Nikdy nevracíme 'EN' jen proto, že byl vyhledávací dotaz v angličtině!
        if search_language and search_language.upper() in ('CZ', 'SK'):
            return search_language.upper()
        return "??"

    return "/".join(langs)

def get_language_score(lang: str) -> int:
    """Vrátí skóre priority jazyka (vyšší číslo = vyšší priorita)."""
    if not lang:
        return 0
    u = str(lang).upper().strip()
    # 1. CZ dabing má absolutní prioritu
    if 'CZ' in u and 'TIT' not in u and 'SUB' not in u:
        return 5
    if 'CZE' in u or 'CS' in u:
        return 5
    # 2. CZ titulky a SK dabing
    if 'CZ TIT' in u or 'CZ_TIT' in u or 'SUB' in u or ('TIT' in u and 'CZ' in u):
        return 4
    if 'SK' in u and 'TIT' not in u:
        return 3
    if 'SK TIT' in u:
        return 2
    # 3. EN audio
    if 'EN' in u or 'ENG' in u:
        return 1
    # 4. Multi/Dual bez známého CZ/SK
    if 'MULTI' in u or 'DUAL' in u:
        return 1
    return 0

def get_quality_score(quality: str) -> int:
    """Vrátí skóre priority kvality (vyšší číslo = vyšší priorita)."""
    if not quality:
        return 0
    q = str(quality).upper().replace('~', '').strip()
    if '4K' in q or '2160' in q or 'UHD' in q:
        return 5
    if '2K' in q or '1440' in q:
        return 4
    if '1080' in q or 'FHD' in q:
        return 3
    if '720' in q or 'HD' in q:
        return 2
    if 'SD' in q or '576' in q or '480' in q or 'DVD' in q:
        return 1
    return 0

def get_source_score(f):
    """
    Vrátí skóre priority zdroje pro řazení souborů:
      1. Webshare   -> 4
      2. HellSpy    -> 3
      3. Přehraj.to -> 2
      4. Anglické   -> 1
    """
    src = str(f.get('source') or '').lower().strip()
    ident = str(f.get('ident') or '').lower().strip()

    if src in ('streamtape', 'mixdrop', 'filemoon') or ident.startswith('english::') or ident.startswith('english'):
        return 1
    if src == 'prehrajto' or ident.startswith('prehrajto::') or ident.startswith('prehrajto'):
        return 2
    if src == 'hellspy' or ('_' in ident and len(ident.split('_')[0]) >= 16):
        return 3
    return 4  # Webshare

def sort_webshare_files(files, sort_mode=None):
    """
    Seřadí nalezené soubory podle priority zdrojů:
      1. Webshare, 2. HellSpy, 3. Přehraj.to, 4. Anglické servery
    A v rámci každého zdroje podle zvolené priority (jazyk / kvalita / velikost):
      - 'language': 1. Jazyk (CZ > CZ TIT > SK > EN), 2. Kvalita, 3. Velikost
      - 'quality':  1. Kvalita (4K > 1080p > 720p > SD), 2. Jazyk, 3. Velikost
      - 'size':     1. Velikost (největší soubor první), 2. Jazyk, 3. Kvalita
    """
    if not files:
        return []

    if sort_mode is None:
        try:
            if xbmcaddon:
                raw_setting = (xbmcaddon.Addon().getSetting('sort_mode') or '').strip()
                if 'KVALIT' in raw_setting.upper() or raw_setting == '1':
                    sort_mode = 'quality'
                elif 'VELIKOST' in raw_setting.upper() or raw_setting == '2':
                    sort_mode = 'size'
                elif 'JAZYK' in raw_setting.upper() or raw_setting == '0':
                    sort_mode = 'language'
                else:
                    sort_mode = 'language'
        except Exception:
            sort_mode = 'language'

    sm = str(sort_mode or 'language').lower()
    if 'kvalit' in sm or sm == 'quality':
        return sorted(
            files,
            key=lambda f: (
                -get_source_score(f),
                -get_quality_score(f.get('quality', '')),
                -get_language_score(f.get('lang', '')),
                -f.get('size_mb', 0)
            )
        )
    elif 'velikost' in sm or sm == 'size':
        return sorted(
            files,
            key=lambda f: (
                -get_source_score(f),
                -f.get('size_mb', 0),
                -get_language_score(f.get('lang', '')),
                -get_quality_score(f.get('quality', ''))
            )
        )
    else:
        return sorted(
            files,
            key=lambda f: (
                -get_source_score(f),
                -get_language_score(f.get('lang', '')),
                -get_quality_score(f.get('quality', '')),
                -f.get('size_mb', 0)
            )
        )

def normalize_title(text):
    """
    Normalizuje text pro porovnání (lowercase, bez diakritiky, jen alfanumerické znaky)
    """
    if not text:
        return ""
    text = re.sub(r'^\[.*?\]\s*', '', text)
    text = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

def words_match(w1, w2):
    """Porovná dva výrazy s tolerancí drobných jazykových odchylek (např. Odyssea vs Odyssey)."""
    if w1 == w2:
        return True
    if len(w1) >= 4 and len(w2) >= 4:
        if difflib.SequenceMatcher(None, w1, w2).ratio() >= 0.8:
            return True
    return False

def validate_file(
    filename,
    is_passworded,
    target_title,
    target_year,
    media_type='movie',
    target_season=None,
    target_episode=None
):
    """Ověří platnost souboru podle flexibilního porovnání slov a segmentů."""

    # 1. Kontrola přípony
    ext = ('.' + filename.split('.')[-1].lower() if '.' in filename else '')
    if ext not in VIDEO_EXTENSIONS:
        return False, f"Neplatná přípona ({ext})"

    # 2. Kontrola hesla
    if is_passworded:
        return False, "Zaheslováno na Webshare"
    if re.search(r'\b(?:zaheslov[aá]n[ooyí]|heslo\s*[:=]|heslo\s+v\s+popis[ue]?)\b', filename, re.IGNORECASE):
        return False, "Zaheslováno v popisu/názvu"

    # 3. Kontrola názvu pomocí složených segmentů a vyhledávání sekvence slov
    filename_without_ext = os.path.splitext(filename)[0].strip()
    titles_list = target_title if isinstance(target_title, list) else [target_title]
    
    # Rozšířený regex pro zachycení S01E01, 1x01 i 1 - 01 / 1-1
    se_pattern = r'(?<![a-z0-9])(?:s(\d{1,2})[\s._-]*e(\d{1,2})|(\d{1,2})x(\d{1,2})|(\d{1,2})[\s._-]*[-][\s._-]*(\d{1,2}))(?![a-z0-9])'
    se_match = re.search(se_pattern, filename_without_ext, re.IGNORECASE)
    year_m = re.search(r'(?<!\d)(19\d{2}|20\d{2})(?!\d)', filename_without_ext)

    if se_match:
        fn_title_part = filename_without_ext[:se_match.start()]
    elif year_m:
        fn_title_part = filename_without_ext[:year_m.start()]
    else:
        fn_title_part = filename_without_ext
            
    # Ošetření nechtěných podtitulů, pokračování a spin-offů (např. "Resident Evil: Apokalypsa" u "Resident Evil")
    if media_type == 'tv':
        title_core = fn_title_part
    else:
        if year_m:
            title_core = filename_without_ext[:year_m.start()]
        else:
            tech_m = re.search(TECH_CUT_PATTERN, filename_without_ext, re.IGNORECASE)
            title_core = filename_without_ext[:tech_m.start()] if tech_m else filename_without_ext

    fn_core_words = normalize_title(title_core).split()
    target_words = set()
    for t in titles_list:
        if t:
            for w in normalize_title(t).split():
                target_words.add(w)

    unexpected = [
        w for w in fn_core_words
        if w not in target_words
        and w not in ARTICLES_AND_STOPWORDS
        and w not in TECHNICAL_WORDS
        and not re.match(r'^\d+$', w)
    ]
    if unexpected:
        return False, f"Obsahuje doplňující název / jiný díl ({unexpected[0]})"
    
    # Rozdělení složených názvů (např. "The Rookie - Zelenáč", "The Rookie / Zelenáč", "The Rookie-Zelenáč")
    raw_segments = re.split(r'\s*[-/:|]\s*|\s+-\s*', fn_title_part)
    raw_segments.append(fn_title_part)
    raw_segments.append(filename_without_ext)

    fn_segments_words = []
    for seg in raw_segments:
        norm_seg = normalize_title(seg)
        words = norm_seg.split()
        if words:
            fn_segments_words.append(words)

    if not fn_segments_words:
        return False, "Prázdný název souboru"

    match_found = False

    for t in titles_list:
        if not t:
            continue

        t_clean = t.strip()
        t_variants = [t_clean]

        t_lower = t_clean.lower()
        for prefix in ("the ", "a ", "an "):
            if t_lower.startswith(prefix):
                t_variants.append(t_clean[len(prefix):].strip())
                break

        for variant in t_variants:
            v_norm = normalize_title(variant)
            v_words = v_norm.split()
            if not v_words:
                continue

            v_len = len(v_words)

            for fn_words in fn_segments_words:
                fn_len = len(fn_words)
                if fn_len < v_len:
                    continue

                # Zkontrolujeme, zda v_words odpovídá souvislé sekvenci slov v fn_words
                for start_idx in range(fn_len - v_len + 1):
                    if all(words_match(fn_words[start_idx + i], v_words[i]) for i in range(v_len)):
                        match_found = True
                        break
                if match_found:
                    break

            if match_found:
                break

        if match_found:
            break

    if not match_found:
        return False, "Nezačíná správným textem"

    # 4. Kontrola traileru
    all_titles_str = " ".join([str(t) for t in titles_list]).lower()
    if 'trailer' not in all_titles_str:
        if re.search(r'(?<![a-z0-9])trailer(?![a-z0-9])', filename, re.IGNORECASE):
            return False, "Jedná se o Trailer"

    # 5. Kontrola seriálového označení (S01E01, 1x01 atd.)
    #has_series_pattern = bool(
    #    re.search(
    #        r'(?<![A-Za-z0-9])(?:s\d{1,2}[\s._-]*e\d{1,2}|\d{1,2}x\d{1,2})(?![A-Za-z0-9])',
    #        filename,
    #        re.IGNORECASE
    #    )
    #)
    
    # 5. Kontrola seriálového označení a PŘESNÉHO čísla epizody
    se_matches = re.findall(
        r'(?<![A-Za-z0-9])(?:s(\d{1,2})[\s._-]*e(\d{1,2})|(\d{1,2})x(\d{1,2}))(?![A-Za-z0-9])',
        filename,
        re.IGNORECASE
    )

    if media_type == 'movie':
        if se_matches:
            return False, "Jedná se o seriál"
    else:
        if not se_matches:
            return False, "Nejedná se o díl seriálu"
        
        # Pokud známe požadovanou sezónu a díl, ověříme je
        if target_season is not None and target_episode is not None:
            found_correct_episode = False
            for s1, e1, s2, e2 in se_matches:
                s_num = int(s1 if s1 else s2)
                e_num = int(e1 if e1 else e2)
                
                if s_num == int(target_season) and e_num == int(target_episode):
                    found_correct_episode = True
                    break

            if not found_correct_episode:
                # Vypíšeme první nalezenou epizodu ze souboru pro jasný debug log
                first_s = int(se_matches[0][0] if se_matches[0][0] else se_matches[0][2])
                first_e = int(se_matches[0][1] if se_matches[0][1] else se_matches[0][3])
                return False, f"Nesprávný díl (soubor má S{first_s:02d}E{first_e:02d}, hledáno S{int(target_season):02d}E{int(target_episode):02d})"

    # 6. Kontrola roku (pouze pro filmy; u seriálů ročník v názvu označuje vysílání konkrétní sezóny)
    if target_year and media_type == 'movie':
        target_year_str = str(target_year)
        bracket_year = re.search(r'[\(\[]\s*(19\d{2}|20\d{2})\s*[\)\]]', filename)
        if bracket_year and bracket_year.group(1) != target_year_str:
            return False, f"Špatný rok ({bracket_year.group(1)})"

        fn_years = re.findall(r'(?<![a-z0-9])(19\d{2}|20\d{2})(?![a-z0-9])', filename, re.IGNORECASE)

        if fn_years and target_year_str not in fn_years:
            return False, f"Špatný rok ({fn_years[0]})"

    # 7. Kontrola čísel v názvu (pouze pro filmy)
    if media_type == 'movie':
        primary_title = titles_list[0] if titles_list else ""
        target_numbers = set(re.findall(r'\b\d+\b', primary_title))
        fn_lower = filename.lower()

        if target_year and str(target_year) in fn_lower:
            title_part = fn_lower.split(str(target_year))[0]
        else:
            year_match = re.search(r'(?<!\d)(19|20)\d{2}(?!\d)', fn_lower)
            title_part = fn_lower.split(year_match.group(0))[0] if year_match else fn_lower

        file_numbers = set(re.findall(r'\b\d+\b', title_part))

        if target_numbers:
            for num in target_numbers:
                if num not in file_numbers:
                    return False, f"Chybí číslo dílu / neshoda čísla ({num})"
        else:
            unexpected = [n for n in file_numbers if len(n) == 1 and n != '0']
            if unexpected:
                return False, f"Obsahuje číslo dílu ({unexpected[0]}), které v názvu filmu neexistuje"

    return True, "OK"

def search_webshare_raw(query, token=None, limit=20):
    norm_query = normalize_title(query)
    use_cache = _is_setting_enabled('exp_cache_results', True)
    mem_cache_key = (norm_query, limit, bool(token))
    disk_cache_key = "ws_srch_" + norm_query + "_" + str(limit)

    now = time.time()
    if use_cache:
        if mem_cache_key in _search_cache:
            cached_ts, cached_files = _search_cache[mem_cache_key]
            if now - cached_ts < _CACHE_TTL:
                return [dict(f) for f in cached_files]
        if db:
            disk_files = db.get_cache(disk_cache_key, ttl_days=1.0/48)  # 30 minut TTL
            if disk_files is not None and isinstance(disk_files, list):
                _search_cache[mem_cache_key] = (now, disk_files)
                return [dict(f) for f in disk_files]

    url = "https://webshare.cz/api/search/"
    data = {
        'what': norm_query,
        'limit': limit,
        'sort': 'size',
        'category': 'video'
    }
    if token:
        data['wst'] = token
        
    try:
        use_keepalive = _is_setting_enabled('exp_session_keepalive', True)
        client = session if use_keepalive else requests
        r = client.post(url, data=data, timeout=5)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            
            status = root.findtext('status')
            if status and status != 'OK':
                return []

            files = []
            for f in root.findall('file'):
                files.append({
                    'ident': f.findtext('ident', ''),
                    'name': f.findtext('name', ''),
                    'size': int(f.findtext('size', 0)),
                    'password': str(f.findtext('password', '0')).strip().lower() in ('1', 'true', 'yes')
                })

            if use_cache:
                if len(_search_cache) > 500:
                    _search_cache.clear()
                _search_cache[mem_cache_key] = (now, files)
                if db:
                    db.set_cache(disk_cache_key, files)

            return files
    except Exception as e:
        log_debug(f"[Webshare API Chyba] {e}")
    return []

def search_and_verify_movie(tmdb_item, token=None, media_type='movie', limit=20):
    """Najde a vyhodnotí soubory pro jeden TMDB film (česky, anglicky i originální název)"""
    year = str(tmdb_item.get('year', '')).strip()
    title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
    title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()
    title_orig = (tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type=media_type)
    title_en = clean_title_for_kodi(title_en, year=year, media_type=media_type)
    if title_orig:
        title_orig = clean_title_for_kodi(title_orig, year=year, media_type=media_type)

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        title_orig,
        tmdb_item.get('english_title', '').strip(),
        tmdb_item.get('title', '').strip(),
        tmdb_item.get('original_title', '').strip()
    ]))))

    queries = []
    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} {year}".strip(), "CZ"))
        queries.append((title_cz, "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} {year}".strip(), "EN"))
        queries.append((title_en, "EN"))

    if title_orig and title_orig != title_cz and title_orig != title_en and not has_unrenderable_chars(title_orig):
        queries.append((f"{title_orig} {year}".strip(), "ORIG"))
        queries.append((title_orig, "ORIG"))

    found_files = {}
    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)
        for f in raw_files:
            f['_search_language'] = search_language
            found_files[f['ident']] = f

    results = []
    for ident, f in found_files.items():
        search_language = f.get('_search_language')

        valid, reason = validate_file(
            f['name'],
            f['password'],
            all_titles,
            year,
            media_type=media_type
        )

        orig_lang = tmdb_item.get('original_language') if isinstance(tmdb_item, dict) else None
        lang = detect_language(f['name'], search_language=search_language, original_language=orig_lang)
        quality = detect_quality(f['name'])

        results.append({
            'name': f['name'],
            'ident': f['ident'],
            'size_mb': round(f['size'] / (1024 * 1024), 2),
            'valid': valid,
            'reason': reason,
            'lang': lang,
            'quality': quality
        })

    valid_count = sum(1 for r in results if r.get('valid'))
    item_name = title_cz or title_en
    if not results:
        log_debug(f"[Nenalezeno] '{item_name}' ({year}): Na Webshare nebyl nalezen žádný soubor.")
    elif valid_count == 0:
        reasons = {}
        for r in results:
            if not r.get('valid'):
                rsn = r.get('reason', 'Neshoda')
                reasons[rsn] = reasons.get(rsn, 0) + 1
        reason_desc = ", ".join(["%dx %s" % (cnt, rsn) for rsn, cnt in reasons.items()])
        log_debug(f"[Filtrace] '{item_name}' ({year}): Všech {len(results)} nalezených souborů na Webshare vyřazeno ({reason_desc})")
    else:
        log_debug(f"[Nalezeno] '{item_name}' ({year}): {valid_count} platných z {len(results)} nalezených na Webshare")

    return {
        'tmdb_title': title_cz or title_en,
        'tmdb_id': tmdb_item.get('id'),
        'files': results
    }

def search_and_verify_movie_quick(tmdb_item, token=None, media_type='movie', limit=5): 
    """Rychlá verze vyhledání filmu - minimalizuje počet API dotazů"""
    year = str(tmdb_item.get('year', '')).strip()
    title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip() 
    title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip() 

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type=media_type)
    title_en = clean_title_for_kodi(title_en, year=year, media_type=media_type)

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        tmdb_item.get('english_title', '').strip(),
        tmdb_item.get('title', '').strip(),
        tmdb_item.get('original_title', '').strip()
    ]))))

    queries = [] 
    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} {year}".strip(), "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} {year}".strip(), "EN"))

    found_files = {}
    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)

        for f in raw_files:
            f['_search_language'] = search_language
            found_files[f['ident']] = f

        if found_files:
            break

    results = []
    for f in found_files.values():
        search_language = f.get('_search_language')

        valid, reason = validate_file(
            f['name'],
            f.get('password', False),
            all_titles,
            year,
            media_type=media_type
        )

        if not valid:
            #log_debug(
            #    f"search_and_verify_movie_quick() - "
            #    f"Rejected: {f['name']} - {reason}"
            #)
            continue

        orig_lang = tmdb_item.get('original_language') if isinstance(tmdb_item, dict) else None
        lang = detect_language(f['name'], search_language=search_language, original_language=orig_lang)
        quality = detect_quality(f['name'])

        results.append({
            'name': f['name'],
            'ident': f['ident'],
            'size_mb': round(f['size'] / (1024 * 1024), 2),
            'valid': True,
            'reason': reason,
            'lang': lang,
            'quality': quality
        })

    return {
        'tmdb_title': title_cz or title_en,
        'tmdb_id': tmdb_item.get('id'),
        'files': results
    }

def search_and_verify_episode(show_item, season_number, episode_number, token=None, limit=20):
    """Najde a vyhodnotí soubory pro jednu epizodu seriálu na Webshare (česky, anglicky i originální název)."""
    if isinstance(show_item, dict):
        tmdb_item = show_item
        year = str(tmdb_item.get('year', '')).strip()
        title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
        title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()
        title_orig = (tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()
    else:
        tmdb_item = {}
        year = ""
        title_cz = str(show_item or '').strip()
        title_en = ""
        title_orig = ""

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type='tv')
    if title_en:
        title_en = clean_title_for_kodi(title_en, year=year, media_type='tv')
    if title_orig:
        title_orig = clean_title_for_kodi(title_orig, year=year, media_type='tv')

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        title_orig,
        tmdb_item.get('english_title', '').strip() if tmdb_item else '',
        tmdb_item.get('title', '').strip() if tmdb_item else '',
        tmdb_item.get('name', '').strip() if tmdb_item else '',
        tmdb_item.get('original_title', '').strip() if tmdb_item else '',
        tmdb_item.get('original_name', '').strip() if tmdb_item else ''
    ]))))

    queries = []
    ep_tag = f"S{season_number:02d}E{episode_number:02d}"
    alt_tag = f"{season_number}x{episode_number:02d}"

    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} {ep_tag}", "CZ"))
        queries.append((f"{title_cz} {alt_tag}", "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} {ep_tag}", "EN"))
        queries.append((f"{title_en} {alt_tag}", "EN"))

    if title_orig and title_orig != title_cz and title_orig != title_en and not has_unrenderable_chars(title_orig):
        queries.append((f"{title_orig} {ep_tag}", "ORIG"))
        queries.append((f"{title_orig} {alt_tag}", "ORIG"))

    found_files = {}
    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)
        for f in raw_files:
            ident = f.get('ident')
            if ident and ident not in found_files:
                f['_search_language'] = search_language
                found_files[ident] = f

    results = []
    for ident, f in found_files.items():
        search_language = f.get('_search_language')
        valid, reason = validate_file(
            f['name'],
            f.get('password', False),
            all_titles,
            year,
            media_type='tv',
            target_season=season_number,
            target_episode=episode_number
        )

        orig_lang = tmdb_item.get('original_language') if isinstance(tmdb_item, dict) else None
        lang = detect_language(f['name'], search_language=search_language, original_language=orig_lang)
        quality = detect_quality(f['name'])

        results.append({
            'name': f['name'],
            'ident': f['ident'],
            'size_mb': round(f['size'] / (1024 * 1024), 2),
            'size': f.get('size', 0),
            'valid': valid,
            'reason': reason,
            'lang': lang,
            'quality': quality,
            'source': 'webshare'
        })

    valid_count = sum(1 for r in results if r.get('valid'))
    item_name = title_cz or title_en
    ep_str = f"S{season_number:02d}E{episode_number:02d}"
    if not results:
        log_debug(f"[Nenalezeno] '{item_name}' {ep_str}: Na Webshare nebyl nalezen žádný soubor.")
    elif valid_count == 0:
        reasons = {}
        for r in results:
            if not r.get('valid'):
                rsn = r.get('reason', 'Neshoda')
                reasons[rsn] = reasons.get(rsn, 0) + 1
        reason_desc = ", ".join(["%dx %s" % (cnt, rsn) for rsn, cnt in reasons.items()])
        log_debug(f"[Filtrace] '{item_name}' {ep_str}: Všech {len(results)} nalezených souborů na Webshare vyřazeno ({reason_desc})")
    else:
        log_debug(f"[Nalezeno] '{item_name}' {ep_str}: {valid_count} platných z {len(results)} nalezených na Webshare")

    return {
        'tmdb_title': title_cz or title_en,
        'season': season_number,
        'episode': episode_number,
        'files': results
    }


def check_tv_episode_availability(show_title, season_number, episode_number, year="", token=None, limit=10, original_title=None, english_title=None):
    """Zkontroluje dostupnost jednoho dílu seriálu na Webshare a vrátí nejlepší shodu."""
    if isinstance(show_title, dict):
        tmdb_item = show_title
        year = str(year or tmdb_item.get('year', '')).strip()
        title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
        title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()
    else:
        tmdb_item = {}
        year = str(year or '').strip()
        title_cz = str(show_title or '').strip()
        title_en = str(english_title or original_title or '').strip()

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type='tv')
    if title_en:
        title_en = clean_title_for_kodi(title_en, year=year, media_type='tv')

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        tmdb_item.get('english_title', '').strip() if tmdb_item else '',
        tmdb_item.get('title', '').strip() if tmdb_item else '',
        tmdb_item.get('original_title', '').strip() if tmdb_item else '',
        str(original_title or '').strip(),
        str(english_title or '').strip()
    ]))))

    queries = []
    ep_tag = f"S{season_number:02d}E{episode_number:02d}"
    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} {ep_tag}", "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} {ep_tag}", "EN"))

    valid_candidates = []

    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)

        for file_item in raw_files:
            file_name = file_item['name']
            valid, reason = validate_file(
                file_name,
                file_item.get('password', False),
                all_titles,
                year,
                media_type='tv',
                target_season=season_number,
                target_episode=episode_number
            )

            if not valid:
                continue

            orig_lang = tmdb_item.get('original_language') if isinstance(tmdb_item, dict) else None
            lang = detect_language(file_name, search_language=search_language, original_language=orig_lang)
            quality = detect_quality(file_name)

            valid_candidates.append({
                'available': True,
                'lang': lang,
                'quality': quality,
                'name': file_name,
                'reason': reason,
                'ident': file_item.get('ident', ''),
                'query': query,
                'lang_score': get_language_score(lang),
                'quality_score': get_quality_score(quality)
            })

        # Zrychlení: pokud jsme nalezli CZ dabing, není třeba posílat další dotaz
        if any(c.get('lang') == 'CZ' for c in valid_candidates):
            break

    if valid_candidates:
        best_candidate = max(
            valid_candidates,
            key=lambda x: (x['lang_score'], x['quality_score'])
        )
        best_candidate.pop('lang_score', None)
        best_candidate.pop('quality_score', None)
        return best_candidate

    fallback_query = queries[0][0] if queries else f"{title_cz} {ep_tag}"
    return {
        'available': False,
        'lang': '??',
        'quality': '??',
        'name': '',
        'reason': 'Nenalezeno',
        'ident': '',
        'query': fallback_query,
    }

def check_tv_series(tmdb_item, token=None, limit=10):
    """Prohledá všechny výsledky pro daný seriál a vrátí nejlepší shodu dle jazyka a kvality."""
    year = str(tmdb_item.get('year', '')).strip()
    title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
    title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()

    title_cz = clean_title_for_kodi(title_cz, year=year, media_type='tv')
    title_en = clean_title_for_kodi(title_en, year=year, media_type='tv')

    all_titles = list(filter(None, list(dict.fromkeys([
        title_cz,
        title_en,
        tmdb_item.get('english_title', '').strip(),
        tmdb_item.get('title', '').strip(),
        tmdb_item.get('original_title', '').strip()
    ]))))

    queries = []
    if title_cz and not has_unrenderable_chars(title_cz):
        queries.append((f"{title_cz} S01E01", "CZ"))
        if year:
            queries.append((f"{title_cz} {year} S01E01", "CZ"))

    if title_en and title_en != title_cz and not has_unrenderable_chars(title_en):
        queries.append((f"{title_en} S01E01", "EN"))
        if year:
            queries.append((f"{title_en} {year} S01E01", "EN"))

    valid_candidates = []

    for query, search_language in queries:
        raw_files = search_webshare_raw(query, token=token, limit=limit)
        
        for file_item in raw_files:
            file_name = file_item['name']
            
            valid, reason = validate_file(
                file_name,
                file_item.get('password', False),
                all_titles,
                year,
                media_type='tv',
                target_season=1,
                target_episode=1
            )

            orig_lang = tmdb_item.get('original_language') if isinstance(tmdb_item, dict) else None
            lang = detect_language(file_name, search_language=search_language, original_language=orig_lang)
            quality = detect_quality(file_name)

            if not valid:
                continue

            # Uložíme kandidáta spolu s vypočítaným skóre
            valid_candidates.append({
                'lang': lang,
                'quality': quality,
                'lang_score': get_language_score(lang),
                'quality_score': get_quality_score(quality)
            })

        # Zrychlení: pokud jsme nalezli CZ dabing, není třeba posílat další dotazy
        if any(c.get('lang') == 'CZ' for c in valid_candidates):
            break

    if valid_candidates:
        # Seřazení kandidátů: primárně podle jazyka (lang_score), sekundárně podle kvality (quality_score)
        best_match = max(
            valid_candidates,
            key=lambda x: (x['lang_score'], x['quality_score'])
        )

        return {
            'available': True,
            'lang': best_match['lang'],
            'quality': best_match['quality']
        }

    return {
        'available': False,
        'lang': '??',
        'quality': '??',
        'reason': 'Nenalezeno'
    }

def md5_crypt(password, salt, magic='$1$'):
    """MD5 crypt pro Webshare API"""
    if isinstance(password, str): password = password.encode('utf-8')
    if isinstance(salt, str): salt = salt.encode('utf-8')
    if isinstance(magic, str): magic = magic.encode('utf-8')
    m = hashlib.md5(); m.update(password + magic + salt)
    a = hashlib.md5(password + salt + password).digest()
    for i in range(len(password), 0, -16): m.update(a[:min(16, i)])
    i = len(password)
    while i:
        if i & 1: m.update(b'\x00')
        else: m.update(password[0:1])
        i >>= 1
    final = m.digest()
    for i in range(1000):
        m2 = hashlib.md5()
        if i & 1: m2.update(password)
        else: m2.update(final)
        if i % 3: m2.update(salt)
        if i % 7: m2.update(password)
        if i & 1: m2.update(final)
        else: m2.update(password)
        final = m2.digest()
    itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    def to64(v, n):
        ret = ""
        while n - 1 >= 0: n -= 1; ret += itoa64[v & 0x3f]; v >>= 6
        return ret
    hashed = to64((final[0]<<16)|(final[6]<<8)|final[12], 4) + to64((final[1]<<16)|(final[7]<<8)|final[13], 4) + \
             to64((final[2]<<16)|(final[8]<<8)|final[14], 4) + to64((final[3]<<16)|(final[9]<<8)|final[15], 4) + \
             to64((final[4]<<16)|(final[10]<<8)|final[5], 4) + to64(final[11], 2)
    return magic.decode('utf-8') + salt.decode('utf-8') + '$' + hashed

def login(user, password):
    """Přihlášení k Webshare API"""
    if not user or not password:
        return None
    try:
        r = session.post("https://webshare.cz/api/salt/", data={'username_or_email': user}, timeout=TIMEOUT)
        salt = ET.fromstring(r.content).findtext("salt")
        if not salt:
            log_debug("[Webshare CHYBA] login(): Nezískán salt ze serveru")
            return None
        enc = hashlib.sha1(md5_crypt(password, salt).encode('utf-8')).hexdigest()
        r = session.post("https://webshare.cz/api/login/", data={'username_or_email': user, 'password': enc, 'keep_logged_in': 1}, timeout=TIMEOUT)
        token = ET.fromstring(r.content).findtext("token")
        if not token:
            log_debug("[Webshare CHYBA] login(): Neplatné přihlašovací údaje")
        return token
    except Exception as e:
        log_debug(f"[Webshare CHYBA] login() výjimka: {e}")
        return None


def get_webshare_file_length(ident, token=None):
    """
    Vrátí délku videa v sekundách z Webshare API file_info.
    """
    if not ident:
        return 0
    try:
        url = "https://webshare.cz/api/file_info/"
        data = {'ident': str(ident)}
        if token:
            data['wst'] = token
        use_keepalive = _is_setting_enabled('exp_session_keepalive', True)
        client = session if use_keepalive else requests
        r = client.post(url, data=data, timeout=3)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            l_str = root.findtext('length')
            if l_str and l_str.isdigit():
                return int(l_str)
    except Exception:
        pass
    return 0


def is_duration_within_tolerance(file_duration_sec, expected_duration_minutes_or_sec, tolerance=0.05, file_name="", media_type="movie"):
    """
    Ověří, zda délka souboru odpovídá očekávané délce z TMDB s tolerancí (výchozí 5%).
    Pokud délka souboru není známa (0), soubor nezahazujeme (vrací True).
    Pokud název indikuje prodlouženou / režisérskou verzi (extended, unrated, director's cut),
    povoluje se vyšší tolerance (až 18%).
    """
    try:
        f_dur = float(file_duration_sec or 0)
        exp = float(expected_duration_minutes_or_sec or 0)
        if 0 < exp < 500:
            exp_dur = exp * 60.0
        else:
            exp_dur = exp

        if f_dur <= 0 or exp_dur <= 0:
            return True, 0.0

        diff = abs(f_dur - exp_dur)
        diff_pct = diff / exp_dur

        name_lower = str(file_name or "").lower()
        allowed_tol = tolerance
        if any(w in name_lower for w in ("extended", "director", "unrated", "remastered", "special edition", "verze", "cut")):
            allowed_tol = max(tolerance, 0.18)
        elif media_type == 'tv':
            allowed_tol = max(tolerance, 0.15)

        if diff_pct <= allowed_tol:
            return True, diff_pct
        return False, diff_pct
    except Exception:
        return True, 0.0