import ast
import sys
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import json

try:
    from main import log_debug
except ImportError:
    def log_debug(msg):
        xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)
        
def _parse_dict(data):
    """Pomocná funkce pro bezpečný převod str -> dict"""
    if isinstance(data, dict):
        return data
    if isinstance(data, str) and data.strip():
        try:
            return json.loads(data)
        except Exception:
            try:
                return ast.literal_eval(data)
            except Exception:
                pass
    return {}

def play_webshare_video(file_id, file_name="Název_souboru.mp4", tmdb_info=None, season=0, episode=0, wst_token="", tmdb_details="", episode_name="", episode_plot="", episode_still="", media_type=None, from_popup=False):
    # film: {'title': 'Scary Movie', 'original_title': 'Scary Movie', 'year': '2026', 'id': '1273221', 'media_type': 'movie'}
    # seroš: {'title': 'Zelenáč', 'original_title': 'Zelenáč', 'year': '2018', 'id': '79744'}
    tmdb_info = _parse_dict(tmdb_info)
    tmdb_details = _parse_dict(tmdb_details)

    # 2. Extrakce hodnot s fallbackem na file_name
    title = tmdb_info.get('title') or tmdb_info.get('name') or file_name
    year = tmdb_info.get('year', '')
    tmdb_id = tmdb_info.get('id') or tmdb_info.get('tmdb_id') or ''

    season_num = int(season or tmdb_info.get('season') or 0)
    episode_num = int(episode or tmdb_info.get('episode') or 0)

    if not media_type:
        media_type = tmdb_info.get('media_type') or tmdb_details.get('media_type')
    if not media_type:
        if season_num > 0 or episode_num > 0 or tmdb_info.get('season') or tmdb_details.get('seasons') or tmdb_details.get('number_of_seasons'):
            media_type = 'tv'
        else:
            media_type = 'movie'

    ep_name = episode_name or tmdb_info.get('episode_name') or ''
    ep_plot = episode_plot or tmdb_info.get('episode_plot') or ''
    ep_still = episode_still or tmdb_info.get('episode_still') or ''

    # Pokud jde o epizodu a chybí nám její název nebo popisek, zkusíme načíst z TMDB
    if (season_num > 0 or episode_num > 0) and (not ep_plot or not ep_name):
        try:
            import xbmcaddon
            from . import tmdb
            addon = xbmcaddon.Addon()
            tmdb_key = addon.getSetting('tmdb_api_key')
            if tmdb_id and tmdb_key:
                s_data = tmdb.get_season_details(tmdb_id, season_num, tmdb_key)
                for ep in s_data.get('episodes', []):
                    if ep.get('episode_number') == episode_num:
                        if not ep_name:
                            ep_name = ep.get('name', '')
                        if not ep_plot:
                            ep_plot = ep.get('overview', '')
                        if not ep_still and ep.get('still_path'):
                            ep_still = "https://image.tmdb.org/t/p/w500" + str(ep.get('still_path', ''))
                        break
        except Exception as e:
            log_debug(f"Chyba při doplňování detailů epizody: {e}")

    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
    
    if not wst_token:
        log_debug("Není k dispozici platný Webshare Token")

    # 3. Získej přímou URL z Prehraj.to, Hellspy, Anglických zdrojů nebo Webshare API
    stream_source = tmdb_info.get('source') if isinstance(tmdb_info, dict) else None
    if not stream_source and isinstance(tmdb_details, dict):
        stream_source = tmdb_details.get('source')

    fid_str = str(file_id or '')
    is_prehrajto = (stream_source == 'prehrajto' or fid_str.startswith('prehrajto::'))
    is_english = (stream_source in ('streamtape', 'mixdrop', 'filemoon', 'english') or fid_str.startswith('english::'))
    is_hellspy = (stream_source == 'hellspy' or ('_' in fid_str and len(fid_str.split('_')[0]) >= 16 and not is_prehrajto and not is_english))

    if is_prehrajto:
        try:
            from . import prehrajto
            href = fid_str.split('::', 1)[1] if fid_str.startswith('prehrajto::') else fid_str
            stream_url = prehrajto.get_prehrajto_direct_url(href)
            if stream_url:
                headers = {
                    'User-Agent': prehrajto.USER_AGENT,
                    'Referer': 'https://prehrajto.cz/'
                }
                stream_url = stream_url + '|' + urllib.parse.urlencode(headers)
        except Exception as e:
            log_debug("Chyba při získávání streamu z Prehraj.to: " + str(e))
            stream_url = None
    elif is_english:
        try:
            from . import english_sources
            stream_url = english_sources.resolve_stream(fid_str, hoster=stream_source)
        except Exception as e:
            log_debug("Chyba při získávání anglického streamu: " + str(e))
            stream_url = None
    elif is_hellspy:
        try:
            from . import hellspy
            parts = fid_str.split('_')
            f_hash = parts[0]
            v_id = parts[1] if len(parts) > 1 else ''
            stream_url = hellspy.get_hellspy_direct_url(f_hash, v_id, verify_stream=True)
            if stream_url:
                # Nastavíme hlavičky pro Kodi přehrávač (User-Agent a Referer) přes pipe oddělovač
                headers = {
                    'User-Agent': hellspy.USER_AGENT,
                    'Referer': 'https://hellspy.to/'
                }
                stream_url = stream_url + '|' + urllib.parse.urlencode(headers)
        except Exception as e:
            log_debug("Chyba při získávání streamu z Hellspy: " + str(e))
            stream_url = None
    else:
        stream_url = get_webshare_direct_url(file_id, wst_token=wst_token)

    if not stream_url:
        log_debug("Nepodařilo se získat přímou URL ke streamu.")
        if is_prehrajto:
            xbmcgui.Dialog().notification("Přehraj.to", "Nepodařilo se načíst stream ze serveru", xbmcgui.NOTIFICATION_ERROR, 3500)
        elif is_english:
            xbmcgui.Dialog().notification("Anglický zdroj", "Nepodařilo se rozbalit odkaz streamu", xbmcgui.NOTIFICATION_ERROR, 3500)
        elif is_hellspy:
            xbmcgui.Dialog().notification("HellSpy", "Soubor nelze přehrát (CDN odmítla přístup / 401)", xbmcgui.NOTIFICATION_ERROR, 4000)
        else:
            xbmcgui.Dialog().notification("Přehrávač", "Nepodařilo se získat přímou URL ke streamu", xbmcgui.NOTIFICATION_ERROR, 3500)
        if not from_popup and handle >= 0:
            xbmcplugin.setResolvedUrl(handle=handle, succeeded=False, listitem=xbmcgui.ListItem())
        return

    # 4. Vytvoř ListItem a nastav přímou adresu ke streamu
    if season_num > 0 and episode_num > 0:
        if ep_name:
            label_text = f"{title} - S{season_num:02d}E{episode_num:02d} - {ep_name}"
        else:
            label_text = f"{title} - S{season_num:02d}E{episode_num:02d}"
    elif year:
        label_text = f"{title} ({year})"
    else:
        label_text = title

    list_item = xbmcgui.ListItem(label=label_text)
    list_item.setPath(stream_url)

    # 5. Dynamické načtení obrázků z tmdb_details a ep_still
    poster_path = tmdb_details.get('poster_path', '')
    backdrop_path = tmdb_details.get('backdrop_path', '')

    poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''
    fanart_url = f"https://image.tmdb.org/t/p/original{backdrop_path}" if backdrop_path else ''

    art = {
        'poster': poster_url,
        'fanart': fanart_url,
        'thumb': ep_still or poster_url
    }
    if ep_still:
        art['still'] = ep_still
    list_item.setArt(art)
    
    # 6. Nastavení informací o médiu pro Kodi VideoInfoTag
    info_tag = list_item.getVideoInfoTag()
    
    if season_num > 0 or episode_num > 0:
        info_tag.setMediaType('episode')
        info_tag.setTvShowTitle(title)
        ep_display_title = ep_name if ep_name else f"Epizoda {episode_num}"
        info_tag.setTitle(f"{title} - S{season_num:02d}E{episode_num:02d} - {ep_display_title}" if ep_name else f"{title} - S{season_num:02d}E{episode_num:02d}")
        
        # Popisek u epizody seriálu: popisek daného dílu, nikoli celého seriálu!
        plot = ep_plot or tmdb_details.get('overview', '')
        if plot:
            info_tag.setPlot(plot)
        if season_num > 0:
            info_tag.setSeason(season_num)
        if episode_num > 0:
            info_tag.setEpisode(episode_num)
    else:
        info_tag.setMediaType('movie')
        info_tag.setTitle(title)
        plot = tmdb_details.get('overview', '')
        if plot:
            info_tag.setPlot(plot)
        
    if tmdb_id:
        info_tag.setUniqueID(str(tmdb_id), type='tmdb')

    # 7. Uložení metadat do DB a kontrola rozkoukaného bodu
    try:
        from . import db
        combined_details = {**tmdb_details, **tmdb_info}
        if ep_name:
            combined_details['episode_name'] = ep_name
        if ep_plot:
            combined_details['episode_plot'] = ep_plot
            combined_details['overview'] = ep_plot
        if ep_still:
            combined_details['episode_still'] = ep_still
        if poster_url and 'poster' not in combined_details:
            combined_details['poster'] = poster_url
        if fanart_url and 'fanart' not in combined_details:
            combined_details['fanart'] = fanart_url
        if tmdb_id:
            db.save_item_metadata(tmdb_id, 'episode' if (season_num > 0 or episode_num > 0) else 'movie', title, season_num, episode_num, combined_details)

        item_status = db.get_item_watch_status(tmdb_id, season_num, episode_num)
        resume_time = item_status.get('resume_time', 0) if item_status else 0
        total_time = item_status.get('total_time', 0) if item_status else 0
        is_watched = item_status.get('watched', False) if item_status else False

        if is_watched:
            info_tag.setPlaycount(1)

        if resume_time > 15 and not is_watched:
            def _format_time(s):
                s = int(s)
                h = s // 3600
                m = (s % 3600) // 60
                sec = s % 60
                if h > 0:
                    return f"{h:02d}:{m:02d}:{sec:02d}"
                return f"{m:02d}:{sec:02d}"

            time_str = _format_time(resume_time)
            choice = xbmcgui.Dialog().yesno(
                "Pokračovat v přehrávání",
                f"Byl nalezen rozkoukaný bod v čase [COLOR orange]{time_str}[/COLOR].\nChcete pokračovat v přehrávání?",
                yeslabel="Pokračovat",
                nolabel="Od začátku"
            )
            if choice:
                log_debug(f"Uživatel zvolil pokračovat od {resume_time}s")
                xbmcgui.Window(10000).setProperty("webshare_resume_seek", str(resume_time))
                info_tag.setResumePoint(resume_time, total_time)
                list_item.setProperty('ResumeTime', str(resume_time))
                list_item.setProperty('TotalTime', str(total_time))
            else:
                log_debug("Uživatel zvolil přehrát od začátku")
                xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
                info_tag.setResumePoint(0, total_time)
                list_item.setProperty('ResumeTime', '0')
        else:
            xbmcgui.Window(10000).clearProperty("webshare_resume_seek")

        active_meta = {
            'file_id': file_id,
            'file_name': file_name,
            'source': stream_source or 'webshare',
            'tmdb_id': str(tmdb_id) if tmdb_id else '',
            'media_type': media_type,
            'title': title,
            'season': season_num,
            'episode': episode_num,
            'details': combined_details,
        }
        xbmcgui.Window(10000).setProperty("webshare_active_media", json.dumps(active_meta))

        # Integrace UpNext pro seriály
        if season_num > 0 and episode_num > 0 and tmdb_id:
            send_upnext_notification(
                tmdb_id=tmdb_id,
                show_title=title,
                season_num=season_num,
                episode_num=episode_num,
                current_title=ep_name,
                current_thumb=ep_still or poster_url,
                poster_url=poster_url,
                fanart_url=fanart_url,
                list_item=list_item
            )
    except Exception as e:
        log_debug(f"Chyba při inicializaci stavu rozkoukání v přehrávači: {e}")

    # 8. Předání připraveného ListItemu Kodi přehrávači
    if from_popup:
        log_debug(f"Spouštím přehrávání z popup dialogu přes xbmc.Player: {title}")
        xbmc.Player().play(item=stream_url, listitem=list_item)
    else:
        xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=list_item)


def send_upnext_notification(tmdb_id, show_title, season_num, episode_num, current_title, current_thumb, poster_url, fanart_url, list_item=None):
    """Připraví metadata a odešle signál do doplňku service.upnext pro zobrazení výzvy k dalšímu dílu."""
    if not (season_num > 0 and episode_num > 0 and tmdb_id):
        return

    next_season = season_num
    next_ep = episode_num + 1

    next_title = f"Epizoda {next_ep}"
    next_thumb = current_thumb or poster_url or ""
    try:
        import xbmcaddon
        from . import tmdb
        addon = xbmcaddon.Addon()
        tmdb_key = addon.getSetting('tmdb_api_key')
        if tmdb_key:
            s_data = tmdb.get_season_details(tmdb_id, next_season, tmdb_key)
            ep_found = False
            for ep in s_data.get('episodes', []):
                if ep.get('episode_number') == next_ep:
                    next_title = ep.get('name') or next_title
                    if ep.get('still_path'):
                        next_thumb = "https://image.tmdb.org/t/p/w500" + str(ep.get('still_path'))
                    ep_found = True
                    break
            if not ep_found:
                next_season += 1
                next_ep = 1
                s2_data = tmdb.get_season_details(tmdb_id, next_season, tmdb_key)
                for ep in s2_data.get('episodes', []):
                    if ep.get('episode_number') == next_ep:
                        next_title = ep.get('name') or f"S{next_season:02d}E01"
                        if ep.get('still_path'):
                            next_thumb = "https://image.tmdb.org/t/p/w500" + str(ep.get('still_path'))
                        ep_found = True
                        break
    except Exception as e:
        log_debug(f"UpNext: Chyba při zjišťování další epizody: {e}")

    encoded_title = urllib.parse.quote_plus(show_title or "")
    next_play_url = f"plugin://plugin.video.webshare.stream.cinema.v2/?mode=play_next_episode&tmdb_id={tmdb_id}&season={next_season}&episode={next_ep}&title={encoded_title}"

    if list_item:
        list_item.setProperty('UpNext.NextTitle', next_title)
        list_item.setProperty('UpNext.NextEpisode', str(next_ep))
        list_item.setProperty('UpNext.NextSeason', str(next_season))
        list_item.setProperty('UpNext.NextStill', next_thumb)
        list_item.setProperty('UpNext.NextShowTitle', show_title)
        list_item.setProperty('UpNext.PlayURL', next_play_url)

    try:
        import importlib
        addonsignals = importlib.import_module("addonsignals")
        AddonSignals = getattr(addonsignals, "AddonSignals", None)
        if AddonSignals:
            data = {
                "current_episode": {
                    "title": current_title or f"Epizoda {episode_num}",
                    "episode": episode_num,
                    "season": season_num,
                    "showtitle": show_title,
                    "art": {
                        "thumb": current_thumb or poster_url or "",
                        "fanart": fanart_url or ""
                    },
                    "unique_id": {"tmdb": str(tmdb_id)}
                },
                "next_episode": {
                    "title": next_title,
                    "episode": next_ep,
                    "season": next_season,
                    "showtitle": show_title,
                    "art": {
                        "thumb": next_thumb,
                        "fanart": fanart_url or ""
                    },
                    "play_url": next_play_url,
                    "unique_id": {"tmdb": str(tmdb_id)}
                },
                "notification_time": 30
            }
            AddonSignals.send('service.upnext', 'upnext_data', data)
            log_debug(f"UpNext: Úspěšně odeslána data pro další díl S{next_season:02d}E{next_ep:02d} ({next_title})")
    except Exception:
        pass
    
def get_webshare_direct_url(file_id, wst_token="", password=None, silent=False, timeout=None):
    """
    Získá přímý streamovací odkaz z Webshare API s podporou hesel a ošetřením chyb.
    
    :param file_id: Identifikátor souboru na Webshare (ident)
    :param wst_token: Uživatelský token získaný při přihlášení (Webshare Token)
    :param password: Heslo k souboru (pokud je chráněn)
    :param silent: Pokud je True, nezobrazuje GUI dialogy ani chybové notifikace (pro ověřování/cache)
    :param timeout: Volitelný timeout pro HTTP požadavek (výchozí 3s pro silent, 10s pro přehrávání)
    :return: Přímá HTTPS URL pro přehrání nebo None
    """
    api_url = "https://webshare.cz/api/file_link/"
    api_timeout = timeout if timeout is not None else (3.0 if silent else 10.0)
    
    payload = {
        'ident': file_id,
        'wst': wst_token
    }
    if password:
        payload['password'] = password
    
    def _call_api(req_payload):
        encoded_data = urllib.parse.urlencode(req_payload).encode('utf-8')
        request = urllib.request.Request(
            url=api_url,
            data=encoded_data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )
        with urllib.request.urlopen(request, timeout=api_timeout) as response:
            res_body = response.read().decode('utf-8')
            import xml.etree.ElementTree as ET
            root = ET.fromstring(res_body)
            status = root.findtext('status')
            code = root.findtext('code', '')
            message = root.findtext('message', 'Neznámá chyba Webshare API')
            link = root.findtext('link')
            return status, code, message, link

    try:
        status, code, message, link = _call_api(payload)
        
        is_password_issue = (
            code in ('FILE_LINK_FATAL_2', 'FILE_LINK_FATAL_3') or
            'password' in message.lower() or
            'heslo' in message.lower() or
            'hesl' in message.lower()
        )
        
        if status != 'OK' and is_password_issue:
            log_debug(f"Soubor {file_id} vyžaduje heslo ({code}: {message})")
            if silent:
                return None
            user_pwd = xbmcgui.Dialog().input("Tento soubor je chráněn heslem. Zadejte heslo:", type=xbmcgui.INPUT_ALPHANUM)
            if user_pwd:
                payload['password'] = user_pwd
                status, code, message, link = _call_api(payload)
                if status == 'OK' and link:
                    return link
                else:
                    xbmcgui.Dialog().notification("Chyba hesla", "Zadané heslo k souboru je nesprávné.", xbmcgui.NOTIFICATION_ERROR)
                    return None
            else:
                xbmcgui.Dialog().notification("Přehrávání zrušeno", "Soubor vyžaduje heslo.", xbmcgui.NOTIFICATION_WARNING)
                return None

        if status == 'OK' and link:
            return link
        else:
            log_debug(f"[Webshare Addon Error] {code}: {message}")
            if not silent:
                xbmcgui.Dialog().notification("Webshare chyba", f"{message}", xbmcgui.NOTIFICATION_ERROR)
            return None

    except Exception as e:
        if not silent:
            log_debug(f"[Webshare Addon Error] Selhalo volání API: {e}")
            xbmcgui.Dialog().notification("Webshare chyba", f"Nelze načíst odkaz: {e}", xbmcgui.NOTIFICATION_ERROR)
        else:
            log_debug(f"Tiché ověření odkazu pro {file_id} selhalo / vypršel čas ({api_timeout}s): {e}")
        return None