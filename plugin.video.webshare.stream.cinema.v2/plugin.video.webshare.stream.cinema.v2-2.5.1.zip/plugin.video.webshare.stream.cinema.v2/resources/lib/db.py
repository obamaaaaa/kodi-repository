import json
import os
import sqlite3
import time
try:
    import xbmcvfs
    ADDON_DATA_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.webshare.stream.cinema.v2/')
except Exception:
    ADDON_DATA_DIR = ""

if not ADDON_DATA_DIR:
    ADDON_DATA_DIR = os.path.join(os.path.expanduser("~"), ".kodi_addon_data")

if not os.path.exists(ADDON_DATA_DIR):
    os.makedirs(ADDON_DATA_DIR, exist_ok=True)

DB_PATH = os.path.join(ADDON_DATA_DIR, 'tmdb_cache.db')


try:
    import xbmc
    def log_db(msg):
        xbmc.log(f"[Webshare DB] {msg}", xbmc.LOGINFO)
except ImportError:
    def log_db(msg):
        print(f"[Webshare DB] {msg}")

def _get_connection():
    """Vrátí připojení k SQLite databázi."""
    return sqlite3.connect(DB_PATH)

def init_db():
    """Vytvoří všechny potřebné tabulky a provede migraci starších verzí databáze."""
    with _get_connection() as conn:
        cursor = conn.cursor()
        
        # 1. Tabulka pro API Cache
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_cache (
                url TEXT PRIMARY KEY,
                data TEXT,
                timestamp INTEGER
            )
        ''')
        
        # 2. Tabulka pro Historii vyhledávání
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS search_history (
                query TEXT PRIMARY KEY,
                timestamp INTEGER
            )
        ''')
        
        # 3. Tabulka pro Rozkoukané a Zhlédnuté
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS watch_status (
                tmdb_id TEXT,
                season INTEGER DEFAULT 0,
                episode INTEGER DEFAULT 0,
                media_type TEXT,
                title TEXT,
                resume_time REAL,
                total_time REAL,
                watched INTEGER,
                last_watched INTEGER,
                details TEXT,
                PRIMARY KEY (tmdb_id, season, episode)
            )
        ''')
        
        # 4. Tabulka pro Oblíbené položky
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS favorites (
                tmdb_id TEXT,
                media_type TEXT,
                season INTEGER DEFAULT 0,
                episode INTEGER DEFAULT 0,
                title TEXT,
                year TEXT,
                poster TEXT,
                fanart TEXT,
                overview TEXT,
                added_at INTEGER,
                details TEXT,
                PRIMARY KEY (tmdb_id, media_type, season, episode)
            )
        ''')
        
        # Automatická migrace: pokud stará tabulka neměla složený primární klíč
        try:
            cursor.execute("SELECT sql FROM sqlite_master WHERE name='watch_status'")
            row = cursor.fetchone()
            if row and "PRIMARY KEY (tmdb_id, season, episode)" not in row[0]:
                log_db("Detekováno staré schéma watch_status. Spouštím migraci na složený primární klíč...")
                cursor.execute("ALTER TABLE watch_status RENAME TO watch_status_old")
                cursor.execute('''
                    CREATE TABLE watch_status (
                        tmdb_id TEXT,
                        season INTEGER DEFAULT 0,
                        episode INTEGER DEFAULT 0,
                        media_type TEXT,
                        title TEXT,
                        resume_time REAL,
                        total_time REAL,
                        watched INTEGER,
                        last_watched INTEGER,
                        details TEXT,
                        PRIMARY KEY (tmdb_id, season, episode)
                    )
                ''')
                cursor.execute("PRAGMA table_info(watch_status_old)")
                old_cols = [c[1] for c in cursor.fetchall()]
                s_col = "COALESCE(season, 0)" if "season" in old_cols else "0"
                e_col = "COALESCE(episode, 0)" if "episode" in old_cols else "0"
                cursor.execute(f'''
                    INSERT OR IGNORE INTO watch_status
                    (tmdb_id, season, episode, media_type, title, resume_time, total_time, watched, last_watched, details)
                    SELECT tmdb_id, {s_col}, {e_col}, media_type, title, resume_time, total_time, watched, last_watched, details
                    FROM watch_status_old
                ''')
                cursor.execute("DROP TABLE watch_status_old")
                log_db("Migrace watch_status úspěšně dokončena.")
        except Exception as e:
            log_db(f"[DB Migration Error] {e}")

        conn.commit()



# ==========================================
# 1. TMDB API CACHE
# ==========================================

def get_cache(cache_key, ttl_days=7):
    """Načte data z cache podle URL. Vrací Python dict/list nebo None."""
    init_db()
    now = int(time.time())
    ttl_seconds = ttl_days * 24 * 60 * 60

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT data, timestamp FROM api_cache WHERE url = ?", (cache_key,))
            row = cursor.fetchone()

            if row:
                cached_data, timestamp = row
                if now - timestamp < ttl_seconds:
                    return json.loads(cached_data)
    except Exception as e:
        print(f"[DB Cache Error] Chyba při čtení: {e}")

    return None


def set_cache(cache_key, data):
    """Uloží nebo přepíše data v cache pro dané URL."""
    init_db()
    now = int(time.time())

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR REPLACE INTO api_cache (url, data, timestamp) VALUES (?, ?, ?)",
                (cache_key, json.dumps(data), now)
            )
            conn.commit()
    except Exception as e:
        print(f"[DB Cache Error] Chyba při zápisu: {e}")


def get_availability_cache(media_type, tmdb_id, ttl_seconds=86400):
    """Načte data o dostupnosti z 24h SQLite cache (rychlé znovunačtení bez sítě)."""
    key = f"avail_{media_type}_{tmdb_id}"
    return get_cache(key, ttl_days=ttl_seconds / 86400.0)


def set_availability_cache(media_type, tmdb_id, data):
    """Uloží data o dostupnosti do SQLite cache na 24 hodin."""
    key = f"avail_{media_type}_{tmdb_id}"
    set_cache(key, data)


def cleanup_cache(ttl_days=7):
    """Smaže záznamy starší než X dní."""
    init_db()
    now = int(time.time())
    expiration_time = now - (ttl_days * 24 * 60 * 60)

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM api_cache WHERE timestamp < ?", (expiration_time,))
            conn.commit()
    except Exception as e:
        print(f"[DB Cache Error] Chyba při čištění: {e}")


# ==========================================
# 2. HISTORIE VYHLEDÁVÁNÍ
# ==========================================

def add_search_query(query):
    """Uloží nový hledaný výraz nebo aktualizuje čas vyhledání."""
    if not query or not query.strip():
        return
    
    init_db()
    now = int(time.time())
    cleaned_query = query.strip()

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR REPLACE INTO search_history (query, timestamp) VALUES (?, ?)",
                (cleaned_query, now)
            )
            conn.commit()
    except Exception as e:
        print(f"[DB Search Error] Chyba při ukládání hledání: {e}")


def get_search_history(limit=20):
    """Vrátí seznam naposledy hledaných výrazů seřazený od nejnovějších."""
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT query FROM search_history ORDER BY timestamp DESC LIMIT ?", 
                (limit,)
            )
            rows = cursor.fetchall()
            return [row[0] for row in rows]
    except Exception as e:
        print(f"[DB Search Error] Chyba při načítání historie: {e}")
        return []


def remove_search_query(query):
    """Odstraní jeden konkrétní dotaz z historie."""
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM search_history WHERE query = ?", (query,))
            conn.commit()
    except Exception as e:
        print(f"[DB Search Error] Chyba při mazání položky z historie: {e}")


def clear_search_history():
    """Vymaže celou historii vyhledávání."""
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM search_history")
            conn.commit()
    except Exception as e:
        print(f"[DB Search Error] Chyba při mazání historie: {e}")


def clear_watch_history():
    """Vymaže všechny záznamy o rozkoukaných a zhlédnutých položkách."""
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM watch_status")
            conn.commit()
    except Exception as e:
        print(f"[DB Watch Error] Chyba při mazání historie sledování: {e}")


# ==========================================
# 3. ROZKOUKANÉ A ZHLÉDNUTÉ
# ==========================================
def save_item_metadata(tmdb_id, media_type, title, season=0, episode=0, details=None):
    """Uloží metadata položky (plakát, popis, rok atd.) do DB bez zrušení stavu sledování."""
    if not tmdb_id:
        return
    init_db()
    normalized_media = str(media_type or "movie").lower()
    if normalized_media in {"tv", "tvshow", "series", "episode"} or int(season or 0) > 0 or int(episode or 0) > 0:
        media_type = "tv"
    else:
        media_type = "movie"
    season_val = int(season or 0)
    episode_val = int(episode or 0)
    details_json = json.dumps(details) if (details and isinstance(details, dict)) else "{}"
    now = int(time.time())

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO watch_status
                (tmdb_id, season, episode, media_type, title, resume_time, total_time, watched, last_watched, details)
                VALUES (?, ?, ?, ?, ?, 0, 0, 0, ?, ?)
                ON CONFLICT(tmdb_id, season, episode) DO UPDATE SET
                    media_type = excluded.media_type,
                    title = CASE WHEN excluded.title != '' THEN excluded.title ELSE watch_status.title END,
                    details = CASE WHEN excluded.details != '{}' THEN excluded.details ELSE watch_status.details END
            ''', (str(tmdb_id), season_val, episode_val, media_type, title or "", now, details_json))
            conn.commit()
    except Exception as e:
        print(f"[DB Watch Error] Chyba při ukládání metadat: {e}")

def update_watch_status(tmdb_id, media_type, title, resume_time, total_time, season=0, episode=0, details=None):
    """
    Uloží nebo aktualizuje stav přehrávání videa (filmu nebo epizody seriálu).
    Položka se automaticky označí jako zhlédnutá (watched=1), pokud uživatel dokoukal >= 90 %.
    Pokud je čas < 15s a není watched, resume_time se vynuluje (zabrání zanechání smetí v rozkoukaných).
    """
    if not tmdb_id:
        return

    normalized_media = str(media_type or "movie").lower()
    if normalized_media in {"tv", "tvshow", "series", "episode"} or int(season or 0) > 0 or int(episode or 0) > 0:
        media_type = "tv"
    else:
        media_type = "movie"

    init_db()
    now = int(time.time())
    season_val = int(season or 0)
    episode_val = int(episode or 0)
    resume_time = float(resume_time or 0)
    total_time = float(total_time or 0)

    watched = 0
    if total_time > 0 and (resume_time / total_time) >= 0.90:
        watched = 1
        resume_time = 0
    elif resume_time < 15:
        resume_time = 0

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            # Načteme existující hodnoty, abychom nepřepsali dříve uložené detaily nebo stav
            cursor.execute('''
                SELECT title, details, watched FROM watch_status
                WHERE tmdb_id = ? AND season = ? AND episode = ?
            ''', (str(tmdb_id), season_val, episode_val))
            existing = cursor.fetchone()

            existing_title = existing[0] if existing else ""
            existing_details = existing[1] if existing else "{}"
            existing_watched = existing[2] if existing else 0

            if existing_watched == 1 and resume_time == 0:
                watched = 1

            final_title = title or existing_title or "Neznámý název"

            if details and isinstance(details, dict) and len(details) > 0:
                details_json = json.dumps(details)
            elif existing_details and existing_details != "{}":
                details_json = existing_details
            else:
                details_json = "{}"

            cursor.execute('''
                INSERT INTO watch_status 
                (tmdb_id, season, episode, media_type, title, resume_time, total_time, watched, last_watched, details)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(tmdb_id, season, episode) DO UPDATE SET
                    media_type = excluded.media_type,
                    title = excluded.title,
                    resume_time = excluded.resume_time,
                    total_time = CASE WHEN excluded.total_time > 0 THEN excluded.total_time ELSE watch_status.total_time END,
                    watched = excluded.watched,
                    last_watched = excluded.last_watched,
                    details = CASE WHEN excluded.details != '{}' THEN excluded.details ELSE watch_status.details END
            ''', (str(tmdb_id), season_val, episode_val, media_type, final_title, resume_time, total_time, watched, now, details_json))
            conn.commit()
            log_db(f"Uloženo do DB: TMDB ID={tmdb_id}, S{season_val}E{episode_val}, Typ={media_type}, Název={final_title}, Resume={resume_time:.1f}s, Total={total_time:.1f}s, Watched={watched}")
    except Exception as e:
        log_db(f"[DB Watch Error] Chyba při ukládání stavu (TMDB ID={tmdb_id}): {e}")


def mark_item_watched(tmdb_id, media_type, season=0, episode=0, title=None, details=None):
    """Ručně označí položku jako zhlédnutou (watched=1, resume_time=0)."""
    if not tmdb_id:
        return
    init_db()
    normalized_media = str(media_type or "movie").lower()
    if normalized_media in {"tv", "tvshow", "series", "episode"} or int(season or 0) > 0 or int(episode or 0) > 0:
        media_type = "tv"
    else:
        media_type = "movie"
    now = int(time.time())
    season_val = int(season or 0)
    episode_val = int(episode or 0)
    details_json = json.dumps(details) if (details and isinstance(details, dict)) else "{}"

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            if media_type == "tv" and season_val == 0 and episode_val == 0:
                cursor.execute('''
                    INSERT INTO watch_status
                    (tmdb_id, season, episode, media_type, title, resume_time, total_time, watched, last_watched, details)
                    VALUES (?, 0, 0, 'tv', ?, 0, 0, 1, ?, ?)
                    ON CONFLICT(tmdb_id, season, episode) DO UPDATE SET
                        watched = 1,
                        resume_time = 0,
                        last_watched = excluded.last_watched,
                        details = CASE WHEN excluded.details != '{}' THEN excluded.details ELSE watch_status.details END
                ''', (str(tmdb_id), title or "", now, details_json))
                cursor.execute('''
                    UPDATE watch_status
                    SET watched = 1, resume_time = 0, last_watched = ?
                    WHERE tmdb_id = ? AND media_type = 'tv'
                ''', (now, str(tmdb_id)))
            elif media_type == "tv" and season_val > 0 and episode_val == 0:
                cursor.execute('''
                    UPDATE watch_status
                    SET watched = 1, resume_time = 0, last_watched = ?
                    WHERE tmdb_id = ? AND season = ?
                ''', (now, str(tmdb_id), season_val))
                cursor.execute('''
                    INSERT INTO watch_status
                    (tmdb_id, season, episode, media_type, title, resume_time, total_time, watched, last_watched, details)
                    VALUES (?, ?, 0, 'tv', ?, 0, 0, 1, ?, ?)
                    ON CONFLICT(tmdb_id, season, episode) DO UPDATE SET
                        watched = 1,
                        resume_time = 0,
                        last_watched = excluded.last_watched
                ''', (str(tmdb_id), season_val, title or "", now, details_json))
            else:
                cursor.execute('''
                    INSERT INTO watch_status
                    (tmdb_id, season, episode, media_type, title, resume_time, total_time, watched, last_watched, details)
                    VALUES (?, ?, ?, ?, ?, 0, 0, 1, ?, ?)
                    ON CONFLICT(tmdb_id, season, episode) DO UPDATE SET
                        watched = 1,
                        resume_time = 0,
                        last_watched = excluded.last_watched,
                        title = CASE WHEN excluded.title != '' THEN excluded.title ELSE watch_status.title END,
                        details = CASE WHEN excluded.details != '{}' THEN excluded.details ELSE watch_status.details END
                ''', (str(tmdb_id), season_val, episode_val, media_type, title or "", now, details_json))
            conn.commit()
    except Exception as e:
        print(f"[DB Watch Error] Chyba při označování jako zhlédnuté: {e}")

def mark_item_unwatched(tmdb_id, media_type, season=0, episode=0):
    """Ručně označí položku jako nezhlédnutou (smaže stav sledování)."""
    if not tmdb_id:
        return
    init_db()
    normalized_media = str(media_type or "movie").lower()
    season_val = int(season or 0)
    episode_val = int(episode or 0)

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            if normalized_media in {"tv", "tvshow", "series"} and season_val == 0 and episode_val == 0:
                cursor.execute("DELETE FROM watch_status WHERE tmdb_id = ?", (str(tmdb_id),))
            elif normalized_media in {"tv", "tvshow", "series"} and season_val > 0 and episode_val == 0:
                cursor.execute("DELETE FROM watch_status WHERE tmdb_id = ? AND season = ?", (str(tmdb_id), season_val))
            else:
                cursor.execute("DELETE FROM watch_status WHERE tmdb_id = ? AND season = ? AND episode = ?",
                               (str(tmdb_id), season_val, episode_val))
            conn.commit()
    except Exception as e:
        print(f"[DB Watch Error] Chyba při označování jako nezhlédnuté: {e}")

def remove_from_in_progress(tmdb_id, media_type="movie", season=0, episode=0):
    """Odebere položku z rozkoukaných."""
    if not tmdb_id:
        return
    init_db()
    normalized_media = str(media_type or "movie").lower()
    season_val = int(season or 0)
    episode_val = int(episode or 0)

    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            if normalized_media in {"tv", "tvshow", "series"} and season_val == 0 and episode_val == 0:
                cursor.execute("UPDATE watch_status SET resume_time = 0 WHERE tmdb_id = ?", (str(tmdb_id),))
                cursor.execute("DELETE FROM watch_status WHERE tmdb_id = ? AND watched = 0", (str(tmdb_id),))
            else:
                cursor.execute('''
                    UPDATE watch_status SET resume_time = 0 
                    WHERE tmdb_id = ? AND season = ? AND episode = ?
                ''', (str(tmdb_id), season_val, episode_val))
                cursor.execute('''
                    DELETE FROM watch_status 
                    WHERE tmdb_id = ? AND season = ? AND episode = ? AND watched = 0
                ''', (str(tmdb_id), season_val, episode_val))
            conn.commit()
    except Exception as e:
        print(f"[DB Watch Error] Chyba při odebírání z rozkoukaných: {e}")

def clear_in_progress_history():
    """Vymaže pouze rozkoukané položky (ponechá zhlédnuté)."""
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE watch_status SET resume_time = 0 WHERE resume_time > 0")
            cursor.execute("DELETE FROM watch_status WHERE watched = 0")
            conn.commit()
    except Exception as e:
        print(f"[DB Watch Error] Chyba při mazání rozkoukaných: {e}")

def clear_watched_only_history():
    """Vymaže pouze zhlédnuté položky (ponechá rozkoukané)."""
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM watch_status WHERE watched = 1")
            conn.commit()
    except Exception as e:
        print(f"[DB Watch Error] Chyba při mazání zhlédnutých: {e}")

def get_in_progress_items(limit=50):
    """
    Vrátí rozkoukané filmy a seriály:
    - Filmy s resume_time > 15 a watched = 0
    - Seriály, které mají rozkoukanou epizodu nebo zhlédnutou epizodu, ale nejsou 100% zhlédnuté.
    Bez duplicitních záznamů pro tentýž seriál.
    """
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. Filmy
            cursor.execute('''
                SELECT tmdb_id, 0 as season, 0 as episode, media_type, title, resume_time, total_time, watched, last_watched, details
                FROM watch_status
                WHERE media_type = 'movie' AND watched = 0 AND resume_time > 15
                ORDER BY last_watched DESC LIMIT ?
            ''', (limit,))
            movie_rows = cursor.fetchall()
            
            # 2. Seriály
            cursor.execute('''
                SELECT tmdb_id, 
                       MAX(last_watched) as max_last_watched,
                       MAX(CASE WHEN resume_time > 15 AND watched = 0 THEN season ELSE 0 END) as cur_season,
                       MAX(CASE WHEN resume_time > 15 AND watched = 0 THEN episode ELSE 0 END) as cur_episode,
                       MAX(CASE WHEN resume_time > 15 AND watched = 0 THEN resume_time ELSE 0 END) as cur_resume,
                       MAX(CASE WHEN resume_time > 15 AND watched = 0 THEN total_time ELSE 0 END) as cur_total,
                       MAX(title) as title,
                       MAX(details) as details
                FROM watch_status
                WHERE media_type IN ('tv', 'episode', 'tvshow', 'series')
                GROUP BY tmdb_id
                ORDER BY max_last_watched DESC LIMIT ?
            ''', (limit,))
            tv_rows = cursor.fetchall()

            all_items = []
            for r in movie_rows:
                all_items.append({
                    'tmdb_id': r[0],
                    'season': 0,
                    'episode': 0,
                    'media_type': 'movie',
                    'title': r[4],
                    'resume_time': r[5],
                    'total_time': r[6],
                    'watched': False,
                    'last_watched': r[8],
                    'details': json.loads(r[9]) if r[9] else {}
                })

            for r in tv_rows:
                tmdb_id = r[0]
                cursor.execute('''
                    SELECT watched FROM watch_status 
                    WHERE tmdb_id = ? AND season = 0 AND episode = 0
                ''', (tmdb_id,))
                root_show = cursor.fetchone()
                if root_show and root_show[0] == 1:
                    continue

                details_dict = json.loads(r[7]) if r[7] else {}
                num_episodes = details_dict.get('number_of_episodes') or 0

                if num_episodes > 0:
                    cursor.execute('''
                        SELECT COUNT(*) FROM watch_status
                        WHERE tmdb_id = ? AND media_type IN ('tv', 'episode', 'tvshow', 'series') AND watched = 1 AND episode > 0
                    ''', (tmdb_id,))
                    w_cnt = cursor.fetchone()[0]
                    if w_cnt >= num_episodes:
                        continue

                all_items.append({
                    'tmdb_id': tmdb_id,
                    'season': r[2],
                    'episode': r[3],
                    'media_type': 'tv',
                    'title': r[6],
                    'resume_time': r[4],
                    'total_time': r[5],
                    'watched': False,
                    'last_watched': r[1],
                    'details': details_dict
                })

            all_items.sort(key=lambda x: x.get('last_watched', 0), reverse=True)
            return all_items[:limit]
    except Exception as e:
        log_db(f"[DB Watch Error] Chyba při načítání rozkoukaných: {e}")
        return []

def get_watched_items(limit=50):
    """
    Vrátí seznam zhlédnutých filmů a 100% dokončených seriálů (bez duplicit).
    """
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. Zhlédnuté filmy
            cursor.execute('''
                SELECT tmdb_id, media_type, title, last_watched, details
                FROM watch_status 
                WHERE media_type = 'movie' AND watched = 1
                ORDER BY last_watched DESC LIMIT ?
            ''', (limit,))
            movie_rows = cursor.fetchall()
            
            # 2. Seriály
            cursor.execute('''
                SELECT tmdb_id, MAX(last_watched) as max_last_watched, MAX(title) as title, MAX(details) as details
                FROM watch_status
                WHERE media_type IN ('tv', 'episode', 'tvshow', 'series')
                GROUP BY tmdb_id
                ORDER BY max_last_watched DESC LIMIT ?
            ''', (limit,))
            tv_rows = cursor.fetchall()

            all_items = []
            for r in movie_rows:
                all_items.append({
                    'tmdb_id': r[0],
                    'media_type': 'movie',
                    'title': r[2],
                    'last_watched': r[3],
                    'details': json.loads(r[4]) if r[4] else {}
                })

            for r in tv_rows:
                tmdb_id = r[0]
                details_dict = json.loads(r[3]) if r[3] else {}
                num_episodes = details_dict.get('number_of_episodes') or 0

                cursor.execute('''
                    SELECT watched FROM watch_status 
                    WHERE tmdb_id = ? AND season = 0 AND episode = 0
                ''', (tmdb_id,))
                root_row = cursor.fetchone()
                is_completed = (root_row and root_row[0] == 1)

                if not is_completed and num_episodes > 0:
                    cursor.execute('''
                        SELECT COUNT(*) FROM watch_status
                        WHERE tmdb_id = ? AND media_type IN ('tv', 'episode', 'tvshow', 'series') AND watched = 1 AND episode > 0
                    ''', (tmdb_id,))
                    w_cnt = cursor.fetchone()[0]
                    if w_cnt >= num_episodes:
                        is_completed = True

                if is_completed:
                    all_items.append({
                        'tmdb_id': tmdb_id,
                        'media_type': 'tv',
                        'title': r[2],
                        'last_watched': r[1],
                        'details': details_dict
                    })

            all_items.sort(key=lambda x: x.get('last_watched', 0), reverse=True)
            return all_items[:limit]
    except Exception as e:
        log_db(f"[DB Watch Error] Chyba při načítání zhlédnutých: {e}")
        return []


def get_playback_history(limit=50):
    """
    Vrátí chronologický přehled nedávno přehrávaných videí (filmy i konkrétní epizody seriálů).
    """
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT tmdb_id, season, episode, media_type, title, resume_time, total_time, watched, last_watched, details
                FROM watch_status
                WHERE last_watched > 0 AND (watched = 1 OR resume_time > 15)
                ORDER BY last_watched DESC LIMIT ?
            ''', (limit,))
            rows = cursor.fetchall()
            items = []
            for r in rows:
                items.append({
                    'tmdb_id': r[0],
                    'season': r[1],
                    'episode': r[2],
                    'media_type': r[3],
                    'title': r[4],
                    'resume_time': r[5],
                    'total_time': r[6],
                    'watched': r[7] == 1,
                    'last_watched': r[8],
                    'details': json.loads(r[9]) if r[9] else {}
                })
            return items
    except Exception as e:
        log_db(f"[DB Watch Error] Chyba při načítání historie přehrávání: {e}")
        return []


def get_item_watch_status(tmdb_id, season=0, episode=0):
    """Vrátí uložený stav přehrávání pro konkrétní TMDB ID, sezónu a epizodu (nebo None)."""
    if not tmdb_id:
        return None
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT resume_time, total_time, watched, title, details 
                FROM watch_status 
                WHERE tmdb_id = ? AND season = ? AND episode = ?
            ''', (str(tmdb_id), int(season or 0), int(episode or 0)))
            row = cursor.fetchone()
            if row:
                return {
                    'resume_time': row[0],
                    'total_time': row[1],
                    'watched': row[2] == 1,
                    'title': row[3],
                    'details': json.loads(row[4]) if row[4] else {}
                }
    except Exception as e:
        print(f"[DB Watch Error] Chyba při zjišťování stavu položky: {e}")
    return None

def get_tv_show_progress(tmdb_id, total_episodes):
    """
    Spočítá procento zhlédnutí seriálu z plně zhlédnutých dílů.
    Pokud je celý seriál označen jako zhlédnutý, vrací 100 %.
    """
    if not tmdb_id:
        return 0
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT watched FROM watch_status
                WHERE tmdb_id = ? AND season = 0 AND episode = 0
            ''', (str(tmdb_id),))
            root = cursor.fetchone()
            if root and root[0] == 1:
                return 100

            if not total_episodes or total_episodes <= 0:
                return 0

            cursor.execute('''
                SELECT COUNT(*) FROM watch_status 
                WHERE tmdb_id = ? AND media_type IN ('tv', 'episode', 'tvshow', 'series') AND watched = 1 AND episode > 0
            ''', (str(tmdb_id),))
            row = cursor.fetchone()
            watched_count = row[0] if row else 0
            return min(100, round((watched_count / total_episodes) * 100))
    except Exception as e:
        print(f"[DB Watch Error] Chyba při výpočtu procent seriálu: {e}")
    return 0

def get_tv_season_progress(tmdb_id, season, total_episodes):
    """Spočítá procento zhlédnutí konkrétní série seriálu z plně zhlédnutých dílů."""
    if not tmdb_id:
        return 0
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT watched FROM watch_status
                WHERE tmdb_id = ? AND season IN (0, ?) AND episode = 0 AND watched = 1
            ''', (str(tmdb_id), int(season)))
            if cursor.fetchone():
                return 100

            if not total_episodes or total_episodes <= 0:
                return 0

            cursor.execute('''
                SELECT COUNT(*) FROM watch_status 
                WHERE tmdb_id = ? AND season = ? AND media_type IN ('tv', 'episode', 'tvshow', 'series') AND watched = 1 AND episode > 0
            ''', (str(tmdb_id), int(season)))
            row = cursor.fetchone()
            watched_count = row[0] if row else 0
            return min(100, round((watched_count / total_episodes) * 100))
    except Exception as e:
        print(f"[DB Watch Error] Chyba při výpočtu procent série: {e}")
    return 0


# ==========================================
# 5. OBLÍBENÉ POLOŽKY (FAVORITES)
# ==========================================

def add_favorite(tmdb_id, media_type, title, year="", poster="", fanart="", overview="", season=0, episode=0, details=None):
    """Přidá položku (film, seriál, epizodu) do oblíbených."""
    init_db()
    now = int(time.time())
    details_str = json.dumps(details) if isinstance(details, (dict, list)) else (details or "")
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO favorites
                (tmdb_id, media_type, season, episode, title, year, poster, fanart, overview, added_at, details)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (str(tmdb_id), str(media_type), int(season), int(episode), str(title), str(year), str(poster), str(fanart), str(overview), now, details_str))
            conn.commit()
            return True
    except Exception as e:
        log_db(f"Chyba při přidávání do oblíbených: {e}")
        return False


def remove_favorite(tmdb_id, media_type, season=0, episode=0):
    """Odebere položku z oblíbených."""
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                DELETE FROM favorites
                WHERE tmdb_id = ? AND media_type = ? AND season = ? AND episode = ?
            ''', (str(tmdb_id), str(media_type), int(season), int(episode)))
            conn.commit()
            return True
    except Exception as e:
        log_db(f"Chyba při odebírání z oblíbených: {e}")
        return False


def is_favorite(tmdb_id, media_type, season=0, episode=0):
    """Zkontroluje, zda je položka v oblíbených."""
    if not tmdb_id:
        return False
    init_db()
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 1 FROM favorites
                WHERE tmdb_id = ? AND media_type = ? AND season = ? AND episode = ?
            ''', (str(tmdb_id), str(media_type), int(season), int(episode)))
            return cursor.fetchone() is not None
    except Exception as e:
        log_db(f"Chyba při kontrole oblíbených: {e}")
        return False


def get_favorites():
    """Vrátí všechny oblíbené položky seřazené od nejnověji přidaných."""
    init_db()
    try:
        with _get_connection() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
                SELECT tmdb_id, media_type, season, episode, title, year, poster, fanart, overview, added_at, details
                FROM favorites
                ORDER BY added_at DESC
            ''')
            rows = cursor.fetchall()
            result = []
            for r in rows:
                item = dict(r)
                if item.get('details'):
                    try:
                        item['details_parsed'] = json.loads(item['details'])
                    except Exception:
                        item['details_parsed'] = {}
                else:
                    item['details_parsed'] = {}
                result.append(item)
            return result
    except Exception as e:
        log_db(f"Chyba při načítání oblíbených: {e}")
        return []