import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import os

#sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

ADDON = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
ADDON_PATH = ADDON.getAddonInfo('path')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

def _icon(name, fallbacks=None):
    """Vrátí cestu k ikoně s ověřením existence a podporou fallbacků."""
    primary = os.path.join(MEDIA_PATH, name)
    if os.path.exists(primary):
        return primary
    if fallbacks:
        for fb in fallbacks:
            if not fb:
                continue
            if fb.startswith('Default'):
                return fb
            fb_path = os.path.join(MEDIA_PATH, fb) if not os.path.isabs(fb) else fb
            if os.path.exists(fb_path):
                return fb_path
    return primary

ICONS = {
    'SEARCH': _icon('search.png'),
    'SEARCH_PLUS': _icon('searchplus.png', ['search.png']),
    'FILM': _icon('film.png'),
    'HISTORY': _icon('history.png'),
    'RESUME': _icon('history_resume.png', ['resume.png']),
    'WATCHED': _icon('history_watched.png', ['watched.png']),
    'POPULAR': _icon('popular.png', ['fire.png', 'trending.png', 'star.png']),
    'FIRE': _icon('fire.png', ['popular.png']),
    'TREND': _icon('trending.png', ['trend.png', 'fire.png']),
    'TRENDING': _icon('trending.png', ['trend.png', 'fire.png']),
    'NEW': _icon('new.png', ['news.png']),
    'NEWS': _icon('news.png', ['new.png']),
    'THEATRE': _icon('theatre.png'),
    'STAR': _icon('star.png'),
    'LOVE': _icon('love.png', ['star.png']),
    'FAVORITES': _icon('love.png', ['star.png']),
    'GENRES': _icon('genres.png'),
    'CZ': _icon('czech.png', ['cz.png']),
    'CZECH': _icon('czech.png', ['cz.png']),
    'MICROPHONE': _icon('microphone.png', ['czech.png']),
    'TRANSCRIPT': _icon('subtitles.png', ['transcript.png']),
    'SUBTITLES': _icon('subtitles.png', ['transcript.png']),
    'CALENDAR': _icon('calendar.png'),
    'BOOK': _icon('book.png'),
    'OVERLAY_WATCHED': _icon('watched.png', ['history_watched.png']),
    'OVERLAY_RESUME': _icon('resume.png', ['history_resume.png']),
    '4K': _icon('4k.png'),
    '1080': _icon('1080p.png'),
    '1080P': _icon('1080p.png'),
    '720': _icon('720p.png'),
    '720P': _icon('720p.png'),
    'SD': _icon('sd.png'),
    'ACTOR': _icon('actor.png', ['person.png', 'searchplus.png']),
    'DIRECTOR': _icon('director-chair.png', ['director.png', 'clapperboard.png', 'searchplus.png']),
    'DIRECTOR_CHAIR': _icon('director-chair.png', ['director.png']),
    'SETTINGS': _icon('settings.png', ['DefaultAddonService.png']),
    'DEF_VIDEO': 'DefaultVideo.png',
    'DEF_FOLDER': 'DefaultFolder.png',
    'NEXT': _icon('next.png', ['DefaultIconNext.png', 'book.png']),
    'PREV': _icon('prev.png', ['DefaultIconPrevious.png', 'book.png'])
}

def format_release_date_cz(raw_date):
    """Převede datum (např. '2026-02-28' nebo '2026-02-28T00:00:00Z') na formát '28.02.2026'."""
    if not raw_date:
        return ""
    try:
        d_str = str(raw_date).split('T')[0].strip()
        parts = d_str.split('-')
        if len(parts) == 3 and len(parts[0]) == 4:
            y = parts[0]
            m = parts[1].zfill(2)
            d = parts[2].zfill(2)
            return f"{d}.{m}.{y}"
    except Exception:
        pass
    return ""

def build_item_plot(overview, release_date=None, english_title=None, main_title=None):
    """
    Sestaví popis položky pro zobrazení v Kodi infopanelu.
    Na začátek přidá šedý jednořádkový text:
    [COLOR gray]EnglishNameHere · 28.02.2026[/COLOR]
    Anglický název se zobrazí pouze pokud existuje a není shodný s hlavním názvem.
    """
    date_formatted = format_release_date_cz(release_date)

    en_clean = (english_title or "").strip()
    main_clean = (main_title or "").strip()

    show_en = False
    if en_clean and main_clean:
        if en_clean.lower() != main_clean.lower():
            show_en = True
    elif en_clean:
        show_en = True

    header_parts = []
    if show_en:
        header_parts.append(en_clean)
    if date_formatted:
        header_parts.append(date_formatted)

    clean_overview = (overview or "").strip()

    if header_parts:
        header_text = " · ".join(header_parts)
        header = f"[COLOR gray]{header_text}[/COLOR]"
        if clean_overview:
            return f"{header}\n\n{clean_overview}"
        return header

    return clean_overview

def format_fps(fps):
    """Převede číselnou hodnotu FPS na čitelný formát pro uživatele (např. 60 FPS, 23.976 FPS, 24 FPS)."""
    if not fps:
        return ""
    try:
        f = float(fps)
        if f <= 0:
            return ""
        if abs(f - 23.976) < 0.015:
            return "23.976 FPS"
        if abs(f - 24.0) < 0.02:
            return "24 FPS"
        if abs(f - 25.0) < 0.05:
            return "25 FPS"
        if abs(f - 29.97) < 0.015:
            return "29.97 FPS"
        if abs(f - 30.0) < 0.02:
            return "30 FPS"
        if abs(f - 50.0) < 0.05:
            return "50 FPS"
        if abs(f - 59.94) < 0.015:
            return "59.94 FPS"
        if abs(f - 60.0) < 0.02:
            return "60 FPS"
        if abs(f - 120.0) < 0.05:
            return "120 FPS"
        if f.is_integer():
            return f"{int(f)} FPS"
        return f"{f:.2f} FPS"
    except (ValueError, TypeError):
        return ""