import os
import re
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcvfs = None


def get_advancedsettings_path():
    """Vrátí absolutní cestu k advancedsettings.xml v Kodi userdata."""
    if xbmcvfs:
        try:
            return xbmcvfs.translatePath('special://userdata/advancedsettings.xml')
        except Exception:
            pass

    appdata = os.environ.get('APPDATA', '')
    if appdata:
        return os.path.join(appdata, 'Kodi', 'userdata', 'advancedsettings.xml')
    return ""


def get_current_buffer_info():
    """
    Zkontroluje aktuální nastavení vyrovnávací paměti (bufferu) v Kodi.
    Vrací slovník s informacemi o paměti, režimu a doporučení.
    """
    path = get_advancedsettings_path()
    default_info = {
        'exists': False,
        'configured': False,
        'memory_size_bytes': 20971520,  # Tovární hodnota Kodi je 20 MB
        'memory_size_mb': 20,
        'buffermode': 0,
        'readfactor': 4,
        'is_small': True,
        'status_text': "20 MB (Výchozí Kodi - způsobuje záseky u 4K)"
    }

    if not path or not os.path.exists(path):
        return default_info

    try:
        tree = ET.parse(path)
        root = tree.getroot()
        cache = root.find('cache')
        network = root.find('network')

        mem_bytes = None
        b_mode = 1
        r_factor = 4

        if cache is not None:
            mem_elem = cache.find('memorysize')
            if mem_elem is not None and mem_elem.text and mem_elem.text.isdigit():
                mem_bytes = int(mem_elem.text)
            mode_elem = cache.find('buffermode')
            if mode_elem is not None and mode_elem.text and mode_elem.text.isdigit():
                b_mode = int(mode_elem.text)
            rf_elem = cache.find('readfactor')
            if rf_elem is not None and rf_elem.text and rf_elem.text.isdigit():
                r_factor = int(rf_elem.text)
        elif network is not None:
            mem_elem = network.find('cachemembuffersize')
            if mem_elem is not None and mem_elem.text and mem_elem.text.isdigit():
                mem_bytes = int(mem_elem.text)

        if mem_bytes is not None:
            mem_mb = int(mem_bytes // (1024 * 1024))
            is_small = mem_mb < 40
            qual_str = "Malé pro 4K" if is_small else "Optimální pro 4K"
            status_text = f"{mem_mb} MB ({qual_str})"
            return {
                'exists': True,
                'configured': True,
                'memory_size_bytes': mem_bytes,
                'memory_size_mb': mem_mb,
                'buffermode': b_mode,
                'readfactor': r_factor,
                'is_small': is_small,
                'status_text': status_text
            }
    except Exception:
        pass

    return default_info


def set_buffer_size(memory_mb=150, buffermode=1, readfactor=20):
    """
    Zapíše nebo upraví nastavení vyrovnávací paměti v advancedsettings.xml.
    Ponechá veškeré ostatní uživatelské XML tagy nedotčené.
    """
    path = get_advancedsettings_path()
    if not path:
        return False, "Cesta k složce userdata nebyla nalezena."

    parent_dir = os.path.dirname(path)
    if parent_dir and not os.path.exists(parent_dir):
        try:
            os.makedirs(parent_dir, exist_ok=True)
        except Exception as e:
            return False, f"Nelze vytvořit složku: {e}"

    mem_bytes = int(memory_mb * 1024 * 1024)

    try:
        if os.path.exists(path):
            try:
                tree = ET.parse(path)
                root = tree.getroot()
            except Exception:
                root = ET.Element('advancedsettings')
                tree = ET.ElementTree(root)
        else:
            root = ET.Element('advancedsettings')
            tree = ET.ElementTree(root)

        cache = root.find('cache')
        if cache is None:
            cache = ET.SubElement(root, 'cache')

        # Odstraníme starý tag z Kodi 16, pokud existuje
        net = root.find('network')
        if net is not None:
            old_buf = net.find('cachemembuffersize')
            if old_buf is not None:
                net.remove(old_buf)

        def set_or_create(parent, tag, val):
            elem = parent.find(tag)
            if elem is None:
                elem = ET.SubElement(parent, tag)
            elem.text = str(val)

        set_or_create(cache, 'buffermode', buffermode)
        set_or_create(cache, 'memorysize', mem_bytes)
        set_or_create(cache, 'readfactor', readfactor)

        # Naformátování odsazení
        try:
            ET.indent(tree, space="  ", level=0)
        except Exception:
            pass

        tree.write(path, encoding='utf-8', xml_declaration=True)
        return True, f"Vyrovnávací paměť úspěšně nastavena na {memory_mb} MB (readfactor={readfactor})."
    except Exception as e:
        return False, f"Chyba při zápisu do advancedsettings.xml: {e}"


def update_addon_buffer_setting(addon):
    """Aktualizuje zobrazenou hodnotu bufferu v nastavení doplňku."""
    if not addon:
        return ""
    try:
        info = get_current_buffer_info()
        mb = info.get('memory_size_mb', 20)
        configured = info.get('configured', False)
        rf = info.get('readfactor', 4)
        if configured:
            val = f"{mb} MB (vlastní, {rf}x)"
        else:
            val = f"{mb} MB (výchozí)"
        addon.setSetting('current_buffer_info', val)
        return val
    except Exception:
        return ""

