import re
from .title_cleaner import clean_title_for_kodi, has_unrenderable_chars

def _is_generic_season_name(name, season_number):
    """Zjistí, zda název sezóny je pouze generický (např. '2. sezóna', 'Season 2', '2. série', '2. řada')."""
    if not name:
        return True
    norm = name.strip().lower()
    s_num = str(season_number)
    s_pad = f"{season_number:02d}"
    if norm in (s_num, f"{s_num}.", s_pad, f"{s_pad}."):
        return True

    pattern = rf'^(?:(?:sez[oó]na|s[eé]rie|[rř]ada|season|series)\s*(?:{s_num}|{s_pad})|(?:{s_num}|{s_pad})\.?\s*(?:sez[oó]na|s[eé]rie|[rř]ada|season|series))$'
    if re.match(pattern, norm):
        return True
    return False

def format_episode_count(count):
    """Vrátí správně skloňovaný počet epizod v češtině (1 epizoda, 2-4 epizody, 5+ epizod)."""
    try:
        n = int(count)
    except (ValueError, TypeError):
        return f"{count} epizod" if count else ""
    if n == 1:
        return "1 epizoda"
    elif 2 <= n <= 4:
        return f"{n} epizody"
    else:
        return f"{n} epizod"

def _format_lang_tag(lang):
    if not lang or lang == '??':
        return ""
    u = str(lang).upper()
    if 'TIT' in u or 'SUB' in u:
        return f" • [COLOR yellow]{lang}[/COLOR]"
    elif any(d in u for d in ('CZ', 'SK')):
        return f" • [COLOR lime]{lang}[/COLOR]"
    elif 'EN' in u:
        return f" • [COLOR #80D8FF]{lang}[/COLOR]"
    else:
        return f" • [COLOR white]{lang}[/COLOR]"


def build_season_label(show_title, season, lang=None, is_available=True):
    season_number = season.get('season_number', 0)
    name = season.get('name', '').strip()
    if has_unrenderable_chars(name):
        name = f"Sezóna {season_number}" if season_number > 0 else "Speciály"
    air_date = season.get('air_date', '')[:4] if season.get('air_date') else ''
    episode_count = season.get('episode_count', 0)

    year_text = f" ({air_date})" if air_date else ''
    ep_str = format_episode_count(episode_count)
    episode_text = f" • {ep_str}" if ep_str else ''

    if season_number == 0:
        norm_name = name.lower()
        if not name or norm_name in ("speciály", "specials", "speciál", "special", "0", "0."):
            base_title = "Speciály"
        elif norm_name.startswith("speciály:"):
            base_title = name
        else:
            base_title = f"Speciály: {name}"
        raw_label = f"{base_title}{year_text}{episode_text}"
    else:
        if _is_generic_season_name(name, season_number):
            raw_label = f"Sezóna {season_number}{year_text}{episode_text}"
        elif name.lower().startswith(f"sezóna {season_number}:") or name.lower().startswith(f"sezóna {season_number} -"):
            raw_label = f"{name}{year_text}{episode_text}"
        else:
            raw_label = f"Sezóna {season_number}: {name}{year_text}{episode_text}"

    if is_available:
        lang_text = _format_lang_tag(lang)
        return f"{raw_label}{lang_text}"
    else:
        return f"[COLOR gray]{raw_label} (NEDOSTUPNÁ)[/COLOR]"


def build_episode_label(episode, is_available=True, lang=None, is_watched=False):
    episode_number = episode.get('episode_number', 0)
    raw_name = episode.get('name') or f"Díl {episode_number}"
    if has_unrenderable_chars(raw_name):
        clean_name = clean_title_for_kodi(raw_name, media_type='tv')
        name = f"Epizoda {episode_number}" if clean_name.startswith('[') and clean_name.endswith(']') else clean_name
    else:
        name = raw_name

    lang_text = _format_lang_tag(lang)

    if is_watched:
        watched_str = " [COLOR lime](Zhlédnuto)[/COLOR]"
        if is_available:
            return f"[COLOR gray]{episode_number}. {name}[/COLOR]{watched_str}{lang_text}"
        else:
            return f"[COLOR gray]{episode_number}. {name} (NEDOSTUPNÝ)[/COLOR]{watched_str}"

    if is_available:
        return f"{episode_number}. {name}{lang_text}"
    else:
        return f"[COLOR gray]{episode_number}. {name} (NEDOSTUPNÝ)[/COLOR]"

