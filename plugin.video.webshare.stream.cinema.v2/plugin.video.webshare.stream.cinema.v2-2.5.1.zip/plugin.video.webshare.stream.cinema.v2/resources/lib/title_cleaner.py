# -*- coding: utf-8 -*-
"""
title_cleaner.py
Nástroj pro detekci, romanizaci a čištění znaků, které standardní skin/font v Kodi
neumí zobrazit (např. korejský Hangul, japonská Kana, čínské Hanzi, které se jinak
zobrazují jako nečitelné obdélníky / čtverečky).
"""

import re

# Korejský Hangul (Unicode rozsah 0xAC00 až 0xD7A3)
# Algoritmická dekompozice podle standardu Revised Romanization of Korean (RR)
CHOSEONG = [
    'g', 'kk', 'n', 'd', 'tt', 'r', 'm', 'b', 'pp', 's',
    'ss', '', 'j', 'jj', 'ch', 'k', 't', 'p', 'h'
]

JUNGSEONG = [
    'a', 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa',
    'wae', 'oe', 'yo', 'u', 'wo', 'we', 'wi', 'yu', 'eu', 'ui', 'i'
]

JONGSEONG = [
    '', 'k', 'k', 'ks', 'n', 'nj', 'nh', 't', 'l', 'lg',
    'lm', 'lb', 'ls', 'lt', 'lp', 'lh', 'm', 'p', 'bs', 's',
    'ss', 'ng', 't', 't', 'k', 't', 'p', 'h'
]

# Samostatné Jamo znaky (0x3131 - 0x3163)
JAMO_MAP = {
    0x3131: 'g', 0x3132: 'kk', 0x3133: 'gs', 0x3134: 'n', 0x3135: 'nj', 0x3136: 'nh',
    0x3137: 'd', 0x3138: 'tt', 0x3139: 'r', 0x313A: 'lg', 0x313B: 'lm', 0x313C: 'lb',
    0x313D: 'ls', 0x313E: 'lt', 0x313F: 'lp', 0x3140: 'lh', 0x3141: 'm', 0x3142: 'b',
    0x3143: 'pp', 0x3144: 'bs', 0x3145: 's', 0x3146: 'ss', 0x3147: 'ng', 0x3148: 'j',
    0x3149: 'jj', 0x314A: 'ch', 0x314B: 'k', 0x314C: 't', 0x314D: 'p', 0x314E: 'h',
    0x314F: 'a', 0x3150: 'ae', 0x3151: 'ya', 0x3152: 'yae', 0x3153: 'eo', 0x3154: 'e',
    0x3155: 'yeo', 0x3156: 'ye', 0x3157: 'o', 0x3158: 'wa', 0x3159: 'wae', 0x315A: 'oe',
    0x315B: 'yo', 0x315C: 'u', 0x315D: 'wo', 0x315E: 'we', 0x315F: 'wi', 0x3160: 'yu',
    0x3161: 'eu', 0x3162: 'ui', 0x3163: 'i'
}

# Japonská Hiragana a Katakana
KANA_MAP = {
    # Hiragana
    'あ': 'a', 'い': 'i', 'う': 'u', 'え': 'e', 'お': 'o',
    'か': 'ka', 'き': 'ki', 'く': 'ku', 'け': 'ke', 'こ': 'ko',
    'さ': 'sa', 'し': 'shi', 'す': 'su', 'せ': 'se', 'そ': 'so',
    'た': 'ta', 'ち': 'chi', 'つ': 'tsu', 'て': 'te', 'と': 'to',
    'な': 'na', 'に': 'ni', 'ぬ': 'nu', 'ね': 'ne', 'の': 'no',
    'は': 'ha', 'ひ': 'hi', 'ふ': 'fu', 'へ': 'he', 'ほ': 'ho',
    'ま': 'ma', 'み': 'mi', 'む': 'mu', 'め': 'me', 'も': 'mo',
    'や': 'ya', 'ゆ': 'yu', 'よ': 'yo',
    'ら': 'ra', 'り': 'ri', 'る': 'ru', 'れ': 're', 'ろ': 'ro',
    'わ': 'wa', 'を': 'wo', 'ん': 'n',
    'が': 'ga', 'ぎ': 'gi', 'ぐ': 'gu', 'げ': 'ge', 'ご': 'go',
    'ざ': 'za', 'じ': 'ji', 'ず': 'zu', 'ぜ': 'ze', 'ぞ': 'zo',
    'だ': 'da', 'ぢ': 'ji', 'づ': 'zu', 'де': 'de', 'ど': 'do',
    'ば': 'ba', 'び': 'bi', 'ぶ': 'bu', 'べ': 'be', 'ぼ': 'bo',
    'ぱ': 'pa', 'ぴ': 'pi', 'ぷ': 'pu', 'ぺ': 'pe', 'ぽ': 'po',
    'っ': '', 'ー': '',
    # Katakana
    'ア': 'a', 'イ': 'i', 'ウ': 'u', 'エ': 'e', 'オ': 'o',
    'カ': 'ka', 'キ': 'ki', 'ク': 'ku', 'ケ': 'ke', 'コ': 'ko',
    'サ': 'sa', 'シ': 'shi', 'ス': 'su', 'セ': 'se', 'ソ': 'so',
    'タ': 'ta', 'チ': 'chi', 'ツ': 'tsu', 'テ': 'te', 'ト': 'to',
    'ナ': 'na', 'ニ': 'ni', 'ヌ': 'nu', 'ネ': 'ne', 'ノ': 'no',
    'ハ': 'ha', 'ヒ': 'hi', 'フ': 'fu', 'ヘ': 'he', 'ホ': 'ho',
    'マ': 'ma', 'ミ': 'mi', 'ム': 'mu', 'メ': 'me', 'モ': 'mo',
    'ヤ': 'ya', 'ユ': 'yu', 'ヨ': 'yo',
    'ラ': 'ra', 'リ': 'ri', 'ル': 'ru', 'レ': 're', 'ロ': 'ro',
    'ワ': 'wa', 'ヲ': 'wo', 'ン': 'n',
    'ガ': 'ga', 'ギ': 'gi', 'グ': 'gu', 'ゲ': 'ge', 'ゴ': 'go',
    'ザ': 'za', 'ジ': 'ji', 'ズ': 'zu', 'ゼ': 'ze', 'ゾ': 'zo',
    'ダ': 'da', 'ヂ': 'ji', 'ヅ': 'zu', 'デ': 'de', 'ド': 'do',
    'バ': 'ba', 'ビ': 'bi', 'ブ': 'bu', 'ベ': 'be', 'ぼ': 'bo',
    'パ': 'pa', 'ピ': 'pi', 'プ': 'pu', 'ペ': 'pe', 'ポ': 'po',
}


def has_unrenderable_chars(text):
    """
    Vrátí True, pokud text obsahuje znaky, které standardní skin v Kodi
    neumí zobrazit (typicky korejské Hangul, čínské Hanzi, japonská písma,
    thajština apod., které se zobrazují jako čtverečky).
    """
    if not text:
        return False
    for ch in text:
        cp = ord(ch)
        # Korejský Hangul (slabičné bloky i jednotlivé Jamo znaky)
        if 0xAC00 <= cp <= 0xD7AF or 0x1100 <= cp <= 0x11FF or 0x3130 <= cp <= 0x318F:
            return True
        # CJK Unified Ideographs (čínské znaky Hanzi / japonské Kanji)
        if 0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF or 0xF900 <= cp <= 0xFAFF:
            return True
        # Japonská Hiragana a Katakana
        if 0x3040 <= cp <= 0x30FF or 0x31F0 <= cp <= 0x31FF:
            return True
        # Další asijská písma (Devanagari, Thajština atd.)
        if 0x0900 <= cp <= 0x0E7F:
            return True
    return False


def romanize_korean(text):
    """Převede korejský Hangul text na latinku (Revised Romanization of Korean)."""
    if not text:
        return ""
    res = []
    for ch in text:
        code = ord(ch)
        if 0xAC00 <= code <= 0xD7A3:
            s_idx = code - 0xAC00
            l_idx = s_idx // 588
            v_idx = (s_idx % 588) // 28
            t_idx = s_idx % 28
            res.append(CHOSEONG[l_idx] + JUNGSEONG[v_idx] + JONGSEONG[t_idx])
        elif code in JAMO_MAP:
            res.append(JAMO_MAP[code])
        else:
            res.append(ch)
    return "".join(res)


def romanize_japanese(text):
    """Převede japonskou Hiraganu a Katakanu na latinku."""
    if not text:
        return ""
    res = []
    for ch in text:
        res.append(KANA_MAP.get(ch, ch))
    return "".join(res)


def transliterate_all(text):
    """Provede kompletní romanizaci/transliteraci asijských textů."""
    if not text:
        return ""
    return romanize_japanese(romanize_korean(text))


def clean_title_for_kodi(title, english_title="", original_title="", year="", media_type="movie"):
    """
    Zajistí, že název filmu/seriálu je bezpečný a čitelný pro Kodi.
    Nikdy nezobrazí neznámé čtverečky (tofu).
    
    1. Pokud je původní název bezpečný (má latinkové znaky), zachová ho.
    2. Pokud má nečitelné znaky a existuje anglický překlad, použije anglický překlad.
    3. Pokud anglický překlad neexistuje, zkusí korejštinu / japonštinu romanizovat.
    4. Pokud text obsahuje alespoň nějaké latinkové slovo, vyextrahuje ho.
    5. Jako bezpečný fallback vrátí např. '[Film (2024)]' nebo '[Seriál (2023)]'.
    """
    title = (title or "").strip()
    english_title = (english_title or "").strip()
    original_title = (original_title or "").strip()

    # 1. Původní název je čitelný (neobsahuje problematické znaky)
    if title and not has_unrenderable_chars(title):
        return title

    # 2. Anglický překlad je čitelný
    if english_title and not has_unrenderable_chars(english_title):
        return english_title

    # 3. Zkusíme romanizovat korejštinu / japonštinu z title nebo original_title
    for candidate in [title, original_title]:
        if not candidate:
            continue
        trans = transliterate_all(candidate).strip()
        if trans and not has_unrenderable_chars(trans):
            words = trans.split()
            # Hezké velká počáteční písmena (např. 'Assimanim', 'Gisaengchung')
            return " ".join(w.capitalize() for w in words)

    # 4. Pokud zůstaly nečitelné znaky (např. čínské Hanzi bez EN překladu):
    combined = f"{title} {english_title} {original_title}"
    latin_words = re.findall(r"[A-Za-z0-9]{2,}", combined)
    if latin_words:
        return " ".join(w.capitalize() for w in latin_words)

    # 5. Bezpečný fallback, který nikdy nezobrazí čtverečky
    type_label = "Film" if media_type == "movie" else "Seriál"
    y_str = f" ({year})" if year and year != "N/A" else ""
    return f"[{type_label}{y_str}]"


def normalize_for_search(text):
    """Odstraní diakritiku, převede na malá písmena a odstraní interpunkci i pomocné tagy."""
    if not text:
        return ""
    import unicodedata
    text = unicodedata.normalize('NFKD', str(text))
    text = ''.join(c for c in text if not unicodedata.combining(c))
    text = text.lower()
    # Odstranění běžných přípon typu (s), [s], (f), [f], (seriál), (film)
    text = re.sub(r'[\(\[\{]\s*(?:s|f|seri[aá]l|film)\s*[\)\]\}]', ' ', text)
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    return ' '.join(text.split())


def calculate_match_score(query, item):
    """
    Vypočítá skóre shody položky s vyhledávaným dotazem (vyšší = lepší shoda).
    Zohledňuje přesnou shodu, prefix, obsažená slova i specifikaci typu v závorce (s/f).
    """
    if not query or not item:
        return 0

    wants_tv = bool(re.search(r'[\(\[\{]\s*(?:s|seri[aá]l)\s*[\)\]\}]', query, re.I))
    wants_movie = bool(re.search(r'[\(\[\{]\s*(?:f|film)\s*[\)\]\}]', query, re.I))

    norm_q = normalize_for_search(query)
    if not norm_q:
        return 0

    titles = [
        item.get('title', ''),
        item.get('original_title', ''),
        item.get('english_title', ''),
        item.get('raw_title', ''),
        item.get('raw_original_title', '')
    ]

    best_score = 0
    q_words = [w for w in norm_q.split() if w]

    for t in titles:
        if not t:
            continue
        norm_t = normalize_for_search(t)
        if not norm_t:
            continue

        if norm_t == norm_q:
            score = 1000
        elif norm_t.startswith(norm_q + ' ') or norm_t.startswith(norm_q + ':') or norm_t.startswith(norm_q + '-'):
            score = 800
        elif norm_q in norm_t:
            score = 600
        elif q_words and all(w in norm_t.split() for w in q_words):
            score = 450
        elif q_words and all(w in norm_t for w in q_words):
            score = 300
        elif q_words and any(w in norm_t.split() for w in q_words):
            matched = sum(1 for w in q_words if w in norm_t.split())
            score = 150 * (matched / len(q_words))
        else:
            score = 0

        if score > 0:
            len_diff = abs(len(norm_t) - len(norm_q))
            score += max(0, 50 - len_diff)

        if score > best_score:
            best_score = score

    # Bonus, pokud uživatel v dotazu specifikoval typ média např. 'the rookie (s)'
    media_type = item.get('media_type', '')
    if wants_tv and media_type == 'tv':
        best_score += 500
    elif wants_movie and media_type == 'movie':
        best_score += 500

    return best_score
