import json
import re
import socket
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
import xbmc
from resources.lib import webshare

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# Paměťová cache pro vyhledávání (chrání před HTTP 429 Too Many Requests)
_SEARCH_CACHE = {}
_CACHE_TTL = 300  # 5 minut

# Thread-safe rate limiter a ochrana před HTTP 429
_RATE_LOCK = threading.Lock()
_COOLDOWN_UNTIL = 0.0
_COOLDOWN_WARNED = False
_LAST_REQ_TIME = 0.0

def log_debug(msg):
    try:
        from main import log_debug as _log
        _log(msg)
    except Exception:
        xbmc.log("[PrehrajTo] " + str(msg), xbmc.LOGINFO)

def parse_duration_to_seconds(dur_str):
    """Převede časový řetězec (např. '1:25:30', '45:10', '90 min') na sekundy."""
    if not dur_str:
        return 0
    try:
        clean = str(dur_str).strip()
        parts = clean.split(':')
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(float(parts[2]))
        elif len(parts) == 2:
            return int(parts[0]) * 60 + int(float(parts[1]))
        elif 'min' in clean:
            m = re.search(r'(\d+)', clean)
            if m:
                return int(m.group(1)) * 60
        elif clean.isdigit():
            return int(clean)
    except Exception:
        pass
    return 0

import base64
import xbmcaddon

def get_prehrajto_credentials():
    try:
        addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
        user = addon.getSetting('prehrajto_user') or ''
        pwd = addon.getSetting('prehrajto_pass') or ''
        return user.strip(), pwd.strip()
    except Exception:
        return '', ''

class PrehrajtoSession:
    _instance = None
    _lock = threading.Lock()

    def __init__(self):
        self.email = ""
        self.password = ""
        self.cookies = {}
        self.token = ""

    @classmethod
    def get(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = PrehrajtoSession()
            return cls._instance

    def _cookies_from(self, resp):
        out = {}
        headers = resp.headers.get_all("Set-Cookie") if hasattr(resp.headers, "get_all") else [resp.headers.get("Set-Cookie", "")]
        for header in headers or ():
            if not header:
                continue
            for part in header.split(","):
                cookie = part.split(";", 1)[0]
                if "=" in cookie:
                    k, v = cookie.split("=", 1)
                    out[k.strip()] = v.strip()
        return out

    def _jwt_expired(self, token):
        try:
            payload = token.split(".")[1]
            payload += "=" * (-len(payload) % 4)
            exp = json.loads(base64.urlsafe_b64decode(payload)).get("exp") or 0
            return time.time() + 60 >= float(exp)
        except Exception:
            return True

    def login(self, email, password):
        if not email or not password:
            return False
        if self.token and not self._jwt_expired(self.token) and self.email == email:
            return True

        self.email = email
        self.password = password
        self.cookies = {}
        self.token = ""

        try:
            req1 = urllib.request.Request("https://prehrajto.cz/", headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req1, timeout=5.0) as resp1:
                self.cookies.update(self._cookies_from(resp1))

            post_data = urllib.parse.urlencode({
                "email": email,
                "password": password,
                "remember_login": "on",
                "login": "Přihlásit se",
                "_do": "loginDialog-login-loginForm-submit",
            }).encode("utf-8")

            cookie_header = "; ".join(f"{k}={v}" for k, v in self.cookies.items())
            req2 = urllib.request.Request("https://prehrajto.cz/?frm=loginDialog-login-loginForm", data=post_data, headers={
                "User-Agent": USER_AGENT,
                "X-Requested-With": "XMLHttpRequest",
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": cookie_header
            })
            with urllib.request.urlopen(req2, timeout=6.0) as resp2:
                self.cookies.update(self._cookies_from(resp2))

            token = self.cookies.get("access_token")
            if token:
                self.token = token
                log_debug("Úspěšně přihlášeno k účtu Přehraj.to (získán JWT token)")
                return True
            else:
                log_debug("Přihlášení k Přehraj.to nevrátilo access_token (zkontrolujte e-mail a heslo)")
                return False
        except Exception as e:
            log_debug(f"Chyba při přihlašování k Přehraj.to: {e}")
            return False

    def search_api(self, query, limit=32):
        if not self.token or self._jwt_expired(self.token):
            if not self.login(self.email, self.password):
                return []
        try:
            url = f"https://prehrajto.cz/api/v2/videos/search?phrase={urllib.parse.quote(query)}&limit={limit}&offset=0"
            req = urllib.request.Request(url, headers={
                "User-Agent": USER_AGENT,
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/json"
            })
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data.get("status") == "ok":
                    items = (data.get("payload") or {}).get("data") or []
                    results = []
                    for it in items:
                        slug = it.get('slug', '')
                        h_val = it.get('hash', '')
                        results.append({
                            'id': str(it.get('id', '')),
                            'slug': slug,
                            'hash': h_val,
                            'name': it.get('name', ''),
                            'size': int(it.get('size') or 0),
                            'duration': int(it.get('length') or 0),
                            'hd': bool(it.get('hd')),
                            'href': f"/{slug}/{h_val}"
                        })
                    return results
        except Exception as e:
            log_debug(f"Chyba při hledání přes Přehraj.to JSON API: {e}")
        return []

    def get_download_link(self, video_id):
        if not self.token or self._jwt_expired(self.token):
            if not self.login(self.email, self.password):
                return ""
        try:
            url = f"https://prehrajto.cz/api/v2/videos/{video_id}/download"
            req = urllib.request.Request(url, headers={
                "User-Agent": USER_AGENT,
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/json"
            })
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data.get("status") == "ok":
                    link = ((data.get("payload") or {}).get("data") or {}).get("download_link")
                    if link:
                        return link
        except Exception as e:
            log_debug(f"Chyba při získávání download_link z Přehraj.to API: {e}")
        return ""

def search_prehrajto_raw(query, limit=25, timeout=2.5):
    """
    Vyhledá videa na Prehrajto.cz pomocí zadaného dotazu.
    Vrací seznam nalezených karet:
    [{'href': '/...', 'title': '...', 'duration': 7200, 'is_hd': True, 'ident': 'prehrajto::/...'}]
    """
    global _COOLDOWN_UNTIL, _COOLDOWN_WARNED, _LAST_REQ_TIME
    if not query:
        return []

    q_str = str(query).strip()
    cache_key = q_str.lower()
    now = time.time()
    if cache_key in _SEARCH_CACHE:
        cached_time, cached_data = _SEARCH_CACHE[cache_key]
        if now - cached_time < _CACHE_TTL:
            return cached_data

    with _RATE_LOCK:
        now = time.time()
        if now < _COOLDOWN_UNTIL:
            # Server byl dočasně přetížen nebo vypršel timeout, tiše přeskočíme dotaz
            return []

        # Pauza mezi požadavky pro ochranu před rate limitem
        elapsed = now - _LAST_REQ_TIME
        if elapsed < 0.3:
            time.sleep(0.3 - elapsed)
        _LAST_REQ_TIME = time.time()

        encoded_query = urllib.parse.quote(q_str)
        url = f"https://prehrajto.cz/hledej/{encoded_query}"

        req = urllib.request.Request(url, headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "cs,sk,en;q=0.9",
            "Referer": "https://prehrajto.cz/"
        })

        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                html = response.read().decode('utf-8', errors='ignore')
                _COOLDOWN_WARNED = False
        except urllib.error.HTTPError as he:
            if he.code == 429:
                _COOLDOWN_UNTIL = time.time() + 90.0
                if not _COOLDOWN_WARNED:
                    log_debug("[PrehrajTo] Server vrátil HTTP 429 (Too Many Requests), aktivuji cooldown 90s.")
                    _COOLDOWN_WARNED = True
            else:
                log_debug(f"[PrehrajTo] Chyba při vyhledávání ({query}): HTTP {he.code}")
            return []
        except (socket.timeout, TimeoutError) as te:
            _COOLDOWN_UNTIL = time.time() + 90.0
            if not _COOLDOWN_WARNED:
                log_debug(f"[PrehrajTo] Timeout připojení ({te}), aktivuji cooldown 90s a přeskakuji další dotazy.")
                _COOLDOWN_WARNED = True
            return []
        except Exception as e:
            err_msg = str(e).lower()
            if 'timed out' in err_msg or 'timeout' in err_msg:
                _COOLDOWN_UNTIL = time.time() + 90.0
                if not _COOLDOWN_WARNED:
                    log_debug(f"[PrehrajTo] Timeout připojení ({e}), aktivuji cooldown 90s a přeskakuji další dotazy.")
                    _COOLDOWN_WARNED = True
            else:
                log_debug(f"[PrehrajTo] Chyba připojení: {e}")
            return []

    # Zpracování karet z HTML
    card_pattern = r'<a[^>]*class=[\'"][^\'"]*video--link[^\'"]*[\'"][^>]*href=[\'"]([^\'"]+)[\'"][^>]*title=[\'"]([^\'"]*)[\'"]([\s\S]*?)</a>'
    matches = re.findall(card_pattern, html)
    if not matches:
        return []

    results = []
    seen = set()

    for href, title, inner in matches:
        clean_href = href.strip()
        if not clean_href or clean_href in seen:
            continue
        seen.add(clean_href)

        # Čas / délka videa
        time_m = re.search(r'class=[\'"][^\'"]*video__time[^\'"]*[\'"][^>]*>([^<]+)<', inner)
        dur_str = time_m.group(1).strip() if time_m else ""
        dur_sec = parse_duration_to_seconds(dur_str)

        # Příznak HD
        is_hd = ('format__text' in inner and 'HD' in inner) or ('class="hd"' in inner) or ('HD' in title)

        results.append({
            'href': clean_href,
            'title': title.strip(),
            'duration_str': dur_str,
            'duration': dur_sec,
            'is_hd': is_hd,
            'ident': f"prehrajto::{clean_href}"
        })
        if len(results) >= limit:
            break

    _SEARCH_CACHE[cache_key] = (now, results)
    return results

def get_prehrajto_direct_url(video_href, timeout=6.0):
    """
    Získá přímý streamovací odkaz (pf-storage CDN) ze stránky videa na Prehrajto.cz
    nebo originální soubor přes oficiální API v2 (pokud má uživatel zadaný účet).
    """
    if not video_href:
        return None

    clean_href = str(video_href).strip()
    video_id = ""
    if clean_href.startswith('prehrajto::'):
        parts = clean_href.split('::')
        if len(parts) >= 3:
            video_id = parts[1]
            clean_href = parts[2]
        else:
            clean_href = parts[1]

    # 1. Zkusit oficiální API v2 download endpoint pokud máme ID a účet
    if video_id:
        user, pwd = get_prehrajto_credentials()
        if user and pwd:
            session = PrehrajtoSession.get()
            dl = session.get_download_link(video_id)
            if dl:
                log_debug(f"Prehraj.to originální stream z API v2 získán: {dl[:60]}...")
                return dl

    url = clean_href if clean_href.startswith('http') else f"https://prehrajto.cz{clean_href}"

    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Referer": "https://prehrajto.cz/"
    })

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            html = response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        log_debug(f"Chyba při stahování detailu videa Prehraj.to: {e}")
        return None

    # Hledáme JS sources blok: { file: "https://...", label: "1080p" }
    matches = re.findall(r'\{\s*file:\s*["\']([^"\']+)["\'](?:,\s*label:\s*["\']([^"\']+)["\'])?', html)
    if not matches:
        log_debug("V HTML stránky Prehraj.to nebyly nalezeny žádné streamovací zdroje.")
        return None

    # Seřadíme streamy: 1080p > 720p > 480p > 360p > ostatní
    def stream_rank(item):
        label = str(item[1] or '').lower()
        if '2160' in label or '4k' in label:
            return 2160
        elif '1080' in label:
            return 1080
        elif '720' in label:
            return 720
        elif '480' in label:
            return 480
        elif '360' in label:
            return 360
        # Vyřazení audio stop (např. 'ENG - 9303687 - eng'), které nejsou hlavní video soubor
        if any(a in label for a in ('eng', 'cze', 'slo', 'audio', 'tit')):
            return -1
        return 100

    video_streams = [m for m in matches if stream_rank(m) > 0]
    if not video_streams:
        video_streams = matches

    video_streams.sort(key=stream_rank, reverse=True)
    best_stream_url = video_streams[0][0]

    chosen_label = video_streams[0][1] if video_streams[0][1] else "default"
    log_debug("Prehraj.to stream vybrán: " + str(chosen_label) + " -> " + str(best_stream_url[:60]) + "...")
    return best_stream_url

def search_prehrajto(title_or_item, media_type='movie', season=None, episode=None, year="", limit=20):
    """
    Univerzální vyhledávač pro Prehrajto.cz (pro filmy i seriálové epizody).
    Vrací seznam souborů plně kompatibilní se zbytkem doplňku (valid, size_mb, quality, lang, atd.).
    """
    queries = []
    target_titles = []
    s_int = int(season) if season is not None else None
    e_int = int(episode) if episode is not None else None
    y = str(year or (title_or_item.get('year', '') if isinstance(title_or_item, dict) else '')).strip()

    if media_type == 'tv' or (s_int is not None and e_int is not None):
        if isinstance(title_or_item, dict):
            show_title = (title_or_item.get('title') or title_or_item.get('name') or '').strip()
            title_en = (title_or_item.get('english_title') or title_or_item.get('original_title') or title_or_item.get('original_name') or '').strip()
            title_orig = (title_or_item.get('original_title') or title_or_item.get('original_name') or '').strip()
            target_titles = list(filter(None, list(dict.fromkeys([
                show_title,
                title_en,
                title_orig,
                title_or_item.get('english_title', '').strip(),
                title_or_item.get('title', '').strip(),
                title_or_item.get('name', '').strip(),
                title_or_item.get('original_title', '').strip()
            ]))))
        else:
            show_title = str(title_or_item or '').strip()
            title_en = ""
            title_orig = ""
            target_titles = [show_title] if show_title else []

        se_q = f"S{s_int:02d}E{e_int:02d}"
        alt_q = f"{s_int}x{e_int:02d}"

        if show_title:
            queries.append((f"{show_title} {se_q}", "CZ"))
            queries.append((f"{show_title} {alt_q}", "CZ"))
        if title_en and title_en != show_title:
            queries.append((f"{title_en} {se_q}", "EN"))
        if title_orig and title_orig != show_title and title_orig != title_en:
            queries.append((f"{title_orig} {se_q}", "ORIG"))
    else:
        tmdb_item = title_or_item if isinstance(title_or_item, dict) else {'title': title_or_item, 'year': year}
        y = str(year or tmdb_item.get('year', '')).strip()
        title_cz = (tmdb_item.get('title') or tmdb_item.get('name') or '').strip()
        title_en = (tmdb_item.get('english_title') or tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()
        title_orig = (tmdb_item.get('original_title') or tmdb_item.get('original_name') or '').strip()

        target_titles = list(filter(None, list(dict.fromkeys([
            title_cz,
            title_en,
            title_orig,
            tmdb_item.get('english_title', '').strip(),
            tmdb_item.get('title', '').strip(),
            tmdb_item.get('original_title', '').strip()
        ]))))

        if title_cz:
            if y:
                queries.append((f"{title_cz} {y}", "CZ"))
            queries.append((title_cz, "CZ"))
        if title_en and title_en != title_cz:
            if y:
                queries.append((f"{title_en} {y}", "EN"))
            queries.append((title_en, "EN"))
        if title_orig and title_orig != title_cz and title_orig != title_en:
            if y:
                queries.append((f"{title_orig} {y}", "ORIG"))

    user, pwd = get_prehrajto_credentials()
    has_creds = bool(user and pwd)
    session = PrehrajtoSession.get() if has_creds else None
    if has_creds and session:
        session.login(user, pwd)

    found_cards = {}
    for idx, (q_str, search_language) in enumerate(queries):
        if not has_creds and time.time() < _COOLDOWN_UNTIL:
            break
        if idx > 0 and len(found_cards) >= 3:
            # Máme už dostatek výsledků, nezatěžujeme server zbytečnými dotazy
            break
        if idx > 0 and not has_creds:
            time.sleep(0.2)

        if has_creds and session and session.token:
            raw_items = session.search_api(q_str, limit=limit)
        else:
            raw_items = search_prehrajto_raw(q_str, limit=limit, timeout=2.5)

        for it in raw_items:
            href = it['href']
            if href not in found_cards:
                it['_search_language'] = search_language
                found_cards[href] = it
        if len(found_cards) >= limit:
            break

    results = []
    for href, card in found_cards.items():
        title = card.get('title') or card.get('name') or ''
        # Simulujeme název souboru s příponou pro validaci
        filename = title if '.' in title[-5:] else (title + ".mp4")
        search_language = card.get('_search_language')

        valid, reason = webshare.validate_file(
            filename,
            False,
            target_titles if len(target_titles) > 1 else (target_titles[0] if target_titles else filename),
            y,
            media_type='tv' if (s_int is not None and e_int is not None) else 'movie',
            target_season=s_int,
            target_episode=e_int
        )

        lang = webshare.detect_language(filename, search_language=search_language)
        quality = webshare.detect_quality(filename)
        if quality == '??' and card.get('is_hd'):
            quality = '720p'

        # Odhad velikosti streamu na základě kvality a délky
        dur_sec = card.get('duration', 0)
        dur_hours = (dur_sec / 3600.0) if dur_sec > 0 else 1.5

        if quality == '4K':
            est_mb = int(dur_hours * 3500)
        elif quality == '1080p':
            est_mb = int(dur_hours * 1800)
        elif quality == '720p':
            est_mb = int(dur_hours * 1000)
        else:
            est_mb = int(dur_hours * 600)
        est_mb = max(100, est_mb)

        raw_size = int(card.get('size') or 0)
        size_mb_val = round(raw_size / (1024 * 1024), 2) if raw_size > 0 else est_mb
        vid = card.get('id', '')
        ident_key = f"prehrajto::{vid}::{href}" if vid else f"prehrajto::{href}"

        results.append({
            'name': title,
            'ident': ident_key,
            'href': href,
            'id': vid,
            'source': 'prehrajto',
            'size_mb': size_mb_val,
            'size': raw_size if raw_size > 0 else (est_mb * 1024 * 1024),
            'valid': valid,
            'reason': reason,
            'lang': lang,
            'quality': quality,
            'duration': dur_sec
        })

    return results

def search_prehrajto_movies(tmdb_item, limit=20):
    """Zpětná kompatibilita pro vyhledávání filmů."""
    return search_prehrajto(tmdb_item, media_type='movie', limit=limit)

def search_prehrajto_episodes(show_title, season_number, episode_number, year="", limit=20):
    """Zpětná kompatibilita pro vyhledávání seriálů."""
    return search_prehrajto(show_title, media_type='tv', season=season_number, episode=episode_number, year=year, limit=limit)
