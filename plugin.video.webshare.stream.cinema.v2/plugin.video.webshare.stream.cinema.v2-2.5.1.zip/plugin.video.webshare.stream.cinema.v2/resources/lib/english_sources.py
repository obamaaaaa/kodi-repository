import json
import re
import time
import urllib.parse
import urllib.request
import xbmc
from resources.lib import webshare

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# Cache pro anglické zdroje
_EN_CACHE = {}
_EN_TTL = 300

def log_debug(msg):
    try:
        from main import log_debug as _log
        _log(msg)
    except Exception:
        xbmc.log("[EnglishSources] " + str(msg), xbmc.LOGINFO)

def unpack_dean_edwards_js(packed_code):
    """Rozbalí JavaScript zabalený přes Dean Edwards packer (eval(function(p,a,c,k,e,d)...))."""
    m = re.search(r"\}\('(.*)',(\d+),(\d+),'(.*)'\.split\('\|'\)", packed_code)
    if not m:
        return ""
    payload, a_str, c_str, k_str = m.group(1), m.group(2), m.group(3), m.group(4)
    a = int(a_str)
    c = int(c_str)
    k = k_str.split('|')

    def base_e(num):
        chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        if num < a:
            return chars[num]
        return base_e(num // a) + chars[num % a]

    d = {}
    for i in range(c):
        key = base_e(i)
        d[key] = k[i] if i < len(k) and k[i] else key

    def repl(match):
        w = match.group(0)
        return d.get(w, w)

    return re.sub(r'\b\w+\b', repl, payload)

def resolve_streamtape(url, timeout=6.0):
    """Získá přímý streamovací odkaz z Streamtape."""
    if not url:
        return None
    url = url.replace('/e/', '/v/')
    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Referer": "https://streamtape.com/"
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            html = resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        log_debug(f"Streamtape request failed: {e}")
        return None

    # Hledáme token v divu robotlink / norobotlink
    m = re.search(r'id=[\'"]norobotlink[\'"][^>]*>([^<]+)<', html)
    token = m.group(1).strip() if m else ""
    if not token:
        # Fallback regex na get_video
        m_parts = re.findall(r"id=.*?(?=\')", html)
        for part in m_parts:
            if "ip=" in part:
                stream_url = f"https://streamtape.com/get_video?{part}"
                return stream_url + '|' + urllib.parse.urlencode({'User-Agent': USER_AGENT, 'Referer': url})

    if token:
        if token.startswith('//'):
            stream_url = "https:" + token
        elif token.startswith('/'):
            stream_url = "https://streamtape.com" + token
        else:
            stream_url = token
        return stream_url + '|' + urllib.parse.urlencode({'User-Agent': USER_AGENT, 'Referer': url})

    return None

def resolve_mixdrop(url, timeout=6.0):
    """Získá přímý streamovací odkaz z Mixdrop."""
    if not url:
        return None

    try:
        res_url = _get_resolveurl()
        if res_url and res_url.relevant_resolvers(url):
            resolved = res_url.resolve(url)
            if resolved:
                return resolved
    except Exception:
        pass

    clean_url = url.replace('/f/', '/e/')
    curr_host = urllib.parse.urlparse(clean_url).netloc
    domains_to_try = [clean_url]
    for alt in ('mixdrop.ag', 'mixdrop.to', 'mixdrop.sx', 'mixdrop.ch'):
        if alt not in curr_host:
            domains_to_try.append(clean_url.replace(curr_host, alt))

    html = ""
    final_url = clean_url
    for try_url in domains_to_try:
        req = urllib.request.Request(try_url, headers={
            "User-Agent": USER_AGENT,
            "Referer": "https://mixdrop.co/"
        })
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                html = resp.read().decode('utf-8', errors='ignore')
                final_url = try_url
                break
        except Exception:
            continue

    if not html:
        return None

    # Hledáme eval blok
    for match in re.finditer(r'eval\(function\(p,a,c,k,e,d\)[\s\S]*?\)\)', html):
        unpacked = unpack_dean_edwards_js(match.group(0))
        url_match = re.search(r'MDCore\.(?:wurl|link)\s*=\s*"([^"]+)"', unpacked)
        if url_match:
            stream_link = url_match.group(1)
            if stream_link.startswith('//'):
                stream_link = "https:" + stream_link
            return stream_link + '|' + urllib.parse.urlencode({'User-Agent': USER_AGENT, 'Referer': final_url})

    return None

def _get_resolveurl():
    """Bezpečně načte volitelný modul ResolveURL bez falešné chyby importu v IDE."""
    try:
        import importlib
        return importlib.import_module("resolveurl")
    except Exception:
        return None

def resolve_filemoon(url, timeout=6.0):
    """Získá přímý streamovací odkaz z Filemoon."""
    if not url:
        return None
    # Filemoon vyžaduje buď ResolveURL nebo embed iframing
    try:
        res_url = _get_resolveurl()
        if res_url and res_url.relevant_resolvers(url):
            resolved = res_url.resolve(url)
            if resolved:
                return resolved
    except Exception:
        pass

    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Referer": "https://filemoon.sx/"
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            html = resp.read().decode('utf-8', errors='ignore')
        # Hledáme m3u8 playlist nebo sources
        m3u8 = re.search(r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', html)
        if m3u8:
            return m3u8.group(1) + '|' + urllib.parse.urlencode({'User-Agent': USER_AGENT, 'Referer': url})
    except Exception as e:
        log_debug(f"Filemoon extraction failed: {e}")

    return None

def resolve_stream(stream_url_or_ident, hoster=None):
    """
    Univerzální resolver pro anglické hostery (Streamtape, Mixdrop, Filemoon).
    Nejprve zkusí komunitní ResolveURL (pokud je v Kodi nainstalován),
    následně vlastní vestavěné regex/unpacker resolvery.
    """
    raw = str(stream_url_or_ident or '').strip()
    if raw.startswith('english::'):
        parts = raw.split('::', 2)
        if len(parts) == 3:
            hoster = parts[1]
            raw = parts[2]

    if not raw or '/search?' in raw or 'search=' in raw:
        log_debug(f"Neplatná adresa streamu (vyhledávací dotaz, nikoliv video): {raw}")
        return None

    # 1. Priorita: ResolveURL pokud je k dispozici
    try:
        res_url = _get_resolveurl()
        if res_url and res_url.relevant_resolvers(raw):
            log_debug(f"Předávám URL ke zpracování ResolveURL modulu: {raw[:60]}...")
            direct = res_url.resolve(raw)
            if direct:
                return direct
    except Exception:
        pass

    # 2. Vestavěné nativní resolvery
    hoster_lower = str(hoster or '').lower()
    if 'tape' in hoster_lower or 'streamtape' in raw:
        return resolve_streamtape(raw)
    elif 'drop' in hoster_lower or 'mixdrop' in raw:
        return resolve_mixdrop(raw)
    elif 'moon' in hoster_lower or 'filemoon' in raw:
        return resolve_filemoon(raw)

    return raw

def search_english(title_or_item, media_type='movie', season=None, episode=None, year="", limit=10):
    """
    Vyhledá dostupné anglické streamy z volných video-hosterů (Streamtape, Mixdrop, Filemoon).
    Vrací seznam položek označených jako 'streamtape', 'mixdrop' nebo 'filemoon' v originálním znění (EN).
    """
    if isinstance(title_or_item, dict):
        title = (title_or_item.get('english_title') or title_or_item.get('title') or title_or_item.get('name') or '').strip()
        y = str(year or title_or_item.get('year', '')).strip()
        tmdb_id = str(title_or_item.get('id', '')).strip()
    else:
        title = str(title_or_item or '').strip()
        y = str(year or '').strip()
        tmdb_id = ""

    s_int = int(season) if season is not None else None
    e_int = int(episode) if episode is not None else None
    ep_tag = f"S{s_int:02d}E{e_int:02d}" if (s_int is not None and e_int is not None) else ""

    cache_key = f"{title}_{ep_tag}_{y}".lower()
    now = time.time()
    if cache_key in _EN_CACHE:
        cached_time, cached_data = _EN_CACHE[cache_key]
        if now - cached_time < _EN_TTL:
            return cached_data

    results = []

    # Seznam veřejných indexerů / embed API nabízejících Streamtape, Mixdrop nebo Filemoon
    # Podle TMDB ID nebo názvu sestavíme dotaz
    hosters = ['streamtape', 'mixdrop', 'filemoon']

    # Dotaz na veřejný multi-hoster katalog
    if tmdb_id:
        target_urls = []
        if media_type == 'tv' and s_int and e_int:
            target_urls.append(f"https://www.2embed.cc/embedtv/{tmdb_id}&s={s_int}&e={e_int}")
        else:
            target_urls.append(f"https://www.2embed.cc/embed/{tmdb_id}")

        for target_url in target_urls:
            try:
                req = urllib.request.Request(target_url, headers={
                    "User-Agent": USER_AGENT,
                    "Referer": "https://google.com/"
                })
                with urllib.request.urlopen(req, timeout=4) as resp:
                    html = resp.read().decode('utf-8', errors='ignore')

                # Prohledáme stránku na odkazy na dané hostery
                for h in hosters:
                    pattern = r'https?://[^\s\'"]*' + re.escape(h) + r'[^\s\'"]*'
                    found = re.findall(pattern, html)
                    for stream_link in found[:2]:
                        name_display = f"{title} {ep_tag} [EN Original]".strip()
                        results.append({
                            'name': name_display,
                            'ident': f"english::{h}::{stream_link}",
                            'source': h,
                            'stream_url': stream_link,
                            'size_mb': 1600,
                            'size': 1600 * 1024 * 1024,
                            'valid': True,
                            'reason': 'OK',
                            'lang': 'EN',
                            'quality': '1080p',
                            'duration': 0
                        })
            except Exception as e:
                log_debug(f"Chyba při dotazu na embed katalog: {e}")

    _EN_CACHE[cache_key] = (now, results)
    return results
