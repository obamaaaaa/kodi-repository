import zlib,base64;exec(zlib.decompress(base64.b64decode('eNpLK8rPVShILC7OyUzSK0pNzywuKapUyMwtyC8qUYgvKMqvqOSC8oori7mAWC83P6U0J7U4Oj4+LzE3NT4+1haiDgBV6x1N')).decode('utf-8'))
