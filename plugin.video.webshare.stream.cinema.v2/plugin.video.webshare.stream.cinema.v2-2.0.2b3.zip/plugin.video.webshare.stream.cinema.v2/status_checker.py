import json
import time
import xbmc
import xbmcgui
import xbmcaddon

import resources.lib.db as db


def log_debug(msg):
    """Bezpečné logování do Kodi logu."""
    xbmc.log(f"[Webshare StatusChecker] {msg}", xbmc.LOGINFO)


class WebsharePlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.reset_state()

    def reset_state(self):
        """Vynuluje sledované proměnné pro nové video."""
        self.current_tmdb_id = None
        self.current_media_type = "movie"
        self.current_title = ""
        self.current_season = 0
        self.current_episode = 0
        self.current_details = {}
        self.is_tracking = False
        self.last_saved_time = 0
        self.last_known_time = 0
        self.last_known_total_time = 0
        self.seek_attempts = 0

    def start_tracking(self, tmdb_id, media_type, title, season=0, episode=0, details=None):
        """Ruční inicializace dat pro sledování s ošetřením záporných hodnot sezóny/dílu."""
        self.current_tmdb_id = str(tmdb_id) if tmdb_id else None
        normalized = str(media_type or "movie").lower()
        if normalized in {"tv", "tvshow", "series", "episode"} or season > 0 or episode > 0:
            self.current_media_type = "tv"
        else:
            self.current_media_type = "movie"
        self.current_title = title or "Neznámý název"
        self.current_season = max(0, int(season or 0))
        self.current_episode = max(0, int(episode or 0))
        self.current_details = details or {}
        self.is_tracking = True if self.current_tmdb_id else False
        self.last_known_time = 0
        self.last_known_total_time = 0
        log_debug(
            f"Start tracking: {self.current_title} S{self.current_season}E{self.current_episode} (ID: {self.current_tmdb_id})"
        )

    def check_and_init_tracking(self):
        """Inicializuje sledování pozice a spolehlivý skok na rozkoukaný bod (resume)."""
        if not self.isPlayingVideo():
            return

        if not self.is_tracking:
            # 1. Zkusíme načíst metadata z Window property nastavené přehrávačem
            active_json = xbmcgui.Window(10000).getProperty("webshare_active_media")
            if active_json:
                try:
                    meta = json.loads(active_json)
                    if meta.get("tmdb_id"):
                        self.start_tracking(
                            tmdb_id=meta.get("tmdb_id"),
                            media_type=meta.get("media_type", "movie"),
                            title=meta.get("title", ""),
                            season=meta.get("season", 0),
                            episode=meta.get("episode", 0),
                            details=meta.get("details", {})
                        )
                except Exception as e:
                    log_debug(f"Chyba při parsování webshare_active_media: {e}")

            # 2. Fallback na Kodi VideoInfoTag
            if not self.is_tracking:
                try:
                    tag = self.getVideoInfoTag()
                    title = tag.getTitle()
                    tmdb_id = tag.getUniqueID("tmdb")
                    season = max(0, tag.getSeason())
                    episode = max(0, tag.getEpisode())
                    media_type = tag.getMediaType() or ("tv" if episode > 0 else "movie")
                    normalized = str(media_type or "movie").lower()
                    if normalized in {"tv", "tvshow", "series", "episode"} or episode > 0 or season > 0:
                        media_type = "tv"
                    else:
                        media_type = "movie"

                    if tmdb_id and title:
                        self.start_tracking(
                            tmdb_id=tmdb_id,
                            media_type=media_type,
                            title=title,
                            season=season,
                            episode=episode,
                        )
                except Exception as e:
                    log_debug(f"Chyba při auto-detekci metadat z Tagu: {e}")

        # 3. Zpracování a ověření seeku (Resume)
        seek_target = xbmcgui.Window(10000).getProperty("webshare_resume_seek")
        if seek_target:
            try:
                seek_sec = float(seek_target)
                if seek_sec > 1:
                    cur_time = self.getTime()
                    # Pokud se video ještě nenachází v požadovaném čase, aplikujeme seek
                    if cur_time < (seek_sec - 5) and self.seek_attempts < 15:
                        log_debug(f"Aplikuji resume skok na {seek_sec}s (pokus {self.seek_attempts + 1}, aktuální čas: {cur_time:.1f}s)")
                        self.seekTime(seek_sec)
                        self.seek_attempts += 1
                        self.last_saved_time = seek_sec
                        self.last_known_time = seek_sec
                    else:
                        log_debug(f"Resume skok dokončen nebo vyčerpány pokusy. Aktuální čas: {cur_time:.1f}s")
                        xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
                        self.seek_attempts = 0
            except Exception as e:
                log_debug(f"Chyba při provádění resume seeku: {e}")

    def update_time_cache(self):
        """Ukládá do paměti aktuální pozici, dokud přehrávač běží."""
        if self.isPlayingVideo():
            try:
                self.last_known_time = self.getTime()
                self.last_known_total_time = self.getTotalTime()
            except Exception:
                pass

    # =========================================================================
    # DETEKČNÍ METODY (UDÁLOSTI KODI PLAYERU)
    # =========================================================================
    
    def onAVStarted(self):
        """DETEKCE 1: Video se úspěšně načetlo a začalo hrát."""
        log_debug("Událost: onAVStarted - Video začalo hrát.")
        self.check_and_init_tracking()

    def onPlayBackPaused(self):
        """DETEKCE 2: Uživatel video pauznul -> uložit aktuální stav."""
        log_debug("Událost: onPlayBackPaused - Uživatel pozastavil video.")
        self._save_current_position(notify=True)

    def onPlayBackResumed(self):
        """Událost: Uživatel pokračuje v přehrávání po pauze."""
        pass

    def onPlayBackStopped(self):
        """DETEKCE 3: Uživatel ručně ukončil video."""
        log_debug("Událost: onPlayBackStopped - Uživatel ukončil video.")
        self._save_current_position(notify=True)
        self.reset_state()
        xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
        xbmcgui.Window(10000).clearProperty("webshare_active_media")

    def onPlayBackEnded(self):
        """DETEKCE 4: Video dohrálo až do úplného konce."""
        log_debug("Událost: onPlayBackEnded - Video dohrálo do konce.")
        self._save_current_position(force_ended=True, notify=True)
        self.reset_state()
        xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
        xbmcgui.Window(10000).clearProperty("webshare_active_media")

        
    def _save_current_position(self, force_ended=False, notify=False):
        """Interní logika pro výpočet času a uložení do DB bez pádu při zavřeném přehrávači."""
        if not self.is_tracking or not self.current_tmdb_id:
            return

        try:
            # Pokud video ještě běží, načteme přesný čas. Pokud už bylo ukončeno, použijeme chytrou cache.
            if self.isPlayingVideo():
                current_time = self.getTime()
                total_time = self.getTotalTime()
                self.last_known_time = current_time
                self.last_known_total_time = total_time
            else:
                current_time = self.last_known_time
                total_time = self.last_known_total_time

            if force_ended and total_time > 0:
                current_time = total_time

            log_debug(
                f"Ukládám pozici -> TMDB ID: {self.current_tmdb_id} | S{self.current_season}E{self.current_episode} Čas: {current_time:.1f}s / {total_time:.1f}s | Film/Serial: {self.current_title}"
            )


            db.update_watch_status(
                tmdb_id=self.current_tmdb_id,
                media_type=self.current_media_type,
                title=self.current_title,
                resume_time=current_time,
                total_time=total_time,
                season=self.current_season,
                episode=self.current_episode,
                details=self.current_details,
            )
            self.last_saved_time = current_time

            # Zobrazení oznámení při uložení
            if notify:
                try:
                    addon = xbmcaddon.Addon('plugin.video.webshare.stream.cinema.v2')
                    notify_enabled = addon.getSetting('notify_on_save') != 'false'
                except Exception:
                    notify_enabled = True

                if notify_enabled:
                    if (total_time > 0 and (current_time / total_time) >= 0.90) or force_ended:
                        msg = f"Označeno jako zhlédnuté: {self.current_title}"
                        xbmcgui.Dialog().notification("Webshare", msg, xbmcgui.NOTIFICATION_INFO, 3000)
                    elif current_time > 15:
                        s = int(current_time)
                        h = s // 3600
                        m = (s % 3600) // 60
                        sec = s % 60
                        time_str = f"{h:02d}:{m:02d}:{sec:02d}" if h > 0 else f"{m:02d}:{sec:02d}"
                        ep_str = f" (S{self.current_season:02d}E{self.current_episode:02d})" if (self.current_season > 0 and self.current_episode > 0) else ""
                        msg = f"Pozice uložena{ep_str}: {time_str}"
                        xbmcgui.Dialog().notification("Webshare", msg, xbmcgui.NOTIFICATION_INFO, 3000)

        except Exception as e:
            log_debug(f"Chyba při ukládání pozice do DB: {e}")


# =============================================================================
# HLAVNÍ SMYČKA SLUŽBY (RUNNER)
# =============================================================================
if __name__ == "__main__":
    monitor = xbmc.Monitor()
    player = WebsharePlayer()

    was_in_webshare_root = False
    last_settings_check = 0
    exit_to_home_enabled = True

    while not monitor.abortRequested():
        now = time.time()

        # Obnovení nastavení každé 3 sekundy
        if now - last_settings_check > 3.0:
            last_settings_check = now
            try:
                addon = xbmcaddon.Addon("plugin.video.webshare.stream.cinema.v2")
                exit_to_home_enabled = addon.getSetting("exit_to_home") != "false"
            except Exception:
                exit_to_home_enabled = True

        if player.isPlayingVideo():
            was_in_webshare_root = False
            player.check_and_init_tracking()
            if player.is_tracking:
                player.update_time_cache()
                try:
                    curr_time = player.last_known_time
                    if abs(curr_time - player.last_saved_time) > 10:
                        player._save_current_position()
                except Exception:
                    pass
        else:
            # Kontrola návratu z hlavního menu doplňku na domovskou obrazovku Kodi
            if exit_to_home_enabled:
                try:
                    current_path = xbmc.getInfoLabel("Container.FolderPath") or ""
                    clean_path = current_path.rstrip('/')
                    is_in_root = (clean_path == "plugin://plugin.video.webshare.stream.cinema.v2")
                    is_in_addon = clean_path.startswith("plugin://plugin.video.webshare.stream.cinema.v2")

                    if is_in_root:
                        was_in_webshare_root = True
                    elif is_in_addon:
                        was_in_webshare_root = False
                    elif was_in_webshare_root:
                        # Uživatel byl v kořenovém menu Webshare a stiskl Zpět
                        window_id = xbmcgui.getCurrentWindowId()
                        is_video_nav = (
                            window_id == 10025 or
                            xbmc.getCondVisibility("Window.IsVisible(videos)") or
                            any(clean_path.startswith(prefix) for prefix in (
                                "sources://", "library://", "addons://sources", "special://videonav"
                            ))
                        )
                        was_in_webshare_root = False
                        if is_video_nav:
                            log_debug(
                                f"Detekován odchod z hlavního menu Webshare do '{current_path}' (okno {window_id}). Přepínám na domovskou obrazovku Kodi."
                            )
                            xbmc.executebuiltin("ActivateWindow(home)")
                except Exception as e:
                    pass

        if monitor.waitForAbort(0.25):
            break