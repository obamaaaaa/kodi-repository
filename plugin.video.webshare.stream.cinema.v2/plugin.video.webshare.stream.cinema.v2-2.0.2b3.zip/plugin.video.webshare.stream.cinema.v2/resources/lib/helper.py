import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import os

#sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

ICONS = {
    'SEARCH': os.path.join(MEDIA_PATH, 'search.png'),
    'FILM': os.path.join(MEDIA_PATH, 'film.png'),
    'HISTORY': os.path.join(MEDIA_PATH, 'history.png'),
    'RESUME': os.path.join(MEDIA_PATH, 'history_resume.png'),
    'WATCHED': os.path.join(MEDIA_PATH, 'history_watched.png'),
    'POPULAR': os.path.join(MEDIA_PATH, 'popular.png'),
    'THEATRE': os.path.join(MEDIA_PATH, 'theatre.png'),
    'CZ': os.path.join(MEDIA_PATH, 'cz.png'),
    'TRANSCRIPT': os.path.join(MEDIA_PATH, 'transcript.png'),
    'CALENDAR': os.path.join(MEDIA_PATH, 'calendar.png'),
    'BOOK': os.path.join(MEDIA_PATH, 'book.png'),
    'OVERLAY_WATCHED': os.path.join(MEDIA_PATH, 'watched.png'),
    'OVERLAY_RESUME': os.path.join(MEDIA_PATH, 'resume.png'),
    '4K': os.path.join(MEDIA_PATH, '4k.png'),
    '1080': os.path.join(MEDIA_PATH, '1080p.png'),
    '720': os.path.join(MEDIA_PATH, '720p.png'),
    'SD': os.path.join(MEDIA_PATH, 'sd.png'),
    'DEF_VIDEO': 'DefaultVideo.png',
    'DEF_FOLDER': 'DefaultFolder.png',
    'SETTINGS': 'DefaultAddonService.png',
    'NEXT': 'DefaultIconNext.png',
    'PREV': 'DefaultIconPrevious.png'
}