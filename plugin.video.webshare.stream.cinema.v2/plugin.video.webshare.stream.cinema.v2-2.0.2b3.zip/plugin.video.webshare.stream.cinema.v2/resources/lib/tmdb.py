from concurrent.futures import ThreadPoolExecutor

import requests
import xbmc
from . import db
try:
    from main import log_debug
except ImportError:
    def log_debug(msg):
        xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)
        
TMDB_BASE_URL = "https://api.themoviedb.org/3"
IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

def get_item_details(media_type, tmdb_id, api_key):
    """Načte podrobné informace s využitím modulu db.py"""
    url = f"{TMDB_BASE_URL}/{media_type}/{tmdb_id}"
    params = {
        'api_key': api_key,
        'language': 'cs-CZ',
        'append_to_response': 'credits'
    }
    
    # 1. Čistý klíč nezávislý na API klíči (např. "tmdb_movie_634649_cs-CZ")
    cache_key = f"tmdb_{media_type}_{tmdb_id}_cs-CZ"

    cached_data = db.get_cache(cache_key, ttl_days=7)
    if cached_data is not None:
        log_debug("Mám data!")
        return cached_data

    try:
        r = requests.get(url, params=params, timeout=5)
        if r.status_code == 200:
            data = r.json()
            db.set_cache(cache_key, data)
            return data
    except Exception as e:
        log_debug(f"Chyba při načítání detailu ID {tmdb_id}: {e}")

    return {}

def _process_tmdb_item(item, media_type, api_key):
    # OK
    """Pomocná funkce pro paralelní zpracování jedné položky."""
    tmdb_id = item.get('id')
    details = get_item_details(media_type, tmdb_id, api_key)
    
    title = item.get('title') or item.get('name', 'Neznámý název')
    original_title = item.get('original_title') or item.get('original_name', '')
    release_date = item.get('release_date') or item.get('first_air_date', '')
    year = release_date[:4] if release_date else 'N/A'
    
    runtime = details.get('runtime') if media_type == 'movie' else (
        details.get('episode_run_time', [0])[0] if details.get('episode_run_time') else 0
    )
    
    genres = [g['name'] for g in details.get('genres', [])]
    
    credits = details.get('credits', {})
    cast = [
        {
            'name': actor.get('name'),
            'role': actor.get('character', ''),
            'thumbnail': f"{IMAGE_BASE_URL}w185{actor['profile_path']}" if actor.get('profile_path') else ''
        }
        for actor in credits.get('cast', [])[:5]
    ]
    
    directors = [crew['name'] for crew in credits.get('crew', []) if crew.get('job') == 'Director']

    poster_path = item.get('poster_path')
    backdrop_path = item.get('backdrop_path')
    
    parsed_item = {
        'id': tmdb_id,
        'title': title,
        'original_title': original_title,
        'year': year,
        'release_date': release_date,
        'rating': round(item.get('vote_average', 0), 1),
        'overview': item.get('overview', ''),
        'tagline': details.get('tagline', ''),
        'runtime': runtime or 0,
        'genres': genres,
        'cast': cast,
        'directors': directors,
        'poster': f"{IMAGE_BASE_URL}w500{poster_path}" if poster_path else '',
        'fanart': f"{IMAGE_BASE_URL}w1280{backdrop_path}" if backdrop_path else '',
        'number_of_seasons': details.get('number_of_seasons') or 0,
        'number_of_episodes': details.get('number_of_episodes') or 0
    }
    
    # Pro search potřebujeme vědět, zda jde o movie nebo tv
    if 'media_type' in item:
        parsed_item['media_type'] = item['media_type']
    else:
        parsed_item['media_type'] = media_type

    return parsed_item

def get_season_details(series_id, season_number, api_key):
    """Načte detail jedné sezóny seriálu z TMDB."""
    url = f"{TMDB_BASE_URL}/tv/{series_id}/season/{season_number}"
    params = {
        'api_key': api_key,
        'language': 'cs-CZ',
    }
    try:
        r = requests.get(url, params=params, timeout=5)
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        xbmc.log(f"[TMDB] Chyba při načítání sezóny {season_number} pro seriál {series_id}: {e}", xbmc.LOGINFO)
    return {}


def get_tv_seasons(series_id, api_key):
    """Vrátí seznam sezón pro seriál včetně osnovních metadat bleskově přímo z detailů seriálu."""
    details = get_item_details('tv', series_id, api_key)
    raw_seasons = details.get('seasons') or []
    seasons = []

    if raw_seasons:
        for s in raw_seasons:
            season_number = s.get('season_number', 0)
            poster_path = s.get('poster_path')
            poster = f"{IMAGE_BASE_URL}w500{poster_path}" if poster_path else ''
            default_name = "Speciály" if season_number == 0 else f"Sezóna {season_number}"
            seasons.append({
                'season_number': season_number,
                'name': s.get('name') or default_name,
                'overview': s.get('overview', ''),
                'air_date': s.get('air_date', ''),
                'episode_count': s.get('episode_count') or 0,
                'poster': poster,
                'episodes': [],
            })
    else:
        season_count = details.get('number_of_seasons') or 0
        for season_number in range(1, season_count + 1):
            seasons.append({
                'season_number': season_number,
                'name': f"Sezóna {season_number}",
                'overview': '',
                'air_date': '',
                'episode_count': 0,
                'poster': '',
                'episodes': [],
            })

    # Seřadit tak, aby sezóna 0 byla na začátku (nebo podle season_number)
    seasons.sort(key=lambda x: x.get('season_number', 0))
    return seasons


def fetch_tmdb_items(media_type, category, api_key, genre_id=None, page=1):
    # OK
    if category == "popular":
        url = f"{TMDB_BASE_URL}/{media_type}/popular"
        params = {'api_key': api_key, 'language': 'cs-CZ', 'page': page}
    elif category == "new":
        endpoint = "now_playing" if media_type == "movie" else "on_the_air"
        url = f"{TMDB_BASE_URL}/{media_type}/{endpoint}"
        params = {'api_key': api_key, 'language': 'cs-CZ', 'page': page}
    elif category == "genre":
        url = f"{TMDB_BASE_URL}/discover/{media_type}"
        params = {'api_key': api_key, 'language': 'cs-CZ', 'with_genres': genre_id, 'page': page}
    else:
        return []
        
    try:
        r = requests.get(url, params=params, timeout=10)
        r.raise_for_status()
        results = r.json().get('results', [])
        
        # Paralelní načtení detailů pro všechny položky najednou
        items = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(_process_tmdb_item, item, media_type, api_key)
                for item in results
            ]
            for future in futures:
                items.append(future.result())

        return items
    except Exception as e:
        log_debug(f"Chyba při komunikaci s TMDB: {e}")
        return []
    
def search_tmdb_items(query, api_key, page=1):
    # OK
    if not query:
        return []

    all_items = []
    for media_type in ("movie", "tv"):
        url = f"{TMDB_BASE_URL}/search/{media_type}"
        params = {
            'api_key': api_key,
            'language': 'cs-CZ',
            'query': query,
            'page': page
        }
        try:
            r = requests.get(url, params=params, timeout=10)
            r.raise_for_status()
            results = r.json().get('results', [])

            # Paralelní načtení detailů pro vyhledané položky
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = [
                    executor.submit(_process_tmdb_item, item, media_type, api_key)
                    for item in results
                ]
                for future in futures:
                    all_items.append(future.result())

        except Exception as e:
            log_debug(f"Chyba při vyhledávání v TMDB pro typ {media_type}: {e}")

    return all_items