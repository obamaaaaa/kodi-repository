import ast
import sys
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import json

try:
    from main import log_debug
except ImportError:
    def log_debug(msg):
        xbmc.log(f"[Webshare] {msg}", xbmc.LOGINFO)
        
def _parse_dict(data):
    """Pomocná funkce pro bezpečný převod str -> dict"""
    if isinstance(data, dict):
        return data
    if isinstance(data, str) and data.strip():
        try:
            return json.loads(data)
        except Exception:
            try:
                return ast.literal_eval(data)
            except Exception:
                pass
    return {}

def play_webshare_video(file_id, file_name="Název_souboru.mp4", tmdb_info=None, season=0, episode=0, wst_token="", tmdb_details=""):
    # film: {'title': 'Scary Movie', 'original_title': 'Scary Movie', 'year': '2026', 'id': '1273221', 'media_type': 'movie'}
    # seroš: {'title': 'Zelenáč', 'original_title': 'Zelenáč', 'year': '2018', 'id': '79744'}
    tmdb_info = _parse_dict(tmdb_info)
    tmdb_details = _parse_dict(tmdb_details)

    # 2. Extrakce hodnot s fallbackem na file_name
    title = tmdb_info.get('title') or tmdb_info.get('name') or file_name
    year = tmdb_info.get('year', '')
    tmdb_id = tmdb_info.get('id') or tmdb_info.get('tmdb_id') or ''

    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
    
    if not wst_token:
        log_debug("Není k dispozici platný Webshare Token")

    # 3. Získej přímou URL z Webshare API
    stream_url = get_webshare_direct_url(file_id, wst_token=wst_token)

    if not stream_url:
        log_debug("Nepodařilo se získat přímou URL ke streamu.")
        xbmcplugin.setResolvedUrl(handle=handle, succeeded=False, listitem=xbmcgui.ListItem())
        return

    # 4. Vytvoř ListItem a nastav přímou adresu ke streamu
    season_num = int(season or 0)
    episode_num = int(episode or 0)

    if season_num > 0 and episode_num > 0:
        label_text = f"{title} - S{season_num:02d}E{episode_num:02d}"
    elif year:
        label_text = f"{title} ({year})"
    else:
        label_text = title

    list_item = xbmcgui.ListItem(label=label_text)
    list_item.setPath(stream_url)

    # 5. Dynamické načtení obrázků z tmdb_details
    poster_path = tmdb_details.get('poster_path', '')
    backdrop_path = tmdb_details.get('backdrop_path', '')

    poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''
    fanart_url = f"https://image.tmdb.org/t/p/original{backdrop_path}" if backdrop_path else ''

    list_item.setArt({
        'poster': poster_url,
        'fanart': fanart_url
    })
    
    # 6. Nastavení informací o médiu pro Kodi VideoInfoTag
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    
    plot = tmdb_details.get('overview', '')
    if plot:
        info_tag.setPlot(plot)
        
    if tmdb_id:
        info_tag.setUniqueID(str(tmdb_id), type='tmdb')

    # Nastavení sezóny, epizody a typu média pro status_checker.py
    if season_num > 0:
        info_tag.setSeason(season_num)
    if episode_num > 0:
        info_tag.setEpisode(episode_num)

    media_type = tmdb_info.get('media_type') or ('tv' if (season_num > 0 or episode_num > 0) else 'movie')
    info_tag.setMediaType(media_type)

    # 7. Uložení metadat do DB a kontrola rozkoukaného bodu
    try:
        from . import db
        combined_details = {**tmdb_details, **tmdb_info}
        if poster_url and 'poster' not in combined_details:
            combined_details['poster'] = poster_url
        if fanart_url and 'fanart' not in combined_details:
            combined_details['fanart'] = fanart_url
        if tmdb_id:
            db.save_item_metadata(tmdb_id, media_type, title, season_num, episode_num, combined_details)

        item_status = db.get_item_watch_status(tmdb_id, season_num, episode_num)
        resume_time = item_status.get('resume_time', 0) if item_status else 0
        total_time = item_status.get('total_time', 0) if item_status else 0
        is_watched = item_status.get('watched', False) if item_status else False

        if is_watched:
            info_tag.setPlaycount(1)

        if resume_time > 15 and not is_watched:
            def _format_time(s):
                s = int(s)
                h = s // 3600
                m = (s % 3600) // 60
                sec = s % 60
                if h > 0:
                    return f"{h:02d}:{m:02d}:{sec:02d}"
                return f"{m:02d}:{sec:02d}"

            time_str = _format_time(resume_time)
            choice = xbmcgui.Dialog().yesno(
                "Pokračovat v přehrávání",
                f"Byl nalezen rozkoukaný bod v čase [COLOR orange]{time_str}[/COLOR].\nChcete pokračovat v přehrávání?",
                yeslabel="Pokračovat",
                nolabel="Od začátku"
            )
            if choice:
                log_debug(f"Uživatel zvolil pokračovat od {resume_time}s")
                xbmcgui.Window(10000).setProperty("webshare_resume_seek", str(resume_time))
                info_tag.setResumePoint(resume_time, total_time)
                list_item.setProperty('ResumeTime', str(resume_time))
                list_item.setProperty('TotalTime', str(total_time))
            else:
                log_debug("Uživatel zvolil přehrát od začátku")
                xbmcgui.Window(10000).clearProperty("webshare_resume_seek")
                info_tag.setResumePoint(0, total_time)
                list_item.setProperty('ResumeTime', '0')
        else:
            xbmcgui.Window(10000).clearProperty("webshare_resume_seek")

        active_meta = {
            'tmdb_id': str(tmdb_id) if tmdb_id else '',
            'media_type': media_type,
            'title': title,
            'season': season_num,
            'episode': episode_num,
            'details': combined_details,
        }
        xbmcgui.Window(10000).setProperty("webshare_active_media", json.dumps(active_meta))
    except Exception as e:
        log_debug(f"Chyba při inicializaci stavu rozkoukání v přehrávači: {e}")

    # 8. Předání připraveného ListItemu Kodi přehrávači
    xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=list_item)
    
def get_webshare_direct_url(file_id, wst_token=""):
    """
    Získá přímý streamovací odkaz z Webshare API.
    
    :param file_id: Identifikátor souboru na Webshare (ident)
    :param wst_token: Uživatelský token získaný při přihlášení (Webshare Token)
    :return: Přímá HTTPS URL pro přehrání
    """
    api_url = "https://webshare.cz/api/file_link/"
    
    # 1. Příprava dat pro POST požadavek
    payload = {
        'ident': file_id,
        'wst': wst_token  # Pro VIP rychlost je nutné předat platný WST token
    }
    
    encoded_data = urllib.parse.urlencode(payload).encode('utf-8')
    
    # 2. Odeslání požadavku na Webshare API
    request = urllib.request.Request(
        url=api_url,
        data=encoded_data,
        headers={'Content-Type': 'application/x-www-form-urlencoded'}
    )
    
    try:
        with urllib.request.urlopen(request) as response:
            res_body = response.read().decode('utf-8')
            
            # Webshare API vrací XML obalené odpovědí, ale samotná data jsou v datastreamu/JSON.
            # Oficiální API endpoint /api/file_link/ vrací XML ve tvaru:
            # <response><status>OK</status><link>https://...</link></response>
            
            # Jednoduché vytažení odkazu z XML tagu <link>:
            import xml.etree.ElementTree as ET
            root = ET.fromstring(res_body)
            
            status = root.findtext('status')
            if status == 'OK':
                return root.findtext('link')
            else:
                message = root.findtext('message', 'Neznámá chyba Webshare API')
                log_debug(f"[Webshare Addon Error] {message}")
                return None

    except Exception as e:
        log_debug(f"[Webshare Addon Error] Selhalo volání API: {e}")
        return None