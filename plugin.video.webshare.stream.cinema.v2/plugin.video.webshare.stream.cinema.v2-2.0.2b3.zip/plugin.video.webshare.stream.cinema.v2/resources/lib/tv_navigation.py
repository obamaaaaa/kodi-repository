def build_season_label(show_title, season, lang=None, is_available=True):
    season_number = season.get('season_number', 0)
    name = season.get('name', '').strip()
    air_date = season.get('air_date', '')[:4] if season.get('air_date') else ''
    episode_count = season.get('episode_count', 0)

    year_text = f" ({air_date})" if air_date else ''
    episode_text = f" • {episode_count} epizod" if episode_count else ''

    if season_number == 0:
        base_title = name if name else "Speciály"
        raw_label = f"{base_title}{year_text}{episode_text}"
    else:
        default_names = [f"sezóna {season_number}", f"season {season_number}", f"řada {season_number}"]
        if not name or name.lower() in default_names:
            raw_label = f"Sezóna {season_number}{year_text}{episode_text}"
        elif name.lower().startswith(f"sezóna {season_number}:"):
            raw_label = f"{name}{year_text}{episode_text}"
        else:
            raw_label = f"Sezóna {season_number}: {name}{year_text}{episode_text}"

    if is_available:
        lang_text = f" • [COLOR lime]{lang}[/COLOR]" if lang and lang != '??' else ''
        return f"{raw_label}{lang_text}"
    else:
        return f"[COLOR gray]{raw_label} (NEDOSTUPNÁ)[/COLOR]"


def build_episode_label(episode, is_available=True, lang=None, is_watched=False):
    episode_number = episode.get('episode_number', 0)
    name = episode.get('name') or f"Díl {episode_number}"

    if is_watched:
        watched_str = " [COLOR lime](Zhlédnuto)[/COLOR]"
        if is_available:
            lang_text = f" • [COLOR lime]{lang}[/COLOR]" if lang and lang != '??' else ''
            return f"[COLOR gray]{episode_number}. {name}[/COLOR]{watched_str}{lang_text}"
        else:
            return f"[COLOR gray]{episode_number}. {name} (NEDOSTUPNÝ)[/COLOR]{watched_str}"

    if is_available:
        lang_text = f" • [COLOR lime]{lang}[/COLOR]" if lang and lang != '??' else ''
        return f"{episode_number}. {name}{lang_text}"
    else:
        return f"[COLOR gray]{episode_number}. {name} (NEDOSTUPNÝ)[/COLOR]"

